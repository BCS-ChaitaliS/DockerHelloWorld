package gov.irs.jios.controller;

import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.SECOND_CALL_FOR_PARTIAL_TAX_CALC;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.irs.jios.common.client.tr.pojo.RetrieveFieldsResponseDTO;
import gov.irs.jios.common.client.tr.service.AuthLocatorService;
import gov.irs.jios.common.client.tr.service.OpenSessionService;
import gov.irs.jios.common.client.tr.service.PingTokenService;
import gov.irs.jios.common.client.tr.service.RetrieveFieldsService;
import gov.irs.jios.common.client.tr.service.SaveFieldsService;
import gov.irs.jios.common.exception.ValidationException;
import gov.irs.jios.common.validation.GenericValidator;
import gov.irs.jios.request.TaxCalculationRequest;
import gov.irs.jios.request.VarianceAnalysisRequest;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@Tag(name = "Variance Analysis", description = "Operations related to variance analysis")
@RequestMapping("/jios-taxcalculator") //TODO /jios/api/v1.0 - should be property driven or if there is any other better way to handle versioning
public class VarianceAnalysisController {
	
	public static final String SBX = "sbx";
	public static final String LOCAL = "local";
	
    private final GenericValidator validator;
    
    @Autowired
    private AuthLocatorService authLocatorService;
    
    @Autowired
    private PingTokenService pingTokenService;
    
    @Autowired
    private OpenSessionService openSessionService;
    
    @Autowired
    private SaveFieldsService saveFieldsService;
    
    @Autowired
    private RetrieveFieldsService retrieveFieldsService;
    
    @Autowired
    private ObjectMapper objectMapper;
   
    @Value("${spring.profiles.active}")
	private String activeProfile;
    
    @Value("${should.make.tr.call:true}")
	private boolean shouldMakeTrCall;

    public VarianceAnalysisController() {
        this.validator = new GenericValidator("validation-rules/variance-analysis-validation-rules.json");
    }
    
    private static final String LINE_SEPARATOR = System.lineSeparator();

    @PostMapping("/api/v1.0/varianceAnalysis")
    public ResponseEntity<?> varianceAnalysis(@RequestBody VarianceAnalysisRequest request) {
        try {
            if (request == null) {
                log.warn("Received null request");
                return ResponseEntity.badRequest().body("Request body is missing");
            }
            
            if (request.getHeader() == null) {
                log.warn("header object is missing in the request");
                return ResponseEntity.badRequest().body("Header object is missing in the request");
            }
            
            String transactionId = (String) request.getHeader().get("transactionId");
            if (transactionId != null) {
            	int lastIndex = transactionId.lastIndexOf("-");
            	if (lastIndex > 0) {
            		MDC.put("requestId", transactionId.substring(lastIndex + 1, transactionId.length()));
            	}
            }
            
            log.debug("Received Variance Analysis Request");
            log.info("Active Profile: {}", activeProfile);
            /*List<String> validationErrors = validator.validate(request);
            if (!validationErrors.isEmpty()) {
                log.warn("Validation errors: {}", validationErrors);
                return ResponseEntity.badRequest().body(validationErrors); //TODO - enable validation back after it is refactored for the latest ECM payload
            }*/
            
            String token = null;
            Map<String, String> authTokenSessionToken = null;
            if (shouldMakeTrCall) {
	            token = LOCAL.equals(activeProfile)  || SBX.equals(activeProfile) ? authLocatorService.getToken() : pingTokenService.getAccessToken();
	            log.info("token: {}", token);
	             
	            String locatorId = authLocatorService.createLocator(request.getHeader(), token);
	            log.info("locatorId: {}", locatorId);
	            
	            authTokenSessionToken = openSessionService.openSession(request.getHeader(), token, locatorId);
	            log.info("authTokenSessionToken: {}", authTokenSessionToken);
            }

            // Log the ECM request payload
        	try {
                String requestJson = objectMapper.writeValueAsString(request);
                log.info("saveFields - Request JSON from ECM: {}{}", LINE_SEPARATOR, requestJson);
            } catch (JsonProcessingException e) {
            	log.error("Error converting ECM Varaince Request payload to JSON", e);
            }

            saveFieldsService.saveFields(request, token, authTokenSessionToken);
            RetrieveFieldsResponseDTO response = retrieveFieldsService.retrieveFields(request, token, authTokenSessionToken);

            log.info("Variance Analysis Completed Successfully");
            HttpHeaders headers = new HttpHeaders();         
            headers.setContentType(MediaType.APPLICATION_JSON);       
            return new ResponseEntity<>(response.getJsonResponse(), headers, HttpStatus.OK);
        }
        catch (ValidationException e) {
            log.error("ValidationException occurred during Variance Analysis", e);
            HttpHeaders headers = new HttpHeaders();         
            headers.setContentType(MediaType.APPLICATION_JSON);       
            return new ResponseEntity<>(e.getMessage(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        catch (Exception e) {
            log.error("Exception occurred during Variance Analysis", e);
            HttpHeaders headers = new HttpHeaders();         
            headers.setContentType(MediaType.APPLICATION_JSON);       
            return new ResponseEntity<>("An unexpected error occurred: " + e.getMessage(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        finally {
            MDC.remove("requestId");
        }
    }
    
    @PostMapping("/api/v1.0/taxCalculation")
    public ResponseEntity<?> taxCalculation(@RequestBody TaxCalculationRequest request) {
        log.debug("Received Tax Calculation Request");
        try {
        	 if (request == null) {
                 log.warn("Received null request");
                 return ResponseEntity.badRequest().body("Request body is missing");
             }
             
             if (request.getHeader() == null) {
                 log.warn("header object is missing in the request");
                 return ResponseEntity.badRequest().body("Header object is missing in the request");
             }
            
            String transactionId = (String) request.getHeader().get("transactionId");
            if (transactionId != null) {
            	int lastIndex = transactionId.lastIndexOf("-");
            	if (lastIndex > 0) {
            		MDC.put("requestId", transactionId.substring(lastIndex + 1, transactionId.length()));
            	}
            }
	    
            log.info("Active Profile: {}", activeProfile);
            /*List<String> validationErrors = validator.validate(request);
            if (!validationErrors.isEmpty()) {
                log.warn("Validation errors: {}", validationErrors);
                return ResponseEntity.badRequest().body(validationErrors); //TODO - enable validation back after it is refactored for the latest ECM payload
            }*/
            
            String token = null;
            Map<String, String> authTokenSessionToken = null;
            if (shouldMakeTrCall) {
	            token = LOCAL.equals(activeProfile)  || SBX.equals(activeProfile) ? authLocatorService.getToken() : pingTokenService.getAccessToken();
	            log.info("token: {}", token);
	            
	            String locatorId = authLocatorService.createLocator(request.getHeader(), token);
	            log.info("locatorId: {}", locatorId);
	            
	            authTokenSessionToken = openSessionService.openSession(request.getHeader(), token, locatorId);
	            log.info("authTokenSessionToken: {}", authTokenSessionToken);
            }

            // Log the ECM request payload
        	try {
                String requestJson = objectMapper.writeValueAsString(request);
                log.info("saveFields - Request JSON from ECM: {}{}", LINE_SEPARATOR, requestJson);
            } catch (JsonProcessingException e) {
            	log.error("Error converting ECM Varaince Request payload to JSON", e);
            }

            saveFieldsService.saveFields(request, token, authTokenSessionToken);
            RetrieveFieldsResponseDTO response = retrieveFieldsService.retrieveFields(request, token, authTokenSessionToken);
            
            String calcTypeTxt = (String)request.getHeader().get(CALC_TYPE_TXT);
            if ("Partial".equals(calcTypeTxt)) {
                // Make the second call for Partial calculation type
            	TaxCalculationRequest secondRequest = createSecondRequest(request, response);
                saveFieldsService.saveFields(secondRequest, token, authTokenSessionToken);
                response = retrieveFieldsService.retrieveFields(secondRequest, token, authTokenSessionToken);
            }

            log.info("Tax Calculation Completed Successfully");
            HttpHeaders headers = new HttpHeaders();         
            headers.setContentType(MediaType.APPLICATION_JSON);       
            return new ResponseEntity<>(response.getJsonResponse(), headers, HttpStatus.OK);
        }
        catch (ValidationException e) {
            log.error("ValidationException occurred during Tax Calculation", e);
            HttpHeaders headers = new HttpHeaders();         
            headers.setContentType(MediaType.APPLICATION_JSON);       
            return new ResponseEntity<>(e.getMessage(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        catch (Exception e) {
            log.error("Exception occurred during Tax Calculation", e);
            HttpHeaders headers = new HttpHeaders();         
            headers.setContentType(MediaType.APPLICATION_JSON);       
            return new ResponseEntity<>("An unexpected error occurred: " + e.getMessage(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        finally {
            MDC.remove("requestId");
        }
    }
    
    private TaxCalculationRequest createSecondRequest(TaxCalculationRequest originalRequest, RetrieveFieldsResponseDTO firstResponse) {
    	TaxCalculationRequest secondRequest = new TaxCalculationRequest();
    	Map<String, Object> headerMap = originalRequest.getHeader();
    	headerMap.put(SECOND_CALL_FOR_PARTIAL_TAX_CALC, true);
        secondRequest.setHeader(headerMap);
        
        // Update the body with the response from the first call
        Map<String, Object> newBody = new HashMap<>(originalRequest.getBody());
        newBody.put("forms", firstResponse.getStructuredResponse().get("forms"));
        secondRequest.setBody(newBody);

        return secondRequest;
    }
}