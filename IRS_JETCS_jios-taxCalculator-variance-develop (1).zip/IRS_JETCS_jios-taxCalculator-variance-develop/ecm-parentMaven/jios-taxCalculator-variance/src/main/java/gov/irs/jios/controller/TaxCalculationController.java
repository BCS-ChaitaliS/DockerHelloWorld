package gov.irs.jios.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gov.irs.jios.common.client.tr.service.AuthLocatorService;
import gov.irs.jios.common.client.tr.service.OpenSessionService;
import gov.irs.jios.common.validation.GenericValidator;
import gov.irs.jios.request.TaxCalculationRequest;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@Tag(name = "Tax Calculation", description = "Operations related to tax calculation")
@RequestMapping("/api/calculation")
public class TaxCalculationController {
    private static final Logger logger = LoggerFactory.getLogger(TaxCalculationController.class);
    private final GenericValidator validator;
    
    @Autowired
    private AuthLocatorService authLocatorService;
    
    @Autowired
    private OpenSessionService openSessionService;

    public TaxCalculationController() {
        this.validator = new GenericValidator("validation-rules/tax-calc-validation-rules.json");
    }

    @PostMapping
    public ResponseEntity<?> taxCalculation(@RequestBody TaxCalculationRequest request) {
        logger.debug("Received calculation request");
        try {
            if (request == null) {
                logger.warn("Received null request");
                return ResponseEntity.badRequest().body("Request body is missing");
            }
            
            String token = authLocatorService.getToken();
            logger.info("token: {}", token);
            
            String locatorId = authLocatorService.createLocator(request.getHeader(), token);
            logger.info("locatorId: {}", locatorId);
            
            Map<String, String> authTokenSessionToken = openSessionService.openSession(request.getHeader(), token, locatorId);
            logger.info("authTokenSessionToken: {}", authTokenSessionToken);

            List<String> validationErrors = validator.validate(request);
            if (!validationErrors.isEmpty()) {
                logger.warn("Validation errors: {}", validationErrors);
                return ResponseEntity.badRequest().body(validationErrors);
            }
            logger.info("Calculation submitted successfully");
            return ResponseEntity.ok("Calculation submitted successfully");
        } catch (Exception e) {
            logger.error("Error processing calculation request", e);
            return ResponseEntity.internalServerError().body("An unexpected error occurred");
        }
    }
}