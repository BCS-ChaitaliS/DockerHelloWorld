# Address Verification Service

## Introduction
The Address Verification Service is designed to validate addresses using the USPS API. It employs a microservice architecture powered by Spring WebFlux, ensuring a highly scalable and robust solution for address verification.

## Prerequisites
- **Java Development Kit (JDK) 17 or higher**
- **Maven 3.9.9 or higher**
- **An IDE (e.g., IntelliJ IDEA, Eclipse)**

- ## Install Dependencies
- **mvn clean install**

- ## Building the Project
- **mvn clean package**

- ## Running the Application
- **mvn spring-boot:run**

- ## Accessing the Application
- **http://localhost:8080**
- **Swagger UI - http://localhost:8080/swagger-ui/index.html#/**

## Version History
### [1.1.1] - 2025-01-09
- Fixed Logging Issues
  - Request Log now shows NA for  eventStatus, errorMsg, statusCode
  - Added Error Log now shows actual errors in log pattern
  - Also now shows enterpriseBusCorrelationId instead of correlationID(passed in body) in logs
### [1.1.0] - 2024-12-13
- Added AddressValidationSpec2.3
- Switched client to OKHttpClient
### [1.0.0]
- Initial release