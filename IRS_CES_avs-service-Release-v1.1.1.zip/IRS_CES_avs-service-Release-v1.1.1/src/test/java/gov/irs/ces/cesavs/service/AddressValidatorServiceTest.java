package gov.irs.ces.cesavs.service;

import gov.irs.ces.cesavs.model.*;
import gov.irs.ces.cesavs.model.request.AddressValidationRequest;
import gov.irs.ces.cesavs.model.request.AuditRequest;
import gov.irs.ces.cesavs.model.response.AddressValidationResponse;
import gov.irs.ces.cesavs.model.response.ErrorResponse;
import gov.irs.ces.cesavs.util.errorhandling.request.AccessTokenFailed;
import gov.irs.ces.cesavs.util.errorhandling.request.EmptyAddresses;
import gov.irs.ces.cesavs.util.errorhandling.request.OverTheLimitAddresses;
import gov.irs.ces.cesavs.util.loggger.ErrorLogPrinter;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;

import java.util.Collections;

import java.util.concurrent.CompletableFuture;


@ExtendWith(MockitoExtension.class)
class AddressValidatorServiceTest {


    @InjectMocks
    private AddressValidatorService addressValidatorService;

    @Mock
    private EmptyAddresses emptyAddresses;

    @Mock
    private AccessTokenFailed accessTokenFailed;

    @Mock
    private OverTheLimitAddresses overTheLimitAddresses;

    @Test
    public void testValidateAddressesTestMode() {
        // Arrange
        AddressValidationRequest request = new AddressValidationRequest();
        Address address1 = new Address("0", null, null, "123 Main St", "", "Apple Valley", "MI", "", "12345", "678", "");
        Address address2 = new Address("1", null, null, "456 Main St", "", "Lakeville", "WI", "", "54321", "000", "");
        request.setAddresses(Arrays.asList(address1, address2));

        System.out.println(request);
        System.out.println(request.getAddresses());
        // Act
        CompletableFuture<ResponseEntity> responseFuture = addressValidatorService.validateAddressesTestMode(request);
        System.out.println(responseFuture);

        ResponseEntity responseEntity = responseFuture.join();

        // Assert
        assertNotNull(responseEntity);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        AddressValidationResponse responseBody = (AddressValidationResponse) responseEntity.getBody();
        assertNotNull(responseBody);
        assertEquals(2, responseBody.getFoundAddresses().size());
        assertEquals("123 Main St", address1.getAddressLine1());

    }

/*
    @Test
    public void testValidateAddresses_EmptyAddresses() {
        // Arrange
        AddressValidationRequest request = new AddressValidationRequest();
        request.setAddresses(Collections.emptyList());
        AuditRequest auditRequest = new AuditRequest();
        request.setAuditRequest(auditRequest);

        ErrorResponse errorResponse = new ErrorResponse();
        doNothing().when(emptyAddresses).handleEmptyAddresses(any(ErrorResponse.class));

        // Act
        CompletableFuture<ResponseEntity> responseFuture = addressValidatorService.validateAddresses(request, "corrId");
        ResponseEntity responseEntity = responseFuture.join();

        // Assert
        assertNotNull(responseEntity);
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
    }

    @Test
    public void testValidateAddresses_OverTheLimit() {

        AddressValidationRequest request = new AddressValidationRequest();
        AuditRequest auditRequest = new AuditRequest();
        auditRequest.setRequestId("aId");
        auditRequest.setSystemId("sId");
        auditRequest.setTransactionId("tId");
        auditRequest.setCorrelationId("cId");
        request.setAuditRequest(auditRequest);
        request.setAddresses(Collections.emptyList());
        Address address1 = new Address("0", null, null, "123 Main St", "", "Apple Valley", "MI", "", "12345", "678", "");
        Address address2 = new Address("1", null, null, "456 Main St", "", "Lakeville", "WI", "", "54321", "000", "");
        request.setAddresses(Arrays.asList(address1, address2));

        ErrorResponse errorResponse = new ErrorResponse();

        doNothing().when(overTheLimitAddresses).handleOverLimitAddresses(any(ErrorResponse.class), eq(0));

        // Act
        CompletableFuture<ResponseEntity> responseFuture = addressValidatorService.validateAddresses(request, "corrId");
        ResponseEntity responseEntity = responseFuture.join();

        // Assert
        assertNotNull(responseEntity);
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
    }
*/

}

