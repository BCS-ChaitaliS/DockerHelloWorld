package gov.irs.ces.cesavs.utils;

import gov.irs.ces.cesavs.model.Address;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class TestUtils {

    public static List<Address> loadAddressesFromInputFile() throws IOException {
        List<Address> addresses = new ArrayList<>();
        Resource resource = new ClassPathResource("address.in");

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(resource.getInputStream()))) {
            String line;
            int addressIdCounter = 1;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 5) {
                    Address addressFromInputFile = new Address();
                    addressFromInputFile.setAddressId(parts[0].trim());
                    addressFromInputFile.setAddressLine1(parts[1].trim());
                    addressFromInputFile.setAddressLine2(parts[2].trim());
                    addressFromInputFile.setCity(parts[3].trim());
                    addressFromInputFile.setState(parts[4].trim());
                    addressFromInputFile.setZip(parts[5].trim());

                    addresses.add(addressFromInputFile);
                } else {
                    System.out.println("Invalid address format: " + line);
                }
            }
        }

        return addresses;
    }

    public static List<String> loadExpectedOutputFile(String outputfile) throws IOException {
        List<String> outputLines = new ArrayList<>();
        Resource resource = new ClassPathResource(outputfile);

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(resource.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                outputLines.add(line.trim());
            }
        }
        return outputLines;
    }

}