package gov.irs.ces.cesavs.utils;


/**
 * Author: Naveen Reddy
 * Date:12/9/2024
 * Time:3:27 PM
 */

import gov.irs.ces.cesavs.constant.UspsHttpStatusCodes;
import gov.irs.ces.cesavs.model.response.ErrorResponse;
import gov.irs.ces.cesavs.util.errorhandling.request.EmptyAddresses;
import gov.irs.ces.cesavs.util.loggger.LoggerTimeStamp;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static gov.irs.ces.cesavs.constant.AVSErrorMessages.NO_ADDRESS_PROVIDED_IN_REQUEST;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mockStatic;

@ExtendWith(MockitoExtension.class)
public class EmptyAddressesTest {

    @InjectMocks
    private EmptyAddresses emptyAddresses;

    private ErrorResponse errorResponse;

    @BeforeEach
    public void setUp() {
        errorResponse = new ErrorResponse();
    }

    @Test
    public void testHandleEmptyAddresses() {
        String expectedTimestamp = "2024-12-09T15:23:36";

        try (var mockedLoggerTimeStamp = mockStatic(LoggerTimeStamp.class)) {
            mockedLoggerTimeStamp.when(LoggerTimeStamp::generateTimeStamp).thenReturn(expectedTimestamp);

            emptyAddresses.handleEmptyAddresses(errorResponse);

            assertEquals(String.valueOf(UspsHttpStatusCodes.BAD_REQUEST), errorResponse.getErrorCode());
            assertEquals(NO_ADDRESS_PROVIDED_IN_REQUEST, errorResponse.getErrorMessage());
            assertEquals(expectedTimestamp, errorResponse.getTimestamp());
            assertEquals(null, errorResponse.getErrorTraceId());
            assertEquals(null, errorResponse.getDetails());
        }
    }
}