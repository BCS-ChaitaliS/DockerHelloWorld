package gov.irs.ces.cesavs.utils;


/**
 * Author: Naveen Reddy
 * Date:12/9/2024
 * Time:3:28 PM
 */

import gov.irs.ces.cesavs.model.response.ErrorResponse;
import gov.irs.ces.cesavs.util.errorhandling.request.AccessTokenFailed;
import gov.irs.ces.cesavs.util.loggger.LoggerTimeStamp;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static gov.irs.ces.cesavs.constant.AVSErrorMessages.COMMON_ERROR_MSG;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mockStatic;


@ExtendWith(MockitoExtension.class)
public class AccessTokenFailedTest {

    @InjectMocks
    private AccessTokenFailed accessTokenFailed;

    private ErrorResponse errorResponse;

    @BeforeEach
    public void setUp() {
        errorResponse = new ErrorResponse();
    }

    @Test
    public void testHandleAccessToken() {
        String expectedTimestamp = "2024-12-09T15:23:36";

        try (var mockedLoggerTimeStamp = mockStatic(LoggerTimeStamp.class)) {
            mockedLoggerTimeStamp.when(LoggerTimeStamp::generateTimeStamp).thenReturn(expectedTimestamp);

            accessTokenFailed.handleAccessToken(errorResponse);

            assertEquals("", errorResponse.getDetails());
            assertEquals("400", errorResponse.getErrorCode());
            assertEquals(COMMON_ERROR_MSG, errorResponse.getErrorMessage());
            assertEquals(expectedTimestamp, errorResponse.getTimestamp());
            assertEquals("", errorResponse.getErrorTraceId());
        }
    }
}