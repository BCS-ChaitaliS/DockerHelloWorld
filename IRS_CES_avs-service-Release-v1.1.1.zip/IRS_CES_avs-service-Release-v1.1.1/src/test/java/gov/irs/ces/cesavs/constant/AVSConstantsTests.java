package gov.irs.ces.cesavs.constant;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AVSConstantsTests {

    @Test
    public void testAddressConstants() {
        assertEquals("address", AVSConstants.ADDRESS);
        assertEquals("streetAddress", AVSConstants.STREET_ADDRESS);
        assertEquals("secondaryAddress", AVSConstants.SECONDARY_ADDRESS);
        assertEquals("city", AVSConstants.CITY);
        assertEquals("state", AVSConstants.STATE);
        assertEquals("ZIPCode", AVSConstants.ZIP_CODE);
    }

    @Test
    public void testAuthorizationAVSConstants() {
        assertEquals("Authorization", AVSConstants.AUTHORIZATION);
        assertEquals("Bearer ", AVSConstants.BEARER); // Note the space after "Bearer"
    }

    @Test
    public void testErrorAVSConstants() {
        assertEquals("error", AVSConstants.ERROR);
        assertEquals("message", AVSConstants.MESSAGE);
        assertEquals("code", AVSConstants.CODE);
        assertEquals("systemMessage", AVSConstants.SYSTEM_MESSGAE);  // Check spelling of "MESSGAE"
    }

    @Test
    public void testOAuthConstants() {
        assertEquals("grant_type", AVSConstants.GRANT_TYPE);
        assertEquals("client_credentials", AVSConstants.CLIENT_CREDENTIALS);
        assertEquals("client_id", AVSConstants.CLIENT_ID);
        assertEquals("client_secret", AVSConstants.CLIENT_SECRET);
        assertEquals("scope", AVSConstants.SCOPE);
        assertEquals("addresses", AVSConstants.ADDRESSES);
    }

    @Test
    public void testContentTypeConstants() {
        assertEquals("Content-Type", AVSConstants.CONTENT_TYPE);
        assertEquals("application/x-www-form-urlencoded", AVSConstants.CONTENT_TYPE_VALUE);
    }

    @Test
    public void testAccessTokenConstants() {
        assertEquals("access_token", AVSConstants.ACCESS_TOKEN);
        assertEquals("expires_in", AVSConstants.EXPIRES_IN);
    }

    @Test
    public void testAddressAdditionalInfoConstants() {
        assertEquals("additionalInfo", AVSConstants.ADDITIONAL_INFO);
        assertEquals("deliveryPoint", AVSConstants.DELIVERY_POINT);
        assertEquals("carrierRoute", AVSConstants.CARRIER_ROUTE);
        assertEquals("DPVConfirmation", AVSConstants.DPV_CONFIRMATION);
        assertEquals("DPVCMRA", AVSConstants.DPV_CMRA);
        assertEquals("business", AVSConstants.BUSINESS);
        assertEquals("centralDeliveryPoint", AVSConstants.CENTRAL_DELIVERY_POINT);
        assertEquals("vacant", AVSConstants.VACANT);
    }

}