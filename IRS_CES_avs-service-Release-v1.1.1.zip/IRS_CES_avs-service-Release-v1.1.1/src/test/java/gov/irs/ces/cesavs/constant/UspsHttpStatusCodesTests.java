package gov.irs.ces.cesavs.constant;


import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Author: Naveen Reddy
 * Date:11/20/2024
 * Time:4:01 PM
 */

public class UspsHttpStatusCodesTests {

    @Test
    public void testUspsHttpStatusCodes() {
        assertEquals(200, UspsHttpStatusCodes.OK);
        assertEquals(400, UspsHttpStatusCodes.BAD_REQUEST);
        assertEquals(401, UspsHttpStatusCodes.UNAUTHORIZED);
        assertEquals(403, UspsHttpStatusCodes.FORBIDDEN);
        assertEquals(404, UspsHttpStatusCodes.NOT_FOUND);
        assertEquals(429, UspsHttpStatusCodes.TOO_MANY_REQUESTS);
        assertEquals(503, UspsHttpStatusCodes.SERVICE_UNAVAILABLE);

    }
}
