package gov.irs.ces.cesavs.utils;


/**
 * Author: Naveen Reddy
 * Date:12/9/2024
 * Time:3:24 PM
 */

import gov.irs.ces.cesavs.constant.UspsHttpStatusCodes;
import gov.irs.ces.cesavs.model.response.ErrorResponse;
import gov.irs.ces.cesavs.util.errorhandling.request.OverTheLimitAddresses;
import gov.irs.ces.cesavs.util.loggger.LoggerTimeStamp;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static gov.irs.ces.cesavs.constant.AVSErrorMessages.T00_MANY_ADDRESSES_IN_REQUEST;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mockStatic;

@ExtendWith(MockitoExtension.class)
public class OverTheLimitAddressesTest {

    @InjectMocks
    private OverTheLimitAddresses overTheLimitAddresses;

    private ErrorResponse errorResponse;

    @BeforeEach
    public void setUp() {
        errorResponse = new ErrorResponse();
    }

    @Test
    public void testHandleOverLimitAddresses() {
        int addressLimit = 5;
        String expectedTimestamp = "2024-12-09T15:23:36";

        try (var mockedLoggerTimeStamp = mockStatic(LoggerTimeStamp.class)) {
            mockedLoggerTimeStamp.when(LoggerTimeStamp::generateTimeStamp).thenReturn(expectedTimestamp);

            overTheLimitAddresses.handleOverLimitAddresses(errorResponse, addressLimit);

            assertEquals(String.valueOf(UspsHttpStatusCodes.BAD_REQUEST), errorResponse.getErrorCode());
            assertEquals(T00_MANY_ADDRESSES_IN_REQUEST + addressLimit, errorResponse.getErrorMessage());
            assertEquals(expectedTimestamp, errorResponse.getTimestamp());
            assertNull(errorResponse.getErrorTraceId());
            assertNull(errorResponse.getDetails());
        }
    }
}