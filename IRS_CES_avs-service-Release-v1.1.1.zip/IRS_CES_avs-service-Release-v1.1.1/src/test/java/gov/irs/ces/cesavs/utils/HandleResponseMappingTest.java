package gov.irs.ces.cesavs.utils;


/**
 * Author: Naveen Reddy
 * Date:12/9/2024
 * Time:3:30 PM
 */

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import gov.irs.ces.cesavs.model.Address;
import gov.irs.ces.cesavs.model.response.AddressFoundResponse;
import gov.irs.ces.cesavs.model.response.AddressNotFoundResponse;
import gov.irs.ces.cesavs.util.errorhandling.response.HandleResponseMapping;
import gov.irs.ces.cesavs.util.loggger.LogPrinter;
import gov.irs.ces.cesavs.util.loggger.LoggerTimeStamp;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class HandleResponseMappingTest {

    @Mock
    private LogPrinter logPrinter;

    @Captor
    private ArgumentCaptor<String> logCaptor;

    @InjectMocks
    private HandleResponseMapping handleResponseMapping;

    private Address address;
    private String responseBody;
    private String seId;
    private String sessionId;
    private String addressId;
    private String correlationId;
    private int clientResponseStatusCode;

    @BeforeEach
    public void setUp() {
        address = new Address();
        address.setAddressLine1("123 Main St");
        address.setAddressLine2("Apt 4");
        address.setCity("Anytown");
        address.setState("CA");
        address.setZip("12345");
        address.setZipPlus4("6789");
        address.setCountry("USA");
        address.setUrbanization("Urban");

        responseBody = "{ \"address\": { \"streetAddress\": \"123 Main St\", \"secondaryAddress\": \"Apt 4\", \"city\": \"Anytown\", \"state\": \"CA\", \"zip\": \"12345\", \"zipCodePlus4\": \"6789\", \"country\": \"USA\", \"streetAddressAbbr\": \"Main St\", \"cityAbbr\": \"Any\", \"urbanization\": \"Urban\" }, \"additionalInfo\": { \"deliveryPoint\": \"DP\", \"carrierRoute\": \"CR\", \"dpvConfirmation\": \"Y\", \"dpvCMRA\": \"N\", \"business\": \"N\", \"centralDeliveryPoint\": \"N\", \"vacant\": \"N\" } }";
        seId = "seId";
        sessionId = "sessionId";
        addressId = "addressId";
        correlationId = "correlationId";
        clientResponseStatusCode = 200;
    }

    @Test
    public void testHandleFoundResponse() throws JsonProcessingException {
        String expectedTimestamp = "2024-12-09T15:23:36";

        try (var mockedLoggerTimeStamp = mockStatic(LoggerTimeStamp.class)) {
            mockedLoggerTimeStamp.when(LoggerTimeStamp::generateTimeStamp).thenReturn(expectedTimestamp);

            AddressFoundResponse response = HandleResponseMapping.handleFoundResponse(responseBody, seId, sessionId, addressId, correlationId, clientResponseStatusCode, address);

            assertEquals("123 Main St", response.getAddressLine1());
            assertEquals("Apt 4", response.getAddressLine2());
            assertEquals("Anytown", response.getCity());
            assertEquals("CA", response.getState());

        }
    }

    @Test
    public void testHandleNotFoundAddressResponse() throws JsonProcessingException {
        String expectedTimestamp = "2024-12-09T15:23:36";
        String errorResponseBody = "{ \"error\": { \"code\": \"404\", \"message\": \"Address not found\" } }";

        try (var mockedLoggerTimeStamp = mockStatic(LoggerTimeStamp.class)) {
            mockedLoggerTimeStamp.when(LoggerTimeStamp::generateTimeStamp).thenReturn(expectedTimestamp);

            AddressNotFoundResponse response = HandleResponseMapping.handleNotFoundAddressResponse(errorResponseBody, seId, sessionId, addressId, correlationId, clientResponseStatusCode, address);

            assertEquals("123 Main St", response.getAddressLine1());
            assertEquals("Apt 4", response.getAddressLine2());
            assertEquals("Anytown", response.getCity());
            assertEquals("CA", response.getState());
            assertEquals("12345", response.getZip());
            assertEquals("6789", response.getZipPlus4());
            assertEquals("Urban", response.getUrbanization());
            assertEquals("404", response.getErrorCode());
            assertEquals("Address not found", response.getErrorMessage());

        }
    }
}