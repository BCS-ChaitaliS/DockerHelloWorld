package gov.irs.ces.cesavs.utils;


/**
 * Author: Naveen Reddy
 * Date:12/9/2024
 * Time:3:41 PM
 */

import gov.irs.ces.cesavs.config.OkHttpConfig;
import okhttp3.OkHttpClient;
import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import static org.junit.jupiter.api.Assertions.assertNotNull;

class OkHttpConfigTest {

    @Test
    void testOkHttpClientBean() {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(OkHttpConfig.class);
        OkHttpClient okHttpClient = context.getBean(OkHttpClient.class);
        assertNotNull(okHttpClient, "The OkHttpClient bean should not be null");
        context.close();
    }
}