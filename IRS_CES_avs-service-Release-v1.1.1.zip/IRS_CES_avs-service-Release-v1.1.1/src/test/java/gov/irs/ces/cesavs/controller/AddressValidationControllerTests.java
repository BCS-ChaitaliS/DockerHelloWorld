package gov.irs.ces.cesavs.controller;


/**
 * Author: Naveen Reddy
 * Date:12/11/2024
 * Time:10:52 AM
 */

import gov.irs.ces.cesavs.model.Address;
import gov.irs.ces.cesavs.model.request.AddressValidationRequest;
import gov.irs.ces.cesavs.model.response.AddressValidationResponse;
import gov.irs.ces.cesavs.service.AddressValidatorService;
import gov.irs.ces.cesavs.util.AuthTokenService;
import gov.irs.ces.cesavs.util.loggger.RequestLogPrinter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class AddressValidationControllerTest {

    @InjectMocks
    private AddressValidationController addressValidationController;

    @Mock
    private AddressValidatorService addressValidatorService;

    @Mock
    private RequestLogPrinter requestLogPrinter;

    @Mock
    private AuthTokenService authTokenService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testValidateAddress_TestModeEnabled() throws NoSuchFieldException, IllegalAccessException {
        // Set up test mode
        String testMode = "true";
        ReflectionTestUtils.setField(addressValidationController, "apiTestMode", testMode);

        // Mock the Address object
        Address mockAddress1 = mock(Address.class);
        Address mockAddress2 = mock(Address.class);

        // Define behavior for mock methods
        when(mockAddress1.getAddressId()).thenReturn("1");
        when(mockAddress1.getFullAddress()).thenReturn("Mocked Address 1");
        when(mockAddress1.getCity()).thenReturn("MockCity1");

        when(mockAddress2.getAddressId()).thenReturn("2");
        when(mockAddress2.getFullAddress()).thenReturn("Mocked Address 2");
        when(mockAddress2.getCity()).thenReturn("MockCity2");

        // Create AddressValidationRequest with mocked Address objects
        AddressValidationRequest request = new AddressValidationRequest();
        request.setAddresses(List.of(mockAddress1, mockAddress2));

        // Mock service behavior
        CompletableFuture<ResponseEntity> mockResponse = CompletableFuture.completedFuture(ResponseEntity.ok(new AddressValidationResponse()));
        when(addressValidatorService.validateAddressesTestMode(any(AddressValidationRequest.class))).thenReturn(mockResponse);

        // Call the method
        CompletableFuture<ResponseEntity> response = addressValidationController.validateAddress("correlationId", request);

        // Verify interactions and response
        verify(addressValidatorService, times(1)).validateAddressesTestMode(request);
        verifyNoInteractions(requestLogPrinter);
        assertEquals(mockResponse, response);

    }


    @Test
    void testValidateAddress_InvalidRequest() {
        // Mock the production mode
        String testMode = "false";
        ReflectionTestUtils.setField(addressValidationController, "apiTestMode", testMode);

        // Prepare input data with an empty list
        AddressValidationRequest request = new AddressValidationRequest();
        request.setAddresses(List.of());

        // Call the method
        CompletableFuture<ResponseEntity> response = addressValidationController.validateAddress("correlationId", request);

        // Verify the behavior
        verify(requestLogPrinter, times(1)).printRequest(request, "correlationId"); // Request log should still be printed
        verify(addressValidatorService, times(1)).validateAddresses(request, "correlationId"); // Validation should be called
    }
}