package gov.irs.ces.cesavs.model.request;

import gov.irs.ces.cesavs.model.Address;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.stereotype.Component;

import java.util.List;


@Component
@Schema(description = "AddressValidationRequest")
public class AddressValidationRequest {

    @Schema
    private AuditRequest auditRequest;
    @Schema
    private String status;
    @Schema
    private List<Address> addresses;

    public AuditRequest getAuditRequest() {
        return auditRequest;
    }

    public void setAuditRequest(AuditRequest auditRequest) {
        this.auditRequest = auditRequest;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<Address> getAddresses() {
        return addresses;
    }

    public void setAddresses(List<Address> addresses) {
        this.addresses = addresses;
    }

    @Override
    public String toString() {
        return "AddressValidationRequest{" +
                "auditRequest=" + auditRequest +
                ", status='" + status + '\'' +
                ", addresses=" + addresses +
                '}';
    }
}
