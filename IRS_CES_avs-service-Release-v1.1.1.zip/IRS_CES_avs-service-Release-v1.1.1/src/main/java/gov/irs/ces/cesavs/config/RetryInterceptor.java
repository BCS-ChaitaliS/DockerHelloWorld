package gov.irs.ces.cesavs.config;


import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;

/**
 * Author: Naveen Reddy
 * Date:12/6/2024
 * Time:12:50 PM
 */
public class RetryInterceptor implements Interceptor {
    private int maxRetries;
    private long retryDelay;

    public RetryInterceptor(int maxRetries, long retryDelay) {
        this.maxRetries = maxRetries;
        this.retryDelay = retryDelay;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request request = chain.request();
        Response response = null;
        IOException exception = null;
        int attempt = 0;

        while (attempt < maxRetries) {
            try {
                if (response != null)
                    response.close();
                response = chain.proceed(request);
                if (response.isSuccessful()) {
                    return response;
                }
            } catch (IOException e) {
                exception = e;
            }

            attempt++;
            try {
                Thread.sleep(retryDelay);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IOException("Retry interrupted", e);
            }
        }

        if (exception != null) {
            throw exception;
        }

        assert response != null;
        return response;
    }
}
