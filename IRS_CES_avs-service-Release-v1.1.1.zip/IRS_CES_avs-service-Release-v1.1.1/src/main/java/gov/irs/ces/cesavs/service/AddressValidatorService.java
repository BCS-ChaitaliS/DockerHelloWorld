package gov.irs.ces.cesavs.service;


import gov.irs.ces.cesavs.config.RetryInterceptor;
import gov.irs.ces.cesavs.constant.UspsHttpStatusCodes;
import gov.irs.ces.cesavs.model.Address;
import gov.irs.ces.cesavs.model.request.AddressValidationRequest;
import gov.irs.ces.cesavs.model.response.AddressFoundResponse;
import gov.irs.ces.cesavs.model.response.AddressNotFoundResponse;
import gov.irs.ces.cesavs.model.response.AddressValidationResponse;
import gov.irs.ces.cesavs.model.response.ErrorResponse;
import gov.irs.ces.cesavs.util.AuthTokenService;
import gov.irs.ces.cesavs.util.errorhandling.request.AccessTokenFailed;
import gov.irs.ces.cesavs.util.errorhandling.request.EmptyAddresses;
import gov.irs.ces.cesavs.util.errorhandling.request.EnterpriseBusCorrelationIdFailure;
import gov.irs.ces.cesavs.util.errorhandling.request.OverTheLimitAddresses;
import gov.irs.ces.cesavs.util.errorhandling.response.HandleResponseMapping;
import gov.irs.ces.cesavs.util.loggger.ErrorLogPrinter;
import jakarta.annotation.PostConstruct;
import okhttp3.*;
import org.jboss.logging.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import static gov.irs.ces.cesavs.constant.AVSConstants.*;
import static gov.irs.ces.cesavs.constant.AVSErrorMessages.COMMON_ERROR_MSG;

/**
 * Author: Naveen Reddy
 * Date:11/29/2024
 * Time:10:18 AM
 */


@Service
public class AddressValidatorService {

    private static final Logger logger = Logger.getLogger(AddressValidatorService.class);
    private final AuthTokenService authTokenService;
    private final HandleResponseMapping handleResponseMapping;
    private final EmptyAddresses emptyAddresses;
    private final OverTheLimitAddresses overTheLimitAddresses;
    private final AccessTokenFailed accessTokenFailed;
    private final EnterpriseBusCorrelationIdFailure enterpriseBusCorrelationIdFailure;
    private final ErrorLogPrinter errorLogPrinter;

    @Value("${api.addressLimit}")
    private int addressLimit;

    @Value(("${api.address.maxRetryAttempts}"))
    private int maxRetryAttempts;

    @Value(("${api.address.retryDelayInSec}"))
    private int retryDelayInSec;

    @Value(("${api.address.jitterFactor}"))
    private String jitterFactor;

    @Value(("${api.address.connectTimeOut}"))
    private String timeOut;

    @Value("${usps.url.api.address}")
    private String addressApiUrl;

    @Autowired
    public AddressValidatorService(AuthTokenService authTokenService, HandleResponseMapping handleResponseMapping, EmptyAddresses emptyAddresses, OverTheLimitAddresses overTheLimitAddresses, AccessTokenFailed accessTokenFailed, EnterpriseBusCorrelationIdFailure enterpriseBusCorrelationIdFailure, ErrorLogPrinter errorLogPrinter) {
        this.authTokenService = authTokenService;
        this.handleResponseMapping = handleResponseMapping;
        this.emptyAddresses = emptyAddresses;
        this.overTheLimitAddresses = overTheLimitAddresses;
        this.accessTokenFailed = accessTokenFailed;
        this.enterpriseBusCorrelationIdFailure = enterpriseBusCorrelationIdFailure;
        this.errorLogPrinter = errorLogPrinter;
    }

    @PostConstruct
    public void init() {
        logger.info("Address limit: " + addressLimit);
    }


    public CompletableFuture<ResponseEntity> validateAddressesTestMode(AddressValidationRequest addressValidationRequest) {

        AddressValidationResponse addressValidationResponse = new AddressValidationResponse();
        List<AddressFoundResponse> addressFoundResponseList = new ArrayList<>();
        List<Address> addresses = addressValidationRequest.getAddresses();
        List<CompletableFuture<Void>> futures = new ArrayList<>();

        for (Address address : addresses) {
            CompletableFuture<Void> future = CompletableFuture.runAsync(() -> {
                AddressFoundResponse addressFoundResponse = new AddressFoundResponse();
                BeanUtils.copyProperties(address, addressFoundResponse);
                synchronized (addressFoundResponseList) {
                    addressFoundResponseList.add(addressFoundResponse);
                }
            });
            futures.add(future);
        }

        addressValidationResponse.setFoundAddresses(addressFoundResponseList);
        logger.info("Successfully Processed Addresses in Test Mode : 200 : OK");

        return CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]))
                .thenApply(v -> new ResponseEntity<>(addressValidationResponse, HttpStatus.OK));
    }


    public CompletableFuture<ResponseEntity> validateAddresses(AddressValidationRequest addressValidationRequest, String enterpriseBusCorrelationId) {

        String correlationId = addressValidationRequest.getAuditRequest().getCorrelationId();
        String seId = addressValidationRequest.getAuditRequest().getSeid();
        String sessionId = addressValidationRequest.getAuditRequest().getTransactionId();

        List<Address> addresses = addressValidationRequest.getAddresses();
        ErrorResponse errorResponse = new ErrorResponse();

        AtomicReference<String> clientStatusCode = new AtomicReference<>("");

        if (enterpriseBusCorrelationId.trim().isEmpty()) {
            enterpriseBusCorrelationIdFailure.handleEnterpriseBusCorrelationIdFailure(errorResponse);
            logger.error("The required parameter 'EnterpriseBusCorrelationId' is missing from the request.");
            errorLogPrinter.printRequest(enterpriseBusCorrelationId, "The required parameter 'EnterpriseBusCorrelationId' is missing from the request.", NOT_APPLICABLE);
            return CompletableFuture.completedFuture(new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST));
        } else if (addresses.isEmpty()) {
            emptyAddresses.handleEmptyAddresses(errorResponse);
            logger.info("Addresses provided in the request : " + addressValidationRequest.getAddresses().size());
            logger.error("No Addresses are provided in the request");
            errorLogPrinter.printRequest(enterpriseBusCorrelationId, "No Addresses are provided in the request", NOT_APPLICABLE);
            return CompletableFuture.completedFuture(new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST));
        } else if (addresses.size() > addressLimit) {
            overTheLimitAddresses.handleOverLimitAddresses(errorResponse, addressLimit);
            logger.info("Addresses provided in the request : " + addressValidationRequest.getAddresses().size());
            logger.error("Addresses provided in the request are more than the limit");
            errorLogPrinter.printRequest(enterpriseBusCorrelationId, "Address provided in the request are more than the limit", NOT_APPLICABLE);
            return CompletableFuture.completedFuture(new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST));

        }


        String authToken = "";
        try {
            logger.info("validate accessToken");
            authToken = authTokenService.getAccessToken();
        } catch (Exception e) {
            logger.error("Failed to fetch the accessToken : ");
            accessTokenFailed.handleAccessToken(errorResponse);
            errorLogPrinter.printRequest(enterpriseBusCorrelationId, e.getMessage(), NOT_APPLICABLE);
            return CompletableFuture.completedFuture(new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST));
        }

        AddressValidationResponse addressValidationResponse = new AddressValidationResponse();
        List<AddressFoundResponse> foundAddresses = new ArrayList<>();
        List<AddressNotFoundResponse> notFoundAddresses = new ArrayList<>();

        String finalAuthToken = authToken;
        logger.info("Response loggers");
        try {
            OkHttpClient client = new OkHttpClient.Builder()
                    .connectTimeout(Long.parseLong(timeOut), TimeUnit.SECONDS)
                    .addInterceptor(new RetryInterceptor(maxRetryAttempts, retryDelayInSec))
                    .build();
            List<CompletableFuture<Void>> futures = new ArrayList<>();

            for (Address address : addresses) {
                try {
                    CompletableFuture<Void> future = new CompletableFuture<>();
                    futures.add(future);

                    String addressId = address.getAddressId();
                    String addressLine1 = address.getAddressLine1();
                    String addressLine2 = address.getAddressLine2();
                    String city = address.getCity();
                    String state = address.getState();
                    String zip = (address.getZip() == null || address.getZip().isEmpty()) ? null : address.getZip();

                    HttpUrl.Builder urlBuilder = Objects.requireNonNull(HttpUrl.parse(addressApiUrl)).newBuilder()
                            .addQueryParameter(STREET_ADDRESS, addressLine1)
                            .addQueryParameter(SECONDARY_ADDRESS, addressLine2)
                            .addQueryParameter(CITY, city)
                            .addQueryParameter(STATE, state)
                            .addQueryParameter(ZIP_CODE, zip);

                    Request request = new Request.Builder()
                            .url(urlBuilder.build())
                            .addHeader(AUTHORIZATION, BEARER + finalAuthToken)
                            .build();

                    client.newCall(request).enqueue(new Callback() {
                        @Override
                        public void onFailure(Call call, IOException e) {
                            logger.error("Request failed: " + e.getMessage());
                            errorLogPrinter.printRequest(enterpriseBusCorrelationId, e.getMessage(), NOT_APPLICABLE);
                            future.completeExceptionally(e);
                        }

                        @Override
                        public void onResponse(Call call, Response response) throws IOException {
                            try (ResponseBody responseBody = response.body()) {
                                if (response.isSuccessful()) {
                                    clientStatusCode.set(String.valueOf(response.code()));
                                    String responseBodyString = responseBody.string();
                                    AddressFoundResponse foundAddress = HandleResponseMapping.handleFoundResponse(responseBodyString, seId, sessionId, addressId, enterpriseBusCorrelationId, response.code(), address);
                                    foundAddresses.add(foundAddress);
                                } else if (response.code() == 400) {
                                    clientStatusCode.set(String.valueOf(response.code()));
                                    String responseBodyString = responseBody.string();
                                    AddressNotFoundResponse notFoundAddress = HandleResponseMapping.handleNotFoundAddressResponse(responseBodyString, seId, sessionId, addressId, enterpriseBusCorrelationId, response.code(), address);
                                    notFoundAddresses.add(notFoundAddress);
                                } else {
                                    logger.error("USPS Response Error Code: " + response.code());
                                    clientStatusCode.set(String.valueOf(response.code()));
                                    errorResponse.setErrorMessage(COMMON_ERROR_MSG);
                                    errorResponse.setErrorCode(String.valueOf(UspsHttpStatusCodes.BAD_REQUEST));
                                    String errorMessage = responseBody.string();
                                    logger.error("USPS Response Error Message: " + errorMessage);
                                    errorLogPrinter.printRequest(enterpriseBusCorrelationId, errorMessage, String.valueOf(response.code()));
                                }
                            } finally {
                                future.complete(null);
                            }
                        }
                    });
                } catch (Exception e) {
                    errorLogPrinter.printRequest(enterpriseBusCorrelationId, e.getMessage(), NOT_APPLICABLE);
                }
            }
            return CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]))
                .thenApply(v -> {
                    if (clientStatusCode.get().equals("200")) {
                        addressValidationResponse.setFoundAddresses(foundAddresses);
                        addressValidationResponse.setNotFoundAddresses(notFoundAddresses);
                        return new ResponseEntity<>(addressValidationResponse, HttpStatus.OK);
                    }
                    else if (clientStatusCode.get().equals("400")) {
                        addressValidationResponse.setFoundAddresses(foundAddresses);
                        addressValidationResponse.setNotFoundAddresses(notFoundAddresses);
                        return new ResponseEntity<>(addressValidationResponse, HttpStatus.BAD_REQUEST);
                    }
                    else {
                        errorLogPrinter.printRequest(enterpriseBusCorrelationId, errorResponse.getErrorMessage(), errorResponse.getErrorCode());
                        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
                    }
                });
        } catch (Exception e) {
            errorLogPrinter.printRequest(enterpriseBusCorrelationId, e.getMessage(), NOT_APPLICABLE);
            return CompletableFuture.completedFuture(new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST));
        }
    }
}



