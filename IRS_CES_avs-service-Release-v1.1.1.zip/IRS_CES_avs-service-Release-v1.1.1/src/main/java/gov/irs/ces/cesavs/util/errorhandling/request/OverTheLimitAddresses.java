package gov.irs.ces.cesavs.util.errorhandling.request;


import gov.irs.ces.cesavs.constant.UspsHttpStatusCodes;
import gov.irs.ces.cesavs.model.response.ErrorResponse;
import gov.irs.ces.cesavs.util.loggger.LoggerTimeStamp;
import org.springframework.stereotype.Component;

import static gov.irs.ces.cesavs.constant.AVSConstants.*;
import static gov.irs.ces.cesavs.constant.AVSErrorMessages.T00_MANY_ADDRESSES_IN_REQUEST;

/**
 * Author: Naveen Reddy
 * Date:11/20/2024
 * Time:12:08 PM
 */

@Component
public class OverTheLimitAddresses {

    private OverTheLimitAddresses() {
    }

    public void handleOverLimitAddresses(ErrorResponse errorResponse, int addressLimit) {
        errorResponse.setErrorCode(String.valueOf(UspsHttpStatusCodes.BAD_REQUEST));
        errorResponse.setErrorMessage(T00_MANY_ADDRESSES_IN_REQUEST + addressLimit);
        errorResponse.setTimestamp(LoggerTimeStamp.generateTimeStamp());
        errorResponse.setErrorTraceId(null);
        errorResponse.setDetails(null);
    }
}
