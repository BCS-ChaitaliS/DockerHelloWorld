package gov.irs.ces.cesavs.model.response;


import gov.irs.ces.cesavs.model.Address;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.stereotype.Component;

/**
 * Author: Naveen Reddy
 * Date:11/29/2024
 * Time:9:46 AM
 */

@Component
@Schema(description = "Address Not Found Response")
public class AddressNotFoundResponse extends Address {

    @Schema
    private String errorCode;
    @Schema
    private String errorMessage;
    @Schema
    private String details;
    @Schema
    private String timestamp;
    @Schema
    private String errorTraceId;

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getErrorTraceId() {
        return errorTraceId;
    }

    public void setErrorTraceId(String errorTraceId) {
        this.errorTraceId = errorTraceId;
    }
}
