package gov.irs.ces.cesavs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CesavsApplication {

	public static void main(String[] args) {
		System.setProperty("java.util.logging.manager", "org.jboss.logmanager.LogManager");
		SpringApplication.run(CesavsApplication.class, args);
	}

}
