package gov.irs.ces.cesavs.model.response;


import gov.irs.ces.cesavs.model.Address;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Author: Naveen Reddy
 * Date:11/29/2024
 * Time:9:52 AM
 */

@Component
@Schema
public class AddressFoundResponse extends Address {

    @Schema
    private String streetAddressAbbreviation;
    @Schema
    private String cityAbbreviation;
    @Schema
    private String deliveryPoint;
    @Schema
    private String returnText;
    @Schema
    private String carrierRoute;
    @Schema
    private String footNotes;
    @Schema
    private String dpvConfirmation;
    @Schema
    private String dpvCMRA;
    @Schema
    private String dpvFootnotes;
    @Schema
    private String business;
    @Schema
    private String centralDeliveryPoint;
    @Schema
    private String vacant;
    @Schema
    private List<Corrections> corrections;
    @Schema
    private List<Matches> matches;
    @Schema
    private String warnings;

    public String getStreetAddressAbbreviation() {
        return streetAddressAbbreviation;
    }

    public void setStreetAddressAbbreviation(String streetAddressAbbreviation) {
        this.streetAddressAbbreviation = streetAddressAbbreviation;
    }

    public String getCityAbbreviation() {
        return cityAbbreviation;
    }

    public void setCityAbbreviation(String cityAbbreviation) {
        this.cityAbbreviation = cityAbbreviation;
    }

    public String getDeliveryPoint() {
        return deliveryPoint;
    }

    public void setDeliveryPoint(String deliveryPoint) {
        this.deliveryPoint = deliveryPoint;
    }

    public String getReturnText() {
        return returnText;
    }

    public void setReturnText(String returnText) {
        this.returnText = returnText;
    }

    public String getCarrierRoute() {
        return carrierRoute;
    }

    public void setCarrierRoute(String carrierRoute) {
        this.carrierRoute = carrierRoute;
    }

    public String getFootNotes() {
        return footNotes;
    }

    public void setFootNotes(String footNotes) {
        this.footNotes = footNotes;
    }

    public String getDpvConfirmation() {
        return dpvConfirmation;
    }

    public void setDpvConfirmation(String dpvConfirmation) {
        this.dpvConfirmation = dpvConfirmation;
    }

    public String getDpvCMRA() {
        return dpvCMRA;
    }

    public void setDpvCMRA(String dpvCMRA) {
        this.dpvCMRA = dpvCMRA;
    }

    public String getDpvFootnotes() {
        return dpvFootnotes;
    }

    public void setDpvFootnotes(String dpvFootnotes) {
        this.dpvFootnotes = dpvFootnotes;
    }

    public String getBusiness() {
        return business;
    }

    public void setBusiness(String business) {
        this.business = business;
    }

    public String getCentralDeliveryPoint() {
        return centralDeliveryPoint;
    }

    public void setCentralDeliveryPoint(String centralDeliveryPoint) {
        this.centralDeliveryPoint = centralDeliveryPoint;
    }

    public String getVacant() {
        return vacant;
    }

    public void setVacant(String vacant) {
        this.vacant = vacant;
    }

    public List<Corrections> getCorrections() {
        return corrections;
    }

    public void setCorrections(List<Corrections> corrections) {
        this.corrections = corrections;
    }

    public List<Matches> getMatches() {
        return matches;
    }

    public void setMatches(List<Matches> matches) {
        this.matches = matches;
    }

    public String getWarnings() {
        return warnings;
    }

    public void setWarnings(String warnings) {
        this.warnings = warnings;
    }
}
