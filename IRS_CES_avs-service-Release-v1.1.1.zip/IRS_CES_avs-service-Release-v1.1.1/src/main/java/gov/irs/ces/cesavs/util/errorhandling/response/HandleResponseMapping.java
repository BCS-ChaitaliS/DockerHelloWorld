package gov.irs.ces.cesavs.util.errorhandling.response;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import gov.irs.ces.cesavs.model.*;
import gov.irs.ces.cesavs.model.response.AddressFoundResponse;
import gov.irs.ces.cesavs.model.response.AddressNotFoundResponse;
import gov.irs.ces.cesavs.util.loggger.ErrorLogPrinter;
import gov.irs.ces.cesavs.util.loggger.LogPrinter;
import gov.irs.ces.cesavs.util.loggger.LoggerTimeStamp;

import org.springframework.stereotype.Component;

import static gov.irs.ces.cesavs.constant.AVSConstants.*;

@Component
public class HandleResponseMapping {

    public static AddressFoundResponse handleFoundResponse(String responseBody, String seId, String sessionId, String addressId, String enterpriseBusCorrelationId, int clientResponseStatusCode, Address address) {

        AddressFoundResponse addressFoundResponse = new AddressFoundResponse();
        try {

            ObjectMapper mapper = new ObjectMapper();
            JsonNode rootNode = mapper.readTree(responseBody);

            JsonNode addressNode = rootNode.path(ADDRESS);
            addressFoundResponse.setAddressId(addressId);
            addressFoundResponse.setAddressLine1(addressNode.path(STREET_ADDRESS).asText());
            addressFoundResponse.setAddressLine2(addressNode.path(SECONDARY_ADDRESS).asText());
            addressFoundResponse.setCity(addressNode.path(CITY).asText());
            addressFoundResponse.setState(addressNode.path(STATE).asText());
            addressFoundResponse.setZip(addressNode.path(ZIP_CODE).asText());
            addressFoundResponse.setZipPlus4(addressNode.path(ZIP_CODE_PLUS4).asText());
            addressFoundResponse.setCountry(addressNode.path(COUNTRY).asText());
            addressFoundResponse.setStreetAddressAbbreviation(addressNode.path(STREET_ADDRESS_ABBR).asText());
            addressFoundResponse.setCityAbbreviation(addressNode.path(CITY_ABBR).asText());
            addressFoundResponse.setUrbanization(addressNode.path(URBANIZATION).asText());
            addressFoundResponse.setCorrections(null);
            addressFoundResponse.setMatches(null);

            JsonNode additionalInfoNode = rootNode.path(ADDITIONAL_INFO);
            addressFoundResponse.setDeliveryPoint(additionalInfoNode.path(DELIVERY_POINT).asText());
            addressFoundResponse.setCarrierRoute(additionalInfoNode.path(CARRIER_ROUTE).asText());
            addressFoundResponse.setDpvConfirmation(additionalInfoNode.path(DPV_CONFIRMATION).asText());
            addressFoundResponse.setDpvCMRA(additionalInfoNode.path(DPV_CMRA).asText());
            addressFoundResponse.setBusiness(additionalInfoNode.path(BUSINESS).asText());
            addressFoundResponse.setCentralDeliveryPoint(additionalInfoNode.path(CENTRAL_DELIVERY_POINT).asText());
            addressFoundResponse.setVacant(additionalInfoNode.path(VACANT).asText());
            addressFoundResponse.setPersonNameIncludedInFullAddress(address.getPersonNameIncludedInFullAddress());

            address.setAddressLine1(addressFoundResponse.getAddressLine1());
            address.setAddressLine2(addressFoundResponse.getAddressLine2());
            address.setCity(addressFoundResponse.getCity());
            address.setState(addressFoundResponse.getState());
            address.setCountry(addressFoundResponse.getCountry());
            address.setZip(addressFoundResponse.getZip());
            address.setZipPlus4(addressFoundResponse.getZipPlus4());
            address.setUrbanization(addressFoundResponse.getUrbanization());

            LogPrinter.formatLogFields(enterpriseBusCorrelationId, seId, USER_TYPE, SYSTEM, EVENT_TYPE_RESPONSE, EVENT_ID, sessionId, EVENT_STATUS_SUCCESS, SUCCESS_MSG, String.valueOf(clientResponseStatusCode), LoggerTimeStamp.generateTimeStamp(), address.toCommaSeparatedString());

        } catch (JsonProcessingException e) {
            return null;
        }

        return addressFoundResponse;
    }

    public static AddressNotFoundResponse handleNotFoundAddressResponse(String responseBody, String seId, String sessionId, String addressId, String enterpriseBusCorrelationId, int clientResponseStatusCode, Address address) {

        AddressNotFoundResponse addressNotFoundResponses = new AddressNotFoundResponse();
        addressNotFoundResponses.setAddressId(addressId);
        addressNotFoundResponses.setAddressLine1(address.getAddressLine1());
        addressNotFoundResponses.setAddressLine2(address.getAddressLine2());
        addressNotFoundResponses.setCity(address.getCity());
        addressNotFoundResponses.setState(address.getState());
        addressNotFoundResponses.setZip(address.getZip());
        addressNotFoundResponses.setState(address.getState());
        addressNotFoundResponses.setUrbanization(address.getUrbanization());
        addressNotFoundResponses.setZipPlus4(address.getZipPlus4());
        addressNotFoundResponses.setPersonNameIncludedInFullAddress(address.getPersonNameIncludedInFullAddress());


        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode rootNode = mapper.readTree(responseBody);
            JsonNode errorNode = rootNode.path(ERROR);

            String errorMessage = errorNode.path(MESSAGE).asText().replace("|", ",");

            addressNotFoundResponses.setErrorCode(errorNode.path(CODE).asText());
            addressNotFoundResponses.setErrorMessage(errorMessage);
            addressNotFoundResponses.setDetails(null);
            addressNotFoundResponses.setTimestamp(null);
            addressNotFoundResponses.setErrorTraceId(null);
            LogPrinter.formatLogFields(enterpriseBusCorrelationId, seId, USER_TYPE, SYSTEM, EVENT_TYPE_RESPONSE, EVENT_ID, sessionId, EVENT_STATUS_FAILED, errorMessage, String.valueOf(clientResponseStatusCode), LoggerTimeStamp.generateTimeStamp(), address.toCommaSeparatedString());

        } catch (JsonProcessingException e) {
            return null;
        }

        return addressNotFoundResponses;
    }
}
