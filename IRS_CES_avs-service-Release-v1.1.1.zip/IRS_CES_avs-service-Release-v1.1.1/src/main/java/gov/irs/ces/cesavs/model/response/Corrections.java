package gov.irs.ces.cesavs.model.response;


import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.stereotype.Component;

/**
 * Author: Naveen Reddy
 * Date:11/29/2024
 * Time:9:56 AM
 */

@Component
@Schema
public class Corrections {

    @Schema
    private String code;
    @Schema
    private String text;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
