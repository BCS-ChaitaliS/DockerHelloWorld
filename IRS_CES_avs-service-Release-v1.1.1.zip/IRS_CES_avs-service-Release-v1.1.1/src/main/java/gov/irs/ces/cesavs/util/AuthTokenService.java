package gov.irs.ces.cesavs.util;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import okhttp3.*;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.Instant;
import java.util.concurrent.TimeUnit;

import static gov.irs.ces.cesavs.constant.AVSConstants.*;

@Service
public class AuthTokenService {

    @Value("${usps.url.api.token}")
    private String tokenApiUrl;

    @Value("${usps.clientId}")
    private String clientId;

    @Value("${usps.clientSecret}")
    private String clientSecret;

    @Value(("${api.token.maxRetryAttempts}"))
    private int maxRetryAttempts;

    @Value(("${api.token.retryDelayInSec}"))
    private int retryDelayInSec;

    @Value(("${api.token.jitterFactor}"))
    private String jitterFactor;

    @Value(("${api.token.connectTimeOut}"))
    private String timeOut;


    private Instant tokenExpiryTime;
    private String accessToken;

    private static final Logger logger = Logger.getLogger(AuthTokenService.class);


    public String getAccessToken() throws IOException, InterruptedException {
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(Long.parseLong(timeOut), TimeUnit.SECONDS)
                // .addInterceptor(new RetryInterceptor(maxRetryAttempts, retryDelayInSec))
                .build();

        if (accessToken == null || tokenExpiryTime == null || Instant.now().isAfter(tokenExpiryTime)) {
            logger.info("AccessToken Status: Creating New Token");

            RequestBody formBody = new FormBody.Builder()
                    .add(GRANT_TYPE, CLIENT_CREDENTIALS)
                    .add(CLIENT_ID, clientId)
                    .add(CLIENT_SECRET, clientSecret)
                    .add(SCOPE, ADDRESSES)
                    .build();

            Request request = new Request.Builder()
                    .url(tokenApiUrl)
                    .header(CONTENT_TYPE, CONTENT_TYPE_VALUE)
                    .post(formBody)
                    .build();

            int attempts = 0;
            long delay = retryDelayInSec * 1000L; // Convert to milliseconds

            while (attempts < maxRetryAttempts) {
                logger.info("Attempt: " + attempts);
                try (Response response = client.newCall(request).execute()) {
                    if (response.isSuccessful()) {
                        logger.info("Status Code for AuthToken Service: " + response.code());
                        assert response.body() != null;
                        String responseBody = response.body().string();
                        return extractAccessToken(responseBody);
                    } else {
                        logger.error("Error Status Code for AuthToken Service: " + response.code());
                        assert response.body() != null;
                        String errorBody = response.body().string();
                        logger.error("Error Body: " + errorBody);
                        throw new RuntimeException("Error retrieving access token");
                    }
                } catch (IOException e) {
                    logger.error("Exception occurred with AuthToken Service: " + e.getMessage());
                    attempts++;
                    logger.info(attempts);
                    if (attempts >= maxRetryAttempts) {
                        logger.error("Max retry attempts reached. Throwing exception.");
                        throw new RuntimeException("Max retry attempts reached", e);
                    }
                    try {
                        logger.info("Retrying in " + delay + " ms");
                        TimeUnit.MILLISECONDS.sleep(delay);
                        delay *= 2; // Exponential backoff
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        throw new RuntimeException("Retry interrupted", ie);
                    }
                }
            }
        } else {
            logger.info("AccessToken Status: Using Existing Token");
            return accessToken;
        }
        return null;
    }

    private String extractAccessToken(String responseBody) {
        JsonObject jsonObject = JsonParser.parseString(responseBody).getAsJsonObject();
        int expiresIn = jsonObject.get(EXPIRES_IN).getAsInt();
        tokenExpiryTime = Instant.now().plusSeconds(expiresIn);
        accessToken = jsonObject.get(ACCESS_TOKEN).getAsString();
        return accessToken;
    }
}