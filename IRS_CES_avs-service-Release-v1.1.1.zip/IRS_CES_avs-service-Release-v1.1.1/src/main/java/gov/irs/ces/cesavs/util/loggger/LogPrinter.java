package gov.irs.ces.cesavs.util.loggger;


import org.jboss.logging.Logger;
import org.springframework.stereotype.Component;


@Component
public class LogPrinter {

    private LogPrinter() {
    }

    private static final Logger logger = Logger.getLogger(LogPrinter.class);

    public static void formatLogFields(String enterpriseBusCorrelationId, String seid, String userType, String system, String eventType, String eventId, String sessionId, String eventStatus, String errorMsg, String statusCode, String timeStamp, String address) {
        String res = String.format("%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|", enterpriseBusCorrelationId, seid, userType, system, eventType, eventId, sessionId, eventStatus, errorMsg, statusCode, timeStamp, address);
        logger.info(res);
    }
}