package gov.irs.ces.cesavs.model.response;


import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Author: Naveen Reddy
 * Date:11/29/2024
 * Time:9:45 AM
 */

@Component
@Schema
public class AddressValidationResponse {

    @Schema
    private List<AddressFoundResponse> foundAddresses;
    @Schema
    private List<AddressNotFoundResponse> notFoundAddresses;

    public List<AddressNotFoundResponse> getNotFoundAddresses() {
        return notFoundAddresses;
    }

    public void setNotFoundAddresses(List<AddressNotFoundResponse> notFoundAddresses) {
        this.notFoundAddresses = notFoundAddresses;
    }

    public List<AddressFoundResponse> getFoundAddresses() {
        return foundAddresses;
    }

    public void setFoundAddresses(List<AddressFoundResponse> foundAddresses) {
        this.foundAddresses = foundAddresses;
    }

}
