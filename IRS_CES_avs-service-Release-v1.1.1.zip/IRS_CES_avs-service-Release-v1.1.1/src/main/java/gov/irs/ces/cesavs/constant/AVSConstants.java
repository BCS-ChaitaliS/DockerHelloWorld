package gov.irs.ces.cesavs.constant;

public class AVSConstants {

    private AVSConstants() {
    }

    public static final String ADDRESS = "address";
    public static final String STREET_ADDRESS = "streetAddress";
    public static final String SECONDARY_ADDRESS = "secondaryAddress";
    public static final String CITY = "city";
    public static final String STATE = "state";
    public static final String ZIP_CODE = "ZIPCode";
    public static final String ZIP_CODE_PLUS4 = "ZIPPlus4";
    public static final String COUNTRY = "country";
    public static final String STREET_ADDRESS_ABBR = "streetAddressAbbreviation";
    public static final String CITY_ABBR = "cityAbbreviation";
    public static final String URBANIZATION = "urbanization";

    public static final String AUTHORIZATION = "Authorization";
    public static final String BEARER = "Bearer ";

    public static final String ERROR = "error";
    public static final String MESSAGE = "message";
    public static final String CODE = "code";
    public static final String SYSTEM_MESSGAE = "systemMessage";

    public static final String GRANT_TYPE = "grant_type";
    public static final String CLIENT_CREDENTIALS = "client_credentials";
    public static final String CLIENT_ID = "client_id";
    public static final String CLIENT_SECRET = "client_secret";
    public static final String SCOPE = "scope";
    public static final String ADDRESSES = "addresses";

    public static final String CONTENT_TYPE = "Content-Type";
    public static final String CONTENT_TYPE_VALUE = "application/x-www-form-urlencoded";

    public static final String ACCESS_TOKEN = "access_token";
    public static final String EXPIRES_IN = "expires_in";

    public static final String ADDITIONAL_INFO = "additionalInfo";
    public static final String DELIVERY_POINT = "deliveryPoint";
    public static final String CARRIER_ROUTE = "carrierRoute";
    public static final String DPV_CONFIRMATION = "DPVConfirmation";
    public static final String DPV_CMRA = "DPVCMRA";
    public static final String BUSINESS = "business";
    public static final String CENTRAL_DELIVERY_POINT = "centralDeliveryPoint";
    public static final String VACANT = "vacant";

    public static final String USER_TYPE = "IRSEE";
    public static final String EVENT_TYPE_RESPONSE = "SVCRESP";
    public static final String EVENT_TYPE_REQUEST = "SVCREQ";
    public static final String EVENT_TYPE_ERROR = "SVCERROR";
    public static final String EVENT_ID = "VALIDATE_ADDRESS";
    public static final String EVENT_STATUS_SUCCESS = "00";
    public static final String EVENT_STATUS_FAILED = "01";
    public static final String SYSTEM = "CES-AVS";
    public static final String SUCCESS_MSG = "Success";
    public static final String REQUEST_MSG = "Request";
    public static final String NOT_APPLICABLE = "NA";
}
