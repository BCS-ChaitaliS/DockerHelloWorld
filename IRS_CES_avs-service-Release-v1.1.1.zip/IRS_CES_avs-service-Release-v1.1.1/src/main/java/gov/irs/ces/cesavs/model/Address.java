package gov.irs.ces.cesavs.model;

import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.stereotype.Component;

@Component
@Schema(description = "Address")
public class Address {
    public Address() {
    }

    public Address(String addressId, String fullAddress, Boolean isPersonNameIncludedInFullAddress, String addressLine1, String addressLine2, String city, String state, String urbanization, String zip, String zipPlus4, String country) {
        this.addressId = addressId;
        this.fullAddress = fullAddress;
        this.isPersonNameIncludedInFullAddress = isPersonNameIncludedInFullAddress;
        this.addressLine1 = addressLine1;
        this.addressLine2 = addressLine2;
        this.city = city;
        this.state = state;
        this.urbanization = urbanization;
        this.zip = zip;
        this.zipPlus4 = zipPlus4;
        this.country = country;
    }

    @Schema
    private String addressId;
    @Schema
    private String fullAddress;
    @Schema
    private Boolean isPersonNameIncludedInFullAddress;
    @Schema
    private String addressLine1;
    @Schema
    private String addressLine2;
    @Schema
    private String city;
    @Schema
    private String state;
    @Schema
    private String urbanization;
    @Schema
    private String zip;
    @Schema
    private String zipPlus4;
    @Schema
    private String country;

    // Getters and Setters
    public String getAddressId() {
        return addressId;
    }

    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }

    public String getFullAddress() {
        return fullAddress;
    }

    public void setFullAddress(String fullAddress) {
        this.fullAddress = fullAddress;
    }

    public Boolean getPersonNameIncludedInFullAddress() {
        return isPersonNameIncludedInFullAddress;
    }

    public void setPersonNameIncludedInFullAddress(Boolean personNameIncludedInFullAddress) {
        isPersonNameIncludedInFullAddress = personNameIncludedInFullAddress;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getUrbanization() {
        return urbanization;
    }

    public void setUrbanization(String urbanization) {
        this.urbanization = urbanization;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }


    public String getZipPlus4() {
        return zipPlus4;
    }

    public void setZipPlus4(String zipPlus4) {
        this.zipPlus4 = zipPlus4;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    @Override
    public String toString() {
        return "Address{" +
                "addressId='" + addressId + '\'' +
                ", addressLine1='" + addressLine1 + '\'' +
                ", addressLine2='" + addressLine2 + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                ", zip='" + zip + '\'' +
                '}';
    }


    public String toCommaSeparatedString() {
        return String.format("%s, %s, %s, %s, %s, %s, %s, %s, %s",
                "addressId: " + addressId,
                "fullAddress: " + fullAddress,
                "addressLine1: " + addressLine1,
                "addressLine2: " + addressLine2,
                "city: " + city,
                "state: " + state,
                "urbanization: " + urbanization,
                "zip: " + zip,
                "zipPlus4: " + zipPlus4);
    }
}

