package gov.irs.ces.cesavs.util.errorhandling.request;


import gov.irs.ces.cesavs.constant.UspsHttpStatusCodes;
import gov.irs.ces.cesavs.model.response.ErrorResponse;
import gov.irs.ces.cesavs.util.loggger.LoggerTimeStamp;
import org.springframework.stereotype.Component;


import static gov.irs.ces.cesavs.constant.AVSErrorMessages.NO_ADDRESS_PROVIDED_IN_REQUEST;

/**
 * Author: Naveen Reddy
 * Date:11/20/2024
 * Time:12:03 PM
 */

@Component
public class EmptyAddresses {

    private EmptyAddresses() {
    }

    public void handleEmptyAddresses(ErrorResponse errorResponse) {
        errorResponse.setErrorCode(String.valueOf(UspsHttpStatusCodes.BAD_REQUEST));
        errorResponse.setErrorMessage(NO_ADDRESS_PROVIDED_IN_REQUEST);
        errorResponse.setTimestamp(LoggerTimeStamp.generateTimeStamp());
        errorResponse.setErrorTraceId(null);
        errorResponse.setDetails(null);
    }
}
