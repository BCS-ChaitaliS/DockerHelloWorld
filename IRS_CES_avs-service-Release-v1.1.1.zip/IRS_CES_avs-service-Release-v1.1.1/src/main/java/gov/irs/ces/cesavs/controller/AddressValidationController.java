package gov.irs.ces.cesavs.controller;

import gov.irs.ces.cesavs.model.request.AddressValidationRequest;
import gov.irs.ces.cesavs.model.response.AddressValidationResponse;
import gov.irs.ces.cesavs.model.response.ErrorResponse;
import gov.irs.ces.cesavs.service.AddressValidatorService;
import gov.irs.ces.cesavs.util.loggger.RequestLogPrinter;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.concurrent.CompletableFuture;

@CrossOrigin(origins = "null")
@RestController
@RequestMapping(value = "/addressvalidation")
public class AddressValidationController {

    private static final Logger logger = Logger.getLogger(AddressValidationController.class);
    private final AddressValidatorService addressValidatorService;
    private final RequestLogPrinter requestLogPrinter;

    @Autowired
    public AddressValidationController(AddressValidatorService addressValidatorService, RequestLogPrinter requestLogPrinter) {
        this.addressValidatorService = addressValidatorService;
        this.requestLogPrinter = requestLogPrinter;
    }

    @Value("${api.testMode}")
    private String apiTestMode;

    @Operation(summary = "Verify the customer address", description = "This API verifies a given address using USPS services and returns the corrected address if there aren't any errors. This endpoint allows up to 3600 requests per hour.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Success - includes both valid and errored addresses", content = @Content(schema = @Schema(implementation = AddressValidationResponse.class))),
            @ApiResponse(responseCode = "400", description = "Bad Request - invalid input, missing parameters, or incorrect address format", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
            @ApiResponse(responseCode = "401", description = "Unauthorized - authentication failure or invalid API key", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
            @ApiResponse(responseCode = "403", description = "Forbidden - insufficient permissions for the requested operation", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
            @ApiResponse(responseCode = "404", description = "Not Found - the requested resource or endpoint does not exist", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
            @ApiResponse(responseCode = "429", description = "Too Many Requests. Too many requests have been received from client in a short amount of time.", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error - an unexpected error occurred on the server", content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
            @ApiResponse(responseCode = "503", description = "Service Unavailable - USPS or internal service is temporarily unavailable", content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
    })
    @PostMapping
    public CompletableFuture<ResponseEntity> validateAddress(@RequestHeader("enterpriseBusCorrelationId") String enterpriseBusCorrelationId,
                                                @RequestBody AddressValidationRequest addressValidationRequest) {

        logger.info("Addresses received in the request : " + addressValidationRequest.getAddresses().size());

        if (apiTestMode.equals("true")) {
            logger.info("Running In Test Mode");
            return addressValidatorService.validateAddressesTestMode(addressValidationRequest);
        } else {
            logger.info("Printing Request Loggers");
            requestLogPrinter.printRequest(addressValidationRequest, enterpriseBusCorrelationId);
            logger.info("Request Status: Processing");
            return addressValidatorService.validateAddresses(addressValidationRequest, enterpriseBusCorrelationId);
        }
    }

}
