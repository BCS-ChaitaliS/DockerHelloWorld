package gov.irs.ces.cesavs.util.errorhandling.request;


import gov.irs.ces.cesavs.model.response.ErrorResponse;
import gov.irs.ces.cesavs.util.loggger.LoggerTimeStamp;
import org.springframework.stereotype.Component;

import static gov.irs.ces.cesavs.constant.AVSErrorMessages.COMMON_ERROR_MSG;
import static gov.irs.ces.cesavs.constant.AVSErrorMessages.MISSING_ENTERPRISE_BUS_CORRELATION_ID;

/**
 * Author: Naveen Reddy
 * Date:12/12/2024
 * Time:9:32 AM
 */
@Component
public class EnterpriseBusCorrelationIdFailure {

    private EnterpriseBusCorrelationIdFailure() {
    }


    public void handleEnterpriseBusCorrelationIdFailure(ErrorResponse errorResponse) {
        errorResponse.setDetails("");
        errorResponse.setErrorCode("400");
        errorResponse.setErrorMessage(MISSING_ENTERPRISE_BUS_CORRELATION_ID);
        errorResponse.setTimestamp(LoggerTimeStamp.generateTimeStamp());
        errorResponse.setErrorTraceId("");
    }
}
