package gov.irs.ces.cesavs.constant;


/**
 * Author: Naveen Reddy
 * Date:11/20/2024
 * Time:1:02 PM
 */

public class UspsHttpStatusCodes {

    private UspsHttpStatusCodes() {
    }

    public static final int OK = 200;
    public static final int BAD_REQUEST = 400;
    public static final int UNAUTHORIZED = 401;
    public static final int FORBIDDEN = 403;
    public static final int NOT_FOUND = 404;
    public static final int TOO_MANY_REQUESTS = 429;
    public static final int SERVICE_UNAVAILABLE = 503;
}
