package gov.irs.ces.cesavs.util.loggger;


import gov.irs.ces.cesavs.model.Address;
import gov.irs.ces.cesavs.model.request.AddressValidationRequest;
import gov.irs.ces.cesavs.model.request.AuditRequest;
import org.springframework.stereotype.Component;

import java.util.List;

import static gov.irs.ces.cesavs.constant.AVSConstants.*;

/**
 * Author: Naveen Reddy
 * Date:11/20/2024
 * Time:10:02 AM
 */

@Component
public class RequestLogPrinter {


    private RequestLogPrinter() {
    }

    public void printRequest(AddressValidationRequest addressValidationRequest, String enterpriseBusCorrelationId) {
        AuditRequest auditRequest = addressValidationRequest.getAuditRequest();
        String seid = auditRequest.getSeid();
        String tId = auditRequest.getTransactionId();
        String formattedTimestamp = LoggerTimeStamp.generateTimeStamp();
        List<Address> addresses = addressValidationRequest.getAddresses();

        addresses.forEach(address ->
                LogPrinter.formatLogFields(enterpriseBusCorrelationId, seid, USER_TYPE, SYSTEM, EVENT_TYPE_REQUEST, EVENT_ID, tId, NOT_APPLICABLE, NOT_APPLICABLE, NOT_APPLICABLE, formattedTimestamp, address.toCommaSeparatedString()));

    }
}
