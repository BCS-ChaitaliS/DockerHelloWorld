package gov.irs.ces.cesavs.constant;


/**
 * Author: Naveen Reddy
 * Date:12/3/2024
 * Time:10:06 AM
 */

public class AVSErrorMessages {

    private AVSErrorMessages() {
    }

    public static final String COMMON_ERROR_MSG = "We are currently experiencing an unexpected outage affecting access to AVS. " +
            "Our technical team is actively investigating the cause and working to restore service as soon as possible.";

    public static final String T00_MANY_ADDRESSES_IN_REQUEST = "Request exceeds the maximum allowed limit of addresses. Please limit the total number of addresses less than or equal to ";
    public static final String NO_ADDRESS_PROVIDED_IN_REQUEST = "No addresses were provided. Please supply at least one address and try again.";

    public static final String MISSING_ENTERPRISE_BUS_CORRELATION_ID = "The required parameter 'EnterpriseBusCorrelationId' is missing from the request.";

}
