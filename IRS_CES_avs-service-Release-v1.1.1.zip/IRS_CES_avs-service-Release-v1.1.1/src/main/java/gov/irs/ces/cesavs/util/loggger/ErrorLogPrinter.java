package gov.irs.ces.cesavs.util.loggger;


import org.springframework.stereotype.Component;

import static gov.irs.ces.cesavs.constant.AVSConstants.*;

/**
 * Author: Naveen Reddy
 * Date:11/20/2024
 * Time:10:02 AM
 */

@Component
public class ErrorLogPrinter {


    private ErrorLogPrinter() {
    }

    public void printRequest(String enterpriseBusCorrelationId, String errorMessage, String statusCode) {
        String formattedTimestamp = LoggerTimeStamp.generateTimeStamp();
        LogPrinter.formatLogFields(enterpriseBusCorrelationId, NOT_APPLICABLE, USER_TYPE, SYSTEM, EVENT_TYPE_ERROR, EVENT_ID, NOT_APPLICABLE, EVENT_STATUS_FAILED, errorMessage, statusCode, formattedTimestamp, NOT_APPLICABLE);
    }
}
