package gov.irs.ces.cesavs.util.errorhandling.request;


import gov.irs.ces.cesavs.model.response.ErrorResponse;
import gov.irs.ces.cesavs.util.loggger.LoggerTimeStamp;
import org.springframework.stereotype.Component;

import static gov.irs.ces.cesavs.constant.AVSErrorMessages.COMMON_ERROR_MSG;


/**
 * Author: Naveen Reddy
 * Date:11/23/2024
 * Time:11:16 PM
 */

@Component
public class AccessTokenFailed {

    private AccessTokenFailed() {
    }


    public void handleAccessToken(ErrorResponse errorResponse) {
        errorResponse.setDetails("");
        errorResponse.setErrorCode("400");
        errorResponse.setErrorMessage(COMMON_ERROR_MSG);
        errorResponse.setTimestamp(LoggerTimeStamp.generateTimeStamp());
        errorResponse.setErrorTraceId("");
    }
}

