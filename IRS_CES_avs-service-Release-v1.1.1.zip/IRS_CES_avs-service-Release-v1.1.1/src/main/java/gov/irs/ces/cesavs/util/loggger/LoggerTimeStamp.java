package gov.irs.ces.cesavs.util.loggger;


import org.springframework.stereotype.Component;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Author: Naveen Reddy
 * Date:11/20/2024
 * Time:11:18 AM
 */

@Component
public class LoggerTimeStamp {

   private LoggerTimeStamp() {
    }

    public static String generateTimeStamp() {
        ZonedDateTime now = ZonedDateTime.now(ZoneId.of("UTC+4"));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        return now.format(formatter);
    }

}
