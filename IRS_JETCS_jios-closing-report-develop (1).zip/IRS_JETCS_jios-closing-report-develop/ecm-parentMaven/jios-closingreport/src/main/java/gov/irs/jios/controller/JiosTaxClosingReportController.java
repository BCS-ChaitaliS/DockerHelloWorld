package gov.irs.jios.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import gov.irs.jios.config.FormConstants;
import gov.irs.jios.model.*;
import gov.irs.jios.service.ClosingReportService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@Tag(name = "Closing", description = "Operations related to closing a verified report")
@RequestMapping("/jios-closingreport")
@RequiredArgsConstructor
public class JiosTaxClosingReportController {

    private final ClosingReportService closingReportService;

    private static final Logger logger = LoggerFactory.getLogger(JiosTaxClosingReportController.class);

	@PostMapping("/api/v1.0/closingreport")
	public ResponseEntity<?> closingReport(@RequestBody JiosRequest  request) {
		logger.debug("Received ClosingReport Request");
		try {
			
			JiosResponse response = prepareJiosResponse(request);

            //initialize the processedForms which will capture the reports requested
            List<Form> processedForms = new ArrayList<>();

            List<TaxPeriod> multipleTaxPeriods = request.getBody().getTaxPeriod();
            if(request.getHeader().getReportsRequested().contains(FormConstants.FORM4549))
                 processedForms.addAll(closingReportService.processForm4549(multipleTaxPeriods));
            //Processes Forms from Multiple taxpersiods and address the requested reports.
            processFormsByTaxPeriod(multipleTaxPeriods, processedForms);

            response.getBody().setForms(processedForms);
			logger.info("Closing Report Processed Successfully");
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
        catch (Exception e) {
            logger.error("Exception occurred during Closing Report", e);
            HttpHeaders headers = new HttpHeaders();         
            headers.setContentType(MediaType.APPLICATION_JSON);       
            return new ResponseEntity<>("An unexpected error occurred: " + e.getMessage(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
         }
		
	}

    private JiosResponse prepareJiosResponse(JiosRequest request){
        JiosResponse response = new JiosResponse();

        JiosBody jiosBody = new JiosBody();
        jiosBody.setForms(new ArrayList<>());
        response.setBody(jiosBody);
        response.setHeader(request.getHeader());
        return response;
    }

    private void processFormsByTaxPeriod(List<TaxPeriod> multipleTaxPeriods, List<Form> processedForms){
        AtomicReference<String> taxPrd = new AtomicReference<>("");
        if(!CollectionUtils.isEmpty(multipleTaxPeriods)){

            multipleTaxPeriods.forEach(taxPeriod->{
                List<Form> formsListByTaxPeriod =  taxPeriod.getForms();
                taxPrd.set(taxPeriod.getTaxPrd());
                processedForms.addAll(closingReportService.processForms(formsListByTaxPeriod , taxPrd.get(), taxPeriod.getReportsRequested(),taxPeriod.getCalcTypeTxt()));
            });
        }

    }
}
