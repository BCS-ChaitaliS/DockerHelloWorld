package gov.irs.jios.config;

public class LineNum4549 {

    public static final String LINE1= "/IRS4549/adjustmentsToIncomeGroup";
    public static final String LINE2 = "/IRS4549/AdjustmentsToIncome/totaladjustmentAmtGroup";

    public static final String LINE1_AdjName= "/IRS4549/adjustmentsToIncomeGroup/issueNm";
    public static final String LINE1_AdjAmt = "/IRS4549/adjustmentsToIncomeGroup/adjustmentAmt";
    public static final String LINE1_TaxPeriodGrp = "/IRS4549/taxPeriodsGrp";
    public static final String LINE1_TaxPrd = "/IRS4549/taxPeriodsGrp/taxPrd";
    public static final String  LINE2_totAdjAmt = "/IRS4549/AdjustmentsToIncome/totalAdjustmentAmt";
    public static final String LINE3 = "/IRS4549/taxableIncomeGrp";
    public static final String LINE3_TaxIncAdjAmt = "/IRS4549/taxableIncomeGrp/taxableIncomeAdjAmt";
    public static final String LINE4= "/IRS4549/correctedTaxableIncomeGrp";
    public static final String LINE4_correctedTaxIncAmt = "/IRS4549/correctedTaxableIncomeGrp/correctedTaxableIncomeAmt";
    public static final String LINE4_taxMethod = "/IRS4549/correctedTaxableIncomeGroup/taxMethod";

    public static final String LINE4_FS = "/IRS4549/correctedTaxableIncomeGroup/filingStatus";
    public static final String LINE5 = "/IRS4549/taxGrp";
    public static final String LINE5_taxAmt = "/IRS4549/taxGrp/taxAmt";
    public static final String LINE5_FS = "/IRS4549/taxGrp/filingStatusTxt";
    public static final String LINE5_TaxMethod = "/IRS4549/taxGrp/taxMethodTxt";

    public static final String LINE6 = "/IRS4549/additionalTaxesGrp";
    public static final String LINE6_AddAmt = "/IRS4549/additionalTaxesGrp/additionalTaxAmt";
    public static final String LINE7 = "/IRS4549/correctedTaxLiabilityGrp";
    public static final String LINE7_liabAmt = "/IRS4549/correctedTaxLiabilityGrp/correctedTaxLiabilityAmt";

    public static final String LINE8 = "/IRS4549/correctedTaxLiabilityGrp";

}
