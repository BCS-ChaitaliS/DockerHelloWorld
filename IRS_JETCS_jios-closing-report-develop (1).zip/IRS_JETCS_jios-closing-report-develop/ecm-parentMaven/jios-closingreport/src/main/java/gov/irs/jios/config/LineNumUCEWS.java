package gov.irs.jios.config;

public class LineNumUCEWS {
    public static final String LINE_TaxPayerName= "/UCE_worksheet_2020/totalIncomeBeforeAdjAmt";
    public static final String LINE_TaxPeriod= "/UCE_worksheet_2020/totalIncomeBeforeAdjAmt";
    public static final String LINE_RptDate= "/UCE_worksheet_2020/totalIncomeBeforeAdjAmt";
    public static final String LINE_RptType= "/UCE_worksheet_2020/totalIncomeBeforeAdjAmt";
    public static final String LINE_TIN= "/UCE_worksheet_2020/totalIncomeBeforeAdjAmt";
    public static final String LINE_SoftWareVTxt= "/UCE_worksheet_2020/totalIncomeBeforeAdjAmt";

    public static final String LINE1 = "/UCE_worksheet_2020/totalIncomeBeforeAdjAmt";
    public static final String LINE2 = "/UCE_worksheet_2020/totalAdjToIncomeAmt";
    public static final String LINE3 = "/UCE_worksheet_2020/modifiedAdjGrossIncomeAmt";

}
