package gov.irs.jios.service;

import gov.irs.jios.config.FormConstants;
import gov.irs.jios.config.LineNum1040;
import gov.irs.jios.config.LineNum4549;
import gov.irs.jios.model.Form;
import gov.irs.jios.model.LineItem;
import gov.irs.jios.model.TaxPeriod;
import gov.irs.jios.utility.CommonUtility;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Service
@Slf4j
public class Form4549Service {

    private static final String DELIMITER = "-";
    private static Map<String, List<String>> adjustmentToIncomeMapping = new HashMap<>();

    public Form4549Service(){
        super();
        init();

    }

    private void init(){
       adjustmentToIncomeMapping.put("IRS1040", Arrays.asList("/IRS1040/HouseholdEmployeeWagesAmt", "/IRS1040/TipIncomeAmt",
               "/IRS1040/MedicaidWaiverPymtNotRptW2Amt","/IRS1040/OtherEarnedIncomeAmt",
               "/IRS1040/TaxableInterestAmt", "/IRS1040/OrdinaryDividendsAmt", "/IRS1040/TaxableIRAAmt", "/IRS1040/TaxableForeignPensionsTotalAmt"));
    }

    public List<Form> processAllTaxPeriods(List<TaxPeriod> taxPeriods){
        AtomicInteger taxPeriodSeq = new AtomicInteger(1);
        List<Form> form4549List = new ArrayList<>();
        TaxPeriod taxPeriod1 = !taxPeriods.isEmpty()? taxPeriods.get(0) :null;
        TaxPeriod taxPeriod2 = taxPeriods.size()>1? taxPeriods.get(1) :null;
        TaxPeriod taxPeriod3 = taxPeriods.size()>2? taxPeriods.get(2) :null;
        Form form4549 = Form.builder().formNum(FormConstants.FORM4549).lineItems(new ArrayList<>()).build();
        //Map<String, TaxPeriod> taxPeriodByFormMap= CommonUtility.transformTaxPeriodListToMap(taxPeriods);
        Map<String, LineItem> lineItemMap = new HashMap<>();
        populateAdjustmentsToIncomeByTaxPeriod(taxPeriod1, taxPeriod2, taxPeriod3, lineItemMap);
        //form4549.getLineItems().addAll(lineItemMap.values().stream().toList());
        if(!CollectionUtils.isEmpty(taxPeriods)){
            taxPeriods.forEach(taxPeriod->{

                   processForm(taxPeriod.getForms(), lineItemMap, taxPeriod.getTaxPrd(),
                           taxPeriod.getCalcTypeTxt(), String.valueOf(taxPeriodSeq.getAndIncrement()));


            });
        }

        form4549.getLineItems().addAll(lineItemMap.values().stream().toList());

        form4549List.add(form4549);
        return form4549List;
    }

    /**
     * Process Form4549 for line calculations
     * @param forms
     * @param taxPeriod
     */
    public void processForm(List<Form> forms,Map<String, LineItem> lineItemMap,  String taxPeriod, String calcType, String taxPeriodSeq) {
        try {


            //Map<String, LineItem> lineItemMap = CommonUtility.transformLineItemsListToMap(form4549.getLineItems());
            Map<String,Form> formsMap = CommonUtility.transformFormsListToMap(forms);
             Form form1040 = formsMap.get(FormConstants.FORM1040);
             Form schedule3 = formsMap.get(FormConstants.SCHEDULE_3);
             Map<String, LineItem> form1040LineMap = CommonUtility.transformLineItemsListToMap(form1040.getLineItems());

            //TODO: calculations
            populateTaxPeriodGroup(lineItemMap, taxPeriod, taxPeriodSeq);

            // Line 2
            calculateTotalAdjustmentAmt(lineItemMap);
            //Line3
            calcuateTaxableIncomePerReturn(form1040LineMap, lineItemMap, taxPeriodSeq);
            //Line 4
            calculateCorrectedTaxableIncomeAmt(form1040LineMap, lineItemMap, taxPeriodSeq);
            //Line 5
            calculateTaxAmt(form1040, lineItemMap, taxPeriodSeq, calcType);

            //Line 6
            calculateAdditionTaxes(form1040LineMap, lineItemMap, taxPeriodSeq, calcType);

            //Line 7
            calculateCorrectedTaxLiability(lineItemMap, taxPeriodSeq);

            //Line 8
             calculateLessCredits(form1040LineMap, schedule3, lineItemMap, taxPeriodSeq );
            //form4549.getLineItems().addAll(lineItemMap.values().stream().toList());
        } catch (Exception e) {
           log.error("Failed to process 4595" + e.getMessage());
        }

    }

    public void populateTaxPeriodGroup(Map<String, LineItem> lineItemMap, String taxPeriod, String taxPeriodSeq){
        LineItem lineItemTaxPrdGrp = lineItemMap.containsKey(LineNum4549.LINE1_TaxPeriodGrp+FormConstants.DELIMITER+"1") ?
                lineItemMap.get(LineNum4549.LINE1_TaxPeriodGrp+FormConstants.DELIMITER+"1")
                : LineItem.builder().lineNameTxt(LineNum4549.LINE1_TaxPeriodGrp).sequenceNum("1").lineItems(new ArrayList<>()).build();
        LineItem lineItemTxPrd = LineItem.builder().lineNameTxt(LineNum4549.LINE1_TaxPrd).sequenceNum(String.valueOf(taxPeriodSeq)).lineValueTxt(taxPeriod).build();
        lineItemTaxPrdGrp.getLineItems().add(lineItemTxPrd);
        lineItemMap.put(LineNum4549.LINE1_TaxPeriodGrp+FormConstants.DELIMITER+"1",lineItemTaxPrdGrp);
    }
    /**
     * Populate form1 to 4549
     * @param formMap
     * @param lineItemMap
     * @param calcType
     */
    public void populateAdjustmentsToIncome(Map<String, Form> formMap, Map<String, LineItem> lineItemMap, String calcType, String taxPeriodSeq){
        Form form1040 = formMap.get(FormConstants.FORM1040);
        int sequence = 1 ;
        LineItem lineItem = new LineItem(LineNum4549.LINE1, StringUtils.EMPTY, String.valueOf(taxPeriodSeq));

        lineItem.setLineItems(new ArrayList<>());
        lineItemMap.put(lineItem.getLineNameTxt()+FormConstants.DELIMITER+taxPeriodSeq, lineItem);
        if(!CollectionUtils.isEmpty(form1040.getLineItems())){

           List<LineItem> adjustForm1040 =  form1040.getLineItems().stream().
                   filter(form1040lineItem->adjustmentToIncomeMapping.get("IRS1040")
                           .contains(form1040lineItem.getLineNameTxt())).collect(Collectors.toList());
           List<LineItem> lineItemsList = new ArrayList<>();
           log.info("form1040 list"+ adjustForm1040.size());
           if(!CollectionUtils.isEmpty(adjustForm1040)){
               Iterator<LineItem> form1040Items = adjustForm1040.iterator();

               while(form1040Items.hasNext()){
                   LineItem form1040LineItem = form1040Items.next();
                   LineItem lineItem1_issueName= new LineItem(LineNum4549.LINE1_AdjName, form1040LineItem.getLineNameTxt(), String.valueOf(sequence));

                   String lineValueAdjAmt = CommonUtility.retrieveAdjustmentAmountByCalcType(form1040LineItem,calcType);
                   LineItem lineItem1_ajtAmt = new LineItem(LineNum4549.LINE1_AdjAmt,lineValueAdjAmt , String.valueOf(sequence));
                   if(StringUtils.isNotBlank(lineValueAdjAmt)) {
                       lineItemsList.add(lineItem1_issueName);
                       lineItemsList.add(lineItem1_ajtAmt);
                       sequence++;
                   }
               }

           }
          if(lineItemsList.size()>0)
              lineItem.getLineItems().addAll(lineItemsList);
        }

    }

    /**
     * To Calculate Line 2 Total Adjustments Amt
     * @param lineItemMap
     */
    public void calculateTotalAdjustmentAmt(Map<String, LineItem> lineItemMap) {
        try {
             //LineItem lineItem1 = lineItemMap.containsKey(lineNameMap.get("LINE1"))?lineItemMap.get(lineNameMap.get("LINE1")):lineItemMap.get(lineNameMap.get("LINE1") + "_1");
            LineItem lineItem1 = lineItemMap.containsKey(LineNum4549.LINE1) ? lineItemMap.get(LineNum4549.LINE1) : lineItemMap.get(LineNum4549.LINE1+ "-1");

            System.out.println("lineItem1 " + lineItem1.getLineNameTxt());
            List<LineItem> lineItem1List = lineItem1.getLineItems();
            String lineItem2Name = lineItemMap.containsKey(LineNum4549.LINE2)?LineNum4549.LINE2:LineNum4549.LINE2 + "-1";
            List<LineItem> lineItem2List = lineItemMap.get(lineItem2Name).getLineItems();
            Map<String, LineItem> aggregateLine2Map = CommonUtility.transformLineItemsListToMap(lineItem2List);
            String amountLineName = LineNum4549.LINE1_AdjAmt;
            String aggregateAmountLineName =LineNum4549.LINE2_totAdjAmt;
            BigDecimal total_1 = BigDecimal.ZERO;
            BigDecimal total_2 = BigDecimal.ZERO;
            BigDecimal total_3 = BigDecimal.ZERO;

            if (!lineItem1List.isEmpty()) {
                //Iterate 1a through 1p
                lineItem1List.forEach(lineItemAdjustment -> {
                    List<LineItem> amountLineItems = lineItemAdjustment.getLineItems();
                    Map<String, LineItem> amountLineMap = CommonUtility.transformLineItemsListToMap(amountLineItems);
                    int column = 1;
                    //Iterate through amounts for each period to calculate the total for each of the tax period
                    while (amountLineMap.containsKey(amountLineName + DELIMITER + column)) {
                        BigDecimal total = new BigDecimal(aggregateLine2Map.get(aggregateAmountLineName + DELIMITER + column).getLineValueTxt());
                        total = total.add(new BigDecimal(amountLineMap.get(amountLineName + DELIMITER + column).getLineValueTxt()));
                        aggregateLine2Map.get(aggregateAmountLineName + DELIMITER + column).setLineValueTxt(String.valueOf(total));
                        column++;
                    }
                });
            }
            //set the Line2 Items back to the main linItemMap
            lineItemMap.get(lineItem2Name).setLineItems(aggregateLine2Map.values().stream().toList());
        } catch (Exception e) {
            log.error("Failed to calculate Line 2 "+e.getMessage()) ;
        }

    }

    /**
     * To calculate line 3 of form 4549
     * @param form1040Map
     * @param lineItemMap
     * @param taxPeriodSeq
     */
    public void calcuateTaxableIncomePerReturn(Map<String, LineItem> form1040Map, Map<String, LineItem> lineItemMap, String taxPeriodSeq){

       // List<LineItem> form1040LineItems = form1040.getLineItems();
        LineItem line4549Item3= lineItemMap.containsKey(LineNum4549.LINE3+FormConstants.DELIMITER+"1")?lineItemMap.get(LineNum4549.LINE3+FormConstants.DELIMITER+"1")
                : LineItem.builder().lineNameTxt(LineNum4549.LINE3).lineItems(new ArrayList<>()).sequenceNum("1").build();


        LineItem lineItem15 =form1040Map.containsKey(LineNum1040.LINE15)? form1040Map.get(LineNum1040.LINE15): form1040Map.get(LineNum1040.LINE15+FormConstants.DELIMITER+"1");
        LineItem lineItem3Adj = LineItem.builder().lineNameTxt(LineNum4549.LINE3_TaxIncAdjAmt).sequenceNum(taxPeriodSeq).build();
        if(null != lineItem15) {
            lineItem3Adj.setLineValueTxt(lineItem15.getPerReturnValueTxt());
            line4549Item3.getLineItems().add(lineItem3Adj);
        }
       lineItemMap.put(LineNum4549.LINE3+FormConstants.DELIMITER+"1", line4549Item3);
    }

    /**
     *
     * @param form1040Map
     * @param lineItemMap
     * @param taxPeriodSeq
     */
    public void calculateCorrectedTaxableIncomeAmt(Map<String, LineItem> form1040Map, Map<String, LineItem> lineItemMap, String taxPeriodSeq){

        //List<LineItem> form1040LineItems = form1040.getLineItems();
        LineItem line4549Item4= lineItemMap.containsKey(LineNum4549.LINE4+FormConstants.DELIMITER+"1")?lineItemMap.get(LineNum4549.LINE4+FormConstants.DELIMITER+"1")
                : LineItem.builder().lineNameTxt(LineNum4549.LINE4).lineItems(new ArrayList<>()).sequenceNum("1").build();

//        List<LineItem> lineItem15List = form1040LineItems.stream().filter(
//                        lineItem->lineItem.getLineNameTxt().equalsIgnoreCase(LineNum1040.LINE15))
//                .collect(Collectors.toList());
        LineItem lineItem15 = form1040Map.containsKey(LineNum1040.LINE15) ? form1040Map.get(LineNum1040.LINE15):form1040Map.get(LineNum1040.LINE15+FormConstants.DELIMITER+"1");

        LineItem lineItem4Adj = LineItem.builder().lineNameTxt(LineNum4549.LINE4_correctedTaxIncAmt).sequenceNum(taxPeriodSeq).build();


        if(null != lineItem15) {
            lineItem4Adj.setLineValueTxt(lineItem15.getTotalAdjTaxCalcValueTxt());
            line4549Item4.getLineItems().add(lineItem4Adj);
        }

            lineItemMap.put(LineNum4549.LINE4+FormConstants.DELIMITER+"1", line4549Item4);
    }

    /**
     * To Process the adjustmentsToIncomeByTaxPeriod in horizontal
     * @param taxPeriod1
     * @param taxPeriod2
     * @param taxPeriod3
     * @param lineItemMap
     */
    public void populateAdjustmentsToIncomeByTaxPeriod(TaxPeriod taxPeriod1, TaxPeriod taxPeriod2, TaxPeriod taxPeriod3, Map<String, LineItem> lineItemMap){

        Map<String, Form> taxPeriod1FormMap = CommonUtility.transformFormsListToMap(taxPeriod1.getForms());
        Map<String, Form> taxPeriod2FormMap = CommonUtility.transformFormsListToMap(taxPeriod2.getForms());
        Map<String, Form> taxPeriod3FormMap = CommonUtility.transformFormsListToMap(taxPeriod3.getForms());
        Form taxPer1Form1040 = taxPeriod1FormMap.get(FormConstants.FORM1040);
        Form taxPer2Form1040 = taxPeriod2FormMap.get(FormConstants.FORM1040);
        Form taxPer3Form1040 = taxPeriod3FormMap.get(FormConstants.FORM1040);
        // TODO : Add specific logic to get Itemized and Standard deduction (Line 12 Form 1040 perreturnValue - taxCalcValue) , Name -Net Change to Standard/Itemized
        List<String> adjustmentToIncome1040List = adjustmentToIncomeMapping.get(FormConstants.FORM1040);
        AtomicInteger adjToIncomeSequnece = new AtomicInteger(1);
        adjustmentToIncome1040List.forEach(adjustmentToIncome->{
            List<LineItem> adjAmtLineItemList = new ArrayList<>();
             Optional<LineItem> taxPer1LineItem = !CollectionUtils.isEmpty(taxPer1Form1040.getLineItems())
                     ? taxPer1Form1040.getLineItems().stream().filter(lineItem->lineItem.getLineNameTxt()
                     .equalsIgnoreCase(adjustmentToIncome)).findFirst(): Optional.empty();
            Optional<LineItem> taxPer2LineItem =  !CollectionUtils.isEmpty(taxPer2Form1040.getLineItems())
                    ? taxPer2Form1040.getLineItems().stream().filter(lineItem->lineItem.getLineNameTxt()
                    .equalsIgnoreCase(adjustmentToIncome)).findFirst() : Optional.empty();
            Optional<LineItem> taxPer3LineItem =  !CollectionUtils.isEmpty(taxPer3Form1040.getLineItems())
                    ? taxPer2Form1040.getLineItems().stream().filter(lineItem->lineItem.getLineNameTxt()
                    .equalsIgnoreCase(adjustmentToIncome)).findFirst() : Optional.empty();
             LineItem adjLineItem1 = taxPer1LineItem.isPresent() ? getAdjToIncomeLineItem(taxPer1LineItem.get(),
                     taxPeriod1.getCalcTypeTxt(), LineNum4549.LINE1_AdjAmt, "1"): null;
             LineItem adjLineItem2 = taxPer2LineItem.isPresent() ? getAdjToIncomeLineItem(taxPer2LineItem.get(),
                     taxPeriod2.getCalcTypeTxt(), LineNum4549.LINE1_AdjAmt, "2"): null;
            LineItem adjLineItem3 = taxPer3LineItem.isPresent() ? getAdjToIncomeLineItem(taxPer3LineItem.get(),
                    taxPeriod3.getCalcTypeTxt(), LineNum4549.LINE1_AdjAmt, "3"): null;
            if(null!=adjLineItem1 || null!=adjLineItem2 || null!= adjLineItem3){
                LineItem lineItem1 = LineItem.builder()
                        .lineNameTxt(LineNum4549.LINE1)
                        .lineItems(new ArrayList<>())
                        .sequenceNum(String.valueOf(adjToIncomeSequnece.get())).build();
                LineItem lineItem1_issueName = LineItem.builder()
                        .lineNameTxt(LineNum4549.LINE1_AdjName)
                        .lineValueTxt(adjustmentToIncome)
                        .sequenceNum(String.valueOf(adjToIncomeSequnece.get())).build();
                if(null != adjLineItem1){
                    lineItem1.getLineItems().add(adjLineItem1);
                }
                if(null != adjLineItem2){
                    lineItem1.getLineItems().add(adjLineItem2);
                }
                if(null != adjLineItem3){
                    lineItem1.getLineItems().add(adjLineItem3);
                }
                lineItem1.getLineItems().add(lineItem1_issueName);
                lineItemMap.put(LineNum4549.LINE1+FormConstants.DELIMITER+adjToIncomeSequnece, lineItem1);
                adjToIncomeSequnece.getAndIncrement();
            }

        });
    }

    /**
     * To Calculate Line 5 of form4549
     * @param form1040
     * @param lineItemMap
     * @param taxPeriodSeq
     * @param calcType
     */
    public void calculateTaxAmt(Form form1040, Map<String, LineItem> lineItemMap, String taxPeriodSeq,String  calcType){
        LineItem lineItem5 =lineItemMap.containsKey(LineNum4549.LINE5+FormConstants.DELIMITER+"1")
                ? lineItemMap.get((LineNum4549.LINE5+FormConstants.DELIMITER+"1") )
                : LineItem.builder().lineNameTxt(LineNum4549.LINE5).sequenceNum("1").lineItems(new ArrayList<>()).build();
        LineItem lineItem5_TMGrp =lineItemMap.containsKey(LineNum4549.LINE5+FormConstants.DELIMITER+"2")
                ? lineItemMap.get((LineNum4549.LINE5+FormConstants.DELIMITER+"2") )
                : LineItem.builder().lineNameTxt(LineNum4549.LINE5).sequenceNum("2").lineItems(new ArrayList<>()).build();
        LineItem lineItem5_FSGrp =lineItemMap.containsKey(LineNum4549.LINE5+FormConstants.DELIMITER+"3")
                ? lineItemMap.get((LineNum4549.LINE5+FormConstants.DELIMITER+"3") )
                : LineItem.builder().lineNameTxt(LineNum4549.LINE5).sequenceNum("3").lineItems(new ArrayList<>()).build();
        Optional<LineItem> form1040LineItem16 = form1040.getLineItems().stream()
                .filter(lineItem->lineItem.getLineNameTxt().equalsIgnoreCase(LineNum1040.LINE16))
                .findFirst();
        //LineItem form1040LineItem16 = form1040Map.containsKey(LineNum1040.LINE16)? form1040Map.get(LineNum1040.LINE16):form1040Map.get(LineNum1040.LINE16+FormConstants.DELIMITER+"1");
        Optional<LineItem> filingStatusLineItem = form1040.getLineItems().stream().filter(
                        lineItem->lineItem.getLineNameTxt().equalsIgnoreCase(LineNum1040.LINE_FS))
                .findFirst();
        //LineItem filingStatusLineItem =  form1040Map.containsKey(LineNum1040.LINE_FS)? form1040Map.get(LineNum1040.LINE_FS):form1040Map.get(LineNum1040.LINE_FS+FormConstants.DELIMITER+"1");

        //TODO : Clean up
        String lineValue5_Amt = form1040LineItem16.isPresent()?getAgreedOrTotal(form1040LineItem16.get(),calcType):"0";
        LineItem lineItem5_Amt = LineItem.builder().lineNameTxt(LineNum4549.LINE5_taxAmt).sequenceNum(taxPeriodSeq).lineValueTxt(lineValue5_Amt).build();
        LineItem lineItem5_FS = LineItem.builder().lineNameTxt(LineNum4549.LINE5_FS)
                .sequenceNum(taxPeriodSeq).lineValueTxt(filingStatusLineItem.get().getPerReturnValueTxt()).build();
        LineItem lineItem5_TM = LineItem.builder().lineNameTxt(LineNum4549.LINE5_TaxMethod)
                .sequenceNum(taxPeriodSeq).lineValueTxt("TAX TABLE").build();
        //TODO : Impelement taxmethod logic
        lineItem5_TMGrp.getLineItems().add(lineItem5_TM);
        lineItem5_FSGrp.getLineItems().add(lineItem5_FS);
        lineItem5.getLineItems().add(lineItem5_Amt);
        lineItemMap.put(LineNum4549.LINE5+FormConstants.DELIMITER+"1", lineItem5);
        lineItemMap.put(LineNum4549.LINE5+FormConstants.DELIMITER+"2", lineItem5_TMGrp);
        lineItemMap.put(LineNum4549.LINE5+FormConstants.DELIMITER+"3", lineItem5_FSGrp);
    }

    /**
     * To Calulate Line 6 of Form 1040 (otherTaxAmt of  Line 16 Form 1040 ))
     * @param form1040Map
     * @param lineItemMap
     * @param taxPeriodSeq
     * @param calcType
     */
    public void calculateAdditionTaxes(Map<String, LineItem> form1040Map, Map<String, LineItem> lineItemMap,String taxPeriodSeq, String calcType){
        LineItem lineItem6 =lineItemMap.containsKey(LineNum4549.LINE6+FormConstants.DELIMITER+"1")
                ? lineItemMap.get((LineNum4549.LINE6+FormConstants.DELIMITER+"1") )
                : LineItem.builder().lineNameTxt(LineNum4549.LINE6).sequenceNum("1").lineItems(new ArrayList<>()).build();
//        Optional<LineItem> form1040Line16_Grp = form1040.getLineItems().stream().filter(
//                        lineItem->lineItem.getLineNameTxt().equalsIgnoreCase(LineNum1040.LINE16Grp))
//                .findFirst();
         Optional<LineItem> form1040Line16_Grp = Optional.ofNullable(form1040Map.get(LineNum1040.LINE16Grp+FormConstants.DELIMITER+"1"));
        if(form1040Line16_Grp.isPresent()){
            Optional<LineItem> form1040Line16_othertax =!CollectionUtils.isEmpty(form1040Line16_Grp.get().getLineItems())
                    ? form1040Line16_Grp.get().getLineItems().stream()
                    .filter(lineItem->lineItem.getLineNameTxt()
                            .equalsIgnoreCase(LineNum1040.LINE16of4)).findFirst() : Optional.empty();
            String otherTaxAmt = form1040Line16_othertax.isPresent()? getAgreedOrTotal(form1040Line16_othertax.get(), calcType): "0";
            LineItem lineItem6_othertax = LineItem.builder().lineNameTxt(LineNum4549.LINE6_AddAmt).lineValueTxt(otherTaxAmt).sequenceNum(taxPeriodSeq).build();
            lineItem6.getLineItems().add(lineItem6_othertax);
//            Optional<LineItem> form1040Line17 = form1040.getLineItems().stream().filter(
//                            lineItem->lineItem.getLineNameTxt().equalsIgnoreCase(LineNum1040.LINE17))
//                    .findFirst();
            Optional<LineItem> form1040Line17 = Optional.ofNullable(form1040Map.get(LineNum1040.LINE17+FormConstants.DELIMITER+"1"));
            String additionTaxAmt = form1040Line17.isPresent()?getAgreedOrTotal(form1040Line17.get(), calcType): "0";
            lineItem6_othertax.setLineValueTxt(String.valueOf(new BigDecimal(otherTaxAmt).add(new BigDecimal(additionTaxAmt))));
            lineItem6.getLineItems().add(lineItem6_othertax);
        }
        lineItemMap.put(LineNum4549.LINE6+FormConstants.DELIMITER+"1", lineItem6);
    }

    /**
     *
     * @param lineItemMap
     * @param taxPeriodSeq
     */
    public void calculateCorrectedTaxLiability(Map<String, LineItem> lineItemMap, String taxPeriodSeq){
        LineItem lineItem7 = lineItemMap.containsKey(LineNum4549.LINE7 +  FormConstants.DELIMITER+ "1")
                ? lineItemMap.get(LineNum4549.LINE7 + FormConstants.DELIMITER+ "1")
                : LineItem.builder().lineNameTxt(LineNum4549.LINE7).lineItems(new ArrayList<>()).sequenceNum("1").build();

        LineItem lineItem5 = lineItemMap.get(LineNum4549.LINE5 + FormConstants.DELIMITER+ "1");
        LineItem lineItem6 = lineItemMap.get(LineNum4549.LINE6 + FormConstants.DELIMITER+ "1");
        Optional<LineItem> lineItem5_AddAmt =  null != lineItem5 ?
                lineItem5.getLineItems().stream().filter(lineItem->(lineItem.getLineNameTxt().equalsIgnoreCase(LineNum4549.LINE5_taxAmt)
                && lineItem.getSequenceNum().equalsIgnoreCase(taxPeriodSeq))).findFirst(): Optional.empty();
        Optional<LineItem> lineItem6_AddAmt =  null != lineItem6 ?
                lineItem6.getLineItems().stream().filter(lineItem->(lineItem.getLineNameTxt().equalsIgnoreCase(LineNum4549.LINE6_AddAmt)
                && lineItem.getSequenceNum().equalsIgnoreCase(taxPeriodSeq))).findFirst(): Optional.empty();
         BigDecimal lineItem6Value = lineItem6_AddAmt.isPresent()?new BigDecimal(CommonUtility.getDefaultLineValue(lineItem6_AddAmt.get().getLineValueTxt())):BigDecimal.ZERO;
         BigDecimal lineItem5Value = lineItem5_AddAmt.isPresent()?new BigDecimal(CommonUtility.getDefaultLineValue(lineItem5_AddAmt.get().getLineValueTxt())):BigDecimal.ZERO;
         LineItem lineItem7_LiabAmt =  LineItem.builder().lineNameTxt(LineNum4549.LINE7_liabAmt).sequenceNum(taxPeriodSeq).build();
         lineItem7_LiabAmt.setLineValueTxt(String.valueOf(lineItem5Value.add(lineItem6Value)));
         lineItem7.getLineItems().add(lineItem7_LiabAmt);
         lineItemMap.put(LineNum4549.LINE7 +  FormConstants.DELIMITER+ "1", lineItem7);
         //lineItemMap.get(lineItemMap)
    }

    /**
     * To calculate Line 8 a b c of Form 4549
     * @param form1040LineMap
     * @param schedule3
     * @param lineItemMap
     * @param taxPeriodSeq
     */
    public void calculateLessCredits(Map<String, LineItem> form1040LineMap,Form schedule3,Map<String, LineItem> lineItemMap,String  taxPeriodSeq ){
       LineItem lineItem8 = lineItemMap.containsKey(LineNum4549.LINE8 +FormConstants.DELIMITER +"1")
               ?  lineItemMap.get(LineNum4549.LINE8 +FormConstants.DELIMITER +"1")
               : LineItem.builder().lineNameTxt(LineNum4549.LINE8).sequenceNum("1").build();
    }

    /**
     * To determine taxMethod
     * @param SCHDWS
     * @param QDWS
     * @param form1040Line16
     * @return taxMethod
     */
    private String determineTaxMethod(Form SCHDWS, Form QDWS, BigDecimal form1040Line16 ){
        String taxMethod = "Tax Method";
        if(null != SCHDWS){
            taxMethod = "SchD";
        }else if(null != QDWS){
            taxMethod = "QDWS";
        }else if(form1040Line16.compareTo(new BigDecimal(100000))>0){
            taxMethod = "Tax Rate";
        }
        return taxMethod;
    }

    private LineItem getAdjToIncomeLineItem(LineItem lineItem, String calcType, String lineName, String sequence){
        return StringUtils.isNotBlank(CommonUtility.retrieveAdjustmentAmountByCalcType(lineItem, calcType))
                ? LineItem.builder().lineNameTxt(lineName)
                .lineValueTxt(CommonUtility.retrieveAdjustmentAmountByCalcType(lineItem, calcType))
                .sequenceNum(sequence).build() : null;

    }
    private String getAgreedOrTotal( LineItem lineItem, String calcType ){
        if(calcType.equalsIgnoreCase("AGREED") || calcType.equalsIgnoreCase("UNAGREED")){
            return lineItem.getTotalAdjTaxCalcValueTxt();
        }else{
            return lineItem.getAgreedAdjTaxCalcValueTxt();
        }
    }
}