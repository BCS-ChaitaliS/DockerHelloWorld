package gov.irs.jios.service;

import gov.irs.jios.Exception.InvalidFormException;
import gov.irs.jios.config.FormConstants;
import gov.irs.jios.config.LineNum1040;
import gov.irs.jios.config.LineNum4952;
import gov.irs.jios.model.Form;
import gov.irs.jios.model.LineItem;
import gov.irs.jios.utility.CommonUtility;
import gov.irs.jios.utility.TransformationUtilty;
import io.micrometer.common.util.StringUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class CommonWorksheetService {

     /**
     * To generate Report from the Schedule D Tax Worksheet Available in the taxCalcResponse
     * @param forms
     * @param taxYear
     * @return
     */
    public Form generateReportFromTaxCalcResponse(List<Form> forms, String taxYear, String formName,String calcType) {
        try {
            Map<String, Form> formMap = CommonUtility.transformFormsListToMap(forms);
            Form report = null;
            if(formMap.containsKey(formName)) {
                report = TransformationUtilty.transformFormToReport(formMap.get(formName), taxYear, calcType);
            }
            return report;
        } catch (Exception e) {
           throw new InvalidFormException("Failed to process ScheduleDTaxWorkSheet :"+e.getMessage());
        }

    }


    /**
     *
     * @param forms
     * @param taxYear
     * @return
     */

    public Form processForm(List<Form> forms, String taxYear){
        try{

        Form formSchedulDTaxWS = Form.builder().formNum(FormConstants.SCHDWS_2020).build();
        Map<String, String> wslineNames = CommonUtility.retrieveLineNamesFromYaml("SchDTaxWorkSheet",taxYear);
        Map<String, Form> formsMap = CommonUtility.transformFormsListToMap(forms);
        Map<String, LineItem> wsLineMap = new HashMap<>();
        //retrieve form1040 and form 4952 lineitems
        Map<String, LineItem> f1040LineMap = CommonUtility.transformLineItemsListToMap(formsMap.get(FormConstants.FORM1040).getLineItems());
        Map<String, LineItem> f4952LineMap = CommonUtility.transformLineItemsListToMap(formsMap.get(FormConstants.FORM4952).getLineItems());

        //Line 1 and Line 2
        populateForm1040(f1040LineMap, wsLineMap, wslineNames);
        //Line3 and Line 4
        populateForm4952(f4952LineMap, wsLineMap, wslineNames);
        //Line 5
        calculateschdWsL3MinusL4Amt(wsLineMap, wslineNames);

        formSchedulDTaxWS.setLineItems(wsLineMap.values().stream().toList());
        return formSchedulDTaxWS;
        }catch(Exception e){
            log.error("Failed to process scheduleTXWS:"+e.getMessage());
        }
        return null;
    }

    /**
     * To populate Form1040 line 15 and line3a to Line1 and Line 2 of Schedule D Tax Worksheet
     * @param f1040lineMap
     * @param wsLineMap
     * @param lineNames
     */
        public void populateForm1040(Map<String, LineItem> f1040lineMap,Map<String, LineItem> wsLineMap, Map<String, String> lineNames ){
            LineItem lineItem1 = new LineItem(lineNames.get("LINE1"),"0", "1");
            LineItem lineItem2 = new LineItem(lineNames.get("LINE2"), "0", "1");

            if(!f1040lineMap.isEmpty()){
               lineItem1.setLineValueTxt(getDefaultValueIfNull(f1040lineMap.get(LineNum1040.LINE15+"-1").getPerReturnValueTxt()));
               lineItem2.setLineValueTxt(getDefaultValueIfNull(f1040lineMap.get(LineNum1040.LINE3A+"-1").getPerReturnValueTxt()));

          }
            wsLineMap.put(lineItem1.getLineNameTxt(), lineItem1);
            wsLineMap.put(lineItem2.getLineNameTxt(), lineItem2);
        }

    /**
     * To populate form4952 line 4g and line 4e to Line3 and Line 4 of Schedule D Tax Worksheet
     * @param f4952lineMap
     * @param wsLineMap
     * @param lineNames
     */
    public void populateForm4952(Map<String, LineItem> f4952lineMap,Map<String, LineItem> wsLineMap, Map<String, String> lineNames ){
        LineItem lineItem3 = new LineItem(lineNames.get("LINE3"),"0", "1");
        LineItem lineItem4 = new LineItem(lineNames.get("LINE4"), "0", "1");

        if(!f4952lineMap.isEmpty()){
            lineItem3.setLineValueTxt(getDefaultValueIfNull(f4952lineMap.get(LineNum4952.LINE4g+"-1").getPerReturnValueTxt()));
            lineItem4.setLineValueTxt(getDefaultValueIfNull(f4952lineMap.get(LineNum4952.LINE4e+"-1").getPerReturnValueTxt()));

        }
        wsLineMap.put(lineItem3.getLineNameTxt(), lineItem3);
        wsLineMap.put(lineItem4.getLineNameTxt(), lineItem4);
    }

    /**
     * Calculate Line 5 , subtract line 4 from line3 .if zero or less enter 0
     * @param wsLineMap
     * @param lineNames
     */
    public void calculateschdWsL3MinusL4Amt(Map<String,LineItem> wsLineMap, Map<String, String> lineNames ){
        LineItem lineItem3 =wsLineMap.get(lineNames.get("LINE3"));
        LineItem lineItem4 = wsLineMap.get(lineNames.get("LINE4"));

        LineItem lineItem5 = new LineItem(lineNames.get("LINE5"), "0", "1");
        //Subtract line 4 from lin3. If zero or less, enter -0-
        BigDecimal line3Value = new BigDecimal(lineItem3.getLineValueTxt());
        BigDecimal line4Value = new BigDecimal(lineItem4.getLineValueTxt());
        BigDecimal line5Value = line3Value.subtract(line4Value);
        lineItem5.setLineValueTxt((line5Value.compareTo(BigDecimal.ZERO)>0?line5Value:BigDecimal.ZERO).toString());
        wsLineMap.put(lineItem5.getLineNameTxt(), lineItem5);

    }
    private String getDefaultValueIfNull(String value){
        if(StringUtils.isBlank(value)){
            return "0";
        }else{
            return value;
        }
    }
}
