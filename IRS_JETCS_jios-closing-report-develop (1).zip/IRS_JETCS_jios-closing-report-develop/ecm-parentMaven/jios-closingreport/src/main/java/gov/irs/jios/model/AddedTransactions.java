package gov.irs.jios.model;

public class AddedTransactions {

}
