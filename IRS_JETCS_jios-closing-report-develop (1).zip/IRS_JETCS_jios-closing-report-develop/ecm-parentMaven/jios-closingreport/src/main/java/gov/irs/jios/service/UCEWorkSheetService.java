package gov.irs.jios.service;


import gov.irs.jios.config.FormConstants;
import gov.irs.jios.config.LineNum1040;
import gov.irs.jios.config.LineNumUCEWS;
import gov.irs.jios.model.Form;
import gov.irs.jios.model.LineItem;
import gov.irs.jios.utility.CommonUtility;
import io.micrometer.common.util.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class UCEWorkSheetService {


    public Form processReport(List<Form> formsList, String taxYear, String report, String calcType){
       Map<String, Form> formsMap= CommonUtility.transformFormsListToMap(formsList);
       Form form1040 = formsMap.get(FormConstants.FORM1040);
       Form uceWorksheet = Form.builder().formNum(FormConstants.UCE_WORKSHEET).sequenceNum("1").lineItems(new ArrayList<LineItem>()).build();

        Map<String, LineItem> form1040LineItemMap = CommonUtility.transformLineItemsListToMap(form1040.getLineItems());
        Map<String, LineItem> uceWorksheetLineItems = new HashMap<String, LineItem>();
        //TODO : populate form1040 data taxpayer information
        // Line 1 and Line 2 populated from form1040
        populateForm1040ToAdjustments(form1040LineItemMap, uceWorksheetLineItems, calcType);
        //Calculate Line 3
        calculateModifiedAdjGrossIncome(uceWorksheetLineItems);
        uceWorksheet.getLineItems().addAll(uceWorksheetLineItems.values());
        return uceWorksheet;
    }

    public void populateTaxPayerInformation(Map<String, LineItem> form1040LineItemsMap, Map<String, LineItem>  uceWorksheetLineItems, String calcType ){

    }
    public void populateForm1040ToAdjustments(Map<String, LineItem> form1040LineItemsMap,  Map<String, LineItem>  uceWorksheetLineItems, String calcType){
        LineItem line1040Item11 = form1040LineItemsMap.get(LineNum1040.LINE11+FormConstants.DELIMITER+"1");
        LineItem line1040Item10 = form1040LineItemsMap.get(LineNum1040.LINE10A+FormConstants.DELIMITER+"1");
        //Line 1 and 2 of UCE worksheet
        LineItem lineItem1 = new LineItem(LineNumUCEWS.LINE1, CommonUtility.retrieveLineValue(line1040Item11, calcType),"1");
        LineItem lineItem2 = new LineItem(LineNumUCEWS.LINE2, CommonUtility.retrieveLineValue(line1040Item10, calcType),"1");
        // Add the two line items to the uce worksheet
        uceWorksheetLineItems.put(lineItem1.getLineNameTxt()+ FormConstants.DELIMITER +"1", lineItem1);
        uceWorksheetLineItems.put(lineItem2.getLineNameTxt()+FormConstants.DELIMITER+"1", lineItem2);
    }

    public void calculateModifiedAdjGrossIncome(Map<String, LineItem> uceWorkSheetLineItemMap){
        LineItem lineItem1 = uceWorkSheetLineItemMap.get(LineNumUCEWS.LINE1+FormConstants.DELIMITER+"1");
        LineItem lineItem2 = uceWorkSheetLineItemMap.get(LineNumUCEWS.LINE2+FormConstants.DELIMITER+"1");
        BigDecimal lineValue1 = StringUtils.isNotBlank(lineItem1.getLineValueTxt())?new BigDecimal(lineItem1.getLineValueTxt()):BigDecimal.ZERO;
        BigDecimal lineValue2 = StringUtils.isNotBlank(lineItem2.getLineValueTxt())?new BigDecimal(lineItem2.getLineValueTxt()):BigDecimal.ZERO;
        BigDecimal lineValue3 = lineValue1.subtract(lineValue2);
        LineItem lineItem3 = new LineItem(LineNumUCEWS.LINE3,lineValue3.toString(), "1");
        uceWorkSheetLineItemMap.put(lineItem3.getLineNameTxt()+FormConstants.DELIMITER+"1", lineItem3);

    }
}
