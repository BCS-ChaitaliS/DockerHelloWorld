package gov.irs.jios.utility;


import gov.irs.jios.config.FormConstants;
import gov.irs.jios.model.Form;
import gov.irs.jios.model.LineItem;
import gov.irs.jios.model.TaxPeriod;
import io.micrometer.common.util.StringUtils;
import org.springframework.util.CollectionUtils;
import org.yaml.snakeyaml.Yaml;

import java.io.IOException;
import java.io.InputStream;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CommonUtility {
    private static final String SCHD_TAXWORKSHEET_YAML = "SchDTaxWorkSheet";
    private static final String DIVWS_TAXWORKSHEET_YAML = "DivWorksheet";

    private static final String YES = "Y";
    private static final String NO = "N";

    private static final String AGREED = "Agreed";
    private static final String UNAGREED = "Unagreed";
    private static final String PARTIAL = "Partial";
    private static final String TOTAL = "Total";



public static Map<String, String> retrieveLineNamesFromYaml(String formName, String taxYear) throws IOException {
    String filePath = "config/"+getMappingYaml(formName)+".yaml"; // Replace with your YAML file path
    Map<String,String> formLineMap = null;
    InputStream inputStream = CommonUtility.class.getClassLoader().getResourceAsStream(filePath);

        Yaml yaml = new Yaml();
        HashMap<Integer, Object> data = yaml.load(inputStream);
        formLineMap = (HashMap<String, String>) data.get(Integer.valueOf(taxYear.substring(0,4)));
    inputStream.close();
    return formLineMap;

}

public static Map<String, TaxPeriod> transformTaxPeriodListToMap(List<TaxPeriod> taxPeriods){
    HashMap<String, TaxPeriod> taxPeriodHashMap = new HashMap<>();
    if(!CollectionUtils.isEmpty(taxPeriods)){
        taxPeriods.forEach(taxPeriod -> taxPeriodHashMap.put(taxPeriod.getTaxPrd().substring(0,4),taxPeriod));
    }
    return taxPeriodHashMap;
}

public static HashMap<String, Form>  transformFormsListToMap(List<Form> formList){
    HashMap<String, Form> formsMap = new HashMap<>();
    if(!CollectionUtils.isEmpty(formList)){
        formList.forEach(form-> formsMap.put(form.getFormNum(), form));
    }
    return formsMap;
}

public static HashMap<String, LineItem> transformLineItemsListToMap(List<LineItem> lineItemsList) {
    HashMap<String, LineItem> lineItemMap = new HashMap<>();
   if(!CollectionUtils.isEmpty(lineItemsList)){
       lineItemsList.forEach(lineItem->lineItemMap.put
               (StringUtils.isBlank(lineItem.getSequenceNum()) ? lineItem.getLineNameTxt():
                       lineItem.getLineNameTxt()+"-"+lineItem.getSequenceNum(), lineItem));
   }
   return lineItemMap;
}

public static String retrieveLineValue(LineItem lineItem, String calcType){
    String lineValue = "0";
    if(lineItem.getUserAdjustedLineInd().equalsIgnoreCase(YES))
    {
        lineValue = AGREED.equalsIgnoreCase(calcType)|| UNAGREED.equalsIgnoreCase(calcType)?lineItem.getTotalAdjTaxCalcValueTxt():lineItem.getAgreedAdjTaxCalcValueTxt();
    }else{
        lineValue = AGREED.equalsIgnoreCase(calcType)|| UNAGREED.equalsIgnoreCase(calcType)? lineItem.getStatTotalAdjTaxCalcValueTxt(): lineItem.getStatAgreedAdjTaxCalcValueTxt() ;
    }
    return lineValue;
}

    public static String retrieveAdjustmentAmountByCalcType(LineItem lineItem, String calcType){

             return  YES.equalsIgnoreCase(lineItem.getUserAdjustedLineInd())?lineItem.getTotalAdjustmentValueTxt():lineItem.getStatTotalAdjTaxCalcValueTxt();

    }



    public static String getDefaultLineValue(String lineValue){
       if(StringUtils.isNotBlank(lineValue)){
           return lineValue;
       }
       return "0";
    }
    private static String getMappingYaml(String formName){
        switch (formName) {
            case FormConstants.DIVWS_2020:
                return DIVWS_TAXWORKSHEET_YAML;
            case FormConstants.SCHDWS_2020:
                return SCHD_TAXWORKSHEET_YAML;
            default:
                return formName;
        }
    }
}
