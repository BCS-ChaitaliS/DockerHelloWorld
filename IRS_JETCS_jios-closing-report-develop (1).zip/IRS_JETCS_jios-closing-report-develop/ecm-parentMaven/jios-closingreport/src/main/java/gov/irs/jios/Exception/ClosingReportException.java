package gov.irs.jios.Exception;

import java.util.List;

public class ClosingReportException extends RuntimeException {
	
	private final List<String> errors;
	
	public ClosingReportException(String message) {
		super(message);
		this.errors = List.of(message);
	}
	
	public ClosingReportException(List<String> errors) {
		super("Closing failed: " + String.join(", ",errors));
		this.errors = errors;
	}
	
	public List<String> getErrors() {
		return errors;
	}
}
