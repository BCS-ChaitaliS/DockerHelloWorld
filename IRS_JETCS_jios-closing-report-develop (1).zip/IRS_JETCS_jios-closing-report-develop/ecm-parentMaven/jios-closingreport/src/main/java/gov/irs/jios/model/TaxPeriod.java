package gov.irs.jios.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown =true)
@Builder
public class TaxPeriod {

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    String taxPrd;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    String sequenceNum;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    PenaltyCalcResponse penaltyCalcResponse;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    String calcTypeTxt;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    List<Form> forms;


    List<String> reportsRequested;
}
