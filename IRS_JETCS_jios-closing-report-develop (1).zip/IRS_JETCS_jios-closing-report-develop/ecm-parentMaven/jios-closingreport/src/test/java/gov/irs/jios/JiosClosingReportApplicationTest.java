package gov.irs.jios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JiosClosingReportApplicationTest {

	@Test
	void contextLoads() {
	}

}
