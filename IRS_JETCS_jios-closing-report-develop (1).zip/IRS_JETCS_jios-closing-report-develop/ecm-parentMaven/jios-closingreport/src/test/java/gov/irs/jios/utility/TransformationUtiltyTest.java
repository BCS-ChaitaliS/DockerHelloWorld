package gov.irs.jios.utility;

import gov.irs.jios.config.FormConstants;
import gov.irs.jios.model.Form;
import gov.irs.jios.model.LineItem;
import gov.irs.jios.utility.CommonUtility;
import gov.irs.jios.utility.TransformationUtilty;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@ExtendWith(SpringExtension.class)
public class TransformationUtiltyTest {

    @InjectMocks
    private TransformationUtilty transformationUtilty;

    private static final String SCHD_TAXWORKSHEET_YAML = "SchDTaxWorkSheet";

    @Test
    public void testTransformFormToReport() throws Exception {
        Form formSCHDWS = prepareSchDWSheet();
        Form report = transformationUtilty.transformFormToReport(formSCHDWS, "202012","total");
        assertEquals(FormConstants.SCHDWS_2020,report.getFormNum());
        assertEquals("1000", report.getLineItems().get(0).getLineValueTxt());
    }

    private Form prepareSchDWSheet() throws IOException {
        Form form = Form.builder().formNum(FormConstants.SCHDWS_2020).build();
        Map<String, String> lineMap = CommonUtility.retrieveLineNamesFromYaml(SCHD_TAXWORKSHEET_YAML,"202012" );

        List<LineItem> lineItemList = new ArrayList<>();
        for(String line : lineMap.keySet().stream().toList()){
            lineItemList.add(LineItem.builder().lineNameTxt(lineMap.get(line)).sequenceNum("1").perReturnValueTxt("2").totalAdjTaxCalcValueTxt("1000").build());
        }
        form.setLineItems(lineItemList);
        return form;
    }
}
