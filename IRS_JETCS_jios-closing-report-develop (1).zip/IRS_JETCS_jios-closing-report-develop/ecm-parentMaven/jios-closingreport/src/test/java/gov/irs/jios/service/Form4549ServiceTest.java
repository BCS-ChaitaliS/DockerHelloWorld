package gov.irs.jios.service;

import gov.irs.jios.config.FormConstants;
import gov.irs.jios.config.LineNum4549;
import gov.irs.jios.model.Form;
import gov.irs.jios.model.LineItem;
import gov.irs.jios.utility.CommonUtility;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.*;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@ExtendWith(SpringExtension.class)
public class Form4549ServiceTest {

    @InjectMocks
    private Form4549Service form4549Service;
    private static List<String> form1040LineNames = Arrays.asList("/IRS1040/HouseholdEmployeeWagesAmt", "/IRS1040/TipIncomeAmt",
            "/IRS1040/MedicaidWaiverPymtNotRptW2Amt","/IRS1040/OtherEarnedIncomeAmt",
            "/IRS1040/TaxableInterestAmt", "/IRS1040/OrdinaryDividendsAmt", "/IRS1040/TaxableIRAAmt", "/IRS1040/TaxableForeignPensionsTotalAmt");


//    @Test
//    public void testProcessForm(){
//        Form form = getForm4549();
//        form4549Service.processForm(form, "2023");
//        Map<String, LineItem> lineItemMap = CommonUtility.transformLineItemsListToMap(form.getLineItems());
//        assertEquals("4530.00", lineItemMap.get(LineNum4549.LINE2+"-1").getLineItems().get(0).getLineValueTxt());
//
//    }

    @Ignore
    public void testPopulateAdjustmentsToIncome(){
        Map<String, Form> formMap = new HashMap<>();
        Map<String, LineItem> lineItemMap = new HashMap<>();
        formMap.put(FormConstants.FORM1040, getForm1040());
        form4549Service.populateAdjustmentsToIncome(formMap, lineItemMap, "total", "1");
        assertEquals(1,lineItemMap.size());
        assertEquals(16, lineItemMap.get(LineNum4549.LINE1).getLineItems().size());

    }
    @Test
    public void testCalculateTotalAdjustmentAmt(){
        Form form = getForm4549();
        Map<String, LineItem> lineItemMap = CommonUtility.transformLineItemsListToMap(form.getLineItems());
        form4549Service.calculateTotalAdjustmentAmt(lineItemMap);

        assertEquals("4530.00", lineItemMap.get(LineNum4549.LINE2+"-1").getLineItems().get(0).getLineValueTxt());

    }

    private Form getForm4549() {
        List<LineItem> lineItems = new ArrayList<>();
        List<LineItem> subLineItemsList = new ArrayList<>();
        subLineItemsList.add(LineItem.builder().lineNameTxt(LineNum4549.LINE1_AdjName).sequenceNum("1")
                .lineItems(List.of(LineItem.builder().lineValueTxt("4000.00").lineNameTxt(LineNum4549.LINE1_AdjAmt).sequenceNum("1").build())).build());
        subLineItemsList.add(LineItem.builder().lineNameTxt(LineNum4549.LINE1_AdjName).sequenceNum("2")
                .lineItems(List.of(LineItem.builder().lineValueTxt("530.00").lineNameTxt(LineNum4549.LINE1_AdjAmt).sequenceNum("1").build())).build());

        lineItems.add(LineItem.builder().lineNameTxt(LineNum4549.LINE1).lineValueTxt("4000").sequenceNum("1").lineItems(subLineItemsList).build());
        lineItems.add(LineItem.builder().lineNameTxt(LineNum4549.LINE2).lineValueTxt("0").sequenceNum("1").lineItems(List.of(LineItem.builder().lineNameTxt(LineNum4549.LINE2_totAdjAmt).sequenceNum("1").lineValueTxt("0").build())).build());

        return Form.builder().formNum(FormConstants.FORM4549).lineItems(lineItems).build();
    }

    private Form getForm1040(){
        Form form1040 = new Form();
        form1040.setFormNum(FormConstants.FORM1040);
        form1040.setSequenceNum("1");
        form1040.setLineItems(getForm1040LineItems());
        return form1040;
    }
   private List<LineItem> getForm1040LineItems(){
        List<LineItem> lineItemList = new ArrayList<>();
      for(String lineName: form1040LineNames){
          lineItemList.add(LineItem.builder().lineNameTxt(lineName).userAdjustedLineInd("Y").adjustmentStatusCd("N")
                  .perReturnValueTxt("1000").totalAdjustmentValueTxt("500").totalAdjTaxCalcValueTxt("400").agreedAdjTaxCalcValueTxt("300").build());
      }
      return lineItemList;
   }
}

