package gov.irs.jios.penalty.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import gov.irs.jios.common.client.dmi.service.CalculatePenaltyAndInterestService;
import gov.irs.jios.common.client.tr.pojo.PenaltyFlags;
import gov.irs.jios.common.exception.ValidationException;
import gov.irs.jios.common.validation.GenericValidator;
import gov.irs.jios.penalty.request.PenaltyCalculationRequest;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@Tag(name = "Penalty Calculation", description = "Operations related to penalty calculation")
@RequestMapping("/jios-penalties") //TODO /jios-penalties/api/v1.0 - should be property driven or if there is any other better way to handle versioning
public class JiosPenaltyController {

	private final GenericValidator validator;
    
    @Autowired
    private CalculatePenaltyAndInterestService penaltyAndInterestService;
    
    @Autowired
    private ObjectMapper objectMapper;
    
    private static final String LINE_SEPARATOR = System.lineSeparator();
   
    @Value("${spring.profiles.active}")
	private String activeProfile;
    
	public JiosPenaltyController() {
		this.validator = new GenericValidator("validation-rules/1040-penalty-validation-rules.json");
	}
    
    @PostMapping("/api/v1.0/penaltyCalculation")
    public ResponseEntity<?> penaltyCalculation(@RequestBody PenaltyCalculationRequest request) {
        log.debug("Received Penalty Calculation Request");

        HttpHeaders headers = new HttpHeaders();         
        headers.setContentType(MediaType.APPLICATION_JSON);

        try {
            if (request == null) {
            	log.warn("Invalid request");
                return ResponseEntity.badRequest().body("Invalid request");
            }
    
            log.info("Active Profile: {}", activeProfile);
            /*List<String> validationErrors = validator.validate(request);
            if (!validationErrors.isEmpty()) {
                log.warn("Validation errors: {}", validationErrors);
                return ResponseEntity.badRequest().body(validationErrors); //TODO - enable validation back after it is refactored for the latest ECM payload
            }*/
            
            penaltyAndInterestService.computeTaxPrd(request);
            
            PenaltyFlags flags = new PenaltyFlags();
            Set<String> penaltyTypes = penaltyAndInterestService.analyzePenaltyRequest(request, flags);
            log.info("Unique penalty types: {}", penaltyTypes);
            log.info("Analyzed penalty request - ReturnRelated: {}, IssueRelated: {}, Agreed: {}, Total: {}",
                    flags.isReturnRelated, flags.isIssueRelated, flags.isAgreed, flags.isTotal);
            
            // Log the ECM request payload
            try {
                String requestJson = objectMapper.writeValueAsString(request);
                log.info("saveFields - Request JSON from ECM: {}{}", LINE_SEPARATOR, requestJson);
            } catch (JsonProcessingException e) {
                log.error("Error converting ECM Penalty Calculation Request payload to JSON", e);
            }
            
            if (flags.isReturnRelated) {
                log.info("Processing return related penalty calculation");
                JsonNode response = penaltyAndInterestService.calculateReturnRelatedPenaltyInterest(request);
                return createSuccessResponse(response);
            }

            if (flags.isIssueRelated) {
                Map<String, Map<String, String>> trResultMap = new HashMap<>();
                penaltyAndInterestService.processIssueRelatedPenalty(request, trResultMap, flags, penaltyTypes, activeProfile);
                log.info("trResultMap: {}", trResultMap);
                
                Map<String, Map<String, Map<String, String>>> underPaymentMap = penaltyAndInterestService.calculateUnderPayments(request, trResultMap, penaltyTypes, flags);
                log.info("underPaymentMap: {}", underPaymentMap);
                
                ObjectNode response = penaltyAndInterestService.calculateIssueRelatedPenalties(request, underPaymentMap, penaltyTypes);
                return createSuccessResponse(response);
            }
        }
        catch (ValidationException e) {
            log.error("ValidationException occurred during Penalty Calculation", e);
            return new ResponseEntity<>(e.getMessage(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        catch (Exception e) {
            log.error("Exception occurred during Penalty Calculation", e);
            return new ResponseEntity<>("An unexpected error occurred: " + e.getMessage(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        
        return new ResponseEntity<>("Empty Response", headers, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    
    private ResponseEntity<JsonNode> createSuccessResponse(JsonNode response) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return new ResponseEntity<>(response, headers, HttpStatus.OK);
    }
}