package gov.irs.jios.penalty.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class JiosHeader {


    private String taxPrd;


    private String mftCd;


    private String uniqueCalculationId;


    private String calcDt;


    private String reportDt;


    private String caseId;


    private String submitterId;


    private String calcTypeTxt;


}
