package gov.irs.jios.penalty.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import gov.irs.jios.common.client.dmi.service.CalculatePenaltyAndInterestService;
import gov.irs.jios.common.client.tr.pojo.PenaltyFlags;
import gov.irs.jios.common.exception.ValidationException;
import gov.irs.jios.common.validation.GenericValidator;
import gov.irs.jios.penalty.request.PenaltyCalculationRequest;

@ExtendWith(MockitoExtension.class)
class JiosPenaltyControllerTest {

    @Mock
    private CalculatePenaltyAndInterestService penaltyAndInterestService;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private GenericValidator validator;

    @InjectMocks
    private JiosPenaltyController penaltyController;

    private PenaltyCalculationRequest validRequest;
    private ObjectNode mockResponse;
    private Map<String, Object> header;
    private Map<String, List<String>> penalties;

    @BeforeEach
    void setUp() {
        validRequest = new PenaltyCalculationRequest();
        mockResponse = new ObjectMapper().createObjectNode();
        
        // Set up basic request structure
        header = new HashMap<>();
        penalties = new HashMap<>();
        header.put("Penalties", penalties);
        validRequest.setHeader(header);
        
        // Set active profile using reflection
        ReflectionTestUtils.setField(penaltyController, "activeProfile", "test");
    }

    @Test
    void whenRequestIsNull_thenReturnBadRequest() {
        ResponseEntity<?> response = penaltyController.penaltyCalculation(null);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Invalid request", response.getBody());
    }

    @Test
    void whenReturnRelatedPenalty_thenProcessSuccessfully() throws Exception {
        // Arrange
        PenaltyFlags flags = new PenaltyFlags();
        flags.isReturnRelated = true;
        Set<String> penaltyTypes = new HashSet<>();
        
        doNothing().when(penaltyAndInterestService).computeTaxPrd(any());
        when(penaltyAndInterestService.analyzePenaltyRequest(any(), any(PenaltyFlags.class)))
            .thenAnswer(invocation -> {
                PenaltyFlags flagsArg = invocation.getArgument(1);
                flagsArg.isReturnRelated = true;
                return penaltyTypes;
            });
        when(penaltyAndInterestService.calculateReturnRelatedPenaltyInterest(any()))
            .thenReturn(mockResponse);

        // Act
        ResponseEntity<?> response = penaltyController.penaltyCalculation(validRequest);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(penaltyAndInterestService).computeTaxPrd(validRequest);
        verify(penaltyAndInterestService).calculateReturnRelatedPenaltyInterest(validRequest);
    }

    @Test
    void whenIssueRelatedPenalty_thenProcessSuccessfully() throws Exception {
        // Arrange
        PenaltyFlags flags = new PenaltyFlags();
        flags.isIssueRelated = true;
        Set<String> penaltyTypes = new HashSet<>();
        Map<String, Map<String, Map<String, String>>> underPaymentMap = new HashMap<>();
        
        doNothing().when(penaltyAndInterestService).computeTaxPrd(any());
        when(penaltyAndInterestService.analyzePenaltyRequest(any(), any(PenaltyFlags.class)))
            .thenAnswer(invocation -> {
                PenaltyFlags flagsArg = invocation.getArgument(1);
                flagsArg.isIssueRelated = true;
                return penaltyTypes;
            });
            
        when(penaltyAndInterestService.calculateUnderPayments(any(), any(), any(), any()))
            .thenReturn(underPaymentMap);
            
        when(penaltyAndInterestService.calculateIssueRelatedPenalties(any(), any(), any()))
            .thenReturn(mockResponse);

        // Act
        ResponseEntity<?> response = penaltyController.penaltyCalculation(validRequest);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(penaltyAndInterestService).processIssueRelatedPenalty(
            eq(validRequest), 
            any(), 
            any(), 
            eq(penaltyTypes), 
            eq("test")
        );
    }

    @Test
    void whenValidationExceptionOccurs_thenReturnInternalServerError() throws Exception {
        // Arrange
        String errorMessage = "Missing required penalties";
        penalties.put("ReturnPenaltyCd", new ArrayList<>());
        header.put("PenaltyRequest", new ArrayList<>());
        
        doNothing().when(penaltyAndInterestService).computeTaxPrd(any());
        when(penaltyAndInterestService.analyzePenaltyRequest(any(), any(PenaltyFlags.class)))
            .thenThrow(new ValidationException(errorMessage));

        // Act
        ResponseEntity<?> response = penaltyController.penaltyCalculation(validRequest);

        // Assert
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals(errorMessage, response.getBody());
        verify(penaltyAndInterestService).computeTaxPrd(validRequest);
        verify(penaltyAndInterestService).analyzePenaltyRequest(eq(validRequest), any(PenaltyFlags.class));
    }

    @Test
    void whenUnexpectedExceptionOccurs_thenReturnInternalServerError() throws Exception {
        // Arrange
        String errorMessage = "Missing required penalties";
        penalties.put("ReturnPenaltyCd", new ArrayList<>());
        header.put("PenaltyRequest", new ArrayList<>());
        
        doNothing().when(penaltyAndInterestService).computeTaxPrd(any());
        when(penaltyAndInterestService.analyzePenaltyRequest(any(), any(PenaltyFlags.class)))
            .thenThrow(new RuntimeException(errorMessage));

        // Act
        ResponseEntity<?> response = penaltyController.penaltyCalculation(validRequest);

        // Assert
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("An unexpected error occurred: " + errorMessage, response.getBody());
        verify(penaltyAndInterestService).computeTaxPrd(validRequest);
        verify(penaltyAndInterestService).analyzePenaltyRequest(eq(validRequest), any(PenaltyFlags.class));
    }

    @Test
    void whenNoFlagsSet_thenReturnEmptyResponse() throws Exception {
        // Arrange
        Set<String> penaltyTypes = new HashSet<>();
        penalties.put("ReturnPenaltyCd", new ArrayList<>());
        header.put("PenaltyRequest", new ArrayList<>());
        
        doNothing().when(penaltyAndInterestService).computeTaxPrd(any());
        when(penaltyAndInterestService.analyzePenaltyRequest(any(), any(PenaltyFlags.class)))
            .thenReturn(penaltyTypes);

        // Act
        ResponseEntity<?> response = penaltyController.penaltyCalculation(validRequest);

        // Assert
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Empty Response", response.getBody());
        verify(penaltyAndInterestService).computeTaxPrd(validRequest);
        verify(penaltyAndInterestService).analyzePenaltyRequest(eq(validRequest), any(PenaltyFlags.class));
    }
}