package gov.irs.jios.common.client.transformer;
import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;

public class StandardDeductionIndicatorTransformer {
	private static final BiMap<String, String> STD_DED_IND_MAP = ImmutableBiMap.of("X", "B", // force itemized
																								// deductions
			"", "A" // force std ded amt
	);
	public String transformEcmToTr(String ecmStdDedIndicator) {
		String trStatus = STD_DED_IND_MAP.get(ecmStdDedIndicator);
		if (trStatus == null) {
			throw new IllegalArgumentException("Invalid ECM Standard Deduction Indicator code: " + ecmStdDedIndicator);
		}
		return trStatus;
	}
	public String transformTrToECM(String trStdDedIndicator) {
		String ecmStatus = STD_DED_IND_MAP.inverse()
				.get(trStdDedIndicator != null ? trStdDedIndicator.toUpperCase() : "");
		if (ecmStatus == null) {
			throw new IllegalArgumentException("Invalid TR Standard Deduction Indicator code: " + trStdDedIndicator);
		}
		return ecmStatus;
	}
}
