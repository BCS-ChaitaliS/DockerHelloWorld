package gov.irs.jios.common.client.transformer;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class MealsAndBusExpenseTransformer {

    /**
     * Business requirements set by Josh require that we multiply our sent value by 2. Apparently,
     * TR halves the value we send in and we don't want that. 
     */
	public String multiplyECMByTwo(String ecmPayloadValue) {
        try {
            float value = Float.parseFloat(ecmPayloadValue);
            float doubledValue = value * 2;
            return Float.toString(doubledValue);
        } catch (NumberFormatException e) {
            log.warn("MealsAndBusExpenseTransformer: Invalid data: " + ecmPayloadValue);
            return "0";
        }
    }
	
    /**
     * The transformation only needed to happen one way, so this just returns the value found in TR. 
     */
    public String transformTrToEcm(String trValue) {
        return trValue;
    }
}