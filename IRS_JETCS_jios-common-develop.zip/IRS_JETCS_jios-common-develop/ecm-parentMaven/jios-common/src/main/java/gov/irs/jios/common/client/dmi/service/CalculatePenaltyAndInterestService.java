package gov.irs.jios.common.client.dmi.service;

import static gov.irs.jios.common.util.JiosCommonConstants.PCT_20_PENALTY_TYPES;
import static gov.irs.jios.common.util.JiosCommonConstants.PCT_40_PENALTY_TYPES;
import static gov.irs.jios.common.util.JiosCommonConstants.PCT_75_PENALTY_TYPES;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.irs.jios.common.client.dmi.pojo.AccCalc;
import gov.irs.jios.common.client.dmi.pojo.CalcInfo;
import gov.irs.jios.common.client.dmi.pojo.PICalculationRequest;
import gov.irs.jios.common.client.dmi.pojo.PenMain;
import gov.irs.jios.common.request.ValidatableRequest;
import gov.irs.jios.common.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CalculatePenaltyAndInterestService {
    
    private final WebClient webClient;
    
    @Autowired
    private ObjectMapper objectMapper;

    public CalculatePenaltyAndInterestService(
            WebClient.Builder webClientBuilder,
            @Value("${pi.calculation.api.url:\"\"}") String apiUrl) {
        this.webClient = webClientBuilder.baseUrl(apiUrl).build();
    }

    public JsonNode calculatePenaltyAndInterest(ValidatableRequest inputPayload, Map<String, String> resultMap, Set<String> penaltyTypes) {
        PICalculationRequest request = null;
        if (penaltyTypes == null) {
        	request = createPIRequest(inputPayload);
        }
        else {
        	request = createPIRequestForIssueRelated(inputPayload, resultMap, penaltyTypes);
        }
        log.info("PICalculationRequest: {}", request);
        
        //This section is only for printing the DMI request payload
  		try {
  			String sfRequestsJson = objectMapper.writeValueAsString(request);
  			log.info("calculatePenaltyAndInterest - Request JSON to DMI: {}", sfRequestsJson);
  		} catch (JsonProcessingException e) {
  			log.error("Error converting DMI PICalculationRequest to JSON", e);
  		}
        
        return webClient.post()
                .uri("/api/PIcalc")
                .bodyValue(request)
                .retrieve()
                .bodyToMono(JsonNode.class)
                .doOnError(error -> log.error("Error calling PI calculation service: ", error))
                .doOnSuccess(response -> log.debug("Successfully received PI calculation response"))
                .blockOptional(Duration.ofSeconds(30))
                .orElseThrow(() -> new RuntimeException("No response received from calculation service"));
    }

    @SuppressWarnings("unchecked")
    private PICalculationRequest createPIRequest(ValidatableRequest inputPayload) {
        PICalculationRequest request = new PICalculationRequest();
        
        // Get header and CalcInfo maps
        Map<String, Object> header = inputPayload.getHeader();
        Map<String, Object> calcInfoMap = (Map<String, Object>) header.get("CalcInfo");
        
        // Get PenaltyRequest list from header
        List<Map<String, Object>> penaltyRequests = (List<Map<String, Object>>) header.get("PenaltyRequest");
        if (penaltyRequests == null || penaltyRequests.isEmpty()) {
            log.error("No PenaltyRequest found in header");
            throw new IllegalArgumentException("No PenaltyRequest found in header");
        }
        
        // Get the first PenaltyRequest (as it contains the penalty information we need)
        Map<String, Object> penaltyRequest = penaltyRequests.get(0);
        
        // Set AgreedCd from PenaltyRequest
        String agreedCd = (String) penaltyRequest.get("AgreedCd");
        request.setAgreedCd(agreedCd);
        
        // Create and populate CalcInfo
        CalcInfo calcInfo = new CalcInfo();
        String originalTin = String.valueOf(calcInfoMap.get("tin"));
        String formattedTin = CommonUtil.formatTIN(originalTin);
        calcInfo.setTin(formattedTin);
        calcInfo.setMftCd(String.valueOf(calcInfoMap.get("mftCd")));
        calcInfo.setTaxYr(String.valueOf(calcInfoMap.get("taxYr")));
        //calcInfo.setTaxYr("2014"); //TODO - remove this line later
        calcInfo.setTaxMonthNum(String.valueOf(calcInfoMap.get("taxMonthNum")));
        calcInfo.setDueDt(String.valueOf(calcInfoMap.get("dueDt")));
        calcInfo.setExtendedDueDt(String.valueOf(calcInfoMap.get("extendedDueDt")));
        calcInfo.setReturnDt(String.valueOf(calcInfoMap.get("returnDt")));
        calcInfo.setReportDt(String.valueOf(calcInfoMap.get("reportDt")));
        calcInfo.setRunToDt(String.valueOf(calcInfoMap.get("runToDt")));
        calcInfo.setTaxDt(String.valueOf(calcInfoMap.get("taxDt")));
        calcInfo.setTransactionCd(String.valueOf(calcInfoMap.get("transactionCd")));
        calcInfo.setServerTxt(String.valueOf(calcInfoMap.get("serverTxt")));
        calcInfo.setResponseReturnCd(String.valueOf(calcInfoMap.get("responseReturnCd")));
        
        // Get interestPenaltyCd from PenaltyRequest instead of CalcInfo
        List<String> interestPenaltyCd = (List<String>) penaltyRequest.get("interestPenaltyCd");
        calcInfo.setInterestPenaltyCd(interestPenaltyCd);
        
        // Set tax amount from TotalTaxAmt
        double taxAmt = findTotalTaxAmount(inputPayload);
        calcInfo.setTaxAmt(taxAmt);
        request.setCalcInfo(calcInfo);
        
        // Get PenMain from PenaltyRequest instead of header
        List<Map<String, Object>> penMainMapList = (List<Map<String, Object>>) penaltyRequest.get("PenMain");
        List<PenMain> penMainList = new ArrayList<>();
        if (penMainMapList != null) {
            for (Map<String, Object> penMainMap : penMainMapList) {
                PenMain penMain = new PenMain();
                penMain.setPenaltySectionCd(String.valueOf(penMainMap.get("penaltySectionCd")));
                penMainList.add(penMain);
            }
        }
        request.setPenMain(penMainList);
        
        // Get Acc_Calc from PenaltyRequest
        List<Map<String, Object>> accCalcMapList = (List<Map<String, Object>>) penaltyRequest.get("Acc_Calc");
        List<AccCalc> accCalcList = new ArrayList<>();
        if (accCalcMapList != null) {
            for (Map<String, Object> accCalcMap : accCalcMapList) {
                AccCalc accCalc = new AccCalc();
                accCalc.setPenaltySectionCd(String.valueOf(accCalcMap.get("penaltySectionCd")));
                
                // Handle penaltyRt as it could be String or Integer
                Object penaltyRt = accCalcMap.get("penaltyRt");
                if (penaltyRt != null) {
                    if (penaltyRt instanceof Integer) {
                        accCalc.setPenaltyRt((Integer) penaltyRt);
                    } else {
                        accCalc.setPenaltyRt(Integer.parseInt(String.valueOf(penaltyRt)));
                    }
                }
                
                String assessmentAmt = String.valueOf(accCalcMap.get("assessmentAmt"));
                if (assessmentAmt != null && !assessmentAmt.isEmpty() && !"null".equals(assessmentAmt)) {
                    accCalc.setAssessmentAmt(Double.parseDouble(assessmentAmt));
                } else {
                    accCalc.setAssessmentAmt(taxAmt); // Use calculated taxAmt if assessmentAmt is not provided
                }
                
                accCalc.setAssessmentDt(String.valueOf(accCalcMap.get("assessmentDt")));
                
                String previouslyAssessedPenaltyAmt = String.valueOf(accCalcMap.get("previouslyAssessedPenaltyAmt"));
                if (previouslyAssessedPenaltyAmt != null && !previouslyAssessedPenaltyAmt.isEmpty() && !"null".equals(previouslyAssessedPenaltyAmt)) {
                    accCalc.setPreviouslyAssessedPenaltyAmt(previouslyAssessedPenaltyAmt);
                }
                
                accCalcList.add(accCalc);
            }
        }
        request.setAcc_Calc(accCalcList);
        
        // Set empty lists for FTP-related fields
        request.setFTP_Calc(new ArrayList<>());
        request.setFTP_Not(new ArrayList<>());
        request.setFTP_Agreements(new ArrayList<>());
        
        return request;
    }
    
    @SuppressWarnings("unchecked")
    private PICalculationRequest createPIRequestForIssueRelated(ValidatableRequest inputPayload, Map<String, String> resultMap, Set<String> penaltyTypes) {
        PICalculationRequest request = new PICalculationRequest();
        
        // Get header and CalcInfo maps
        Map<String, Object> header = inputPayload.getHeader();
        Map<String, Object> calcInfoMap = (Map<String, Object>) header.get("CalcInfo");
        
        // Get PenaltyRequest list from header
        List<Map<String, Object>> penaltyRequests = (List<Map<String, Object>>) header.get("PenaltyRequest");
        if (penaltyRequests == null || penaltyRequests.isEmpty()) {
            log.error("No PenaltyRequest found in header");
            throw new IllegalArgumentException("No PenaltyRequest found in header");
        }
        
        // Get the first PenaltyRequest (as it contains the penalty information we need)
        Map<String, Object> penaltyRequest = penaltyRequests.get(0);
        
        // Set AgreedCd from PenaltyRequest
        String agreedCd = (String) penaltyRequest.get("AgreedCd");
        request.setAgreedCd(agreedCd);
        
        // Create and populate CalcInfo
        CalcInfo calcInfo = new CalcInfo();
        String originalTin = String.valueOf(calcInfoMap.get("tin"));
        String formattedTin = CommonUtil.formatTIN(originalTin);
        calcInfo.setTin(formattedTin);
        calcInfo.setMftCd(String.valueOf(calcInfoMap.get("mftCd")));
        //calcInfo.setTaxYr(String.valueOf(calcInfoMap.get("taxYr")));
        calcInfo.setTaxYr("2014"); //TODO - remove this line later
        calcInfo.setTaxMonthNum(String.valueOf(calcInfoMap.get("taxMonthNum")));
        calcInfo.setDueDt(String.valueOf(calcInfoMap.get("dueDt")));
        calcInfo.setExtendedDueDt(String.valueOf(calcInfoMap.get("extendedDueDt")));
        calcInfo.setReturnDt(String.valueOf(calcInfoMap.get("returnDt")));
        calcInfo.setReportDt(String.valueOf(calcInfoMap.get("reportDt")));
        calcInfo.setRunToDt(String.valueOf(calcInfoMap.get("runToDt")));
        calcInfo.setTaxDt(String.valueOf(calcInfoMap.get("taxDt")));
        calcInfo.setTransactionCd(String.valueOf(calcInfoMap.get("transactionCd")));
        calcInfo.setServerTxt(String.valueOf(calcInfoMap.get("serverTxt")));
        calcInfo.setResponseReturnCd(String.valueOf(calcInfoMap.get("responseReturnCd")));
        
        // Get interestPenaltyCd from PenaltyRequest instead of CalcInfo
        List<String> interestPenaltyCd = (List<String>) penaltyRequest.get("interestPenaltyCd");
        calcInfo.setInterestPenaltyCd(interestPenaltyCd);
        
        // Set tax amount from TotalTaxAmt
        double taxAmt = findTotalTaxAmount(inputPayload);
        calcInfo.setTaxAmt(taxAmt);
        request.setCalcInfo(calcInfo);
        
        // Get PenMain from PenaltyRequest instead of header
        List<Map<String, Object>> penMainMapList = (List<Map<String, Object>>) penaltyRequest.get("PenMain");
        List<PenMain> penMainList = new ArrayList<>();
        if (penMainMapList != null) {
            for (Map<String, Object> penMainMap : penMainMapList) {
                PenMain penMain = new PenMain();
                penMain.setPenaltySectionCd(String.valueOf(penMainMap.get("penaltySectionCd")));
                penMainList.add(penMain);
            }
        }
        request.setPenMain(penMainList);
        
        List<AccCalc> accCalcList = new ArrayList();
        if (hasPct20PenaltyType(penaltyTypes)) {
        	accCalcList.addAll(createAccCalcList(penaltyRequest, penaltyTypes, resultMap, 0));
        } 
        if (hasPct40PenaltyType(penaltyTypes)) {
        	accCalcList.addAll(createAccCalcList(penaltyRequest, penaltyTypes, resultMap, 0));
        }
        if (hasPct75PenaltyType(penaltyTypes)) {
        	accCalcList.addAll(createAccCalcList(penaltyRequest, penaltyTypes, resultMap, 0));
        }
        
        request.setAcc_Calc(accCalcList);
        
        // Set empty lists for FTP-related fields
        request.setFTP_Calc(new ArrayList<>());
        request.setFTP_Not(new ArrayList<>());
        request.setFTP_Agreements(new ArrayList<>());
        
        return request;
    }

    @SuppressWarnings("unchecked")
    private double findTotalTaxAmount(ValidatableRequest inputPayload) {
        Map<String, Object> body = inputPayload.getBody();
        List<Map<String, Object>> forms = (List<Map<String, Object>>) body.get("forms");
        
        for (Map<String, Object> form : forms) {
            if (!"IRS1040".equals(form.get("formNum"))) {
                continue;
            }
            
            List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get("lineItems");
            for (Map<String, Object> lineItem : lineItems) {
                String lineNameTxt = (String) lineItem.get("lineNameTxt");
                if ("/IRS1040/TotalTaxAmt".equals(lineNameTxt)) {
                    String perReturnValueTxt = (String) lineItem.get("perReturnValueTxt");
                    String totalAdjTaxCalcValueTxt = (String) lineItem.get("totalAdjTaxCalcValueTxt");
                    
                    if (perReturnValueTxt != null && !perReturnValueTxt.isEmpty() && 
                        CommonUtil.isNumeric(perReturnValueTxt) && 
                        totalAdjTaxCalcValueTxt != null && !totalAdjTaxCalcValueTxt.isEmpty() && 
                        CommonUtil.isNumeric(totalAdjTaxCalcValueTxt)) {
                        try {
                            BigDecimal total = new BigDecimal(totalAdjTaxCalcValueTxt);
                            BigDecimal perReturn = new BigDecimal(perReturnValueTxt);
                            return total.subtract(perReturn).doubleValue();
                        } catch (NumberFormatException e) {
                            log.warn("Error calculating tax amount difference: ", e);
                        }
                    }
                    break;
                }
            }
        }
        return 0.0;
    }
    
    private boolean hasPct20PenaltyType(Set<String> penaltyTypes) {
        return penaltyTypes.stream().anyMatch(PCT_20_PENALTY_TYPES::contains);
    }
    
    /*private boolean hasPct30PenaltyType(Set<String> penaltyTypes) {
        return penaltyTypes.stream().anyMatch(PCT_30_PENALTY_TYPES::contains);
    }*/
    
    private boolean hasPct40PenaltyType(Set<String> penaltyTypes) {
        return penaltyTypes.stream().anyMatch(PCT_40_PENALTY_TYPES::contains);
    }
    
    private boolean hasPct75PenaltyType(Set<String> penaltyTypes) {
        return penaltyTypes.stream().anyMatch(PCT_75_PENALTY_TYPES::contains);
    }
    
    @SuppressWarnings("unchecked")
    private List<AccCalc> createAccCalcList(Map<String, Object> penaltyRequest, Set<String> penaltyTypes, 
            Map<String, String> resultMap, double defaultTaxAmt) {
        
        List<AccCalc> accCalcList = new ArrayList<>();
        List<Map<String, Object>> accCalcMapList = (List<Map<String, Object>>) penaltyRequest.get("Acc_Calc");
        
        if (accCalcMapList != null) {
            for (Map<String, Object> accCalcMap : accCalcMapList) {
                AccCalc accCalc = new AccCalc();
                String penaltySectionCd = String.valueOf(accCalcMap.get("penaltySectionCd"));
                accCalc.setPenaltySectionCd(penaltySectionCd);
                
                // Set penalty rate
                Object penaltyRt = accCalcMap.get("penaltyRt");
                if (penaltyRt != null) {
                    if (penaltyRt instanceof Integer) {
                        accCalc.setPenaltyRt((Integer) penaltyRt);
                    } else {
                        accCalc.setPenaltyRt(Integer.parseInt(String.valueOf(penaltyRt)));
                    }
                }
                
                // Set assessment amount based on penalty types
                double assessmentAmt = determineAssessmentAmount(accCalcMap, penaltyTypes, resultMap, defaultTaxAmt);
                accCalc.setAssessmentAmt(assessmentAmt);
                
                // Set assessment date
                accCalc.setAssessmentDt(String.valueOf(accCalcMap.get("assessmentDt")));
                
                // Set previously assessed penalty amount
                String previouslyAssessedPenaltyAmt = String.valueOf(accCalcMap.get("previouslyAssessedPenaltyAmt"));
                if (previouslyAssessedPenaltyAmt != null && !previouslyAssessedPenaltyAmt.isEmpty() 
                        && !"null".equals(previouslyAssessedPenaltyAmt)) {
                    accCalc.setPreviouslyAssessedPenaltyAmt(previouslyAssessedPenaltyAmt);
                }
                
                accCalcList.add(accCalc);
            }
        }
        
        return accCalcList;
    }

    private double determineAssessmentAmount(Map<String, Object> accCalcMap, Set<String> penaltyTypes, 
            Map<String, String> resultMap, double defaultTaxAmt) {
            
        // First check if assessment amount is provided in the map
        String assessmentAmt = String.valueOf(accCalcMap.get("assessmentAmt"));
        if (assessmentAmt != null && !assessmentAmt.isEmpty() && !"null".equals(assessmentAmt)) {
            return Double.parseDouble(assessmentAmt);
        }
        
        // If no direct assessment amount, determine based on penalty types
        if (hasPct20PenaltyType(penaltyTypes)) {
            String amt = resultMap.get("UnderpaymentSubjectTo20PctPenaltyForAgreed");
            if (amt != null && !amt.isEmpty()) {
                return Double.parseDouble(amt);
            }
        }
        
        if (hasPct40PenaltyType(penaltyTypes)) {
            String amt = resultMap.get("UnderpaymentSubjectTo40PctPenaltyForAgreed");
            if (amt != null && !amt.isEmpty()) {
                return Double.parseDouble(amt);
            }
        }
        
        if (hasPct75PenaltyType(penaltyTypes)) {
            String amt = resultMap.get("UnderpaymentSubjectTo75PctPenaltyForAgreed");
            if (amt != null && !amt.isEmpty()) {
                return Double.parseDouble(amt);
            }
        }
        
        // If no specific amount found, return default tax amount
        return defaultTaxAmt;
    }
}