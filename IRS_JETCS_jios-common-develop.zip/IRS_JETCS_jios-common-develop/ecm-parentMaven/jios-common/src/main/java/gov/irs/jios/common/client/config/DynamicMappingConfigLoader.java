package gov.irs.jios.common.client.config;

import java.io.IOException;
import java.io.InputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.irs.jios.common.client.tr.pojo.MappingConfig;
import gov.irs.jios.common.exception.ConfigurationException;

@Component
public class DynamicMappingConfigLoader {

	private static final String CONFIG_PATH = "mapping-configs/";
	private static final String DEFAULT_CONFIG = "default_mapping-config.json";

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private ResourceLoader resourceLoader;

	public MappingConfig loadMappingConfig(String taxYear) {
		String configFileName = taxYear + "_mapping-config.json";
		Resource resource = resourceLoader.getResource("classpath:" + CONFIG_PATH + configFileName);

		if (!resource.exists()) {
			// Fall back to default config if specific config doesn't exist
			resource = resourceLoader.getResource("classpath:" + CONFIG_PATH + DEFAULT_CONFIG);
		}
		
		try (InputStream is = resource.getInputStream()) {
            return objectMapper.readValue(is, MappingConfig.class);
        } catch (IOException e) {
            throw new ConfigurationException("Failed to load mapping configuration for tax year: " + taxYear, e);
        }
	}
}