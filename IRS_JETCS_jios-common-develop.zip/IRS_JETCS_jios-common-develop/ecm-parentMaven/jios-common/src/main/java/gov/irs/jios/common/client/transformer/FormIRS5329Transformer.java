package gov.irs.jios.common.client.transformer;

import static gov.irs.jios.common.util.JiosCommonConstants.PRIMARY_TIN;
import static gov.irs.jios.common.util.JiosCommonConstants.SECONDARY_TIN;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_ITEMS;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_NAME_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.PER_RETURN_VALUE_TXT;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FormIRS5329Transformer {
	
	public static final String IRS5329 = "IRS5329";
	
    public List<FieldMapping> transformFormIRS5329(Map<String, Object> formData, Map<String, Object> header) {
    	List<FieldMapping> fieldMappings = new ArrayList<>();

        if (formData == null || header == null) {
            log.warn("FormData or header is null. Returning empty field mappings.");
            return fieldMappings;
        }

        String ssn = extractSSN(formData);
        if (ssn == null) {
            log.warn("Unable to extract SSN from formData. Returning empty field mappings.");
            return fieldMappings;
        }
        
        String primaryTIN = (String) header.get(PRIMARY_TIN);
        String secondaryTIN = (String) header.get(SECONDARY_TIN);

        if (primaryTIN == null && secondaryTIN == null) {
            log.warn("Both primaryTIN and spouseTIN are null in header. Returning empty field mappings.");
            return fieldMappings;
        }
        
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
        if (lineItems == null) {
            log.warn("No lineItems found in formData");
            return fieldMappings;
        }

        if (Objects.equals(ssn, primaryTIN)) {
        	addFieldMapping(fieldMappings, "/IRS5329/EarlyDistributionsAmt", "RET.TEARLY");
            addFieldMapping(fieldMappings, "/IRS5329/EarlyDistriExceptionReasonCd", "RET.TXNUM");
            addFieldMapping(fieldMappings, "/IRS5329/EarlyDistriNotSubjectToTaxAmt", "RET.TADLTAX");
			addFieldMapping(fieldMappings, "/IRS5329/EducAcctDistriNotSubjToTaxAmt", "RET.TEDEXCEPT");
            addFieldMapping(fieldMappings, "/IRS5329/IRAExcessContriPriorYearAmt", "X127.314.1");
            addFieldMapping(fieldMappings, "/IRS5329/IRAExcessContriCreditAmt", "RET.TCONTCRED");
            addFieldMapping(fieldMappings, "/IRS5329/IRADistriIncludedInIncomeAmt", "RET.TIRA");
            addFieldMapping(fieldMappings, "/IRS5329/IRAExcessContriWithdrawnAmt", "RET.TWITHD");
            addFieldMapping(fieldMappings, "/IRS5329/IRAExcessContriCurrentYearAmt", "RET.TXCSCONTOVR");
            addFieldMapping(fieldMappings, "/IRS5329/RothIRAExcessContriPriorYrAmt", "X127.314.3");
            addFieldMapping(fieldMappings, "/IRS5329/RothIRAExcessContriCreditAmt", "X127.315.3");
            addFieldMapping(fieldMappings, "/IRS5329/RothIRAExcessContriCYAmt", "X127.302.15");
            addFieldMapping(fieldMappings, "/IRS5329/ESAExcessContriPriorYearAmt", "X127.314.5");
            addFieldMapping(fieldMappings, "/IRS5329/ESAExcessContriCreditAmt", "X127.315.11");
            addFieldMapping(fieldMappings, "/IRS5329/ESAExcessContriCYAmt", "X127.302.17");
            addFieldMapping(fieldMappings, "/IRS5329/ArcherMSAExcessContriPrYrAmt", "X127.314.7");
            addFieldMapping(fieldMappings, "/IRS5329/ArcherMSAExcessContriCreditAmt", "X127.302.25");
            addFieldMapping(fieldMappings, "/IRS5329/TaxableArcherMSADistriAmt", "X127.302.27");
            addFieldMapping(fieldMappings, "/IRS5329/ArcherMSAExcessContriCYAmt", "RET.TMRDIST");
            addFieldMapping(fieldMappings, "/IRS5329/HSAExcessContriPriorYearAmt", "X127.HSAPYT");
            addFieldMapping(fieldMappings, "/IRS5329/HSAExcessContriCreditAmt", "X127.HSACRT");
            addFieldMapping(fieldMappings, "/IRS5329/TaxableHSADistributionAmt", "X127.HSADISTT");
            addFieldMapping(fieldMappings, "/IRS5329/HSAExcessContriCurrentYearAmt", "X127.HSAT");
            addFieldMapping(fieldMappings, "/IRS5329/ABLEExcessContriCYAmt", "ABLEOT1");
            addDynamicFieldMapping(lineItems, fieldMappings, "/IRS5329/QlfyRetirePlanMinRqrDistriAmt", "RET.TCMINREQ", "RET.TMINREQ");
            addDynamicFieldMapping(lineItems, fieldMappings, "/IRS5329/QlfyRetirePlanActualDistriAmt", "RET.TCACTUAL", "RET.TACTUAL");
        } else if (Objects.equals(ssn, secondaryTIN)) {
        	addFieldMapping(fieldMappings, "/IRS5329/EarlyDistributionsAmt", "RET.SEARLY");
            addFieldMapping(fieldMappings, "/IRS5329/EarlyDistriExceptionReasonCd", "RET.SXNUM");
            addFieldMapping(fieldMappings, "/IRS5329/EarlyDistriNotSubjectToTaxAmt", "RET.SADLTAX");
			addFieldMapping(fieldMappings, "/IRS5329/EducAcctDistriNotSubjToTaxAmt", "RET.SEDEXCEPT");
            addFieldMapping(fieldMappings, "/IRS5329/IRAExcessContriPriorYearAmt", "X127.314.2");
            addFieldMapping(fieldMappings, "/IRS5329/IRAExcessContriCreditAmt", "RET.SCONTCRED");
            addFieldMapping(fieldMappings, "/IRS5329/IRADistriIncludedInIncomeAmt", "RET.SIRA");
            addFieldMapping(fieldMappings, "/IRS5329/IRAExcessContriWithdrawnAmt", "RET.SWITHD");
            addFieldMapping(fieldMappings, "/IRS5329/IRAExcessContriCurrentYearAmt", "RET.SXCSCONTOVR");
            addFieldMapping(fieldMappings, "/IRS5329/RothIRAExcessContriPriorYrAmt", "X127.314.4");
            addFieldMapping(fieldMappings, "/IRS5329/RothIRAExcessContriCreditAmt", "X127.315.4");
            addFieldMapping(fieldMappings, "/IRS5329/RothIRAExcessContriCYAmt", "X127.302.16");
            addFieldMapping(fieldMappings, "/IRS5329/ESAExcessContriPriorYearAmt", "X127.314.6");
            addFieldMapping(fieldMappings, "/IRS5329/ESAExcessContriCreditAmt", "X127.315.12");
            addFieldMapping(fieldMappings, "/IRS5329/ESAExcessContriCYAmt", "X127.302.18");
            addFieldMapping(fieldMappings, "/IRS5329/ArcherMSAExcessContriPrYrAmt", "X127.314.8");
            addFieldMapping(fieldMappings, "/IRS5329/ArcherMSAExcessContriCreditAmt", "X127.302.26");
            addFieldMapping(fieldMappings, "/IRS5329/TaxableArcherMSADistriAmt", "X127.302.28");
            addFieldMapping(fieldMappings, "/IRS5329/ArcherMSAExcessContriCYAmt", "RET.SMRDIST");
            addFieldMapping(fieldMappings, "/IRS5329/HSAExcessContriPriorYearAmt", "X127.HSAPYS");
            addFieldMapping(fieldMappings, "/IRS5329/HSAExcessContriCreditAmt", "X127.HSACRS");
            addFieldMapping(fieldMappings, "/IRS5329/TaxableHSADistributionAmt", "X127.HSADISTS");
            addFieldMapping(fieldMappings, "/IRS5329/HSAExcessContriCurrentYearAmt", "X127.HSAS");
            addFieldMapping(fieldMappings, "/IRS5329/ABLEExcessContriCYAmt", "ABLEOS1");
            addDynamicFieldMapping(lineItems, fieldMappings, "/IRS5329/QlfyRetirePlanMinRqrDistriAmt", "RET.SCMINREQ", "RET.SMINREQ");
            addDynamicFieldMapping(lineItems, fieldMappings, "/IRS5329/QlfyRetirePlanActualDistriAmt", "RET.SCACTUAL", "RET.SACTUAL");
        } else {
            log.warn("SSN {} does not match primaryTIN {} or spouseTIN {}. Returning empty field mappings.", ssn, primaryTIN, secondaryTIN);
        }
        
        return fieldMappings;
    }
    
    private void addDynamicFieldMapping(List<Map<String, Object>> lineItems, List<FieldMapping> fieldMappings, String ecmAttribute, String tr10PercentField, String tr25PercentField) {
    	for (Map<String, Object> lineItem : lineItems) {
        	if (ecmAttribute.equals(lineItem.get(LINE_NAME_TXT))) {
        		String attributeValue = (String) lineItem.get(PER_RETURN_VALUE_TXT);
        		if (attributeValue == null || attributeValue.isEmpty()) {
                    log.warn(attributeValue + " found but value is null or empty");
                    continue;
                }
        		if(Objects.equals(attributeValue, "10")) {
        			addFieldMapping(fieldMappings, null, tr10PercentField, attributeValue);
        		} else if(Objects.equals(attributeValue, "25")) {
        			addFieldMapping(fieldMappings, null, tr25PercentField, attributeValue);
        		}
        	}
        }
    }
    
    private String extractSSN(Map<String, Object> formData) {
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
        if (lineItems == null) {
            log.warn("No lineItems found in formData");
            return null;
        }

        for (Map<String, Object> lineItem : lineItems) {
            if ("/IRS5329/SSN".equals(lineItem.get(LINE_NAME_TXT))) {
                String ssn = (String) lineItem.get(PER_RETURN_VALUE_TXT);
                if (ssn == null || ssn.isEmpty()) {
                    log.warn("SSN found but value is null or empty");
                    return null;
                }
                return ssn;
            }
        }

        log.warn("No line item with lineNameTxt '/IRS5329/SSN' found");
        return null;
    }
    
    private void addFieldMapping(List<FieldMapping> mappings, String sourceField, String targetField, String targetFieldValue) {
        FieldMapping mapping = new FieldMapping();
        mapping.setSourceForm(IRS5329);
        mapping.setSourceField(sourceField);
        mapping.setTargetField(targetField);
        mapping.setTargetFieldValue(targetFieldValue);
        mappings.add(mapping);
    }
    
    private void addFieldMapping(List<FieldMapping> mappings, String sourceField, String targetField) {
    	addFieldMapping(mappings, sourceField, targetField, null);
    }
    
}