package gov.irs.jios.common.pojo;

import java.util.Objects;

public class FormIdentifier {
    private final String formNum;
    private final String sequenceNum;
    
    public FormIdentifier(String formNum, String sequenceNum) {
        this.formNum = formNum;
        this.sequenceNum = sequenceNum;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FormIdentifier that = (FormIdentifier) o;
        return Objects.equals(formNum, that.formNum) && 
               Objects.equals(sequenceNum, that.sequenceNum);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(formNum, sequenceNum);
    }
}
