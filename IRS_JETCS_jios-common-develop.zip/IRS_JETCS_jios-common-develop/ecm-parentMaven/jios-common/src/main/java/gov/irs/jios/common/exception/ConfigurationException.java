package gov.irs.jios.common.exception;

public class ConfigurationException extends RuntimeException {

	private static final long serialVersionUID = -980007300502911230L;

	public ConfigurationException(String message) {
        super(message);
    }

    public ConfigurationException(String message, Throwable cause) {
        super(message, cause);
    }
}
