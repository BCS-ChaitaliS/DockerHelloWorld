package gov.irs.jios.common.client.dmi.pojo;

import java.util.List;

import lombok.Data;

@Data
public class CalcInfo {
    private String tin;
    private String mftCd;
    private String taxYr;
    private String taxMonthNum;
    private String dueDt;
    private String extendedDueDt;
    private String returnDt;
    private String reportDt;
    private String runToDt;
    private double taxAmt;
    private String taxDt;
    private String transactionCd;
    private String serverTxt;
    private String responseReturnCd;
    private List<String> interestPenaltyCd;
}
