package gov.irs.jios.common.client.dmi.pojo;

import lombok.Data;

@Data
public class AccCalc {
    private String penaltySectionCd;
    private int penaltyRt;
    private double assessmentAmt;
    private String assessmentDt;
    private String previouslyAssessedPenaltyAmt;
}
