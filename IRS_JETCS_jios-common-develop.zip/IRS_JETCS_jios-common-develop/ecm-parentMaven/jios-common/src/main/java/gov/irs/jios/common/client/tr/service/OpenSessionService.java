package gov.irs.jios.common.client.tr.service;

import java.time.Duration;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.irs.jios.common.client.tr.pojo.TrConfig;
import gov.irs.jios.common.exception.ConfigurationException;
import gov.irs.jios.common.profiler.Profiled;
import gov.irs.jios.common.util.CommonUtil;
import static gov.irs.jios.common.util.JiosCommonConstants.*;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

@Service
public class OpenSessionService {
	
	@Value("${webclient.retry.max-attempts:3}")
	private int maxAttempts;

	@Value("${webclient.retry.interval:100}")
	private long retryInterval;

    private final WebClient webClient;
    private final TrConfig trConfig;
    private final ObjectMapper objectMapper;

    public OpenSessionService(WebClient.Builder webClientBuilder, TrConfig trConfig, ObjectMapper objectMapper) {
        this.webClient = webClientBuilder.baseUrl(trConfig.getOpenSessionUrl()).build();
        this.trConfig = trConfig;
        this.objectMapper = objectMapper;
    }

    @Profiled("openSession")
    public Map<String, String> openSession(Map<String, Object> header, String token, String locatorId) {
    	String taxPrd = (String) header.get(TAX_PERIOD);
        if (taxPrd == null) {
            throw new IllegalArgumentException("taxPrd is missing in the header");
        }
        String taxYear;
        try {
            taxYear = CommonUtil.extractTaxYear(taxPrd);
        } catch (IllegalArgumentException e) {
            throw new ConfigurationException("Invalid tax period in header: " + e.getMessage());
        }
        Map<String, String> requestBody = createSessionRequestBody(locatorId, taxYear);

        return webClient.post()
            .contentType(MediaType.APPLICATION_JSON)
            .headers(headers -> headers.setBearerAuth(token))
            .bodyValue(requestBody)
            .retrieve()
            .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(),
                response -> response.bodyToMono(String.class)
                    .flatMap(error -> Mono.error(new RuntimeException("Failed to open session: " + error)))
            )
            .bodyToMono(String.class)
            .retryWhen(Retry.backoff(maxAttempts, Duration.ofMillis(retryInterval))
                    .filter(throwable -> throwable instanceof WebClientException))
            .flatMap(this::parseSessionResponse)
            .block(); // Block to get the result synchronously
    }

    protected Map<String, String> createSessionRequestBody(String locatorId, String taxYear) {
        return Map.of(
            "account", trConfig.getAccount(),
            "taxYear", taxYear,
            "taxReturnId", locatorId
        );
    }

    protected Mono<Map<String, String>> parseSessionResponse(String responseBody) {
        try {
            Map<String, String> responseMap = objectMapper.readValue(responseBody, new TypeReference<Map<String, String>>() {});
            String authToken = responseMap.get(AUTH_TOKEN);
            String taxReturnSessionToken = responseMap.get(TAX_RETURN_SESSION_TOKEN);
            String encodedLocatorDetails = responseMap.get(ENCODED_LOCATOR_DETAILS);
            String locatorToken = responseMap.get(LOCATOR_TOKEN);
            String apiServerCookie = responseMap.get(API_SERVER_COOKIE);
            
            if (authToken != null && taxReturnSessionToken != null) {
                return Mono.just(Map.of(
                	AUTH_TOKEN, authToken,
                    TAX_RETURN_SESSION_TOKEN, taxReturnSessionToken,
                    ENCODED_LOCATOR_DETAILS, encodedLocatorDetails,
                    LOCATOR_TOKEN, locatorToken,
                    API_SERVER_COOKIE, apiServerCookie
                ));
            }
            return Mono.error(new RuntimeException("Required tokens not found in response"));
        } catch (JsonProcessingException e) {
            return Mono.error(new RuntimeException("Failed to parse session response", e));
        }
    }
}