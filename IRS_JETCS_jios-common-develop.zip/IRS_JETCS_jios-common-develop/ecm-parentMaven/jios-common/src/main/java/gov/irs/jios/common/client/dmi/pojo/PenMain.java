package gov.irs.jios.common.client.dmi.pojo;

import lombok.Data;

@Data
public class PenMain {
    private String penaltySectionCd;
}