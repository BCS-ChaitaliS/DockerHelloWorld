package gov.irs.jios.common.client.tr.pojo;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FieldMapping {
	private String sourceForm;
	private String sourceField;
    private String targetField;
    private String targetFieldValue;
    @JsonProperty("isIndex")
    private boolean isIndex;
    private String groupField;
    private String childField;
    private String childFieldValue;
    private boolean isCalculateVariance;
    private String targetForm;
    private String transformationClass;
    private String transformationMethod;
    private String transformationType;
    @JsonProperty("isDynamicTargetField")
    private boolean isDynamicTargetField;
    private Map<String, String> perReturnValueToTargetField;
    private String groupingKey;
    private String dependentSourceField;
    private List<String> relatedSourceFields;
    //private boolean isGroupFieldMapping;
    
    public FieldMapping(String sourceForm, String sourceField) {
        this.sourceForm = sourceForm;
        this.sourceField = sourceField;
    }
}	