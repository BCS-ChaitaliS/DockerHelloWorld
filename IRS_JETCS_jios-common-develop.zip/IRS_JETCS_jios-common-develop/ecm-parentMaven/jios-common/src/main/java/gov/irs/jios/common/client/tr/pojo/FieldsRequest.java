package gov.irs.jios.common.client.tr.pojo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.ALWAYS)
public class FieldsRequest {
    private GroupField groupField;
    private List<Field> fields;
}