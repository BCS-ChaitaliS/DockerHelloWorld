package gov.irs.jios.common.client.transformer;

import java.util.Map;

public class DependentRelationshipCdTransformer {
	
	private static final Map<String, String> ECM_TO_TR_MAP = Map.ofEntries(
			Map.entry("SON", "R"),
		    Map.entry("DAUGHTER", "Q"),
		    Map.entry("STEPCHILD", "Z"),
		    Map.entry("FOSTER CHILD", "O"),
		    Map.entry("BROTHER", "F"),
		    Map.entry("SISTER", "G"),
		    Map.entry("STEPBROTHER", "Y"),
		    Map.entry("STEPSISTER", "X"),
		    Map.entry("HALF BROTHER", "W"),
		    Map.entry("HALF SISTER", "V"),
		    Map.entry("GRANDCHILD", "C"),
		    Map.entry("NIECE", "L"),
		    Map.entry("NEPHEW", "K"),
		    Map.entry("PARENT", "E"),
		    Map.entry("GRANDPARENT", "D"),
		    Map.entry("AUNT", "H"),
		    Map.entry("UNCLE", "I"),
		    Map.entry("OTHER", "P"),
		    Map.entry("NONE", "M")
		);
	
	private static final Map<String, String> TR_TO_ECM_MAP = Map.ofEntries(
		    
		    Map.entry("R", "SON"),
		    Map.entry("Q", "DAUGHTER"),
		    Map.entry("Z", "STEPCHILD"),
    		Map.entry("O", "FOSTER CHILD"),
		    Map.entry("F", "BROTHER"),
		    Map.entry("G", "SISTER"),
		    Map.entry("Y", "STEPBROTHER"),
		    Map.entry("X", "STEPSISTER"),
		    Map.entry("W", "HALF BROTHER"),
		    Map.entry("V", "HALF SISTER"),
		    Map.entry("C", "GRANDCHILD"),
		    Map.entry("L", "NIECE"),
		    Map.entry("K", "NEPHEW"),
		    Map.entry("E", "PARENT"),
		    Map.entry("D", "GRANDPARENT"),
		    Map.entry("H", "AUNT"),
		    Map.entry("I", "UNCLE"),
		    Map.entry("P", "OTHER"),
		    Map.entry("M", "NONE")
		);
	
	public static String transformEcmToTr(String ecmCdValue) {
    	if (ecmCdValue == null) {
    		ecmCdValue = "";
    	}
        String trCd = ECM_TO_TR_MAP.get(ecmCdValue.toUpperCase());
        if (trCd == null) {
            throw new IllegalArgumentException("Invalid ECM Cd value: " + ecmCdValue);
        }
        return trCd;
    }

    public static String transformTrToEcm(String trCdValue) {
        String ecmCd = TR_TO_ECM_MAP.get(trCdValue != null ? trCdValue.toUpperCase() : "");
        if (ecmCd == null) {
            throw new IllegalArgumentException("Invalid TR Indicator value: " + trCdValue);
        }
        return ecmCd;
    }
}
