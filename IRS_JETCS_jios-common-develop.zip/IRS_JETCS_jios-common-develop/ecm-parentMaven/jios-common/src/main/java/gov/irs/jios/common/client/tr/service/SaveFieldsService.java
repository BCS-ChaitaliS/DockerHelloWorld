package gov.irs.jios.common.client.tr.service;

import static gov.irs.jios.common.util.JiosCommonConstants.AUTH_TOKEN;
import static gov.irs.jios.common.util.JiosCommonConstants.TAX_RETURN_SESSION_TOKEN;

import java.rmi.ServerException;
import java.time.Duration;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.irs.jios.common.client.tr.pojo.SaveFieldsRequest;
import gov.irs.jios.common.client.tr.pojo.TrConfig;
import gov.irs.jios.common.exception.ValidationException;
import gov.irs.jios.common.profiler.Profiled;
import gov.irs.jios.common.request.ValidatableRequest;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

@Service
@Slf4j
public class SaveFieldsService {
	
	@Value("${webclient.retry.max-attempts:3}")
	private int maxAttempts;

	@Value("${webclient.retry.interval:100}")
	private long retryInterval;
	
	@Value("${should.make.tr.call:true}")
	private boolean shouldMakeTrCall;

    private final WebClient webClient;
    private final TransformationService transformationService;
    private final ObjectMapper objectMapper;

    public SaveFieldsService(WebClient.Builder webClientBuilder,
                             TrConfig trConfig,
                             TransformationService transformationService,
                             ObjectMapper objectMapper) {
        this.webClient = webClientBuilder.baseUrl(trConfig.getSaveFieldsUrl()).build();
        this.transformationService = transformationService;
        this.objectMapper = objectMapper;
    }

    @Profiled
    public void saveFields(ValidatableRequest request, String token, Map<String, String> authTokenSessionToken) throws ValidationException {
    	
		SaveFieldsRequest saveFieldsRequest = transformationService.transformEcmToTrSaveFields(request);
		
		//This section is only for printing the TR request payload
		try {
			String sfRequestsJson = objectMapper.writeValueAsString(saveFieldsRequest);
			log.info("saveFields - Request JSON to TR: {}", sfRequestsJson);
		} catch (JsonProcessingException e) {
			log.error("Error converting TR SaveFields Request payload to JSON", e);
		}
        
		if(shouldMakeTrCall) {
			sendSaveFieldsRequest(saveFieldsRequest, token, authTokenSessionToken).block(); // Blocking call
		}
    }

    private Mono<Void> sendSaveFieldsRequest(SaveFieldsRequest request, String token, Map<String, String> authTokenSessionToken) {
        return webClient.post()
            .headers(headers -> {
                headers.setBearerAuth(token);
                headers.set(AUTH_TOKEN, authTokenSessionToken.get(AUTH_TOKEN));
                headers.set(TAX_RETURN_SESSION_TOKEN, authTokenSessionToken.get(TAX_RETURN_SESSION_TOKEN));
            })
            .bodyValue(request)
            .retrieve()
            .onStatus(httpStatus -> httpStatus.value() == 207, response ->
                response.bodyToMono(String.class)
                    .flatMap(body -> {
                        return Mono.error(new ValidationException("TR's Validation error: " + body));
                    })
            )
            .onStatus(HttpStatusCode::is5xxServerError, response ->
                response.bodyToMono(String.class)
                    .flatMap(body -> {
                        return Mono.error(new ServerException("Server error: " + response.statusCode() + " - " + body));
                    })
            )
            .bodyToMono(Void.class)
            .doOnSuccess(v -> log.info("Save fields request successful"))
            .onErrorResume(WebClientResponseException.class, e -> {
                if (e.getStatusCode().is2xxSuccessful()) {
                    log.info("Save fields request successful with empty response");
                    return Mono.empty();
                }
                return Mono.error(e);
            })
            .retryWhen(Retry.backoff(maxAttempts, Duration.ofMillis(retryInterval))
                .filter(throwable -> throwable instanceof WebClientResponseException &&
                                    ((WebClientResponseException) throwable).getStatusCode().is5xxServerError()));
    }
}