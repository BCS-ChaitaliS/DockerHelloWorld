package gov.irs.jios.common.profiler;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

@Aspect
@Component
public class ProfilingAspect {

    private static final Logger logger = LoggerFactory.getLogger(ProfilingAspect.class);
    private static final String DOTTED_LINE = "............................................................";

    @Around("@annotation(profiled)")
    public Object profileMethod(ProceedingJoinPoint joinPoint, Profiled profiled) throws Throwable {
        String name = profiled.value().isEmpty() ? joinPoint.getSignature().getName() : profiled.value();
        StopWatch stopWatch = new StopWatch(name);
        stopWatch.start("Execution");
        try {
            return joinPoint.proceed();
        } finally {
            stopWatch.stop();
            logProfilingInfo(name, stopWatch);
        }
    }

    private void logProfilingInfo(String name, StopWatch stopWatch) {
        logger.info(DOTTED_LINE);
        logger.info("PROFILING: {} - Total time taken: {} ms", name, stopWatch.getTotalTimeMillis());
        logger.info(DOTTED_LINE);
    }
}