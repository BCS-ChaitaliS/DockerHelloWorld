package gov.irs.jios.common.client.transformer;

import static gov.irs.jios.common.util.JiosCommonConstants.LINE_ITEMS;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_NAME_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.PER_RETURN_VALUE_TXT;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FormIRS1040Transformer {

	public static final String IRS1040 = "IRS1040";



	@SuppressWarnings("unchecked")
	public List<FieldMapping> transformFormIRS1040(Map<String, Object> formData, Map<String, Object> header) {
		List<FieldMapping> fieldMappings = new ArrayList<>();
		if (formData == null || header == null) {
			log.warn("FormData or header is null. Returning empty field mappings.");
			return fieldMappings;
		}

		fieldMappings = lumpSumElectionMethodIndMapping(formData, fieldMappings);
		fieldMappings = checkFilingStatusCode(formData, fieldMappings);
		return fieldMappings;

	}

	private List<FieldMapping> lumpSumElectionMethodIndMapping(Map<String, Object> formData,
			List<FieldMapping> fieldMappings) {
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
		if (lineItems == null) {
			log.warn("No lineItems found in formData");
			return null;
		}

		for (Map<String, Object> lineItem : lineItems) {
			// No X case: 6a is mapped to MIS.TSAMT (for primary) and MIS.SSPMT (for
			// secondary).
			if ("/IRS1040/LumpSumElectionMethodInd".equals(lineItem.get(LINE_NAME_TXT))) {
				String LumpSumElectionMethodInd = (String) lineItem.get(PER_RETURN_VALUE_TXT);
				if (!LumpSumElectionMethodInd.toUpperCase().equals("X")) {
					String val = get6aVal(lineItems);
					fieldMappings = addFieldMapping(fieldMappings, "/IRS1040/SocSecBnftAmt", "MIS.TSAMT", val);
					fieldMappings = addFieldMapping(fieldMappings, "/IRS1040/SocSecBnftAmt", "MIS.SSPMT", val);
				} else {
					// X case: the values from 6a: map it to X133.678.21, take the value from 6b:
					// map it to X133.678.22.
					String val6A = get6aVal(lineItems);
					String val6B = get6bVal(lineItems);
					fieldMappings = addFieldMapping(fieldMappings, "/IRS1040/SocSecBnftAmt", "X133.678.21", val6A);
					fieldMappings = addFieldMapping(fieldMappings, "/IRS1040/TaxableSocSecAmt", "X133.678.22", val6B);
				}
			}
		}
		return fieldMappings;
	}

	// extracting the value from SocSecBnftAmt (line 6a)
	public String get6aVal(List<Map<String, Object>> lineItems) {

		String val = "";
		for (Map<String, Object> lineItem : lineItems) {
			if ("/IRS1040/SocSecBnftAmt".equals(lineItem.get(LINE_NAME_TXT))) {
				val = (String) lineItem.get(PER_RETURN_VALUE_TXT);
				return val;
			}
		}
		return val;
	}

	// extracting the value from TaxableSocSecAmt (line 6b)
	public String get6bVal(List<Map<String, Object>> lineItems) {

		String val = "";
		for (Map<String, Object> lineItem : lineItems) {
			if ("/IRS1040/TaxableSocSecAmt".equals(lineItem.get(LINE_NAME_TXT))) {
				val = (String) lineItem.get(PER_RETURN_VALUE_TXT);
				return val;
			}
		}
		return val;
	}

	// method checks if filing status is 2 (spouse (Married Filing Jointly))
	public List<FieldMapping> checkFilingStatusCode(Map<String, Object> formData, List<FieldMapping> fieldMappings) {
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
		if (lineItems == null) {
			log.warn("No lineItems found in formData");
			return null;
		}
		for (Map<String, Object> lineItem : lineItems) {
			// add SP.SSN and SP.BIRTH and store with the mock data
			if ("/IRS1040/IndividualReturnFilingStatusCd".equals(lineItem.get(LINE_NAME_TXT))) {
				String filingStatusCd = (String) lineItem.get(PER_RETURN_VALUE_TXT);
				if (filingStatusCd.equals("2")) {
					fieldMappings = addFieldMapping(fieldMappings, "FED.SPSSN", "111223334");
					fieldMappings = addFieldMapping(fieldMappings, "FED.SPBIRTH", "12/12/1985");
				}

			}
		}
		return fieldMappings;
	}

	private List<FieldMapping> addFieldMapping(List<FieldMapping> mappings, String sourceField, String targetField,
			String targetFieldValue) {
		FieldMapping mapping = new FieldMapping();
		mapping.setSourceForm(IRS1040);
		mapping.setSourceField(sourceField);
		mapping.setTargetField(targetField);
		mapping.setTargetFieldValue(targetFieldValue);
		mappings.add(mapping);
		return mappings;
	}

	private List<FieldMapping> addFieldMapping(List<FieldMapping> mappings, String targetField,
			String targetFieldValue) {
		FieldMapping mapping = new FieldMapping();
		mapping.setSourceForm(IRS1040);
		mapping.setTargetField(targetField);
		mapping.setTargetFieldValue(targetFieldValue);
		mappings.add(mapping);
		return mappings;
	}
}
