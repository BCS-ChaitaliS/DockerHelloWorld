package gov.irs.jios.common.client.dmi.pojo;

import lombok.Data;

@Data
public class FTPCalc {
    private String penaltySectionCd;
    private int installAgreeInd;
    private int fraudulentInd;
    private int returnIncomeInd;
    private double assessmentAmt;
    private String assessmentDt;
    private int bankruptcyInd;
}
