package gov.irs.jios.common.exception;

import java.util.List;

public class ValidationException extends RuntimeException {
	private static final long serialVersionUID = 4445824228675076703L;
	private final List<String> errors;

    public ValidationException(String message) {
        super(message);
        this.errors = List.of(message);
    }

    public ValidationException(List<String> errors) {
        super("Validation failed: " + String.join(", ", errors));
        this.errors = errors;
    }

    public List<String> getErrors() {
        return errors;
    }
}