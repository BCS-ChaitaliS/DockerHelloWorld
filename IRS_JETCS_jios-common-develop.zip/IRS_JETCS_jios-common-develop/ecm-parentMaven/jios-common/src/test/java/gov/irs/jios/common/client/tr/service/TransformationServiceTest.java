package gov.irs.jios.common.client.tr.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.env.Environment;

import gov.irs.jios.common.client.config.DynamicMappingConfigLoader;
import gov.irs.jios.common.client.tr.pojo.Field;
import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import gov.irs.jios.common.client.tr.pojo.FieldsRequest;
import gov.irs.jios.common.client.tr.pojo.FieldsResponse;
import gov.irs.jios.common.client.tr.pojo.MappingConfig;
import gov.irs.jios.common.client.tr.pojo.RequestMapping;
import gov.irs.jios.common.client.tr.pojo.ResponseMapping;
import gov.irs.jios.common.client.tr.pojo.RetrieveFields;
import gov.irs.jios.common.client.tr.pojo.RetrieveFieldsRequest;
import gov.irs.jios.common.client.tr.pojo.RetrieveFieldsResponse;
import gov.irs.jios.common.client.tr.pojo.SaveFields;
import gov.irs.jios.common.client.tr.pojo.SaveFieldsRequest;
import gov.irs.jios.common.request.ValidatableRequest;

@ExtendWith(MockitoExtension.class)
class TransformationServiceTest {

    @Mock
    private DynamicMappingConfigLoader configLoader;
    
    @Mock
    private Environment environment;
    
    private TransformationService service;
    
    @BeforeEach
    void setUp() {
        service = new TransformationService(configLoader, environment);
    }

    @Test
    void transformEcmToTrSaveFields_BasicTransformation() {
    	// Given
        MappingConfig mappingConfig = createMockMappingConfig();
        when(configLoader.loadMappingConfig(anyString())).thenReturn(mappingConfig);
        
        ValidatableRequest input = mock(ValidatableRequest.class);
        Map<String, Object> header = createBasicHeader();
        Map<String, Object> body = createBasicBody();
        when(input.getHeader()).thenReturn(header);
        when(input.getBody()).thenReturn(body);
        
        // When
        SaveFieldsRequest result = service.transformEcmToTrSaveFields(input);
        
        // Then
        assertNotNull(result);
        assertNotNull(result.getFieldsRequest());
        assertEquals(1, result.getFieldsRequest().size());
        
        FieldsRequest fieldsRequest = result.getFieldsRequest().get(0);
        assertNotNull(fieldsRequest.getFields());
        assertFalse(fieldsRequest.getFields().isEmpty());
        
        // Verify transformed field exists with correct value
        boolean hasExpectedField = fieldsRequest.getFields().stream()
            .anyMatch(f -> "FED.FS".equals(f.getFieldId()) && "2".equals(f.getValue()));
        assertTrue(hasExpectedField, "Should contain field FED.FS with expected value");
        
        // Verify interactions
        verify(configLoader).loadMappingConfig("2023");
        verify(input, atLeastOnce()).getHeader();
        verify(input, atLeastOnce()).getBody();
    }
    
    @Test
    void transformEcmToTrSaveFields_WithGroupedFields() {
        // Given
        MappingConfig mappingConfig = createMockMappingConfigWithGroups();
        when(configLoader.loadMappingConfig(anyString())).thenReturn(mappingConfig);
        
        ValidatableRequest input = mock(ValidatableRequest.class);
        Map<String, Object> header = createBasicHeader();
        Map<String, Object> body = createBodyWithGroups();
        when(input.getHeader()).thenReturn(header);
        when(input.getBody()).thenReturn(body);
        
        // When
        SaveFieldsRequest result = service.transformEcmToTrSaveFields(input);
        
        // Then
        assertNotNull(result);
        assertTrue(result.getFieldsRequest().size() > 1);
        verifyGroupedFields(result.getFieldsRequest());
    }

    @Test
    void transformEcmToTrSaveFields_WithMockValues() {
        // Given
        MappingConfig mappingConfig = createMockMappingConfigWithMockValues();
        when(configLoader.loadMappingConfig(anyString())).thenReturn(mappingConfig);
        when(environment.getProperty("mock.primary.taxpayer.ssn")).thenReturn("123-45-6789");
        
        ValidatableRequest input = mock(ValidatableRequest.class);
        when(input.getHeader()).thenReturn(createBasicHeader());
        when(input.getBody()).thenReturn(createBasicBody());
        
        // When
        SaveFieldsRequest result = service.transformEcmToTrSaveFields(input);
        
        // Then
        assertNotNull(result);
        List<Field> fields = result.getFieldsRequest().get(0).getFields();
        assertTrue(fields.stream().anyMatch(f -> f.getFieldId().equals("FED.TPSSN") && f.getValue().equals("123-45-6789")));
    }

    @Test
    void transformTrToEcm_BasicTransformation() {
        // Given
        MappingConfig mappingConfig = createMockMappingConfig();
        when(configLoader.loadMappingConfig(anyString())).thenReturn(mappingConfig);
        
        ValidatableRequest originalRequest = mock(ValidatableRequest.class);
        when(originalRequest.getHeader()).thenReturn(createBasicHeader());
        when(originalRequest.getBody()).thenReturn(createBasicBody());
        
        RetrieveFieldsResponse trResponse = createMockTrResponse();
        
        // When
        Map<String, Object> result = service.transformTrToEcm(originalRequest, trResponse);
        
        // Then
        assertNotNull(result);
        verifyEcmTransformation(result);
        
        // Verify the transformed values
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> forms = (List<Map<String, Object>>) result.get("forms");
        assertFalse(forms.isEmpty());
        
        Map<String, Object> form = forms.get(0);
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get("lineItems");
        assertFalse(lineItems.isEmpty());
        
        // Verify field values were properly transformed
        boolean foundTransformedField = lineItems.stream()
            .anyMatch(item -> 
                "/IRS1040/IndividualReturnFilingStatusCd".equals(item.get("lineNameTxt")) &&
                item.containsKey("perReturnValueTxt"));
                
        assertTrue(foundTransformedField, "Transformed field should be present in the result");
    }

    @Test
    void transformEcmToTrSaveFields_WithCalculationType() {
        // Given
        MappingConfig mappingConfig = createMockMappingConfig();
        when(configLoader.loadMappingConfig(anyString())).thenReturn(mappingConfig);
        
        ValidatableRequest input = mock(ValidatableRequest.class);
        Map<String, Object> header = new HashMap<>(createBasicHeader());
        header.put("calcTypeTxt", "Agreed");
        when(input.getHeader()).thenReturn(header);
        when(input.getBody()).thenReturn(createBodyWithCalculations());
        
        // When
        SaveFieldsRequest result = service.transformEcmToTrSaveFields(input);
        
        // Then
        assertNotNull(result);
        verifyCalculationTypeProcessing(result.getFieldsRequest());
    }

    @Test
    void generateRetrieveFieldsPayload_Success() {
    	// Given
        MappingConfig mappingConfig = createMockMappingConfigForRetrieve();
        when(configLoader.loadMappingConfig(anyString())).thenReturn(mappingConfig);
        
        ValidatableRequest input = mock(ValidatableRequest.class);
        when(input.getHeader()).thenReturn(createBasicHeader());
        
        // When
        RetrieveFieldsRequest result = service.generateRetrieveFieldsPayload(input);
        
        // Then
        assertNotNull(result);
        assertNotNull(result.getFieldsRequest());
        assertFalse(result.getFieldsRequest().isEmpty());
        
        // Verify the fields request contains the expected fields
        FieldsRequest fieldsRequest = result.getFieldsRequest().get(0);
        assertNotNull(fieldsRequest.getFields());
        assertFalse(fieldsRequest.getFields().isEmpty());
        
        // Verify specific field exists
        boolean hasExpectedField = fieldsRequest.getFields().stream()
            .anyMatch(field -> "FED.FS".equals(field.getFieldId()));
        assertTrue(hasExpectedField, "Fields request should contain expected field");
    }

    @Test
    void transformEcmToTrSaveFields_WithInvalidInput() {
        assertThrows(IllegalArgumentException.class, () -> 
            service.transformEcmToTrSaveFields(null));
    }

    @Test
    void transformEcmToTrSaveFields_WithInvalidHeader() {
        // Given
        ValidatableRequest input = mock(ValidatableRequest.class);
        when(input.getHeader()).thenReturn(null);
        
        // Then
        assertThrows(IllegalArgumentException.class, () -> 
            service.transformEcmToTrSaveFields(input));
    }

    // Helper methods
    private Map<String, Object> createBasicHeader() {
        Map<String, Object> header = new HashMap<>();
        header.put("taxPrd", "202312");
        return header;
    }

    private Map<String, Object> createBasicBody() {
        Map<String, Object> body = new HashMap<>();
        List<Map<String, Object>> forms = new ArrayList<>();
        Map<String, Object> form = new HashMap<>();
        form.put("formNum", "IRS1040");
        
        List<Map<String, Object>> lineItems = new ArrayList<>();
        Map<String, Object> lineItem = new HashMap<>();
        lineItem.put("lineNameTxt", "/IRS1040/IndividualReturnFilingStatusCd");
        lineItem.put("perReturnValueTxt", "2");
        lineItems.add(lineItem);
        
        form.put("lineItems", lineItems);
        forms.add(form);
        body.put("forms", forms);
        
        return body;
    }

    @SuppressWarnings("unchecked")
	private Map<String, Object> createBodyWithGroups() {
        Map<String, Object> body = createBasicBody();
		List<Map<String, Object>> forms = (List<Map<String, Object>>) body.get("forms");
        Map<String, Object> form = forms.get(0);
        List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get("lineItems");
        
        Map<String, Object> dependentGroup = new HashMap<>();
        dependentGroup.put("lineNameTxt", "/IRS1040/DependentDetail");
        
        List<Map<String, Object>> dependents = new ArrayList<>();
        Map<String, Object> dependent = new HashMap<>();
        dependent.put("lineNameTxt", "/IRS1040/DependentDetail/DependentFirstNm");
        dependent.put("perReturnValueTxt", "John");
        dependents.add(dependent);
        
        dependentGroup.put("lineItems", dependents);
        lineItems.add(dependentGroup);
        
        return body;
    }

    @SuppressWarnings("unchecked")
	private Map<String, Object> createBodyWithCalculations() {
        Map<String, Object> body = createBasicBody();
        List<Map<String, Object>> forms = (List<Map<String, Object>>) body.get("forms");
        Map<String, Object> form = forms.get(0);
        List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get("lineItems");
        
        Map<String, Object> calculationItem = new HashMap<>();
        calculationItem.put("lineNameTxt", "/IRS1040/TaxableIncome");
        calculationItem.put("perReturnValueTxt", "50000");
        calculationItem.put("totalAdjustmentValueTxt", "5000");
        lineItems.add(calculationItem);
        
        return body;
    }
    
    private MappingConfig createMockMappingConfigForRetrieve() {
        MappingConfig config = new MappingConfig();
        
        // Setup RetrieveFields with proper mappings
        RetrieveFields retrieveFields = new RetrieveFields();
        
        // Setup request mapping
        RequestMapping retrieveRequestMapping = new RequestMapping();
        List<FieldMapping> requestFieldMappings = new ArrayList<>();
        
        FieldMapping retrieveMapping = new FieldMapping();
        retrieveMapping.setSourceField("FED.FS");
        requestFieldMappings.add(retrieveMapping);
        
        retrieveRequestMapping.setFieldMappings(requestFieldMappings);
        retrieveFields.setRequestMapping(retrieveRequestMapping);
        
        // Setup response mapping
        ResponseMapping responseMapping = new ResponseMapping();
        responseMapping.setFieldMappings(new ArrayList<>());
        retrieveFields.setResponseMapping(responseMapping);
        
        config.setRetrieveFields(retrieveFields);
        
        return config;
    }

    private MappingConfig createMockMappingConfig() {
        MappingConfig config = new MappingConfig();
        
        // Setup SaveFields
        SaveFields saveFields = new SaveFields();
        RequestMapping saveRequestMapping = new RequestMapping();
        List<FieldMapping> saveFieldMappings = new ArrayList<>();
        
        // Create field mapping for filing status
        FieldMapping mapping = new FieldMapping();
        mapping.setSourceForm("IRS1040");
        mapping.setSourceField("/IRS1040/IndividualReturnFilingStatusCd");
        mapping.setTargetField("FED.FS");
        saveFieldMappings.add(mapping);
        
        saveRequestMapping.setFieldMappings(saveFieldMappings);
        saveFields.setRequestMapping(saveRequestMapping);
        config.setSaveFields(saveFields);
        
        // Setup minimal RetrieveFields
        RetrieveFields retrieveFields = new RetrieveFields();
        RequestMapping retrieveRequestMapping = new RequestMapping();
        retrieveRequestMapping.setFieldMappings(new ArrayList<>());
        retrieveFields.setRequestMapping(retrieveRequestMapping);
        
        ResponseMapping responseMapping = new ResponseMapping();
        responseMapping.setFieldMappings(new ArrayList<>());
        retrieveFields.setResponseMapping(responseMapping);
        
        config.setRetrieveFields(retrieveFields);
        
        return config;
    }

    private MappingConfig createMockMappingConfigWithGroups() {
        MappingConfig config = createMockMappingConfig();
        FieldMapping groupMapping = new FieldMapping();
        groupMapping.setSourceForm("IRS1040");
        groupMapping.setSourceField("/IRS1040/DependentDetail/DependentFirstNm");
        groupMapping.setTargetField("X133.768.133");
        groupMapping.setIndex(true);
        groupMapping.setGroupField("DEP.GROUP");
        
        config.getSaveFields().getRequestMapping().getFieldMappings().add(groupMapping);
        return config;
    }

    private MappingConfig createMockMappingConfigWithMockValues() {
        MappingConfig config = createMockMappingConfig();
        FieldMapping mockMapping = new FieldMapping();
        mockMapping.setSourceForm("IRS1040");
        mockMapping.setTargetField("FED.TPSSN");
        mockMapping.setTargetFieldValue("${mock.primary.taxpayer.ssn}");
        
        config.getSaveFields().getRequestMapping().getFieldMappings().add(mockMapping);
        return config;
    }

    private RetrieveFieldsResponse createMockTrResponse() {
        RetrieveFieldsResponse response = new RetrieveFieldsResponse();
        List<FieldsResponse> fieldsResponses = new ArrayList<>();
        FieldsResponse fieldsResponse = new FieldsResponse();
        List<Field> fields = new ArrayList<>();
        
        Field field = new Field();
        field.setFieldId("FED.FS");
        field.setValue("B");
        fields.add(field);
        
        fieldsResponse.setFields(fields);
        fieldsResponses.add(fieldsResponse);
        response.setFieldsResponse(fieldsResponses);
        
        return response;
    }

    private void verifyGroupedFields(List<FieldsRequest> fieldsRequests) {
        boolean hasGroupField = fieldsRequests.stream()
            .anyMatch(fr -> fr.getGroupField() != null && 
                     "DEP.GROUP".equals(fr.getGroupField().getFieldId()));
        assertTrue(hasGroupField, "Should contain grouped fields");
    }

    private void verifyCalculationTypeProcessing(List<FieldsRequest> fieldsRequests) {
        // Verify calculation fields are properly processed
        assertNotNull(fieldsRequests);
        assertFalse(fieldsRequests.isEmpty());
    }

    private void verifyEcmTransformation(Map<String, Object> result) {
        assertNotNull(result.get("forms"));
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> forms = (List<Map<String, Object>>) result.get("forms");
        assertFalse(forms.isEmpty());
        
        Map<String, Object> form = forms.get(0);
        assertEquals("IRS1040", form.get("formNum"));
        
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get("lineItems");
        assertNotNull(lineItems);
        assertFalse(lineItems.isEmpty());
    }
}
