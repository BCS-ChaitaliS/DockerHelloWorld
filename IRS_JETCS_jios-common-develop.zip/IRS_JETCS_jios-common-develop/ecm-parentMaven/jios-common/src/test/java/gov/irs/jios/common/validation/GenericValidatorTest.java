package gov.irs.jios.common.validation;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

class GenericValidatorTest {

    private static final String VALIDATION_RULES_FILE = "validation-rules/tax-calc-validation-rules.json";

    @Test
    void testValidateCalculationRequest() {
        GenericValidator validator = new GenericValidator(VALIDATION_RULES_FILE);
        validator.printLoadedRules();

        Map<String, Object> request = new HashMap<>();
        Map<String, Object> header = new HashMap<>();
        header.put("taxPrd", "202112");
        header.put("mftCd", "12");
        header.put("uniqueCalculationId", "ABC-123");
        header.put("calcDt", "12/31/2021");
        header.put("caseId", "CASE123");
        header.put("calcTypeTxt", "Total");
        header.put("calculateTaxInd", "Y");
        request.put("header", header);

        Map<String, Object> body = new HashMap<>();
        List<Map<String, Object>> forms = new ArrayList<>();
        Map<String, Object> form = new HashMap<>();
        form.put("formNum", "FORM1");
        List<Map<String, Object>> lineItems = new ArrayList<>();
        Map<String, Object> lineItem = new HashMap<>();
        lineItem.put("lineNameTxt", "Line1");
        lineItem.put("perReturnValueTxt", "100");
        lineItem.put("totalAdjustmentValueTxt", "50");
        lineItem.put("agreedAdjustmentValueTxt", "25");
        lineItems.add(lineItem);
        form.put("lineItems", lineItems);
        forms.add(form);
        body.put("forms", forms);
        request.put("body", body);

        List<String> errors = validator.validate(request);
        assertTrue(errors.isEmpty(), "Expected no validation errors, but got: " + errors);
    }

    @Test
    void testValidateCalculationRequestWithErrors() {
        GenericValidator validator = new GenericValidator(VALIDATION_RULES_FILE);
        validator.printLoadedRules();

        Map<String, Object> request = new HashMap<>();
        Map<String, Object> header = new HashMap<>();
        header.put("taxPrd", "2021"); // Invalid format
        header.put("mftCd", "1"); // Invalid format
        header.put("uniqueCalculationId", "$$$"); // Invalid format
        header.put("calcDt", "2021-12-31"); // Invalid format
        header.put("caseId", "CASE 123"); // Invalid format
        header.put("calcTypeTxt", "Invalid"); // Invalid value
        header.put("calculateTaxInd", "T"); // Invalid value
        request.put("header", header);

        Map<String, Object> body = new HashMap<>();
        List<Map<String, Object>> forms = new ArrayList<>();
        body.put("forms", forms); // Empty forms array
        request.put("body", body);

        List<String> errors = validator.validate(request);
        
        System.out.println("Validation errors: " + errors);
        
        assertFalse(errors.isEmpty(), "Expected validation errors, but got none");
        
        List<String> expectedErrors = Arrays.asList(
            "header.taxPrd does not match the required pattern",
            "header.mftCd does not match the required pattern",
            "header.uniqueCalculationId must be alphanumeric",
            "header.calcDt is not a valid date in the format MM/dd/yyyy",
            "header.caseId must be alphanumeric",
            "header.calcTypeTxt is not an allowed value. Allowed values are [Total, Partial]",
            "header.calculateTaxInd is not an allowed value. Allowed values are [Y, N]",
            "body.forms must have at least 1 item(s)"
        );
        
        for (String expectedError : expectedErrors) {
            assertTrue(errors.contains(expectedError), "Expected error not found: " + expectedError);
        }
        
        assertEquals(expectedErrors.size(), errors.size(), "Number of errors doesn't match expected");
    }
}