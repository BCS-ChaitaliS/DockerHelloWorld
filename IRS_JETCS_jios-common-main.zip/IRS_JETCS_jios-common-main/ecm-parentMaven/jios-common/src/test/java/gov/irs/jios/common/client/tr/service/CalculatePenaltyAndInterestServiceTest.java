package gov.irs.jios.common.client.tr.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.irs.jios.common.client.dmi.service.CalculatePenaltyAndInterestService;

@ExtendWith(MockitoExtension.class)
public class CalculatePenaltyAndInterestServiceTest {

    @InjectMocks
    private CalculatePenaltyAndInterestService service;

    //@Test
    void computeW_WhenValidData_ShouldCalculateCorrectly() {
        // Arrange
        Map<String, Map<String, Object>> form1040LineItems = createForm1040LineItems();
        Map<String, String> trResultMap = createTrResultMap();

        // Act
        BigDecimal result = service.computeW(form1040LineItems, trResultMap, true);

        // Assert
        assertNotNull(result);
        assertEquals(new BigDecimal("900"), result); // Expected value based on mock data
    }

    //@Test
    void computeXY_WhenValidData_ShouldCalculateCorrectly() {
        // Arrange
        Map<String, Map<String, Object>> form1040LineItems = createForm1040LineItems();
        Map<String, String> trResultMap = createTrResultMap();
        String taxShownInReturn = "1000";

        // Act
        BigDecimal[] result = service.computeXY(form1040LineItems, trResultMap, taxShownInReturn, true);

        // Assert
        assertNotNull(result);
        assertEquals(2, result.length);
        assertTrue(result[0].compareTo(BigDecimal.ZERO) >= 0);
        assertTrue(result[1].compareTo(BigDecimal.ZERO) >= 0);
    }

    private Map<String, Map<String, Object>> createForm1040LineItems() {
        Map<String, Map<String, Object>> lineItems = new HashMap<>();
        
        // TotalTaxAmt
        Map<String, Object> totalTaxLine = new HashMap<>();
        totalTaxLine.put("perReturnValueTxt", "1000");
        lineItems.put("/IRS1040/TotalTaxAmt", totalTaxLine);
        
        // FormW2WithheldTaxAmt
        Map<String, Object> w2WithheldLine = new HashMap<>();
        w2WithheldLine.put("userAdjustedLineInd", "Y");
        w2WithheldLine.put("agreedAdjustmentValueTxt", "100");
        w2WithheldLine.put("perReturnValueTxt", "100");
        lineItems.put("/IRS1040/FormW2WithheldTaxAmt", w2WithheldLine);
        
        // Form1099WithheldTaxAmt
        Map<String, Object> form1099Line = new HashMap<>();
        form1099Line.put("userAdjustedLineInd", "N");
        form1099Line.put("perReturnValueTxt", "50");
        lineItems.put("/IRS1040/Form1099WithheldTaxAmt", form1099Line);
        
        return lineItems;
    }

    private Map<String, String> createTrResultMap() {
        Map<String, String> trResultMap = new HashMap<>();
        trResultMap.put("totalTaxAmt", "1000");
        trResultMap.put("earnedIncomeCreditAmt", "50");
        trResultMap.put("additionalChildTaxCreditAmt", "25");
        trResultMap.put("refundableAmerOppCreditAmt", "25");
        trResultMap.put("formW2WithheldTaxAmt", "100");
        trResultMap.put("form1099WithheldTaxAmt", "50");
        return trResultMap;
    }

    //@Test
    void calculate20PctPenalties_WhenValidData_ShouldCalculateCorrectly() {
        // Arrange
        Map<String, Map<String, String>> trResultMap = new HashMap<>();
        trResultMap.put("CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A", createTrResultMap());
        
        Map<String, Map<String, Object>> form1040LineItems = createForm1040LineItems();
        Map<String, Map<String, Map<String, String>>> underPaymentMap = createInitialUnderPaymentMap();
        Set<String> penaltyTypes = new HashSet<>(Arrays.asList("6662"));
        String taxShownInReturn = "1000";

        // Act
        service.calculate20PctPenalties(trResultMap, form1040LineItems, underPaymentMap, penaltyTypes, taxShownInReturn);

        // Assert
        assertTrue(underPaymentMap.containsKey("Agreed"));
        assertTrue(underPaymentMap.get("Agreed").containsKey("20"));
    }

    private Map<String, Map<String, Map<String, String>>> createInitialUnderPaymentMap() {
        Map<String, Map<String, Map<String, String>>> underPaymentMap = new HashMap<>();
        Map<String, Map<String, String>> agreedMap = new HashMap<>();
        Map<String, String> noPenaltyMap = new HashMap<>();
        noPenaltyMap.put("w", "1000");
        noPenaltyMap.put("underPayment", "900");
        agreedMap.put("noPenalty", noPenaltyMap);
        underPaymentMap.put("Agreed", agreedMap);
        underPaymentMap.put("Total", new HashMap<>());
        return underPaymentMap;
    }
}