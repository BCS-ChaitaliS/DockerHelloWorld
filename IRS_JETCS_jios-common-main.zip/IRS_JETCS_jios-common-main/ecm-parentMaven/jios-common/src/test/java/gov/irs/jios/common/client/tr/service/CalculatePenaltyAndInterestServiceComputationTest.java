package gov.irs.jios.common.client.tr.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.irs.jios.common.client.dmi.service.CalculatePenaltyAndInterestService;

@ExtendWith(MockitoExtension.class)
class CalculatePenaltyAndInterestServiceComputationTest {

    @Mock
    private WebClient.Builder webClientBuilder;
    
    @Mock
    private WebClient webClient;
    
    @Mock
    private ObjectMapper objectMapper;
    
    @Mock
    private AuthLocatorService authLocatorService;
    
    @Mock
    private PingTokenService pingTokenService;
    
    @Mock
    private OpenSessionService openSessionService;
    
    @Mock
    private SaveFieldsService saveFieldsService;
    
    @Mock
    private RetrieveFieldsService retrieveFieldsService;

    private CalculatePenaltyAndInterestService service;

    @BeforeEach
    void setUp() {
        when(webClientBuilder.baseUrl(anyString())).thenReturn(webClientBuilder);
        when(webClientBuilder.build()).thenReturn(webClient);
        service = new CalculatePenaltyAndInterestService(webClientBuilder, "http://test-url");
    }

    @Test
    void computeW_WhenValidData_ShouldCalculateCorrectly() {
        // Arrange
        Map<String, Map<String, Object>> form1040LineItems = new HashMap<>();
        
        // Set up TotalTaxAmt line item
        Map<String, Object> totalTaxLine = new HashMap<>();
        totalTaxLine.put("perReturnValueTxt", "1000");
        form1040LineItems.put("/IRS1040/TotalTaxAmt", totalTaxLine);
        
        // Set up Additional Medicare Tax line item
        Map<String, Object> medicareTaxLine = new HashMap<>();
        medicareTaxLine.put("userAdjustedLineInd", "N");
        medicareTaxLine.put("perReturnValueTxt", "100");
        form1040LineItems.put("/IRS8959/AdditionalTaxGrp/AdditionalMedicareTaxGrp/AdditionalMedicareTaxAmt", medicareTaxLine);
        
        Map<String, String> trResultMap = new HashMap<>();
        trResultMap.put("totalTaxAmt", "1000");
        trResultMap.put("additionalMedicareTaxAmt", "50");
        trResultMap.put("earnedIncomeCreditAmt", "0");
        trResultMap.put("additionalChildTaxCreditAmt", "0");
        trResultMap.put("refundableAmerOppCreditAmt", "0");
        trResultMap.put("totalOtherPaymentsRfdblCrAmt", "0");

        // Act
        BigDecimal result = service.computeW(form1040LineItems, trResultMap, true);

        // Assert
        assertNotNull(result);
        assertEquals(new BigDecimal("950"), result); // 1000 - (100-50)
    }

    @Test
    void computeXY_WhenValidData_ShouldCalculateCorrectly() {
        // Arrange
        Map<String, Map<String, Object>> form1040LineItems = createForm1040LineItems();
        Map<String, String> trResultMap = createTrResultMap();
        String taxShownInReturn = "1000";

        // Act
        BigDecimal[] result = service.computeXY(form1040LineItems, trResultMap, taxShownInReturn, true);

        // Assert
        assertNotNull(result);
        assertEquals(2, result.length);
        assertTrue(result[0].compareTo(BigDecimal.ZERO) >= 0);
        assertTrue(result[1].compareTo(BigDecimal.ZERO) >= 0);
    }

    //@Test
    void calculate20PctPenalties_WhenValidData_ShouldCalculateCorrectly() {
        // Arrange
        Map<String, Map<String, String>> trResultMap = new HashMap<>();
        Map<String, String> penaltyMap = createTrResultMap();
        // Use the exact constant as defined in the service
        trResultMap.put("CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_20PCT_PNLTY", penaltyMap);
        trResultMap.put("CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_20PCT_PNLTY", penaltyMap);
        
        Map<String, Map<String, Object>> form1040LineItems = createDetailedForm1040LineItems();
        Map<String, Map<String, Map<String, String>>> underPaymentMap = createInitialUnderPaymentMap();
        Set<String> penaltyTypes = new HashSet<>(Arrays.asList("6662(a)", "6662(b)(1)", "6662(b)(2)")); // Use exact penalty codes
        String taxShownInReturn = "1000";

        // Act
        service.calculate20PctPenalties(trResultMap, form1040LineItems, underPaymentMap, penaltyTypes, taxShownInReturn);

        // Assert
        Map<String, Map<String, String>> agreedMap = underPaymentMap.get("Agreed");
        assertNotNull(agreedMap, "Agreed map should not be null");
        assertTrue(agreedMap.containsKey("20"), "Should contain 20% penalty map");
    }

    //@Test
    void calculate40PctPenalties_WhenValidData_ShouldCalculateCorrectly() {
        // Arrange
        Map<String, Map<String, String>> trResultMap = new HashMap<>();
        Map<String, String> penaltyMap = createTrResultMap();
        // Use the exact constant as defined in the service
        trResultMap.put("CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_40PCT_PNLTY", penaltyMap);
        trResultMap.put("CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_40PCT_PNLTY", penaltyMap);
        
        Map<String, Map<String, Object>> form1040LineItems = createDetailedForm1040LineItems();
        Map<String, Map<String, Map<String, String>>> underPaymentMap = createInitialUnderPaymentMap();
        
        // Add prerequisite 20% penalty data
        Map<String, Map<String, String>> agreedMap = underPaymentMap.get("Agreed");
        Map<String, String> penalty20Map = new HashMap<>();
        penalty20Map.put("w", "1000");
        penalty20Map.put("underPayment", "800");
        agreedMap.put("20", penalty20Map);
        
        Set<String> penaltyTypes = new HashSet<>(Arrays.asList("6662A")); // Use exact penalty code for 40%
        String taxShownInReturn = "1000";

        // Act
        service.calculate40PctPenalties(trResultMap, form1040LineItems, underPaymentMap, penaltyTypes, taxShownInReturn);

        // Assert
        assertTrue(agreedMap.containsKey("40"), "Should contain 40% penalty map");
    }

    //@Test
    void calculate75PctPenalties_WhenValidData_ShouldCalculateCorrectly() {
        // Arrange
        Map<String, Map<String, String>> trResultMap = new HashMap<>();
        Map<String, String> penaltyMap = createTrResultMap();
        // Use the exact constant as defined in the service
        trResultMap.put("CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_75PCT_PNLTY", penaltyMap);
        trResultMap.put("CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_75PCT_PNLTY", penaltyMap);
        
        Map<String, Map<String, Object>> form1040LineItems = createDetailedForm1040LineItems();
        Map<String, Map<String, Map<String, String>>> underPaymentMap = createInitialUnderPaymentMap();
        
        // Add prerequisite penalty data
        Map<String, Map<String, String>> agreedMap = underPaymentMap.get("Agreed");
        Map<String, String> penalty40Map = new HashMap<>();
        penalty40Map.put("w", "1000");
        penalty40Map.put("underPayment", "700");
        agreedMap.put("40", penalty40Map);
        
        Set<String> penaltyTypes = new HashSet<>(Arrays.asList("6663")); // Use exact penalty code for 75%
        String taxShownInReturn = "1000";

        // Act
        service.calculate75PctPenalties(trResultMap, form1040LineItems, underPaymentMap, penaltyTypes, taxShownInReturn);

        // Assert
        assertTrue(agreedMap.containsKey("75"), "Should contain 75% penalty map");
    }
    
    private Map<String, Map<String, Object>> createForm1040LineItems() {
        Map<String, Map<String, Object>> lineItems = new HashMap<>();
        
        // TotalTaxAmt
        Map<String, Object> totalTaxLine = new HashMap<>();
        totalTaxLine.put("perReturnValueTxt", "1000");
        lineItems.put("/IRS1040/TotalTaxAmt", totalTaxLine);
        
        // EarnedIncomeCreditAmt
        Map<String, Object> eicLine = new HashMap<>();
        eicLine.put("perReturnValueTxt", "100");
        lineItems.put("/IRS1040/EarnedIncomeCreditAmt", eicLine);
        
        // FormW2WithheldTaxAmt with userAdjustedLineInd
        Map<String, Object> w2Line = new HashMap<>();
        w2Line.put("userAdjustedLineInd", "Y");
        w2Line.put("agreedAdjustmentValueTxt", "200");
        w2Line.put("perReturnValueTxt", "200");
        lineItems.put("/IRS1040/FormW2WithheldTaxAmt", w2Line);
        
        return lineItems;
    }

    private Map<String, Map<String, Object>> createDetailedForm1040LineItems() {
        Map<String, Map<String, Object>> lineItems = new HashMap<>();
        
        // TotalTaxAmt
        Map<String, Object> totalTaxLine = new HashMap<>();
        totalTaxLine.put("perReturnValueTxt", "1000");
        totalTaxLine.put("totalAdjustmentValueTxt", "200");
        totalTaxLine.put("agreedAdjustmentValueTxt", "200");
        lineItems.put("/IRS1040/TotalTaxAmt", totalTaxLine);
        
        // FormW2WithheldTaxAmt
        Map<String, Object> w2Line = new HashMap<>();
        w2Line.put("userAdjustedLineInd", "Y");
        w2Line.put("perReturnValueTxt", "200");
        w2Line.put("totalAdjustmentValueTxt", "50");
        w2Line.put("agreedAdjustmentValueTxt", "50");
        lineItems.put("/IRS1040/FormW2WithheldTaxAmt", w2Line);
        
        // Form1099WithheldTaxAmt
        Map<String, Object> form1099Line = new HashMap<>();
        form1099Line.put("userAdjustedLineInd", "N");
        form1099Line.put("perReturnValueTxt", "100");
        lineItems.put("/IRS1040/Form1099WithheldTaxAmt", form1099Line);
        
        // EarnedIncomeCreditAmt
        Map<String, Object> eicLine = new HashMap<>();
        eicLine.put("perReturnValueTxt", "50");
        lineItems.put("/IRS1040/EarnedIncomeCreditAmt", eicLine);
        
        return lineItems;
    }

    private Map<String, String> createTrResultMap() {
        Map<String, String> map = new HashMap<>();
        map.put("totalTaxAmt", "1000");
        map.put("earnedIncomeCreditAmt", "50");
        map.put("formW2WithheldTaxAmt", "200");
        map.put("form1099WithheldTaxAmt", "100");
        map.put("taxWithheldOtherAmt", "0");
        map.put("estimatedTaxPaymentsAmt", "0");
        map.put("additionalMedicareTaxAmt", "0");
        map.put("additionalChildTaxCreditAmt", "0");
        map.put("refundableAmerOppCreditAmt", "0");
        map.put("totalOtherPaymentsRfdblCrAmt", "0");
        return map;
    }

    private Map<String, Map<String, Map<String, String>>> createInitialUnderPaymentMap() {
        Map<String, Map<String, Map<String, String>>> underPaymentMap = new HashMap<>();
        
        // Create Agreed map with noPenalty
        Map<String, Map<String, String>> agreedMap = new HashMap<>();
        Map<String, String> noPenaltyMap = new HashMap<>();
        noPenaltyMap.put("w", "1000");
        noPenaltyMap.put("underPayment", "800");
        agreedMap.put("noPenalty", noPenaltyMap);
        underPaymentMap.put("Agreed", agreedMap);
        
        // Create Total map with same structure
        Map<String, Map<String, String>> totalMap = new HashMap<>();
        Map<String, String> totalNoPenaltyMap = new HashMap<>();
        totalNoPenaltyMap.put("w", "1000");
        totalNoPenaltyMap.put("underPayment", "800");
        totalMap.put("noPenalty", totalNoPenaltyMap);
        underPaymentMap.put("Total", totalMap);
        
        return underPaymentMap;
    }
}