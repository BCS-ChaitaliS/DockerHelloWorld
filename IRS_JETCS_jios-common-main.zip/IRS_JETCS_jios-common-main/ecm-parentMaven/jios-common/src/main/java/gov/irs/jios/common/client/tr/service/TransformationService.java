package gov.irs.jios.common.client.tr.service;

import static gov.irs.jios.common.util.JiosCommonConstants.ADJUSTMENT_STATUS_CD;
import static gov.irs.jios.common.util.JiosCommonConstants.AGREED_ADJ_TAX_CALC_VALUE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.AGREED_ADJ_VALUE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_AGREED;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_NO_CHANGE;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PARTIAL;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_TOTAL;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_UNAGREED;
import static gov.irs.jios.common.util.JiosCommonConstants.EMPTY_STRING;
import static gov.irs.jios.common.util.JiosCommonConstants.EXCLUDE_PENALTY_TYPES1;
import static gov.irs.jios.common.util.JiosCommonConstants.EXCLUDE_PENALTY_TYPES2;
import static gov.irs.jios.common.util.JiosCommonConstants.FALSE;
import static gov.irs.jios.common.util.JiosCommonConstants.FORMS;
import static gov.irs.jios.common.util.JiosCommonConstants.FORM_NUM;
import static gov.irs.jios.common.util.JiosCommonConstants.ISSUE_PNLTY_AGREMNT_STATUS_IND;
import static gov.irs.jios.common.util.JiosCommonConstants.ISSUE_PNLTY_TYPE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_ITEMS;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_ITEM_REFERENCE_KEY_ID;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_NAME_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.PCT_20_PENALTY_TYPES;
import static gov.irs.jios.common.util.JiosCommonConstants.PCT_40_PENALTY_TYPES;
import static gov.irs.jios.common.util.JiosCommonConstants.PCT_75_PENALTY_TYPES;
import static gov.irs.jios.common.util.JiosCommonConstants.PER_RETURN_VALUE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.PRIMARY_TIN;
import static gov.irs.jios.common.util.JiosCommonConstants.REMOVE_IT_LATER;
import static gov.irs.jios.common.util.JiosCommonConstants.SECONDARY_TIN;
import static gov.irs.jios.common.util.JiosCommonConstants.SECOND_CALL_FOR_PARTIAL_TAX_CALC;
import static gov.irs.jios.common.util.JiosCommonConstants.SEQUENCE_NUM;
import static gov.irs.jios.common.util.JiosCommonConstants.STAT_AGREED_ADJ_TAX_CALC_VALUE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.STAT_TOTAL_ADJ_TAX_CALC_VALUE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.TAX_CALCULATOR_VALUE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.TOTAL_ADJ_TAX_CALC_VALUE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.TOTAL_ADJ_VALUE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.TRUE;
import static gov.irs.jios.common.util.JiosCommonConstants.USER_ADJ_LINE_IND;
import static gov.irs.jios.common.util.JiosCommonConstants.VARIANCE_VALUE_TXT;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import gov.irs.jios.common.client.preprocessor.EcmPreProcessorRegistry;
import gov.irs.jios.common.client.tr.pojo.Field;
import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import gov.irs.jios.common.client.tr.pojo.FieldsRequest;
import gov.irs.jios.common.client.tr.pojo.FieldsResponse;
import gov.irs.jios.common.client.tr.pojo.GroupField;
import gov.irs.jios.common.client.tr.pojo.RetrieveFieldsRequest;
import gov.irs.jios.common.client.tr.pojo.RetrieveFieldsResponse;
import gov.irs.jios.common.client.tr.pojo.SaveFieldsRequest;
import gov.irs.jios.common.client.tr.util.TRCommonUtil;
import gov.irs.jios.common.client.transformer.Form1040ScheduleBTransformer;
import gov.irs.jios.common.client.transformer.FormIRS1040ScheduleCTransformer;
import gov.irs.jios.common.client.transformer.FormIRS1040ScheduleJTransformer;
import gov.irs.jios.common.client.transformer.FormIRS1040Transformer;
import gov.irs.jios.common.client.transformer.FormIRS5329Transformer;
import gov.irs.jios.common.client.transformer.FormIRS5695Transformer;
import gov.irs.jios.common.client.transformer.FormIRS8615Transformer;
import gov.irs.jios.common.client.transformer.FormIRS8829Transformer;
import gov.irs.jios.common.client.transformer.FormIRS8839Transformer;
import gov.irs.jios.common.client.transformer.FormIRS8863Transformer;
import gov.irs.jios.common.client.transformer.FormIRS8885Transformer;
import gov.irs.jios.common.pojo.FormIdentifier;
import gov.irs.jios.common.pojo.FormStructureBuilder;
import gov.irs.jios.common.pojo.LineItemStructure;
import gov.irs.jios.common.request.ValidatableRequest;
import gov.irs.jios.common.util.CommonUtil;
import gov.irs.jios.common.util.RequestOverrider;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class TransformationService {
	
    private final Environment environment;
    private final ConcurrentHashMap<String, Map<String, String>> perReturnValueToTargetFieldMap = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Class<?>> formTransformers = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Integer> groupFieldIndexCounter = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, List<FieldMapping>> groupFieldToMappingsIndex = new ConcurrentHashMap<>();
    
    private static final ThreadLocal<Boolean> isSecondCallForPartialTaxCalc = ThreadLocal.withInitial(() -> false);
    private static final ThreadLocal<String> calcTypeTxt = new ThreadLocal<>();    
    private final ThreadLocal<Map<String, String>> ssnMappingStore = new ThreadLocal<>();

    @Setter @Getter
    private boolean isSnapShotPresent;

    @Autowired
    private EcmPreProcessorRegistry preProcessorRegistry;

    public TransformationService(Environment environment) {
        this.environment = environment;
        
        // Register form-specific transformers
        formTransformers.put("IRS5329", FormIRS5329Transformer.class);
		formTransformers.put("IRS8615", FormIRS8615Transformer.class);
        formTransformers.put("IRS8839", FormIRS8839Transformer.class);
        formTransformers.put("IRS8863", FormIRS8863Transformer.class);
        formTransformers.put("IRS1040", FormIRS1040Transformer.class);
		formTransformers.put("IRS1040ScheduleC", FormIRS1040ScheduleCTransformer.class);
		formTransformers.put("IRS1040ScheduleB", Form1040ScheduleBTransformer.class);
        formTransformers.put("IRS1040ScheduleJ", FormIRS1040ScheduleJTransformer.class);
		formTransformers.put("IRS5695", FormIRS5695Transformer.class);
        formTransformers.put("IRS8885", FormIRS8885Transformer.class);
        formTransformers.put("IRS8829", FormIRS8829Transformer.class);
    }
    
    public SaveFieldsRequest transformEcmToTrSaveFields(ValidatableRequest request, List<FieldMapping> fieldMappings) {
        log.info("Starting ECM to TR transformation for save fields operation");
        try {
            validateRequest(request, fieldMappings);
            initializePerReturnValueToTargetFieldMap(fieldMappings);
            
            // Store SSN mapping for future use
            Map<String, String> ssnMapping = new HashMap<>();
            ssnMapping.put(PRIMARY_TIN, (String) request.getHeader().get(PRIMARY_TIN));
            ssnMapping.put(SECONDARY_TIN, (String) request.getHeader().get(SECONDARY_TIN));
            ssnMappingStore.set(ssnMapping);
            
            calcTypeTxt.set((String) request.getHeader().get(CALC_TYPE_TXT));
            Boolean isSecondCall = false;
            if (isCalcTypePresent() && request.getHeader().containsKey(SECOND_CALL_FOR_PARTIAL_TAX_CALC)) {
                isSecondCall = (Boolean)request.getHeader().get(SECOND_CALL_FOR_PARTIAL_TAX_CALC);
            }
            isSecondCallForPartialTaxCalc.set(isSecondCall);
            log.info("calcTypeTxt: {} isSecondCallForPartialTaxCalc: {}", calcTypeTxt.get(), isSecondCallForPartialTaxCalc.get());
            
            Map<String, List<Map<String, Object>>> formMap = createFormMap(request.getBody());
            log.info("Created form map with {} unique form types", formMap.size());
            
            List<FieldMapping> relevantFieldMappings = loadRelevantFieldMappings(formMap, request.getHeader(), fieldMappings);
            log.info("Loaded {} relevant field mappings", relevantFieldMappings.size());
            
            indexFieldMappings(relevantFieldMappings);
            preprocessRequest(request, relevantFieldMappings);
            
            // Analyze FieldMappings for duplicates
            analyzeFieldMappingDuplicates(relevantFieldMappings);
            
            SaveFieldsRequest saveFieldsRequest = new SaveFieldsRequest();
            List<FieldsRequest> fieldsRequests = processAllFields(relevantFieldMappings, formMap, request);
            
			RequestOverrider requestOverrider = new RequestOverrider();
			requestOverrider.flagForms(formMap);
			// fieldsRequests should be refactored to avoid reassigning itself.
			fieldsRequests = requestOverrider.customTransformOverFieldsRequests(
					fieldsRequests,
					formTransformers,
					formMap
			);

            postProcessRequest(request);
            
            saveFieldsRequest.setFieldsRequest(fieldsRequests);
            
            log.info("Completed ECM to TR transformation");
            return saveFieldsRequest;
        } finally {
            perReturnValueToTargetFieldMap.clear();
        	groupFieldIndexCounter.clear();
            groupFieldToMappingsIndex.clear();
        }
    }
    
    private void analyzeFieldMappingDuplicates(List<FieldMapping> allMappings) {
        log.info("Starting pre-analysis of field mappings");
        
        // Group mappings by source field
        Map<String, List<FieldMapping>> sourceFieldGroups = allMappings.stream()
            .filter(fm -> fm.getSourceField() != null)
            .collect(Collectors.groupingBy(FieldMapping::getSourceField));
        
        // Log duplicate source fields
        sourceFieldGroups.forEach((sourceField, mappings) -> {
            if (mappings.size() > 1) {
                log.info("Found {} mappings for source field '{}': ", mappings.size(), sourceField);
                mappings.forEach(mapping -> 
                    log.info("  - Target: {}, Form: {}, GroupField: {}", 
                        mapping.getTargetField(), 
                        mapping.getSourceForm(), 
                        mapping.getGroupField())
                );
            }
        });

        // Group mappings by target field
        Map<String, List<FieldMapping>> targetFieldGroups = allMappings.stream()
            .filter(fm -> fm.getTargetField() != null)
            .collect(Collectors.groupingBy(FieldMapping::getTargetField));
        
        // Log duplicate target fields
        targetFieldGroups.forEach((targetField, mappings) -> {
            if (mappings.size() > 1) {
                log.info("Found {} mappings for target field '{}': ", mappings.size(), targetField);
                mappings.forEach(mapping -> 
                    log.info("  - Source: {}, Form: {}, GroupField: {}", 
                        mapping.getSourceField(), 
                        mapping.getSourceForm(), 
                        mapping.getGroupField())
                );
            }
        });
        
        // Log summary
        long duplicateSourceFields = sourceFieldGroups.values().stream()
            .filter(list -> list.size() > 1).count();
        long duplicateTargetFields = targetFieldGroups.values().stream()
            .filter(list -> list.size() > 1).count();
            
        log.info("Field mapping analysis summary:");
        log.info("- Total mappings: {}", allMappings.size());
        log.info("- Unique source fields: {}", sourceFieldGroups.size());
        log.info("- Source fields with multiple mappings: {}", duplicateSourceFields);
        log.info("- Unique target fields: {}", targetFieldGroups.size());
        log.info("- Target fields with multiple mappings: {}", duplicateTargetFields);
    }
    
	private void preprocessRequest(ValidatableRequest request, List<FieldMapping> allMappings) {
        preprocessRelatedFields(request, allMappings);
        preProcessorRegistry.executePreProcessors(request, allMappings);
	}
	
	private void postProcessRequest(ValidatableRequest request) {
        postProcessRelatedFields(request);
	}

	@SuppressWarnings("unchecked")
    private void preprocessRelatedFields(ValidatableRequest request, List<FieldMapping> allMappings) {
        log.info("Starting preprocessing of related fields");
        
        // Build map of related source field mappings
        Map<String, FieldMapping> relatedSourceFieldMappings = new HashMap<>();
        
        // First pass: collect all mappings that have related source fields
        for (FieldMapping mapping : allMappings) {
            if (mapping.getRelatedSourceFields() != null && !mapping.getRelatedSourceFields().isEmpty()) {
                relatedSourceFieldMappings.put(mapping.getSourceField(), mapping);
                log.debug("Added mapping for source field: {} with related fields: {}", 
                    mapping.getSourceField(), mapping.getRelatedSourceFields());
            }
        }

        if (relatedSourceFieldMappings.isEmpty()) {
            log.debug("No related source fields found for preprocessing");
            return;
        }

        // Get forms from request
        Map<String, Object> body = request.getBody();
        List<Map<String, Object>> forms = (List<Map<String, Object>>) body.get(FORMS);
        if (forms == null) {
            log.warn("No forms found in request body");
            return;
        }

        // Process each form
        for (Map<String, Object> form : forms) {
            String formNum = (String) form.get(FORM_NUM);

            // Process each source field that has related fields
            for (String sourceField : relatedSourceFieldMappings.keySet()) {
                FieldMapping mapping = relatedSourceFieldMappings.get(sourceField);
                
                if (!formNum.equals(mapping.getSourceForm())) {
                	continue;
                }
                
                List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get(LINE_ITEMS);
                if (lineItems == null) {
                	continue;
                }
                processFormForRelatedFields(lineItems, mapping, relatedSourceFieldMappings);
            }
        }
        
        log.info("Completed preprocessing of related fields");
    }

    @SuppressWarnings("unchecked")
    private void processFormForRelatedFields(List<Map<String, Object>> lineItems, 
            FieldMapping mapping, Map<String, FieldMapping> relatedSourceFieldMappings) {
        
        // Process current level
        for (int i = 0; i < lineItems.size(); i++) {
            Map<String, Object> lineItem = lineItems.get(i);
                if (lineItem.get(REMOVE_IT_LATER) != null) { //skip as this was added by the framework
                	continue;
                }
            String lineNameTxt = (String) lineItem.get(LINE_NAME_TXT);
            
            if (mapping.getSourceField().equals(lineNameTxt)) {
                // Found matching line item, process its related fields
                for (String relatedSourceField : mapping.getRelatedSourceFields()) {
                    FieldMapping companionMapping = relatedSourceFieldMappings.get(relatedSourceField);
                    if (companionMapping != null) {
                        // Create companion line item using createBasicLineItem
                        Map<String, Object> companionLineItem = createBasicLineItem(
                            companionMapping.getSourceField(), 
                            FALSE
                        );
                        // Add sequence number from original item
                        companionLineItem.put(SEQUENCE_NUM, lineItem.get(SEQUENCE_NUM));
                        // Add flag for post-processing
                        companionLineItem.put(REMOVE_IT_LATER, true);
                        
                        // Insert after current item
                        lineItems.add(i + 1, companionLineItem);
                        i++; // Skip the newly inserted item in next iteration
                        
                        log.debug("Inserted companion line item for {} after {}", 
                            companionMapping.getSourceField(), lineNameTxt);
                    }
                }
            }
            
            // Recursively process nested line items
            List<Map<String, Object>> nestedLineItems = (List<Map<String, Object>>) lineItem.get(LINE_ITEMS);
            if (nestedLineItems != null) {
                processFormForRelatedFields(nestedLineItems, mapping, relatedSourceFieldMappings);
            }
        }
    }
    
    private List<FieldsRequest> processAllFields(List<FieldMapping> fieldMappings, Map<String, List<Map<String, Object>>> formMap, 
    		ValidatableRequest request) {
        log.info("Processing all fields");
        List<FieldsRequest> fieldsRequests = new ArrayList<>();
        Map<String, List<FieldsRequest>> groupedFieldsRequests = new TreeMap<>();
        Map<String, Map<String, Integer>> groupFieldIndexMap = new HashMap<>();

        // Create a single FieldsRequest for non-grouped fields
        FieldsRequest nonGroupedFieldsRequest = new FieldsRequest();
        nonGroupedFieldsRequest.setGroupField(null);
        nonGroupedFieldsRequest.setFields(new ArrayList<>());

        for (FieldMapping mapping : fieldMappings) {
            if (mapping.getGroupField() == null) {
                processNonGroupedField(mapping, formMap, nonGroupedFieldsRequest.getFields(), request);
            } else {
                processGroupedField(mapping, formMap, groupedFieldsRequests, groupFieldIndexMap, request);
            }
        }

        // Add the non-grouped FieldsRequest only if it has fields
        if (!nonGroupedFieldsRequest.getFields().isEmpty()) {
            fieldsRequests.add(nonGroupedFieldsRequest);
            log.info("Added {} non-grouped fields", nonGroupedFieldsRequest.getFields().size());
        }

        // Add all grouped fields requests to the main list
        for (List<FieldsRequest> groupRequests : groupedFieldsRequests.values()) {
            fieldsRequests.addAll(groupRequests);
        }

        // Sort the fieldsRequests list
        fieldsRequests.sort((fr1, fr2) -> {
            if (fr1.getGroupField() == null && fr2.getGroupField() == null) {
                return 0;
            }
            if (fr1.getGroupField() == null) {
                return -1;
            }
            if (fr2.getGroupField() == null) {
                return 1;
            }
            int fieldIdComparison = fr1.getGroupField().getFieldId().compareTo(fr2.getGroupField().getFieldId());
            if (fieldIdComparison != 0) {
                return fieldIdComparison;
            }
            return Integer.compare(fr1.getGroupField().getIndex(), fr2.getGroupField().getIndex());
        });

        log.info("Sorted {} field requests", fieldsRequests.size());

        return fieldsRequests;
    }

    private void processNonGroupedField(FieldMapping mapping, Map<String, List<Map<String, Object>>> formMap, List<Field> fields, 
    		ValidatableRequest request) {
        if (mapping.getSourceForm() != null && mapping.getSourceField() != null) {
			 // This is a regular mapping
            processNonGroupedFieldMapping(mapping, formMap, fields, request);
        } else if (mapping.getTargetFieldValue() != null) {
			// This is a mock value mapping
            Field field = createField(mapping, null, null, 0, request, null, null);
            if (field != null) {
                fields.add(field);
                log.debug("Added single mock field: {} with value: {}", field.getFieldId(), field.getValue());
            }
        } else {
            log.warn("Invalid field mapping: {}", mapping);
        }
    }
    
    private void processGroupedField(FieldMapping mapping, Map<String, List<Map<String, Object>>> formMap,
            Map<String, List<FieldsRequest>> groupedFieldsRequests, Map<String, Map<String, Integer>> groupFieldIndexMap,
            ValidatableRequest request) {
            
    	String groupField = mapping.getGroupField();
        String sourceForm = mapping.getSourceForm();
        
        // Skip if no source data exists for mocked group field
        if (TRUE.equals(mapping.getGroupFieldMapping()) && 
            mapping.getTargetFieldValue() != null && 
            mapping.getTargetFieldValue().startsWith("${") &&
            !hasSourceDataForGroup(mapping, formMap, groupField)) {
            return;
        }

        List<Map<String, Object>> formInstances = formMap.get(sourceForm);
        if (formInstances == null || formInstances.isEmpty()) {
            if (mapping.getTargetFieldValue() != null) {
                createMockGroupField(mapping, groupedFieldsRequests, groupFieldIndexMap, request);
            }
            return;
        }

        if (TRUE.equals(mapping.getGroupFieldMapping())) {
            processGroupFieldMapping(mapping, formInstances, groupedFieldsRequests, groupFieldIndexMap, 
                request);
        } else {
            processNonGroupFieldMapping(mapping, formInstances, groupedFieldsRequests, groupFieldIndexMap, 
                request);
        }
    }
    
    private boolean hasSourceDataForGroup(FieldMapping mapping, Map<String, List<Map<String, Object>>> formMap, 
            String groupField) {
        String indexKey = createGroupFieldIndexKey(groupField, mapping.getGroupingKey());
        List<FieldMapping> groupMappings = groupFieldToMappingsIndex.get(indexKey);
        if (groupMappings == null) return false;
        
        return groupMappings.stream()
            .filter(m -> m.getSourceField() != null)
            .anyMatch(m -> {
                List<Map<String, Object>> formInstances = formMap.get(m.getSourceForm());
                return formInstances != null && formInstances.stream()
                    .anyMatch(form -> !findSourceFieldInstances(form, m.getSourceField()).isEmpty());
            });
    }
    
    private void processGroupFieldMapping(FieldMapping mapping, List<Map<String, Object>> formInstances,
            Map<String, List<FieldsRequest>> groupedFieldsRequests, Map<String, Map<String, Integer>> groupFieldIndexMap,
            ValidatableRequest request) {
        
        String groupField = mapping.getGroupField();
        
        for (Map<String, Object> form : formInstances) {
            List<Map<String, Object>> groupInstances = mapping.getSourceField() != null ?
                findSourceFieldInstances(form, mapping.getSourceField()) :
                Collections.singletonList(form);

            for (Map<String, Object> instance : groupInstances) {
                // Get current index without incrementing
                int groupIndex = groupFieldIndexCounter.getOrDefault(groupField, 0);
                
                String groupKey = createGroupKey(groupField, mapping.getGroupingKey(), groupIndex);
                List<FieldsRequest> groupRequests = groupedFieldsRequests.computeIfAbsent(groupKey, k -> new ArrayList<>());
                groupFieldIndexMap.computeIfAbsent(groupKey, k -> new HashMap<>());
                
                FieldsRequest groupedFieldsRequest = createGroupFieldRequest(
                    groupField, groupIndex, mapping, instance);
                groupedFieldsRequest.setSourceInstance(instance);
                groupRequests.add(groupedFieldsRequest);
                
                // Increment index after creating the request
                groupFieldIndexCounter.put(groupField, groupIndex + 1);
            }
        }
    }

    
    private void processNonGroupFieldMapping(FieldMapping mapping, List<Map<String, Object>> formInstances,
            Map<String, List<FieldsRequest>> groupedFieldsRequests, Map<String, Map<String, Integer>> groupFieldIndexMap,
            ValidatableRequest request) {
        
        log.debug("Starting processNonGroupFieldMapping with mapping: {}", mapping);
        String groupField = mapping.getGroupField();
        String groupingKey = mapping.getGroupingKey();
        
        // Create the prefix once and make it final
        final String groupPrefix = createGroupKey(groupField, groupingKey, 0)
            .substring(0, createGroupKey(groupField, groupingKey, 0).lastIndexOf('_') + 1);
        
        // Get all relevant group requests
        List<FieldsRequest> relevantRequests = new ArrayList<>();
        groupedFieldsRequests.forEach((key, requests) -> {
            if (key.startsWith(groupPrefix)) {
                relevantRequests.addAll(requests);
            }
        });

        log.debug("Found {} relevant requests", relevantRequests.size());
        
        // Process each relevant request
        for (int groupIndex = 0; groupIndex < relevantRequests.size(); groupIndex++) {
            FieldsRequest groupedFieldsRequest = relevantRequests.get(groupIndex);
            String groupKey = createGroupKey(groupField, groupingKey, groupedFieldsRequest.getGroupField() != null ? groupedFieldsRequest.getGroupField().getIndex() : 0);
            Map<String, Integer> fieldIndexMap = groupFieldIndexMap.computeIfAbsent(groupKey, k -> new HashMap<>());

            if (mapping.getTargetFieldValue() != null) {
                addFieldToGroup(mapping, null, groupedFieldsRequest, fieldIndexMap, request, groupIndex);
            } else if (mapping.getSourceField() != null) {
            	// If source form is different from the group's form, find the source form first
                /*if (!mapping.getSourceForm().equals(groupedFieldsRequest.getSourceInstance().get(FORM_NUM))) {
                    // Find the source form
                    Map<String, Object> sourceForm = findSourceForm(request, mapping.getSourceForm());
                    if (sourceForm != null) {
                        List<Map<String, Object>> sourceInstances = findSourceFieldInstances(
                            sourceForm, mapping.getSourceField());
                        
                        for (Map<String, Object> sourceInstance : sourceInstances) {
                            // Process the source instance...
                            if (TRUE.equals(mapping.getDynamicTargetField()) &&
                                mapping.getPerReturnValueToTargetField() != null) {
                            	// Get perReturnValue from source instance
	                            String perReturnValue = (String) sourceInstance.get(PER_RETURN_VALUE_TXT);
	                            if (perReturnValue != null) {
	                                // Lookup actual targetField from perReturnValueToTargetField map
	                                String actualTargetField = mapping.getPerReturnValueToTargetField().get(perReturnValue);
	                                if (actualTargetField != null) {
	                                    // Create a temporary mapping with the resolved target field
	                                    FieldMapping tempMapping = new FieldMapping();
	                                    tempMapping.setSourceField(mapping.getSourceField());
	                                    tempMapping.setTargetField(actualTargetField);
	                                    tempMapping.setGroupField(mapping.getGroupField());
	                                    tempMapping.setGroupingKey(mapping.getGroupingKey());
	                                    tempMapping.setTransformationClass(mapping.getTransformationClass());
	                                    tempMapping.setTransformationMethod(mapping.getTransformationMethod());
	                                    
	                                    addFieldToGroup(tempMapping, sourceInstance, groupedFieldsRequest, 
	                                        fieldIndexMap, request, groupIndex);
	                                }
	                            }
                            } else {
                                addFieldToGroup(mapping, sourceInstance, groupedFieldsRequest,
                                    fieldIndexMap, request, groupIndex);
                            }
                        }
                    }
                }
                else {*/
	                Map<String, Object> parentGroup = groupedFieldsRequest.getSourceInstance();
	                if (parentGroup != null) {
	                    List<Map<String, Object>> sourceInstances = findSourceFieldInstancesInGroup(
	                        parentGroup, mapping.getSourceField());
	                    for (Map<String, Object> sourceInstance : sourceInstances) {
	                        if (TRUE.equals(mapping.getDynamicTargetField()) && mapping.getPerReturnValueToTargetField() != null) {
	                            // Get perReturnValue from source instance
	                            String perReturnValue = (String) sourceInstance.get(PER_RETURN_VALUE_TXT);
	                            if (perReturnValue != null) {
	                                // Lookup actual targetField from perReturnValueToTargetField map
	                                String actualTargetField = mapping.getPerReturnValueToTargetField().get(perReturnValue);
	                                if (actualTargetField != null) {
	                                    // Create a temporary mapping with the resolved target field
	                                    FieldMapping tempMapping = new FieldMapping();
	                                    tempMapping.setSourceField(mapping.getSourceField());
	                                    tempMapping.setTargetField(actualTargetField);
	                                    tempMapping.setGroupField(mapping.getGroupField());
	                                    tempMapping.setGroupingKey(mapping.getGroupingKey());
	                                    tempMapping.setTransformationClass(mapping.getTransformationClass());
	                                    tempMapping.setTransformationMethod(mapping.getTransformationMethod());
	                                    
	                                    addFieldToGroup(tempMapping, sourceInstance, groupedFieldsRequest, fieldIndexMap, 
	                                    		request, groupIndex);
	                                }
	                            }
	                        } else {
	                            addFieldToGroup(mapping, sourceInstance, groupedFieldsRequest, 
	                                fieldIndexMap, request, groupIndex);
	                        }
	                    }
	                }
                //}
            }
        }
    }
    
    /*@SuppressWarnings("unchecked")
    private Map<String, Object> findSourceForm(ValidatableRequest request, String formNum) {
        List<Map<String, Object>> forms = (List<Map<String, Object>>) request.getBody().get(FORMS);
        if (forms != null) {
            return forms.stream()
                .filter(form -> formNum.equals(form.get(FORM_NUM)))
                .findFirst()
                .orElse(null);
        }
        return null;
    }*/

    private List<Map<String, Object>> findSourceFieldInstancesInGroup(Map<String, Object> groupInstance, String sourceField) {
        List<Map<String, Object>> result = new ArrayList<>();
        findSourceFieldInstancesInGroupRecursive(groupInstance, sourceField, result);
        return result;
    }

    private void findSourceFieldInstancesInGroupRecursive(Object obj, String sourceField, List<Map<String, Object>> result) {
        if (obj instanceof Map) {
            @SuppressWarnings("unchecked")
            Map<String, Object> map = (Map<String, Object>) obj;
            if (sourceField.equals(map.get(LINE_NAME_TXT))) {
                result.add(map);
                return; // Stop searching once we find the field in this branch
            }
            for (Object value : map.values()) {
                findSourceFieldInstancesInGroupRecursive(value, sourceField, result);
            }
        } else if (obj instanceof List) {
            for (Object item : (List<?>) obj) {
                findSourceFieldInstancesInGroupRecursive(item, sourceField, result);
            }
        }
    }

    private void createMockGroupField(FieldMapping mapping, Map<String, List<FieldsRequest>> groupedFieldsRequests,
            Map<String, Map<String, Integer>> groupFieldIndexMap, ValidatableRequest request) {
        
        // Get current index without incrementing
        int groupIndex = groupFieldIndexCounter.getOrDefault(mapping.getGroupField(), 0);
        
        String groupKey = createGroupKey(mapping.getGroupField(), mapping.getGroupingKey(), groupIndex);
        List<FieldsRequest> groupRequests = groupedFieldsRequests.computeIfAbsent(groupKey, k -> new ArrayList<>());
        Map<String, Integer> fieldIndexMap = groupFieldIndexMap.computeIfAbsent(groupKey, k -> new HashMap<>());

        FieldsRequest groupedFieldsRequest = createGroupFieldRequest(mapping.getGroupField(), groupIndex, mapping, null);
        groupRequests.add(groupedFieldsRequest);
        
        addFieldToGroup(mapping, null, groupedFieldsRequest, fieldIndexMap, request, null);
        
        // Increment index after creating the request
        groupFieldIndexCounter.put(mapping.getGroupField(), groupIndex + 1);
    }

    private FieldsRequest createGroupFieldRequest(String groupField, int groupIndex, FieldMapping mapping,
            Map<String, Object> instance) {
        
        FieldsRequest request = new FieldsRequest();
        GroupField groupFieldObj = new GroupField();
        groupFieldObj.setFieldId(groupField);
        groupFieldObj.setIndex(groupIndex);
        groupFieldObj.setValue(deriveGroupFieldValue(mapping, instance, groupIndex));

        // Handle child field if present
        if (mapping.getChildField() != null && mapping.getChildFieldValue() != null) {
            GroupField childField = new GroupField();
            childField.setFieldId(mapping.getChildField());
            childField.setIndex(groupIndex);
            childField.setValue(resolveMockValue(mapping.getChildFieldValue(), groupIndex + 1));
            groupFieldObj.setChild(childField);
        }

        request.setGroupField(groupFieldObj);
        request.setFields(new ArrayList<>());
        return request;
    }

    private void addFieldToGroup(FieldMapping mapping, Map<String, Object> sourceInstance, FieldsRequest groupedFieldsRequest,
            Map<String, Integer> fieldIndexMap, ValidatableRequest request, Integer groupIndex) {
        
        String targetField = mapping.getTargetField();
        if (targetField.equals(groupedFieldsRequest.getGroupField().getFieldId())) {
            return;
        }

        String value = null;
        String dependentValue = null;

        if (sourceInstance != null) {
            if (mapping.getSourceField() != null) {
                List<String> values = findFieldValuesRecursive(mapping, sourceInstance, mapping.getSourceField());
                if (!values.isEmpty()) {
                    value = values.get(0);
                }
            }
            if (mapping.getDependentSourceField() != null) {
                List<String> dependentValues = findFieldValuesRecursive(mapping, sourceInstance, mapping.getDependentSourceField());
                if (!dependentValues.isEmpty()) {
                    dependentValue = dependentValues.get(0);
                }
            }
        }

        String resolvedTargetField = resolveTargetField(mapping, value, dependentValue);
        if (resolvedTargetField != null) {
            int fieldIndex = fieldIndexMap.getOrDefault(resolvedTargetField, 0);
            Field field = createField(mapping, value, dependentValue, fieldIndex, request, groupedFieldsRequest, groupIndex);
            
            if (field != null) {
                if (field.getValue() == null) {
                    field.setValue(EMPTY_STRING);
                }
                field.setFieldId(resolvedTargetField);
                groupedFieldsRequest.getFields().add(field);
                fieldIndexMap.put(resolvedTargetField, fieldIndex + 1);
                
                log.debug("Added field: {} with value: {} to group: {}", 
                    resolvedTargetField, field.getValue(), groupedFieldsRequest.getGroupField().getFieldId());
            }
        }
    }
    
    private List<Map<String, Object>> findSourceFieldInstances(Map<String, Object> form, String sourceField) {
        List<Map<String, Object>> result = new ArrayList<>();
        if (sourceField != null) {
            findSourceFieldInstancesRecursive(form, sourceField, result);
        } else {
            result.add(form);
        }
        return result;
    }

    private void findSourceFieldInstancesRecursive(Object obj, String sourceField, List<Map<String, Object>> result) {
        if (obj instanceof Map) {
            @SuppressWarnings("unchecked")
            Map<String, Object> map = (Map<String, Object>) obj;
            if (sourceField.equals(map.get(LINE_NAME_TXT))) {
                result.add(map);
            }
            for (Object value : map.values()) {
                findSourceFieldInstancesRecursive(value, sourceField, result);
            }
        } else if (obj instanceof List) {
            for (Object item : (List<?>) obj) {
                findSourceFieldInstancesRecursive(item, sourceField, result);
            }
        }
    }
    
    private String createGroupKey(String groupField, String groupingKey, int formIndex) {
        StringBuilder keyBuilder = new StringBuilder(groupField);
        if (groupingKey != null && !groupingKey.isEmpty()) {
            keyBuilder.append("_").append(groupingKey);
        }
        keyBuilder.append("_").append(formIndex);
        return keyBuilder.toString();
    }

	private String resolveTargetField(FieldMapping mapping, String value, String dependentValue) {
        if (TRUE.equals(mapping.getDynamicTargetField())) {
            String keyToUse = dependentValue != null ? dependentValue : value;
            String resolvedField = resolveDynamicTargetField(mapping, value, dependentValue);
            if (resolvedField != null) {
                log.debug("Resolved dynamic target field: {} for value: {}", resolvedField, keyToUse);
                return resolvedField;
            }
            log.warn("No dynamic target field found for sourceField: {} and value: {}. Skipping this field.", 
                     mapping.getSourceField(), keyToUse);
            return null;
        }
        return mapping.getTargetField();
    }
    
	private void processNonGroupedFieldMapping(FieldMapping mapping, Map<String, List<Map<String, Object>>> formMap, List<Field> fields, 
			ValidatableRequest request) {
	    String sourceForm = mapping.getSourceForm();
	    String sourceField = mapping.getSourceField();

	    if (sourceForm == null && sourceField == null && mapping.getTargetFieldValue() != null) {
	        // This is a mock field without source, process it directly
	        createAndAddField(mapping, null, null, 0, fields, request);
	        return;
	    }

	    if (formMap.containsKey(sourceForm)) {
	        List<Map<String, Object>> formInstances = formMap.get(sourceForm);
	        for (int formIndex = 0; formIndex < formInstances.size(); formIndex++) {
	            Map<String, Object> form = formInstances.get(formIndex);
	            List<String> values = findFieldValuesRecursive(mapping, form, sourceField);
	            
                List<String> dependentValues = mapping.getDependentSourceField() != null ?
                        findFieldValuesRecursive(mapping, form, mapping.getDependentSourceField()) : Collections.emptyList();
	                
	            if (!values.isEmpty() || !dependentValues.isEmpty()) {
	                int maxSize = Math.max(values.size(), dependentValues.size());

	                for (int valueIndex = 0; valueIndex < maxSize; valueIndex++) {
	                	String value = values.get(valueIndex);
	                    String dependentValue = valueIndex < dependentValues.size() ? dependentValues.get(valueIndex) : null;
	                    createAndAddField(mapping, value, dependentValue, valueIndex, fields, request);
	                }
	            }
	        }
	    }
	}
    
	private void createAndAddField(FieldMapping mapping, String value, String dependentValue, int index, List<Field> fields, ValidatableRequest request) {
        String resolvedTargetField = resolveTargetField(mapping, value, dependentValue);
        if (resolvedTargetField != null) {
            Field field = createField(mapping, value, dependentValue, index, request, null, null);
            if (field == null) {
            	return;
            }
            //Send the field value as empty string for the lineItem that is mapped in the mapping-config buy missing in the ECM payload
            if (field.getValue() == null) {
            	field.setValue(EMPTY_STRING);
            }
            field.setFieldId(resolvedTargetField);
            fields.add(field);
            log.debug("Added field: {} with value: {}, index: {}", resolvedTargetField, value, index);
        }
    }
    
	@SuppressWarnings("unchecked")
    private List<String> findFieldValuesRecursive(FieldMapping mapping, Map<String, Object> item, String sourceField) {
        List<String> values = new ArrayList<>();

        if (item == null || sourceField == null) {
            return values;
        }

        // Check if the current item matches the sourceField
        if (sourceField.equals(item.get(LINE_NAME_TXT))) {
            String value = getAppropriateValue(mapping, item);
            if (value != null) {
                values.add(value);
            }
        }

        // Recursively check nested items
        for (Map.Entry<String, Object> entry : item.entrySet()) {
            if (entry.getValue() instanceof Map) {
                values.addAll(findFieldValuesRecursive(mapping, (Map<String, Object>) entry.getValue(), sourceField));
            } else if (entry.getValue() instanceof List) {
                for (Object listItem : (List<?>) entry.getValue()) {
                    if (listItem instanceof Map) {
                        values.addAll(findFieldValuesRecursive(mapping, (Map<String, Object>) listItem, sourceField));
                    }
                }
            }
        }

        return values;
    }
	
	private void indexFieldMappings(List<FieldMapping> mappings) {
	    mappings.forEach(mapping -> {
	        if (mapping.getGroupField() != null) {
	            String indexKey = createGroupFieldIndexKey(mapping.getGroupField(), mapping.getGroupingKey());
	            groupFieldToMappingsIndex.computeIfAbsent(indexKey, k -> new ArrayList<>())
	                .add(mapping);
	        }
	    });
	}
	
	private String createGroupFieldIndexKey(String groupField, String groupingKey) {
	    return groupingKey != null ? groupField + "_" + groupingKey : groupField;
	}

	public static String getAppropriateValue(Map<String, Object> item) {
		return getAppropriateValue(null, item);
	}
	
    private static String getAppropriateValue(FieldMapping mapping, Map<String, Object> item) {
    	
    	String perReturnValueTxt = (String) item.get(PER_RETURN_VALUE_TXT);
    	String agreedAdjValue = (String) item.get(AGREED_ADJ_VALUE_TXT);
    	String totalAdjustmentValue = (String) item.get(TOTAL_ADJ_VALUE_TXT);
    	//String lineNameTxt = (String) item.get(LINE_NAME_TXT);
    	
    	if (!isCalcTypePresent()) {
            return perReturnValueTxt;
        }

        // Field like /IRS1040/IndividualReturnFilingStatusCd comes in as number but it should not be added to AdjustmentValue.
        // It should be return as is.
        if (mapping != null && TRUE.equals(mapping.getDoNotAddAdjmntValue())){
        	return perReturnValueTxt;
        }
        
        switch (calcTypeTxt.get()) {
        	case CALC_TYPE_NO_CHANGE:
        		return perReturnValueTxt;
            case CALC_TYPE_AGREED:
            case CALC_TYPE_UNAGREED:
            	if (CommonUtil.isNonEmptyNonNumeric(totalAdjustmentValue)) {
                    return totalAdjustmentValue;
                }
            	if (CommonUtil.isNumeric(totalAdjustmentValue)) {
                    if (CommonUtil.isEmpty(perReturnValueTxt)) {
                        return totalAdjustmentValue;
                    }
                    if (CommonUtil.isNumeric(perReturnValueTxt)) {
                        return CommonUtil.addTwoNumbers(perReturnValueTxt, totalAdjustmentValue);
                    }
                }
            	return perReturnValueTxt;
            case CALC_TYPE_PARTIAL:
            case CALC_TYPE_TOTAL:
            	if (isSecondCallForPartialTaxCalc.get()) {
            		if (CommonUtil.isNonEmptyNonNumeric(agreedAdjValue)) {
	            		return agreedAdjValue;
	            	}
            		if (CommonUtil.isNumeric(agreedAdjValue)) {
            			if (CommonUtil.isEmpty(perReturnValueTxt)) {
                            return agreedAdjValue;
                        }
    	            	if (CommonUtil.isNumeric(perReturnValueTxt)) {
    	    	            return CommonUtil.addTwoNumbers(perReturnValueTxt, agreedAdjValue);
    	    	        }
            		}
	            } else {
	            	if (CommonUtil.isNonEmptyNonNumeric(totalAdjustmentValue)) {
	            		return totalAdjustmentValue;
	            	}
	            	if (CommonUtil.isNumeric(totalAdjustmentValue)) {
            			if (CommonUtil.isEmpty(perReturnValueTxt)) {
                            return totalAdjustmentValue;
                        }
    	            	if (CommonUtil.isNumeric(perReturnValueTxt)) {
    	            		return CommonUtil.addTwoNumbers(perReturnValueTxt, totalAdjustmentValue);
    	    	        }
            		}
	            }
            	return perReturnValueTxt;
                
            // Penalty Calculation - Step 3 - Calculate Amounts Subject to Penalty (6662A) - Agreed
            case CALC_TYPE_PENALTY_AGR_UNDRPYMNT_EXCL_6662A:
            	if (CommonUtil.isNonEmptyNonNumeric(agreedAdjValue)) {
            		return agreedAdjValue;
            	}
            	if (CommonUtil.isNonEmptyNonNumeric(perReturnValueTxt)) {
            		return perReturnValueTxt;
            	}
            	if (CommonUtil.isEmpty(agreedAdjValue)) {
            		agreedAdjValue = "0";
            	}
            	if (CommonUtil.isEmpty(perReturnValueTxt)) {
            		perReturnValueTxt = "0";
            	}
            	String issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES1.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Agreed Adj when (issuePenaltyAgreementStatusInd = 'Y' or "")
            	String issuePenaltyAgreementStatusInd = null;
            	if (item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND) != null) {
            		issuePenaltyAgreementStatusInd = (String) item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND);
            	}
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(agreedAdjValue) && 
            		issuePenaltyAgreementStatusInd != null && ("Y".equals(issuePenaltyAgreementStatusInd) || EMPTY_STRING.equals(issuePenaltyAgreementStatusInd))) {
            		return CommonUtil.addTwoNumbers(perReturnValueTxt, agreedAdjValue);
    	        }
                return perReturnValueTxt;
                
            // Penalty Calculation - Step 4 - Calculate Amounts Subject to Penalty (6662A) - Total
            case CALC_TYPE_PENALTY_TOT_UNDRPYMNT_EXCL_6662A:
            	if (CommonUtil.isNonEmptyNonNumeric(totalAdjustmentValue)) {
            		return totalAdjustmentValue;
            	}
            	if (CommonUtil.isNonEmptyNonNumeric(perReturnValueTxt)) {
            		return perReturnValueTxt;
            	}
            	if (CommonUtil.isEmpty(totalAdjustmentValue)) {
            		totalAdjustmentValue = "0";
            	}
            	if (CommonUtil.isEmpty(perReturnValueTxt)) {
            		perReturnValueTxt = "0";
            	}
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES1.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Total Adj
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(totalAdjustmentValue)) {
            		return CommonUtil.addTwoNumbers(perReturnValueTxt, totalAdjustmentValue);
    	        }
            	return perReturnValueTxt;

            // Penalty Calculation - Step 5 - Calculate Amounts Subject to No Penalty - Agreed
            case CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A:
            	if (CommonUtil.isNonEmptyNonNumeric(agreedAdjValue)) {
            		return agreedAdjValue;
            	}
            	if (CommonUtil.isNonEmptyNonNumeric(perReturnValueTxt)) {
            		return perReturnValueTxt;
            	}
            	if (CommonUtil.isEmpty(agreedAdjValue)) {
            		agreedAdjValue = "0";
            	}
            	if (CommonUtil.isEmpty(perReturnValueTxt)) {
            		perReturnValueTxt = "0";
            	}
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES1.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	issuePenaltyAgreementStatusInd = null;
            	if (item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND) != null) {
            		issuePenaltyAgreementStatusInd = (String) item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND);
            	}
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Send Per Return + Agreed Adj when (issuePenaltyAgreementStatusInd = 'Y' or "") and "issuePenaltyTypeTxt" = ""
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(agreedAdjValue) && 
        			issuePenaltyAgreementStatusInd != null && ("Y".equals(issuePenaltyAgreementStatusInd) || EMPTY_STRING.equals(issuePenaltyAgreementStatusInd)) &&
        			issuePenaltyTypeTxt != null && EMPTY_STRING.equals(issuePenaltyTypeTxt)) {
            		return CommonUtil.addTwoNumbers(perReturnValueTxt, agreedAdjValue);
    	        }
            	return perReturnValueTxt;

            // Penalty Calculation - Step 6 - Calculate Amounts Subject to No Penalty - Total
            case CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A:
	            if (CommonUtil.isNonEmptyNonNumeric(totalAdjustmentValue)) {
            		return totalAdjustmentValue;
            	}
	            if (CommonUtil.isNonEmptyNonNumeric(perReturnValueTxt)) {
            		return perReturnValueTxt;
            	}
	            if (CommonUtil.isEmpty(totalAdjustmentValue)) {
            		totalAdjustmentValue = "0";
            	}
            	if (CommonUtil.isEmpty(perReturnValueTxt)) {
            		perReturnValueTxt = "0";
            	}
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES1.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Total Adj when "issuePenaltyTypeTxt" = ""
	            if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(totalAdjustmentValue) &&
        			issuePenaltyTypeTxt != null && EMPTY_STRING.equals(issuePenaltyTypeTxt)) {
	            	return CommonUtil.addTwoNumbers(perReturnValueTxt, totalAdjustmentValue);
            	}
            	return perReturnValueTxt;
            	
            // Penalty Calculation - Step 7 - Calculate Amounts Subject to 20% Penalty - Agreed
            case CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A:
            	if (CommonUtil.isNonEmptyNonNumeric(agreedAdjValue)) {
            		return agreedAdjValue;
            	}
            	if (CommonUtil.isNonEmptyNonNumeric(perReturnValueTxt)) {
            		return perReturnValueTxt;
            	}
            	if (CommonUtil.isEmpty(agreedAdjValue)) {
            		agreedAdjValue = "0";
            	}
            	if (CommonUtil.isEmpty(perReturnValueTxt)) {
            		perReturnValueTxt = "0";
            	}
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES1.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Agreed Adj when (issuePenaltyAgreementStatusInd = 'Y' or "") and ("issuePenaltyTypeTxt" = "" or a 20% Penalty)
            	issuePenaltyAgreementStatusInd = null;
            	if (item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND) != null) {
            		issuePenaltyAgreementStatusInd = (String) item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND);
            	}
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(agreedAdjValue) && 
        			issuePenaltyAgreementStatusInd != null && ("Y".equals(issuePenaltyAgreementStatusInd) || EMPTY_STRING.equals(issuePenaltyAgreementStatusInd)) && 
        			issuePenaltyTypeTxt != null && (
    					EMPTY_STRING.equals(issuePenaltyTypeTxt) ||
    					PCT_20_PENALTY_TYPES.contains(issuePenaltyTypeTxt)
        			)) {
            		return CommonUtil.addTwoNumbers(perReturnValueTxt, agreedAdjValue);
    	        }
            	return perReturnValueTxt;

            // Penalty Calculation - Step 8 - Calculate Amounts Subject to 20% Penalty - Total
            case CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A:
            	if (CommonUtil.isNonEmptyNonNumeric(totalAdjustmentValue)) {
            		return totalAdjustmentValue;
            	}
            	if (CommonUtil.isNonEmptyNonNumeric(perReturnValueTxt)) {
            		return perReturnValueTxt;
            	}
            	if (CommonUtil.isEmpty(totalAdjustmentValue)) {
            		totalAdjustmentValue = "0";
            	}
            	if (CommonUtil.isEmpty(perReturnValueTxt)) {
            		perReturnValueTxt = "0";
            	}
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES1.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Total Adj and ("issuePenaltyTypeTxt" = "" or a 20% Penalty)
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(totalAdjustmentValue) &&
        			issuePenaltyTypeTxt != null && (
    					EMPTY_STRING.equals(issuePenaltyTypeTxt) ||
    					PCT_20_PENALTY_TYPES.contains(issuePenaltyTypeTxt)
        			)) {
            		return CommonUtil.addTwoNumbers(perReturnValueTxt, totalAdjustmentValue);
    	        }
            	return perReturnValueTxt;
            	
            // Penalty Calculation - Step 9 - Calculate Amounts Subject to 40% Penalty - Agreed
            case CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A:
            	if (CommonUtil.isNonEmptyNonNumeric(agreedAdjValue)) {
            		return agreedAdjValue;
            	}
            	if (CommonUtil.isNonEmptyNonNumeric(perReturnValueTxt)) {
            		return perReturnValueTxt;
            	}
            	if (CommonUtil.isEmpty(agreedAdjValue)) {
            		agreedAdjValue = "0";
            	}
            	if (CommonUtil.isEmpty(perReturnValueTxt)) {
            		perReturnValueTxt = "0";
            	}
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES1.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Agreed Adj when (issuePenaltyAgreementStatusInd = 'Y' or "") and ("issuePenaltyTypeTxt" = "" or a 20% Penalty or a 40% Penalty)
            	issuePenaltyAgreementStatusInd = null;
            	if (item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND) != null) {
            		issuePenaltyAgreementStatusInd = (String) item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND);
            	}
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(agreedAdjValue) && 
        			issuePenaltyAgreementStatusInd != null && ("Y".equals(issuePenaltyAgreementStatusInd) || EMPTY_STRING.equals(issuePenaltyAgreementStatusInd)) && 
        			issuePenaltyTypeTxt != null && (
    					EMPTY_STRING.equals(issuePenaltyTypeTxt) ||
    					PCT_20_PENALTY_TYPES.contains(issuePenaltyTypeTxt) ||
    					PCT_40_PENALTY_TYPES.contains(issuePenaltyTypeTxt)
            		)) {
            		return CommonUtil.addTwoNumbers(perReturnValueTxt, agreedAdjValue);
    	        }
            	return perReturnValueTxt;

            // Penalty Calculation - Step 10 - Calculate Amounts Subject to 40% Penalty - Total
            case CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A:
            	if (CommonUtil.isNonEmptyNonNumeric(totalAdjustmentValue)) {
            		return totalAdjustmentValue;
            	}
            	if (CommonUtil.isNonEmptyNonNumeric(perReturnValueTxt)) {
            		return perReturnValueTxt;
            	}
            	if (CommonUtil.isEmpty(totalAdjustmentValue)) {
            		totalAdjustmentValue = "0";
            	}
            	if (CommonUtil.isEmpty(perReturnValueTxt)) {
            		perReturnValueTxt = "0";
            	}
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES1.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Total Adj and ("issuePenaltyTypeTxt" = "" or a 20% Penalty or a 40% Penalty)
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(totalAdjustmentValue) &&
        			issuePenaltyTypeTxt != null && (
    					EMPTY_STRING.equals(issuePenaltyTypeTxt) ||
    					PCT_20_PENALTY_TYPES.contains(issuePenaltyTypeTxt) ||
    					PCT_40_PENALTY_TYPES.contains(issuePenaltyTypeTxt)
        			)) {
            		return CommonUtil.addTwoNumbers(perReturnValueTxt, totalAdjustmentValue);
    	        }
            	return perReturnValueTxt;
            	
            // Penalty Calculation - Step 11 - Calculate Amounts Subject to 75% Penalty - Agreed
            case CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A:
            	if (CommonUtil.isNonEmptyNonNumeric(agreedAdjValue)) {
            		return agreedAdjValue;
            	}
            	if (CommonUtil.isNonEmptyNonNumeric(perReturnValueTxt)) {
            		return perReturnValueTxt;
            	}
            	if (CommonUtil.isEmpty(agreedAdjValue)) {
            		agreedAdjValue = "0";
            	}
            	if (CommonUtil.isEmpty(perReturnValueTxt)) {
            		perReturnValueTxt = "0";
            	}
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES1.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Agreed Adj when (issuePenaltyAgreementStatusInd = 'Y' or "") and ("issuePenaltyTypeTxt" = "" or a 20% Penalty or a 40% Penalty or a 75% Penalty)
            	issuePenaltyAgreementStatusInd = null;
            	if (item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND) != null) {
            		issuePenaltyAgreementStatusInd = (String) item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND);
            	}
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(agreedAdjValue) && 
        			issuePenaltyAgreementStatusInd != null && ("Y".equals(issuePenaltyAgreementStatusInd) || EMPTY_STRING.equals(issuePenaltyAgreementStatusInd)) && 
        			issuePenaltyTypeTxt != null && (
    					EMPTY_STRING.equals(issuePenaltyTypeTxt) ||
    					PCT_20_PENALTY_TYPES.contains(issuePenaltyTypeTxt) ||
    					PCT_40_PENALTY_TYPES.contains(issuePenaltyTypeTxt) ||
    					PCT_75_PENALTY_TYPES.contains(issuePenaltyTypeTxt)
        			)) {
            		return CommonUtil.addTwoNumbers(perReturnValueTxt, agreedAdjValue);
    	        }
            	return perReturnValueTxt;

            // Penalty Calculation - Step 12 - Calculate Amounts Subject to 75% Penalty - Total
            case CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A:
            	if (CommonUtil.isNonEmptyNonNumeric(totalAdjustmentValue)) {
            		return totalAdjustmentValue;
            	}
            	if (CommonUtil.isNonEmptyNonNumeric(perReturnValueTxt)) {
            		return perReturnValueTxt;
            	}
            	if (CommonUtil.isEmpty(totalAdjustmentValue)) {
            		totalAdjustmentValue = "0";
            	}
            	if (CommonUtil.isEmpty(perReturnValueTxt)) {
            		perReturnValueTxt = "0";
            	}
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES1.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Total Adj and "issuePenaltyTypeTxt" = (No Value or a 20% Penalty or a 40% Penalty or a 75% Penalty)
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(totalAdjustmentValue) &&
        			issuePenaltyTypeTxt != null && (
    					EMPTY_STRING.equals(issuePenaltyTypeTxt) ||
    					PCT_20_PENALTY_TYPES.contains(issuePenaltyTypeTxt) ||
    					PCT_40_PENALTY_TYPES.contains(issuePenaltyTypeTxt) ||
    					PCT_75_PENALTY_TYPES.contains(issuePenaltyTypeTxt)
        			)) {
            		return CommonUtil.addTwoNumbers(perReturnValueTxt, totalAdjustmentValue);
    	        }
            	return perReturnValueTxt;
            	
            // Penalty Calculation - Step 13 - for use in calculation of 6662A Underpayment Penalty - Agreed
            case CALC_TYPE_PENALTY_AGR_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY:
            	if (CommonUtil.isNonEmptyNonNumeric(agreedAdjValue)) {
            		return agreedAdjValue;
            	}
            	if (CommonUtil.isNonEmptyNonNumeric(perReturnValueTxt)) {
            		return perReturnValueTxt;
            	}
            	if (CommonUtil.isEmpty(agreedAdjValue)) {
            		agreedAdjValue = "0";
            	}
            	if (CommonUtil.isEmpty(perReturnValueTxt)) {
            		perReturnValueTxt = "0";
            	}
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES2.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Agreed Adj when ("issuePenaltyTypeTxt" = "" or a 20% Penalty or a 40% Penalty or a 75% Penalty)
            	issuePenaltyAgreementStatusInd = null;
            	if (item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND) != null) {
            		issuePenaltyAgreementStatusInd = (String) item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND);
            	}
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(agreedAdjValue) && 
        			issuePenaltyTypeTxt != null && (
    					EMPTY_STRING.equals(issuePenaltyTypeTxt) ||
    					PCT_20_PENALTY_TYPES.contains(issuePenaltyTypeTxt) ||
    					PCT_40_PENALTY_TYPES.contains(issuePenaltyTypeTxt) ||
    					PCT_75_PENALTY_TYPES.contains(issuePenaltyTypeTxt)
        			)) {
            		return CommonUtil.addTwoNumbers(perReturnValueTxt, agreedAdjValue);
    	        }
            	return perReturnValueTxt;

            // Penalty Calculation - Step 14 - for use in calculation of 6662A Underpayment Penalty - Total
            case CALC_TYPE_PENALTY_TOT_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY:
            	if (CommonUtil.isNonEmptyNonNumeric(totalAdjustmentValue)) {
            		return totalAdjustmentValue;
            	}
            	if (CommonUtil.isNonEmptyNonNumeric(perReturnValueTxt)) {
            		return perReturnValueTxt;
            	}
            	if (CommonUtil.isEmpty(totalAdjustmentValue)) {
            		totalAdjustmentValue = "0";
            	}
            	if (CommonUtil.isEmpty(perReturnValueTxt)) {
            		perReturnValueTxt = "0";
            	}
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES2.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Total Adj and ("issuePenaltyTypeTxt" = "" or a 20% Penalty or a 40% Penalty or a 75% Penalty)
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(totalAdjustmentValue) &&
        			issuePenaltyTypeTxt != null && (
    					EMPTY_STRING.equals(issuePenaltyTypeTxt) ||
    					PCT_20_PENALTY_TYPES.contains(issuePenaltyTypeTxt) ||
    					PCT_40_PENALTY_TYPES.contains(issuePenaltyTypeTxt) ||
    					PCT_75_PENALTY_TYPES.contains(issuePenaltyTypeTxt)
        			)) {
            		return CommonUtil.addTwoNumbers(perReturnValueTxt, totalAdjustmentValue);
    	        }
            	return perReturnValueTxt;
        }

        // If no specific value found for calcTypeTxt, fall back to perReturnValueTxt
        return perReturnValueTxt;
    }
    
    public static Map<String, Integer> createPenaltyRatesMap() {
        Map<String, Integer> rates = new HashMap<>();
        
        // 20% penalty rates
        PCT_20_PENALTY_TYPES.forEach(code -> rates.put(code, 20));

        // 40% penalty rates
        PCT_40_PENALTY_TYPES.forEach(code -> rates.put(code, 40));
        
        // 75% penalty rates
        PCT_75_PENALTY_TYPES.forEach(code -> rates.put(code, 75));
        
        return Collections.unmodifiableMap(rates);
    }
    
    private String deriveGroupFieldValue(FieldMapping mapping, Map<String, Object> form, int formIndex) {
        if (mapping.getTargetFieldValue() != null) {
            String value = resolveMockValue(mapping.getTargetFieldValue(), formIndex);
            return value;
        }
        List<String> values = findFieldValuesRecursive(mapping, form, mapping.getSourceField());
        if (values != null && !values.isEmpty()) {
            return values.get(0);
        }
        return "Group " + (formIndex + 1);
    }

    private Map<String, List<Map<String, Object>>> createFormMap(Map<String, Object> body) {
        @SuppressWarnings("unchecked")
		List<Map<String, Object>> forms = (List<Map<String, Object>>) body.get(FORMS);
        return forms.stream()
                .collect(Collectors.groupingBy(form -> (String) form.get(FORM_NUM)));
    }
    
    private void validateRequest(ValidatableRequest request, List<FieldMapping> fieldMappings) {
        if (request == null || request.getHeader() == null || request.getBody() == null || fieldMappings == null) {
            log.error("Invalid request: request is null or missing header/body or fieldMappings is null");
            throw new IllegalArgumentException("Invalid request for transformEcmToTrSaveFields");
        }
    }
    
    private synchronized void initializePerReturnValueToTargetFieldMap(List<FieldMapping> fieldMappings) {
        for (FieldMapping fieldMapping : fieldMappings) {
            if (fieldMapping != null && TRUE.equals(fieldMapping.getDynamicTargetField()) && 
            		fieldMapping.getPerReturnValueToTargetField() != null) {
                perReturnValueToTargetFieldMap.put(fieldMapping.getSourceField(), 
                    new ConcurrentHashMap<>(fieldMapping.getPerReturnValueToTargetField()));
            }
        }
        log.info("Initialized perReturnValueToTargetFieldMap with {} entries", perReturnValueToTargetFieldMap.size());
    }
    
    private List<FieldMapping> loadRelevantFieldMappings(Map<String, List<Map<String, Object>>> formMap, Map<String, Object> header, List<FieldMapping> allMappings) {
        Set<String> relevantForms = formMap.keySet();
        
        List<FieldMapping> relevantMappings = allMappings.stream()
                .filter(fm -> fm.getSourceForm() == null || relevantForms.contains(fm.getSourceForm()))
                .collect(Collectors.toList());
        log.info("Loaded {} fieldMappings from mapping-config", relevantMappings.size());
        
        // Apply form-specific transformations
        for (Map.Entry<String, Class<?>> entry : formTransformers.entrySet()) {
            String formNum = entry.getKey();
            if (relevantForms.contains(formNum)) {
                Class<?> transformerClass = entry.getValue();
                try {
                    Object transformer = transformerClass.getDeclaredConstructor().newInstance();
                    Method transformMethod = transformerClass.getMethod("transformForm" + formNum, Map.class, Map.class);
                    
                    for (Map<String, Object> form : formMap.get(formNum)) {
                        @SuppressWarnings("unchecked")
                        List<FieldMapping> additionalMappings = (List<FieldMapping>) transformMethod.invoke(transformer, form, header);
                        if (additionalMappings != null && !additionalMappings.isEmpty()) {
                        	relevantMappings.addAll(additionalMappings);
                        }
                    }
                } catch (Exception e) {
                    log.error("Error applying form-specific transformation for form {}: {}", formNum, e.getMessage());
                }
            }
        }

        log.info("Loaded {} relevant field mappings including form-specific transformations", relevantMappings.size());
        return relevantMappings;
    }
    
    private Field createField(FieldMapping mapping, String value, String dependentValue, Integer index, ValidatableRequest request,
    	FieldsRequest groupedFieldsRequest, Integer groupIndex) {
        if (mapping == null) {
            log.warn("Null FieldMapping provided to createField");
            return null;
        }
        if (isSnapShotPresent && TRUE.equals(mapping.getDoNotSendIfSnapshotPresents())) {
            log.debug("DoNotSendIfSnapshotPresents is set to true. Skipping field creation for for form: {}, sourceField: {}, targetField: {}", mapping.getSourceForm(), mapping.getSourceField(), mapping.getTargetField());
            return null;
        }

        Field field = new Field();
        field.setFieldId(mapping.getTargetField());
        
        if (mapping.getTargetFieldValue() != null) {
            field.setValue(resolveMockValue(mapping.getTargetFieldValue(), index));
        } else if (mapping.getTransformationClass() != null && mapping.getTransformationMethod() != null) {
        	String returedValue = applyTransformation(mapping, value, request, groupIndex);
            if (returedValue == null) {
            	return null;
            } else {
            	field.setValue(returedValue);
            }
        } else if (TRUE.equals(mapping.getDynamicTargetField())) {
            String dynamicTargetField = resolveDynamicTargetField(mapping, value, dependentValue);
            if (dynamicTargetField != null) {
                field.setFieldId(dynamicTargetField);
                field.setValue(value);
            } else {
                log.warn("Unable to resolve dynamic target field for mapping: {}", mapping);
                return null;
            }
        } else {
            field.setValue(value);
        }
        
        //Overwriting value from zero to empty string for all fieldIds as TR does not like zeros for some of the fieldIds.
        if(field.getValue() == null || "0".equals(field.getValue())) {
        	field.setValue(EMPTY_STRING);
        }
        
        if (TRUE.equals(mapping.getGenerateIndex())) {
            field.setGroup(true);
            field.setIndex(String.valueOf(index));
        }
        
        if (groupedFieldsRequest != null) {
        	log.debug("Created field: {} for sourceField: {}, sourceForm: {} for groupedField {}", field, mapping.getSourceField(), mapping.getSourceForm(), groupedFieldsRequest.getGroupField());
        } else {
        	log.debug("Created field: {} for sourceField: {}, sourceForm: {}", field, mapping.getSourceField(), mapping.getSourceForm());
        }
        return field;
    }
    
    private String resolveMockValue(String mockValue, Integer index) {
        if (mockValue == null || mockValue.isEmpty()) {
            return null;
        }
        if (mockValue.startsWith("${") && mockValue.endsWith("}")) {
            String propertyKey = mockValue.substring(2, mockValue.length() - 1);
            boolean appendIndex = propertyKey.endsWith("+INDEX");
            
            if (appendIndex) {
                propertyKey = propertyKey.substring(0, propertyKey.length() - 6);
            }
            
            String value = environment.getProperty(propertyKey);
            if (value == null) {
                log.warn("Environment property not found for key: {}. Using default value.", propertyKey);
                value = "DEFAULT_" + propertyKey;
            }
            
            if (appendIndex) {
                String resolvedValue = value + index;
                log.debug("Resolved indexed mock value: {} to {}", mockValue, resolvedValue);
                return resolvedValue;
            } else {
                log.debug("Resolved non-indexed mock value: {} to {}", mockValue, value);
                return value;
            }
        }
        return mockValue;
    }
    
    private String applyTransformation(FieldMapping mapping, String value, ValidatableRequest request, Integer groupIndex) {
    	    
	    log.debug("Applying transformation: class={}, method={}, type={}", 
	    	mapping.getTransformationClass(), mapping.getTransformationMethod(), mapping.getTransformationType());
	    if (mapping.getTransformationClass() == null || mapping.getTransformationMethod() == null) {
	        log.warn("Null transformationClass or transformationMethod in applyTransformation");
	        return value;
	    }

	    try {
	        Class<?> clazz = Class.forName(mapping.getTransformationClass());
	        Object transformer = clazz.getDeclaredConstructor().newInstance();
	        String transformationType = mapping.getTransformationType();
	        if (transformationType == null) {
	        	transformationType = "";
	        }
	        switch(transformationType) {
	            case "REQUEST":
	                Method requestMethod = clazz.getMethod(mapping.getTransformationMethod(), 
	                    String.class, ValidatableRequest.class, Integer.class);
	                return (String) requestMethod.invoke(transformer, value, request, groupIndex);
	                
	            default:
	                Method stringMethod = clazz.getMethod(mapping.getTransformationMethod(), String.class);
	                return (String) stringMethod.invoke(transformer, value);
	        }
	    } catch (Exception e) {
	        log.error("Error applying transformation: {}", e.getMessage());
	        throw new RuntimeException("Error applying transformation", e);
	    }
	}

    private String resolveDynamicTargetField(FieldMapping mapping, String value, String dependentValue) {
        if (mapping.getSourceField() == null || value == null) {
            return null;
        }
        Map<String, String> dynamicFieldMap = perReturnValueToTargetFieldMap.get(mapping.getSourceField());
        if (dynamicFieldMap != null) {
            return dynamicFieldMap.get(dependentValue != null ? dependentValue : value);
        }
        return null;
    }
    
    @SuppressWarnings("unchecked")
    private void postProcessRelatedFields(ValidatableRequest request) {
        log.info("Starting post-processing to remove temporary line items");
        
        Map<String, Object> body = request.getBody();
        List<Map<String, Object>> forms = (List<Map<String, Object>>) body.get(FORMS);
        if (forms == null) {
            log.debug("No forms found for post-processing");
            return;
        }
        
        for (Map<String, Object> form : forms) {
            List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get(LINE_ITEMS);
            if (lineItems != null) {
                removeTemporaryLineItems(lineItems);
            }
        }
        
        log.info("Completed post-processing");
    }

    @SuppressWarnings("unchecked")
    private void removeTemporaryLineItems(List<Map<String, Object>> lineItems) {
        // Remove items marked for removal at current level
        lineItems.removeIf(item -> {
            Object removeFlag = item.get(REMOVE_IT_LATER);
            return removeFlag != null && 
                   (removeFlag.equals(Boolean.TRUE) || removeFlag.equals(true));
        });

        // Process nested line items
        for (Map<String, Object> lineItem : lineItems) {
            List<Map<String, Object>> nestedLineItems = (List<Map<String, Object>>) lineItem.get(LINE_ITEMS);
            if (nestedLineItems != null) {
                removeTemporaryLineItems(nestedLineItems);
            }
        }
    }

    public Map<String, Object> transformTrToEcm(
            ValidatableRequest originalRequest, 
            RetrieveFieldsResponse trResponse,
            List<FieldMapping> responseFieldMappings) {
        
        log.info("Starting TR to ECM transformation");
        try {
            validateRequest(originalRequest, trResponse);
            
            // Preprocess TR response to normalize field indexes
            trResponse = preprocessTrResponse(trResponse);
            
            // Store SSN mapping for future use
            Map<String, String> ssnMapping = new HashMap<>();
            ssnMapping.put(PRIMARY_TIN, (String) originalRequest.getHeader().get(PRIMARY_TIN));
            ssnMapping.put(SECONDARY_TIN, (String) originalRequest.getHeader().get(SECONDARY_TIN));
            ssnMappingStore.set(ssnMapping);
            
            Map<String, List<FieldMapping>> sourceFieldToRespMapping = createSourceFieldMapping(responseFieldMappings);
            Map<FormIdentifier, LineItemStructure> formToLineNameToLineItemMap = createFormLineItemMapping(originalRequest);
            Map<String, Integer> lineNameTxtToCount = new HashMap<>();
            
            Map<String, Object> updatedPayload = processTrResponse(
                originalRequest,
                trResponse,
                sourceFieldToRespMapping,
                formToLineNameToLineItemMap,
                lineNameTxtToCount
            );
            
            log.info("Completed TR to ECM transformation");
            return Collections.unmodifiableMap(updatedPayload);
            
        } catch (Exception e) {
            log.error("Error in transformTrToEcm: ", e);
            throw e;
        } finally {
            ssnMappingStore.remove();
            calcTypeTxt.remove();
            isSecondCallForPartialTaxCalc.remove();
        }
    }
    
    private RetrieveFieldsResponse preprocessTrResponse(RetrieveFieldsResponse trResponse) {
        log.info("Preprocessing TR response to normalize field indexes");
        
        for (FieldsResponse fieldsResponse : trResponse.getFieldsResponse()) {
            if (fieldsResponse == null || fieldsResponse.getFields() == null) {
                continue;
            }
            
            // Group fields by fieldId
            Map<String, List<Field>> groupedFields = fieldsResponse.getFields().stream()
                .filter(f -> f != null && f.getFieldId() != null)
                .collect(Collectors.groupingBy(Field::getFieldId));
            
            // Process each group of fields
            for (List<Field> fields : groupedFields.values()) {
                if (fields.isEmpty()) continue;
                
                // Sort by index
                fields.sort((f1, f2) -> {
                    Integer i1 = f1.getIndex() != null ? Integer.parseInt(f1.getIndex()) : 0;
                    Integer i2 = f2.getIndex() != null ? Integer.parseInt(f2.getIndex()) : 0;
                    return i1.compareTo(i2);
                });
                
                // Find minimum index
                int minIndex = fields.stream()
                    .filter(f -> f.getIndex() != null)
                    .mapToInt(f -> Integer.parseInt(f.getIndex()))
                    .min()
                    .orElse(0);
                
                // If minimum index is not 0, adjust all indexes
                if (minIndex > 0) {
                    log.debug("Adjusting indexes for fieldId {} by -{}", fields.get(0).getFieldId(), minIndex);
                    for (Field field : fields) {
                        if (field.getIndex() != null) {
                            int newIndex = Integer.parseInt(field.getIndex()) - minIndex;
                            field.setIndex(String.valueOf(newIndex));
                        }
                    }
                }
            }
        }
        return trResponse;
    }

    private void validateRequest(ValidatableRequest originalRequest, RetrieveFieldsResponse trResponse) {
        if (originalRequest == null || originalRequest.getHeader() == null || originalRequest.getBody() == null) {
            throw new IllegalArgumentException("Invalid request for transformTrToEcm: originalRequest is null or incomplete");
        }
        if (trResponse == null || trResponse.getFieldsResponse() == null) {
            throw new IllegalArgumentException("Invalid request for transformTrToEcm: trResponse is null or incomplete");
        }
    }
    
    private Map<String, List<FieldMapping>> createSourceFieldMapping(List<FieldMapping> responseFieldMappings) {
        Map<String, List<FieldMapping>> sourceFieldToRespMapping = new HashMap<>();
        
        for (FieldMapping mapping : responseFieldMappings) {
            if (mapping != null && mapping.getSourceField() != null) {
                sourceFieldToRespMapping.computeIfAbsent(mapping.getSourceField(), k -> new ArrayList<>())
                    .add(mapping);
            }
        }
        
        log.info("Created source field mapping with {} entries", sourceFieldToRespMapping.size());
        return sourceFieldToRespMapping;
    }

    @SuppressWarnings("unchecked")
    private Map<FormIdentifier, LineItemStructure> createFormLineItemMapping(ValidatableRequest request) {
        Map<FormIdentifier, LineItemStructure> formStructureMap = new HashMap<>();
        List<Map<String, Object>> forms = (List<Map<String, Object>>) request.getBody().get(FORMS);
        
        if (forms != null) {
            for (Map<String, Object> form : forms) {
                String formNum = (String) form.get(FORM_NUM);
                String sequenceNum = (String) form.get(SEQUENCE_NUM);
                FormIdentifier identifier = new FormIdentifier(formNum, sequenceNum);
                
                LineItemStructure structure = new LineItemStructure(form);
                processLineItemsForStructure((List<Map<String, Object>>) form.get(LINE_ITEMS), structure);
                
                formStructureMap.put(identifier, structure);
            }
        }
        
        return formStructureMap;
    }

    private void processLineItemsForStructure(List<Map<String, Object>> lineItems, LineItemStructure structure) {
        if (lineItems == null) {
            return;
        }
        processLineItemsRecursive(lineItems, structure);
    }

    private void processLineItemsRecursive(List<Map<String, Object>> lineItems, 
            LineItemStructure structure) {
        if (lineItems == null) {
            return;
        }
        
        // Keep track of count per lineNameTxt to handle nested line items correctly
        Map<String, Integer> lineNameCounter = new HashMap<>();
        
        for (Map<String, Object> lineItem : lineItems) {
            String lineNameTxt = (String) lineItem.get(LINE_NAME_TXT);
            
            if (lineNameTxt != null) {
                // Update sequence number if not already set
                if (lineItem.get(SEQUENCE_NUM) == null) {
                    int sequenceNum = lineNameCounter.compute(lineNameTxt, 
                        (k, v) -> v == null ? 1 : v + 1);
                    lineItem.put(SEQUENCE_NUM, String.valueOf(sequenceNum));
                }
            }
            
            // Process nested items
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> nestedLineItems = (List<Map<String, Object>>) lineItem.get(LINE_ITEMS);
            
            if (nestedLineItems != null) {
                processLineItemsRecursive(nestedLineItems, structure);
            }
        }
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> processTrResponse(
        ValidatableRequest originalRequest,
        RetrieveFieldsResponse trResponse,
        Map<String, List<FieldMapping>> sourceFieldToRespMapping,
        Map<FormIdentifier, LineItemStructure> formToLineNameToLineItemMap,
        Map<String, Integer> lineNameTxtToCount) {
        
        Map<String, Object> updatedPayload = new HashMap<>(originalRequest.getBody());
        List<Map<String, Object>> forms = (List<Map<String, Object>>) updatedPayload.get(FORMS);
        
        if (forms == null) {
            forms = new ArrayList<>();
            updatedPayload.put(FORMS, forms);
        }
        
        for (FieldsResponse fieldsResponse : trResponse.getFieldsResponse()) {
            if (fieldsResponse == null || fieldsResponse.getFields() == null) {
            	continue;
            }
            
            for (Field field : fieldsResponse.getFields()) {
                if (field == null || field.getFieldId() == null) {
                	continue;
                }
                
                List<FieldMapping> mappings = sourceFieldToRespMapping.get(field.getFieldId());
                if (mappings == null || mappings.isEmpty()) {
                    log.warn("No mapping found for field ID: {}", field.getFieldId());
                    continue;
                }
                
                for (FieldMapping mapping : mappings) {
                    processField(field, mapping, formToLineNameToLineItemMap, lineNameTxtToCount, forms, originalRequest);
                }
            }
        }
        
        return updatedPayload;
    }

    @SuppressWarnings("unchecked")
    private void processField(
        Field field,
        FieldMapping mapping,
        Map<FormIdentifier, LineItemStructure> formStructureMap,
        Map<String, Integer> lineNameTxtToCount,
        List<Map<String, Object>> forms,
        ValidatableRequest originalRequest) {
        
        String targetField = mapping.getTargetField();
        String formNum = mapping.getTargetForm();
        String cleanedValue = TRCommonUtil.cleanTrValue(field.getValue());
        
        if (cleanedValue == null || cleanedValue.isEmpty()) {
            return;
        }
        log.debug("Processing sourceField: {} targetField: {}", mapping.getSourceField(), targetField);

        String formSequence = applyReverseTransformation(mapping, field, formStructureMap, originalRequest);
        if (formSequence == null) {
            log.info("Could not determine form sequence for mapping: {}", mapping.getSourceField());
            return;
        }

        FormIdentifier identifier = new FormIdentifier(formNum, formSequence);
        LineItemStructure structure = formStructureMap.get(identifier);

        if (structure == null) {
            FormStructureBuilder builder = new FormStructureBuilder(formNum, formSequence);
            List<Map<String, Object>> currentList = (List<Map<String, Object>>) builder.build().get(LINE_ITEMS);
            createNestedStructure(currentList, mapping, cleanedValue);
            
            Map<String, Object> newForm = builder.build();
            forms.add(newForm);
            structure = new LineItemStructure(newForm);
            formStructureMap.put(identifier, structure);
        } else {
            // Check if target field is within a group
            if (isGroupField(targetField)) {
                String groupPath = extractGroupPath(targetField);
                int groupSeq = determineGroupSequence(originalRequest, formNum, field, groupPath, targetField);
                
                Map<String, Object> group = findOrCreateGroup(structure.getForm(), groupPath, groupSeq);
                createOrUpdateField(group, mapping, targetField, cleanedValue);
            } else {
                // Use the form's sequence number for the line item
                Map<String, Object> existingLineItem = structure.getLineItem(targetField, formSequence);
                if (existingLineItem == null) {
                    List<Map<String, Object>> currentList = (List<Map<String, Object>>) structure.getForm().get(LINE_ITEMS);
                    createNestedStructure(currentList, mapping, cleanedValue);
                } else {
                    updateLineItemValue(existingLineItem, mapping, targetField, cleanedValue);
                }
            }
        }
    }

    @SuppressWarnings("unchecked")
    private int determineGroupSequence(ValidatableRequest originalRequest, String formNum, Field field, String groupPath, String targetField) {
        // Default sequence if we can't find a match
        int defaultSeq = (field.getIndex() != null ? Integer.parseInt(field.getIndex()) : 0) + 1;
        
        // If no original request or body, return default
        if (originalRequest == null || originalRequest.getBody() == null) {
            return defaultSeq;
        }
        
        List<Map<String, Object>> forms = (List<Map<String, Object>>) originalRequest.getBody().get(FORMS);
        if (forms == null) {
            return defaultSeq;
        }
        
        // Get all forms of the specified type
        List<Map<String, Object>> matchingForms = forms.stream()
            .filter(form -> formNum.equals(form.get(FORM_NUM)))
            .collect(Collectors.toList());
            
        if (matchingForms.isEmpty()) {
            return defaultSeq;
        }
        
        // Collect all matching target field occurrences across all forms
        List<GroupFieldOccurrence> allOccurrences = new ArrayList<>();
        
        for (Map<String, Object> form : matchingForms) {
            String formSequence = (String) form.get(SEQUENCE_NUM);
            List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get(LINE_ITEMS);
            if (lineItems != null) {
                findGroupFieldOccurrences(lineItems, groupPath, targetField, formSequence, allOccurrences);
            }
        }
        
        // Sort occurrences by form sequence and then by group sequence
        Collections.sort(allOccurrences);
        
        // If we found occurrences, map the field index to the appropriate sequence
        if (!allOccurrences.isEmpty()) {
            int fieldIndex = field.getIndex() != null ? Integer.parseInt(field.getIndex()) : 0;
            if (fieldIndex < allOccurrences.size()) {
                return allOccurrences.get(fieldIndex).getGroupSequence();
            }
        }
        
        return defaultSeq;
    }

    private static class GroupFieldOccurrence implements Comparable<GroupFieldOccurrence> {
        private final String formSequence;
        private final int groupSequence;
        private final int position; // To maintain original order within the document
        
        public GroupFieldOccurrence(String formSequence, int groupSequence, int position) {
            this.formSequence = formSequence;
            this.groupSequence = groupSequence;
            this.position = position;
        }
        
        public int getGroupSequence() {
            return groupSequence;
        }
        
        @Override
        public int compareTo(GroupFieldOccurrence other) {
            // First compare by form sequence
            int formSeqCompare = this.formSequence.compareTo(other.formSequence);
            if (formSeqCompare != 0) {
                return formSeqCompare;
            }
            // Then by position within the document
            return Integer.compare(this.position, other.position);
        }
    }

    @SuppressWarnings("unchecked")
    private void findGroupFieldOccurrences(List<Map<String, Object>> lineItems, String groupPath, 
        String targetField, String formSequence, List<GroupFieldOccurrence> occurrences) {
        
        if (lineItems == null) {
            return;
        }
        
        for (Map<String, Object> item : lineItems) {
            if (groupPath.equals(item.get(LINE_NAME_TXT))) {
                String seqNum = (String) item.get(SEQUENCE_NUM);
                if (seqNum != null) {
                    try {
                        int sequence = Integer.parseInt(seqNum);
                        // Add occurrence with current position in list
                        occurrences.add(new GroupFieldOccurrence(formSequence, sequence, occurrences.size()));
                    } catch (NumberFormatException e) {
                        log.warn("Invalid sequence number found: {}", seqNum);
                    }
                }
            }
            
            // Recursively check nested items
            List<Map<String, Object>> nestedItems = (List<Map<String, Object>>) item.get(LINE_ITEMS);
            if (nestedItems != null) {
                findGroupFieldOccurrences(nestedItems, groupPath, targetField, formSequence, occurrences);
            }
        }
    }

    private boolean isGroupField(String targetField) {
        if (targetField == null) {
            return false;
        }
        
        // Split the path into components
        String[] pathParts = targetField.split("/");
        // If path has at least 3 parts (form/potential-group/field), it could be a group field
        return pathParts.length > 3;
    }

    private String extractGroupPath(String targetField) {
        if (targetField == null) {
            return null;
        }
        
        String[] pathParts = targetField.split("/");
        if (pathParts.length <= 3) {
            return null;
        }
        
        // Build path up to the parent of the actual field
        StringBuilder path = new StringBuilder();
        // Go up to second-to-last component (parent of the field)
        for (int i = 0; i < pathParts.length - 1; i++) {
            if (pathParts[i].isEmpty()) continue;
            path.append("/").append(pathParts[i]);
        }
        
        log.debug("Extracted group path {} from target field {}", path.toString(), targetField);
        return path.toString();
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> findOrCreateGroup(Map<String, Object> form, String groupPath, int sequence) {
        List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get(LINE_ITEMS);
        if (lineItems == null) {
            lineItems = new ArrayList<>();
            form.put(LINE_ITEMS, lineItems);
        }

        // First try to find existing group recursively
        Map<String, Object> existingGroup = findGroupRecursive(lineItems, groupPath, sequence);
        if (existingGroup != null) {
            log.debug("Found existing group {} with sequence {}", groupPath, sequence);
            return existingGroup;
        }

        // If not found, create new group
        log.debug("Creating new group {} with sequence {}", groupPath, sequence);
        Map<String, Object> newGroup = new LinkedHashMap<>();
        newGroup.put(LINE_ITEM_REFERENCE_KEY_ID, EMPTY_STRING);
        newGroup.put(LINE_NAME_TXT, groupPath);
        newGroup.put(SEQUENCE_NUM, String.valueOf(sequence));
        newGroup.put(LINE_ITEMS, new ArrayList<>());
        
        // Insert at correct position
        int insertIndex = findInsertPosition(lineItems, groupPath, sequence);
        lineItems.add(insertIndex, newGroup);
        
        return newGroup;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> findGroupRecursive(List<Map<String, Object>> lineItems, String groupPath, int sequence) {
        if (lineItems == null) {
            return null;
        }

        for (Map<String, Object> item : lineItems) {
            // Check current item
            if (groupPath.equals(item.get(LINE_NAME_TXT)) && String.valueOf(sequence).equals(item.get(SEQUENCE_NUM))) {
                return item;
            }

            // Check nested items
            List<Map<String, Object>> nestedLineItems = (List<Map<String, Object>>) item.get(LINE_ITEMS);
            if (nestedLineItems != null) {
                Map<String, Object> foundInNested = findGroupRecursive(nestedLineItems, groupPath, sequence);
                if (foundInNested != null) {
                    return foundInNested;
                }
            }
        }

        return null;
    }
    
    private int findInsertPosition(List<Map<String, Object>> lineItems, String groupPath, int targetSequence) {
        if (lineItems == null || lineItems.isEmpty()) {
            return 0;
        }

        // Look for the first item with same path but higher sequence
        for (int i = 0; i < lineItems.size(); i++) {
            Map<String, Object> item = lineItems.get(i);
            String itemPath = (String) item.get(LINE_NAME_TXT);
            String itemSeq = (String) item.get(SEQUENCE_NUM);
            
            if (groupPath.equals(itemPath)) {
                try {
                    int sequence = Integer.parseInt(itemSeq);
                    if (sequence > targetSequence) {
                        return i;
                    }
                } catch (NumberFormatException e) {
                    log.warn("Invalid sequence number {} for group {}", itemSeq, groupPath);
                }
            }
        }
        
        // If no higher sequence found, add to end
        return lineItems.size();
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> createOrUpdateField(Map<String, Object> group, FieldMapping mapping, 
        String targetField, String value) {
        
        List<Map<String, Object>> fields = (List<Map<String, Object>>) group.get(LINE_ITEMS);
        if (fields == null) {
            fields = new ArrayList<>();
            group.put(LINE_ITEMS, fields);
        }

        // Look for existing field
        for (Map<String, Object> field : fields) {
            if (targetField.equals(field.get(LINE_NAME_TXT))) {
                updateLineItemValue(field, mapping, targetField, value);
                return field;
            }
        }

        // Create new field if not found
        Map<String, Object> newField = createBasicLineItem(targetField, value);
        fields.add(newField);
        return newField;
    }

	@SuppressWarnings("unchecked")
	private void createNestedStructure(List<Map<String, Object>> currentList, FieldMapping mapping, String value) {
	    String[] paths = mapping.getTargetField().split("/");
	    
	    if (paths.length <= 2) {
	        currentList.add(createBasicLineItem(mapping.getTargetField(), value));
	        return;
	    }
	    
	    // Build parent paths and create/find parent structures
	    for (int i = 2; i < paths.length - 1; i++) {
	        StringBuilder parentPath = new StringBuilder();
	        for (int j = 1; j <= i; j++) {
	            parentPath.append("/").append(paths[j]);
	        }
	        String currentParentPath = parentPath.toString();
	        
	        // Find or create parent at this level
	        Map<String, Object> parent = findLineItem(currentList, currentParentPath);
	        if (parent == null) {
	            parent = createParentItem(currentParentPath);
	            insertInOrder(currentList, parent);
	        }
	        currentList = (List<Map<String, Object>>) parent.get(LINE_ITEMS);
	    }
	    
	    // Add the actual line item
	    Map<String, Object> lineItem = createBasicLineItem(mapping.getTargetField(), value);
	    insertInOrder(currentList, lineItem);
	}

	// Helper method to insert items in sequence order
	private void insertInOrder(List<Map<String, Object>> items, Map<String, Object> newItem) {
	    String newSequence = (String) newItem.get(SEQUENCE_NUM);
	    if (newSequence == null) {
	        items.add(newItem);
	        return;
	    }

	    int newSeq = Integer.parseInt(newSequence);
	    int insertIndex = items.size();
	    
	    for (int i = 0; i < items.size(); i++) {
	        String seq = (String) items.get(i).get(SEQUENCE_NUM);
	        if (seq != null && Integer.parseInt(seq) > newSeq) {
	            insertIndex = i;
	            break;
	        }
	    }
	    
	    items.add(insertIndex, newItem);
	}
    
    private String applyReverseTransformation(FieldMapping mapping, Field field, 
            Map<FormIdentifier, LineItemStructure> formStructureMap, ValidatableRequest originalRequest) {

        // First try transformation if configured
        if (mapping.getTransformationClass() != null && mapping.getTransformationMethod() != null) {
            try {
                Class<?> transformerClass = Class.forName(mapping.getTransformationClass());
                Object transformer = transformerClass.getDeclaredConstructor().newInstance();
                
                Method method = transformerClass.getMethod(mapping.getTransformationMethod(), 
                    String.class,    // sourceField
                    Field.class,     // field
                    Map.class,       // ssnMapping
                    Map.class,       // formStructureMap
                    ValidatableRequest.class  // original request
                );
                
                String transformedSequence = (String) method.invoke(transformer, 
                    mapping.getSourceField(),
                    field,
                    ssnMappingStore.get(),
                    formStructureMap,
                    originalRequest
                );
                
                if (transformedSequence != null) {
                    return transformedSequence;
                }
            } catch (Exception e) {
                log.error("Error applying sequence transformation: {}", e.getMessage());
            }
        }

        // If no transformation or transformation failed, derive from original request
        String derivedSequence = deriveFormSequenceFromOriginalRequest(field, mapping, originalRequest);
        if (derivedSequence != null) {
            return derivedSequence;
        }

        // Default to index-based sequence if all else fails
        return field.getIndex() != null ? String.valueOf(Integer.parseInt(field.getIndex()) + 1) : "1";
    }

    private String deriveFormSequenceFromOriginalRequest(Field field, FieldMapping mapping, ValidatableRequest originalRequest) {
        if (field == null || mapping == null || originalRequest == null || mapping.getTargetField() == null) {
            return null;
        }
        
        int responseIndex = field.getIndex() != null ? Integer.parseInt(field.getIndex()) : 0;
        
        String[] pathComponents = mapping.getTargetField().split("/");
        if (pathComponents.length < 2) {
            return null;
        }
        
        String formType = pathComponents[1];
        String groupPath = mapping.getTargetField().substring(0, mapping.getTargetField().lastIndexOf("/"));
        
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> forms = (List<Map<String, Object>>) originalRequest.getBody().get(FORMS);
        if (forms == null) {
            return null;
        }
        
        // Track cumulative group count across forms
        int cumulativeCount = 0;
        
        // Find matching form by counting groups until we reach our index
        for (Map<String, Object> form : forms.stream()
                .filter(f -> formType.equals(f.get(FORM_NUM)))
                .collect(Collectors.toList())) {
            
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get(LINE_ITEMS);
            if (lineItems == null) continue;
            
            int groupsInThisForm = countMatchingGroups(lineItems, groupPath);
            
            // If this form contains our target index, return its sequence
            if (cumulativeCount + groupsInThisForm > responseIndex) {
                return (String) form.get(SEQUENCE_NUM);
            }
            
            cumulativeCount += groupsInThisForm;
        }
        
        return null;
    }

    private int countMatchingGroups(List<Map<String, Object>> lineItems, String targetPath) {
        int count = 0;
        
        for (Map<String, Object> item : lineItems) {
            if (targetPath.equals(item.get(LINE_NAME_TXT))) {
                count++;
            }
            
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> nestedItems = (List<Map<String, Object>>) item.get(LINE_ITEMS);
            if (nestedItems != null) {
                count += countMatchingGroups(nestedItems, targetPath);
            }
        }
        
        return count;
    }

    private Map<String, Object> findLineItem(List<Map<String, Object>> items, String lineNameTxt) {
        return items.stream()
            .filter(item -> lineNameTxt.equals(item.get(LINE_NAME_TXT)))
            .findFirst()
            .orElse(null);
    }

    private Map<String, Object> createParentItem(String parentPath) {
        LinkedHashMap<String, Object> parent = new LinkedHashMap<>();
        parent.put(LINE_ITEM_REFERENCE_KEY_ID, parentPath);
        parent.put(LINE_NAME_TXT, parentPath);
        parent.put(SEQUENCE_NUM, "1");
        parent.put(LINE_ITEMS, new ArrayList<Map<String, Object>>());
        return parent;
    }

    private Map<String, Object> createBasicLineItem(String targetField, String value) {
        LinkedHashMap<String, Object> lineItem = new LinkedHashMap<>();
        lineItem.put(LINE_ITEM_REFERENCE_KEY_ID, EMPTY_STRING);
        lineItem.put(LINE_NAME_TXT, targetField);
        lineItem.put(SEQUENCE_NUM, "1");
        lineItem.put(PER_RETURN_VALUE_TXT, EMPTY_STRING);
        
        if (isCalcTypePresent()) {
            lineItem.put(TOTAL_ADJ_VALUE_TXT, EMPTY_STRING);
            lineItem.put(AGREED_ADJ_VALUE_TXT, EMPTY_STRING);
            lineItem.put(ADJUSTMENT_STATUS_CD, EMPTY_STRING);
            lineItem.put(USER_ADJ_LINE_IND, "N");
            lineItem.put(ISSUE_PNLTY_TYPE_TXT, EMPTY_STRING);
            lineItem.put(TOTAL_ADJ_TAX_CALC_VALUE_TXT, value);
            // AGREED_ADJ_TAX_CALC_VALUE_TXT will be populated during second TR call. Here we are creating just the placeholder
          	lineItem.put(AGREED_ADJ_TAX_CALC_VALUE_TXT, EMPTY_STRING);
            // Since perReturnValueTxt will be empty for newly created lineItems, setting STAT value as negative, if value present
            lineItem.put(STAT_TOTAL_ADJ_TAX_CALC_VALUE_TXT, value != null ? value : EMPTY_STRING);
            // STAT_AGREED_ADJ_TAX_CALC_VALUE_TXT will be computed during second TR call. Here we are creating just the placeholder
            lineItem.put(STAT_AGREED_ADJ_TAX_CALC_VALUE_TXT, EMPTY_STRING);
        } else {
            lineItem.put(TAX_CALCULATOR_VALUE_TXT, value);
            lineItem.put(VARIANCE_VALUE_TXT, EMPTY_STRING);
        }
        
        log.info("Created lineItem: {}", lineItem);
        return lineItem;
    }
    
    private void updateLineItemValue(Map<String, Object> lineItem, FieldMapping mapping, String targetField,
            String cleanedTrValue) {
        String userAdjustedLineInd = (String) lineItem.get(USER_ADJ_LINE_IND);
        String perReturnValueTxt = (String) lineItem.get(PER_RETURN_VALUE_TXT);

        if (isCalcTypePresent()) {
            switch (calcTypeTxt.get()) {
                case CALC_TYPE_AGREED:
                case CALC_TYPE_UNAGREED:
                    lineItem.put(TOTAL_ADJ_TAX_CALC_VALUE_TXT, cleanedTrValue);
                    if ("N".equals(userAdjustedLineInd)) {
                        calculateStatValue(lineItem, TOTAL_ADJ_TAX_CALC_VALUE_TXT, 
                            STAT_TOTAL_ADJ_TAX_CALC_VALUE_TXT, perReturnValueTxt);
                    }
                    break;
                case CALC_TYPE_PARTIAL:
                    if (isSecondCallForPartialTaxCalc.get()) {
                        if (lineItem.containsKey(AGREED_ADJ_TAX_CALC_VALUE_TXT)) {
                            lineItem.put(AGREED_ADJ_TAX_CALC_VALUE_TXT, cleanedTrValue);
                            if ("N".equals(userAdjustedLineInd)) {
                                calculateStatValue(lineItem, AGREED_ADJ_TAX_CALC_VALUE_TXT, 
                                    STAT_AGREED_ADJ_TAX_CALC_VALUE_TXT, perReturnValueTxt);
                            }
                        }
                    } else {
                        if (lineItem.containsKey(TOTAL_ADJ_TAX_CALC_VALUE_TXT)) {
                            lineItem.put(TOTAL_ADJ_TAX_CALC_VALUE_TXT, cleanedTrValue);
                            if ("N".equals(userAdjustedLineInd)) {
                                calculateStatValue(lineItem, TOTAL_ADJ_TAX_CALC_VALUE_TXT, 
                                    STAT_TOTAL_ADJ_TAX_CALC_VALUE_TXT, perReturnValueTxt);
                            }
                        }
                    }
                    break;
                case CALC_TYPE_NO_CHANGE:
                    lineItem.put(TAX_CALCULATOR_VALUE_TXT, cleanedTrValue);
                    break;
                default:
                    lineItem.put(TAX_CALCULATOR_VALUE_TXT, cleanedTrValue);
                    break;
            }
        } else {
            // Original behavior when calcTypeTxt is not present
            lineItem.put(TAX_CALCULATOR_VALUE_TXT, cleanedTrValue);
            
            // Calculate variance if needed
            if (TRUE.equals(mapping.getCalculateVariance())) {
                String varianceValueTxt = calculateVariance(
                    cleanedTrValue.isEmpty() ? "0" : cleanedTrValue,
                    perReturnValueTxt != null && perReturnValueTxt.isEmpty() ? "0" : perReturnValueTxt
                );
                lineItem.put(VARIANCE_VALUE_TXT, varianceValueTxt);
                log.debug("Calculated variance for {}: {}", targetField, varianceValueTxt);
            }
        }
    }

	private void calculateStatValue(Map<String, Object> lineItem, String sourceField, String targetField, String perReturnValueTxt) {
	    String sourceValue = (String) lineItem.get(sourceField);
	    if (CommonUtil.isEmpty(sourceValue)) {
	    	sourceValue = "0";
	    }
	    if (CommonUtil.isEmpty(perReturnValueTxt)) {
	    	perReturnValueTxt = "0";
	    }
	    if (CommonUtil.isNumeric(sourceValue) && CommonUtil.isNumeric(perReturnValueTxt)) {
	        try {
	            BigDecimal source = new BigDecimal(sourceValue);
	            BigDecimal perReturn = new BigDecimal(perReturnValueTxt);
	            String statValue = source.subtract(perReturn).toString();
	            lineItem.put(targetField, statValue);
	            log.debug("Calculated {} = {} - {} = {} for {}", targetField, sourceValue, perReturnValueTxt, statValue, lineItem.get(LINE_NAME_TXT));
	        } catch (NumberFormatException e) {
	            log.error("Error calculating {}: Invalid number format", targetField, e);
	        }
	    } else {
	        log.warn("Unable to calculate {}: Missing {} or {}", targetField, sourceField, PER_RETURN_VALUE_TXT);
	    }
	}

    private String calculateVariance(String taxCalculatorValue, String perReturnValue) {
        log.debug("Calculating variance between taxCalculatorValue: {} and perReturnValue: {}", taxCalculatorValue, perReturnValue);
        if (taxCalculatorValue == null || perReturnValue == null) {
            log.warn("Null input in calculateVariance");
            return EMPTY_STRING;
        }
        try {
            BigDecimal taxCalc = new BigDecimal(taxCalculatorValue);
            BigDecimal perReturn = new BigDecimal(perReturnValue);
            String variance = taxCalc.subtract(perReturn).toString();
            log.debug("Calculated variance: {}", variance);
            return variance;
        } catch (NumberFormatException e) {
            log.error("Error calculating variance: {}", e.getMessage());
            return EMPTY_STRING;
        }
    }
    
    public RetrieveFieldsRequest generateRetrieveFieldsPayload(List<FieldMapping> fieldMappings) {
        log.info("Generating retrieve fields payload");
        
        RetrieveFieldsRequest retrieveFieldsRequest = new RetrieveFieldsRequest();
        List<FieldsRequest> fieldsRequests = new ArrayList<>();
        
        // Create map to store group field mappings
        Map<String, List<FieldMapping>> groupFieldMappings = new HashMap<>();
        List<FieldMapping> nonGroupedFields = new ArrayList<>();
        
        // First pass: organize mappings into groups and non-groups
        if (fieldMappings != null) {
            for (FieldMapping mapping : fieldMappings) {
                if (mapping != null && mapping.getSourceField() != null) {
                    if (mapping.getGroupField() != null) {
                        groupFieldMappings.computeIfAbsent(mapping.getGroupField(), k -> new ArrayList<>())
                            .add(mapping);
                    } else {
                        nonGroupedFields.add(mapping);
                    }
                }
            }
        }
        
        // Create default group for non-grouped fields
        if (!nonGroupedFields.isEmpty()) {
            FieldsRequest defaultFieldsRequest = new FieldsRequest();
            defaultFieldsRequest.setGroupField(null);
            defaultFieldsRequest.setFields(new ArrayList<>());
            
            for (FieldMapping mapping : nonGroupedFields) {
                Field field = new Field();
                field.setGroup(true);
                field.setFieldId(mapping.getSourceField());
                defaultFieldsRequest.getFields().add(field);
            }
            
            fieldsRequests.add(defaultFieldsRequest);
        }
        
        // Create separate groups for each groupField mapping
        for (Map.Entry<String, List<FieldMapping>> entry : groupFieldMappings.entrySet()) {
            String groupFieldName = entry.getKey();
            List<FieldMapping> groupMappings = entry.getValue();
            
            // Find the mapping that defines the group
            FieldMapping groupDefiningMapping = groupMappings.stream()
                .filter(m -> TRUE.equals(m.getGroupFieldMapping()))
                .findFirst()
                .orElse(null);
            
            if (groupDefiningMapping != null) {
                FieldsRequest groupFieldsRequest = new FieldsRequest();
                groupFieldsRequest.setGroupField(null);  // Set to null as required
                groupFieldsRequest.setFields(new ArrayList<>());
                
                // First add the group identifier field
                Field groupIdentifierField = new Field();
                groupIdentifierField.setGroup(true);
                groupIdentifierField.setFieldId(groupFieldName);
                groupFieldsRequest.getFields().add(groupIdentifierField);
                
                // Then add all fields that belong to this group
                for (FieldMapping mapping : groupMappings) {
                    // Skip the group identifier field as we already added it
                    if (!mapping.getSourceField().equals(groupFieldName)) {
                        Field field = new Field();
                        field.setGroup(true);
                        field.setFieldId(mapping.getSourceField());
                        groupFieldsRequest.getFields().add(field);
                    }
                }
                
                fieldsRequests.add(groupFieldsRequest);
            }
        }
        
        retrieveFieldsRequest.setFieldsRequest(Collections.unmodifiableList(fieldsRequests));
        log.info("Generated retrieve fields payload with {} field requests", fieldsRequests.size());
        return retrieveFieldsRequest;
    }
    
    private static boolean isCalcTypePresent() {
        return calcTypeTxt.get() != null;
    }
}