package gov.irs.jios.common.client.transformer;

import lombok.extern.slf4j.Slf4j;

/**
 * Author: Kaiwen Tsou
 **/

/**
 * Sometimes, TR expects "NONE" instead of "0", so this handles that.
 */
@Slf4j
public class ZeroToNoneTransformer {

    public static String transformEcmToTr(String value) {
		try {
			if (value.equals("0")) {
				return "NONE";
			} else {
				return value;
			}
		} catch (Exception e) {
			log.warn("ZeroToNoneTransformer error: {}", e.getMessage());
			return "NONE";
		}

    }

    public static String transformTrToEcm(String value) {
		try{
			if (value.equals("NONE")) {
				return "0";
			} else {
				return value;
			}
		} catch (Exception e) {
			log.warn("ZeroToNoneTransformer (reverse) error: {}", e.getMessage());
			return "0";
		}
    }
}
