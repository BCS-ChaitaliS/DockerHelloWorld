package gov.irs.jios.common.pojo;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class FormStructureBuilder {
    private final Map<String, Object> form;
    
    public FormStructureBuilder(String formNum, String sequenceNum) {
        this.form = new LinkedHashMap<>();  // Using LinkedHashMap to maintain order
        form.put("formNum", formNum);
        form.put("sequenceNum", sequenceNum);
        form.put("lineItems", new ArrayList<Map<String, Object>>());
    }
    
    public Map<String, Object> build() {
        return form;
    }
}