package gov.irs.jios.common.client.transformer;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;

/**
 * Author: Kaiwen Tsou
 **/
@Slf4j
/**
 * Transforms ECM payload value to the appropriate TR ui checkbox item. 
 * TODO Can probably merge this file with other transformers. See: InventoryValuationIndTransformer.
 */
public class AtRiskIndicatorTransformer {
    
    private static final Map<String, Boolean> ECM_TO_TR_MAP = Map.of(
	    "TRUE", true,
	    "FALSE", false,
	    "1", true,
	    "0", false,
	    "X", true, // Theoretically, only this type should be sent from ECM for the AtRisk fields.
	    "", false
	);
	private static final Map<String, String> TR_TO_ECM_MAP = Map.of(
	    "X", "TRUE",
	    "Y", "TRUE",
	    "B", "FALSE", 
	    "", "FALSE"
	);
    /**
     * Maps to "X" for All Investment Is At Risk (1040 Schedule C) in the TR ui.
     * @param ecmIndicatorValue true or false
     * @return the value of the field to be sent to tr
     */
    public String transformAllInvestmentIsAtRiskEcmToTr(String ecmIndicatorValue) {
        try {
            if (ecmIndicatorValue == null) {
                ecmIndicatorValue = "";
            }
            Boolean isFieldTrue = ECM_TO_TR_MAP.get(ecmIndicatorValue.toUpperCase());
        
            // See TR Data Dictionary for indvalue
            String trIndicator = isFieldTrue ? "X" : "B";
    
            return trIndicator;
        } catch (Exception e){
            log.warn("AtRiskIndicatorTransformer: " + e.getMessage());
            return "";
        }
    }
    
    /**
     * Maps to "Y" for the Some Investment is Not At Risk (1040 Schedule C) in the TR ui.
     * @param ecmIndicatorValue true or false
     * @return the value of the field to be sent to tr
     */
    public String transformSomeInvestmentIsNotAtRiskIndEcmToTr(String ecmIndicatorValue) {
        try {
            if (ecmIndicatorValue == null) {
                ecmIndicatorValue = "";
            }
            Boolean isFieldTrue = ECM_TO_TR_MAP.get(ecmIndicatorValue.toUpperCase());
            String trIndicator = isFieldTrue ? "Y" : "B";
            return trIndicator;
        } catch (Exception e){
            log.warn("AtRiskIndicatorTransformer: " + e.getMessage());
            return "";
        }
    }

    public String transformTrToEcm(String trIndicatorValue) {
        try {
            String ecmIndicator = TR_TO_ECM_MAP.get(trIndicatorValue != null ? trIndicatorValue.toUpperCase() : "");
            if (ecmIndicator == null) {
                throw new IllegalArgumentException("Invalid TR Indicator value: " + trIndicatorValue);
            }
            return ecmIndicator;
        } catch (Exception e){
            log.warn("AtRiskIndicatorTransformer: " + e.getMessage());
            return "";
        }
    }
}