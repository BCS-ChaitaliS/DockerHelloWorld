package gov.irs.jios.common.pojo;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LineItemFinder {
    private static final String LINE_ITEMS = "lineItems";
    private static final String LINE_NAME_TXT = "lineNameTxt";
    private static final String SEQUENCE_NUM = "sequenceNum";

    public static Map<String, Object> findLineItem(Map<String, Object> form, String lineNameTxt, String targetSequenceNum) {
        if (form == null || lineNameTxt == null || targetSequenceNum == null) {
            return null;
        }

        // Extract parent group path if this is a nested field
        String[] pathParts = lineNameTxt.split("/");
        if (pathParts.length <= 2) {
            return null;
        }

        // For a field like /IRS1040ScheduleE/PropertyRealEstAndRoyaltyGroup/AdvertisingAmt
        // Get parent path /IRS1040ScheduleE/PropertyRealEstAndRoyaltyGroup
        String parentPath = null;
        String fieldName = lineNameTxt;

        if (pathParts.length > 3) {
            StringBuilder parentBuilder = new StringBuilder();
            for (int i = 1; i < pathParts.length - 1; i++) {
                parentBuilder.append("/").append(pathParts[i]);
            }
            parentPath = parentBuilder.toString();
            log.debug("Looking for field: {} in parent group: {} with sequence: {}", 
                lineNameTxt, parentPath, targetSequenceNum);
        }

        // If this is a nested field, first find its parent group
        if (parentPath != null) {
            Map<String, Object> parentGroup = findParentGroup(getLineItems(form), parentPath, targetSequenceNum);
            if (parentGroup != null) {
                log.debug("Found parent group {} with sequence {}, searching for field {}", 
                    parentPath, parentGroup.get(SEQUENCE_NUM), fieldName);
                return findField(getLineItems(parentGroup), fieldName);
            }
            log.debug("Parent group not found: {} with sequence {}", parentPath, targetSequenceNum);
            return null;
        }

        // For non-nested fields
        return findField(getLineItems(form), lineNameTxt);
    }

    private static Map<String, Object> findParentGroup(List<Map<String, Object>> items, 
            String groupPath, String targetSequenceNum) {
        if (items == null) return null;

        for (Map<String, Object> item : items) {
            String itemPath = (String) item.get(LINE_NAME_TXT);
            String itemSeq = (String) item.get(SEQUENCE_NUM);

            log.debug("Checking group: {} with sequence {} against target path: {} seq: {}", 
                itemPath, itemSeq, groupPath, targetSequenceNum);

            // Direct group match
            if (groupPath.equals(itemPath) && targetSequenceNum.equals(itemSeq)) {
                log.debug("Found matching group: {} with sequence: {}", itemPath, itemSeq);
                return item;
            }

            // Check nested groups
            Map<String, Object> found = findParentGroup(getLineItems(item), groupPath, targetSequenceNum);
            if (found != null) return found;
        }
        return null;
    }

    private static Map<String, Object> findField(List<Map<String, Object>> items, String fieldPath) {
        if (items == null) return null;

        for (Map<String, Object> item : items) {
            String itemPath = (String) item.get(LINE_NAME_TXT);
            
            // For fields, we match only the path, not sequence
            if (fieldPath.equals(itemPath)) {
                log.debug("Found field: {}", itemPath);
                return item;
            }

            // Check nested fields
            Map<String, Object> found = findField(getLineItems(item), fieldPath);
            if (found != null) return found;
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> getLineItems(Map<String, Object> container) {
        if (container == null) return Collections.emptyList();
        List<Map<String, Object>> items = (List<Map<String, Object>>) container.get(LINE_ITEMS);
        return items != null ? items : Collections.emptyList();
    }
}