package gov.irs.jios.common.client.config;


import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import gov.irs.jios.common.client.tr.pojo.MappingConfig;
import gov.irs.jios.common.exception.ConfigurationException;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class DynamicMappingConfigLoader {
    private static final String CONFIG_PATH = "mapping-configs/";
    private static final String DEFAULT_CONFIG = "default_mapping-config.json";
    
    @Autowired
    private ObjectMapper objectMapper;
    
    @Autowired
    private ResourceLoader resourceLoader;
    
    private static final ConcurrentHashMap<String, MappingConfig> configCache = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<String, FieldMappingsHolder> mappingsCache = new ConcurrentHashMap<>();
    private static final ReentrantReadWriteLock cacheLock = new ReentrantReadWriteLock();
    private static final Lock readLock = cacheLock.readLock();
    private static final Lock writeLock = cacheLock.writeLock();
        
    public List<FieldMapping> getSaveRequestFieldsMappings(String taxYear) {
        String cacheKey = taxYear + "_save_request_mapping";
        return getMappingsFromCache(taxYear, cacheKey, MappingType.SAVE_FIELDS);
    }
    
    public List<FieldMapping> getRetrieveRequestFieldsMappings(String taxYear) {
        String cacheKey = taxYear + "_retrieve_request_mapping";
        return getMappingsFromCache(taxYear, cacheKey, MappingType.RETRIEVE_FIELDS);
    }
    
    public List<FieldMapping> getRetrieveResponseFieldMappings(String taxYear) {
        String cacheKey = taxYear + "_retrieve_response_mapping";
        return getMappingsFromCache(taxYear, cacheKey, MappingType.RETRIEVE_RESPONSE);
    }
    
    private List<FieldMapping> getMappingsFromCache(String taxYear, String cacheKey, MappingType type) {
        readLock.lock();
        try {
            FieldMappingsHolder holder = mappingsCache.get(cacheKey);
            if (holder != null) {
            	log.info("Already cached data for taxYear {} with {} mappings returned for {}", taxYear, holder.getMappings().size(), cacheKey);
                return holder.getMappings();
            }
        } finally {
            readLock.unlock();
        }
        
        writeLock.lock();
        try {
            MappingConfig mergedConfig = loadMergedConfig(taxYear);
            List<FieldMapping> mappings = extractMappings(mergedConfig, type);
            
            FieldMappingsHolder holder = new FieldMappingsHolder(mappings);
            mappingsCache.put(cacheKey, holder);
            log.info("Caching first time {} mappings for taxYear {} for {}", mappings.size(), taxYear, cacheKey);
            
            return mappings;
        } finally {
            writeLock.unlock();
        }
    }
    
    private List<FieldMapping> extractMappings(MappingConfig config, MappingType type) {
        switch (type) {
            case SAVE_FIELDS:
                return config.getSaveFields().getRequestMapping().getFieldMappings();
            case RETRIEVE_FIELDS:
                return config.getRetrieveFields().getRequestMapping().getFieldMappings();
            case RETRIEVE_RESPONSE:
                return config.getRetrieveFields().getResponseMapping().getFieldMappings();
            default:
                throw new IllegalArgumentException("Unknown mapping type: " + type);
        }
    }
    
    private MappingConfig loadMergedConfig(String taxYear) {
        readLock.lock();
        try {
            MappingConfig cachedConfig = configCache.get(taxYear);
            if (cachedConfig != null) {
                return cachedConfig;
            }
        } finally {
            readLock.unlock();
        }
        
        writeLock.lock();
        try {
            MappingConfig cachedConfig = configCache.get(taxYear);
            if (cachedConfig != null) {
                return cachedConfig;
            }
            
            // Load and merge configurations
            MappingConfig defaultConfig = loadDefaultConfig();
            MappingConfig yearConfig = loadYearConfig(taxYear);
            MappingConfig mergedConfig = mergeConfigs(defaultConfig, yearConfig, taxYear);
            
            configCache.put(taxYear, mergedConfig);
            log.info("Cached merged configuration for tax year: {}", taxYear);
            
            return mergedConfig;
        } finally {
            writeLock.unlock();
        }
    }
    
    private MappingConfig mergeConfigs(MappingConfig defaultConfig, MappingConfig yearConfig, String taxYear) {
        if (yearConfig == null) {
            return defaultConfig;
        }

        // Merge save fields mappings
        if (yearConfig.getSaveFields() != null) {
        	List<FieldMapping> defaultSaveReqMappingConfig = defaultConfig.getSaveFields().getRequestMapping().getFieldMappings();
            log.info("{} saveFields request fieldMappings loaded from default_mapping-config", defaultSaveReqMappingConfig.size());
            List<FieldMapping> mergedSaveMappings = new ArrayList<>(defaultSaveReqMappingConfig);
            List<FieldMapping> yearSpecificSaveReqMappingConfig = yearConfig.getSaveFields().getRequestMapping().getFieldMappings();
            log.info("{} saveFields request fieldMappings loaded from year {} specific mapping-config", yearSpecificSaveReqMappingConfig.size(), taxYear);
            mergedSaveMappings.addAll(yearSpecificSaveReqMappingConfig);
            log.info("{} saveFields request fieldMappings loaded for year {} in TOTAL", mergedSaveMappings.size(), taxYear);
            defaultConfig.getSaveFields().getRequestMapping().setFieldMappings(mergedSaveMappings);
        }

        // Merge retrieve fields request mappings
        if (yearConfig.getRetrieveFields() != null) {
        	List<FieldMapping> defaultRetrieveReqMappingConfig = defaultConfig.getRetrieveFields().getRequestMapping().getFieldMappings();
            log.info("{} retrieveFields request fieldMappings loaded from default_mapping-config", defaultRetrieveReqMappingConfig.size());
            List<FieldMapping> mergedRetrieveMappings = new ArrayList<>(defaultRetrieveReqMappingConfig);
            List<FieldMapping> yearSpecificRetrieveReqMappingConfig = yearConfig.getRetrieveFields().getRequestMapping().getFieldMappings();
            log.info("{} retrieveFields request fieldMappings loaded from year {} specific mapping-config", yearSpecificRetrieveReqMappingConfig.size(), taxYear);
            mergedRetrieveMappings.addAll(yearSpecificRetrieveReqMappingConfig);
            log.info("{} retrieveFields request fieldMappings loaded for year {} in TOTAL", mergedRetrieveMappings.size(), taxYear);
            defaultConfig.getRetrieveFields().getRequestMapping().setFieldMappings(mergedRetrieveMappings);
        }

        // Merge retrieve fields response mappings
        if (yearConfig.getRetrieveFields() != null) {
        	List<FieldMapping> defaultRetrieveRespMappingConfig = defaultConfig.getRetrieveFields().getResponseMapping().getFieldMappings();
            log.info("{} retrieveFields response fieldMappings loaded from default_mapping-config", defaultRetrieveRespMappingConfig.size());
            List<FieldMapping> mergedResponseMappings = new ArrayList<>(defaultRetrieveRespMappingConfig);
            List<FieldMapping> yearSpecificRetrieveRespMappingConfig = yearConfig.getRetrieveFields().getResponseMapping().getFieldMappings();
            log.info("{} retrieveFields response fieldMappings loaded from year {} specific mapping-config", yearSpecificRetrieveRespMappingConfig.size(), taxYear);
            mergedResponseMappings.addAll(yearSpecificRetrieveRespMappingConfig);
            log.info("{} retrieveFields response fieldMappings loaded for year {} in TOTAL", mergedResponseMappings.size(), taxYear);
            defaultConfig.getRetrieveFields().getResponseMapping().setFieldMappings(mergedResponseMappings);
        }

        return defaultConfig;
    }
    
    private MappingConfig loadYearConfig(String taxYear) {
        String configFileName = taxYear + "_mapping-config.json";
        Resource resource = resourceLoader.getResource("classpath:" + CONFIG_PATH + configFileName);
        
        if (!resource.exists()) {
            return null;
        }
        
        try (InputStream is = resource.getInputStream()) {
            return objectMapper.readValue(is, MappingConfig.class);
        } catch (IOException e) {
            log.error("Failed to load year specific configuration for: {}", taxYear, e);
            return null;
        }
    }
    
    private MappingConfig loadDefaultConfig() {
        Resource resource = resourceLoader.getResource("classpath:" + CONFIG_PATH + DEFAULT_CONFIG);
        try (InputStream is = resource.getInputStream()) {
            return objectMapper.readValue(is, MappingConfig.class);
        } catch (IOException e) {
            throw new ConfigurationException("Failed to load default mapping configuration", e);
        }
    }
    
    public void clearAllCaches() {
        writeLock.lock();
        try {
            configCache.clear();
            mappingsCache.clear();
            log.info("Cleared all configuration caches");
        } finally {
            writeLock.unlock();
        }
    }
    
    public void clearCacheForTaxYear(String taxYear) {
        writeLock.lock();
        try {
            configCache.remove(taxYear);
            mappingsCache.remove(taxYear + "_save_request_mapping");
            mappingsCache.remove(taxYear + "_retrieve_request_mapping");
            mappingsCache.remove(taxYear + "_retrieve_response_mapping");
            log.info("Cleared cache for tax year: {}", taxYear);
        } finally {
            writeLock.unlock();
        }
    }
    
    @AllArgsConstructor
    @Getter
    private static class FieldMappingsHolder {
        private final List<FieldMapping> mappings;
    }

    private enum MappingType {
        SAVE_FIELDS,
        RETRIEVE_FIELDS,
        RETRIEVE_RESPONSE
    }
}