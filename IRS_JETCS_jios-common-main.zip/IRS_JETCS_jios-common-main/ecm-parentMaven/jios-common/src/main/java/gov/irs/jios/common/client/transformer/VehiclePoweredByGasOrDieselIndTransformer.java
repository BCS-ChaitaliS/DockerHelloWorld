package gov.irs.jios.common.client.transformer;

import lombok.extern.slf4j.Slf4j;

import java.util.Map;

/**
 * Author: Kaiwen Tsou
 **/

/**
 * ECM is sending a BooleanType here.
 */
@Slf4j
public class VehiclePoweredByGasOrDieselIndTransformer {
    
	private static final Map<String, String> ECM_TO_TR_MAP = Map.of(
	    "TRUE", "",
	    "FALSE", "N",
	    "1", "",
	    "0", "N",
	    "X", "",
	    "", "N"
	);

	private static final Map<String, String> TR_TO_ECM_MAP = Map.of(
	    "", "TRUE",
	    "N", "FALSE"
	);

    public static String transformEcmToTr(String ecmIndicatorValue) {
		try{
			if (ecmIndicatorValue == null) {
				ecmIndicatorValue = "";
			}
			String trIndicator = ECM_TO_TR_MAP.get(ecmIndicatorValue.toUpperCase());
			if (trIndicator == null) {
				throw new IllegalArgumentException("Invalid ECM Indicator value: " + ecmIndicatorValue);
			}
			return trIndicator;
		} catch (IllegalArgumentException e) {
			log.error("VehiclePoweredByGasOrDieselIndTransformer: Invalid data: {}", ecmIndicatorValue);
			return "";
		} catch (Exception e) {
			log.error("VehiclePoweredByGasOrDieselIndTransformer: Unknown error: {}", e.getMessage());
			return "";
		}

    }

    public static String transformTrToEcm(String trIndicatorValue) {
		try {
			String ecmIndicator = TR_TO_ECM_MAP.get(trIndicatorValue != null ? trIndicatorValue.toUpperCase() : "");
			if (ecmIndicator == null) {
				throw new IllegalArgumentException("Invalid TR Indicator value: " + trIndicatorValue);
			}
			return ecmIndicator;
		} catch (IllegalArgumentException e) {
			log.error("VehiclePoweredByGasOrDieselIndTransformer (reverse): Invalid data: {}", trIndicatorValue);
			return "";
		} catch (Exception e) {
			log.error("VehiclePoweredByGasOrDieselIndTransformer (reverse): Unknown error: {}", e.getMessage());
			return "";
		}
    }
}
