package gov.irs.jios.common.client.tr.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import gov.irs.jios.common.client.config.DynamicMappingConfigLoader;
import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import gov.irs.jios.common.ecm.pojo.ErrorDetail;
import gov.irs.jios.common.ecm.pojo.ErrorResponse;
import gov.irs.jios.common.ecm.pojo.TransactionInfo;
import gov.irs.jios.common.ecm.pojo.ValidationField;
import gov.irs.jios.common.ecm.pojo.ValidationFieldsResponse;
import gov.irs.jios.common.ecm.pojo.ValidationGroupField;
import gov.irs.jios.common.ecm.pojo.ValidationResponse;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ErrorTransformationService {
    
    @Autowired
    private DynamicMappingConfigLoader configLoader;
    
    @Autowired
    private ObjectMapper objectMapper;

    public ErrorResponse transformTrValidationError(Map<String, Object> header, String trErrorResponse, String taxYear) {
        try {
            // Get field mappings for source field lookup
            List<FieldMapping> fieldMappings = configLoader.getSaveRequestFieldsMappings(taxYear);
            Map<String, String> targetToSourceFieldMap = createTargetToSourceFieldMap(fieldMappings);
            
            // Parse TR error response into validation response structure
            ValidationResponse validationResponse = objectMapper.readValue(trErrorResponse, ValidationResponse.class);
            
            // Transform to ECM error format
            List<ErrorDetail> errors = new ArrayList<>();

            //When the fields array from TR validation JSON is empty
            if (validationResponse.getFieldsResponse() == null || validationResponse.getFieldsResponse().isEmpty()) {
            	ErrorDetail error = createEcmError(null, trErrorResponse);
            	ErrorResponse errorResponse = new ErrorResponse();
                errorResponse.setErrorDetails(Collections.singletonList(error));
                errorResponse.setTransactionInfo(createTransactionInfo(header));
                return errorResponse;
                
            }
            // Process each FieldsResponse in the TR response
            for (ValidationFieldsResponse response : validationResponse.getFieldsResponse()) {
                processValidationResponse(response, targetToSourceFieldMap, errors);
            }
            
            // Create and return ECM error response
            ErrorResponse errorResponse = new ErrorResponse();
            errorResponse.setErrorDetails(errors);
            errorResponse.setTransactionInfo(createTransactionInfo(header));
            return errorResponse;
        } catch (Exception e) {
            log.error("Error transforming TR validation error response", e);
            return createServerErrorResponse(header, "Exception occurred during TR call", e.getMessage());
        }
    }
    
    private void processValidationResponse(ValidationFieldsResponse fieldsResponse, 
            Map<String, String> targetToSourceFieldMap, List<ErrorDetail> errors) {
        
        // Handle group field errors if present
        if (fieldsResponse.getGroupField() != null) {
            ValidationGroupField groupField = fieldsResponse.getGroupField();
            if (groupField.getResponseStatus() != null) {
                errors.add(createEcmError(
                    getSourceField(groupField.getFieldId(), targetToSourceFieldMap),
                    groupField.getResponseStatus().getMessage()
                ));
            }
        }
        
        // Handle field level errors
        if (fieldsResponse.getFields() != null) {
            for (ValidationField field : fieldsResponse.getFields()) {
                if (field.getResponseStatus() != null) {
                    errors.add(createEcmError(
                        getSourceField(field.getFieldId(), targetToSourceFieldMap),
                        field.getResponseStatus().getMessage()
                    ));
                }
            }
        }
    }
    
    private Map<String, String> createTargetToSourceFieldMap(List<FieldMapping> fieldMappings) {
        return fieldMappings.stream()
            .filter(mapping -> mapping.getTargetField() != null && mapping.getSourceField() != null)
            .collect(Collectors.toMap(
                FieldMapping::getTargetField,
                FieldMapping::getSourceField,
                (existing, replacement) -> existing // Keep first mapping in case of duplicates
            ));
    }
    
    private ErrorDetail createEcmError(String sourceField, String errorMessage) {
        ErrorDetail error = new ErrorDetail();
        error.setSource(sourceField != null ? sourceField : "UNKNOWN");
        error.setMessage("TR Validation error");
        
        try {
            // Try to parse as JSON first
            JsonNode detailsNode = objectMapper.readTree(errorMessage);
            error.setDetails(detailsNode);
        } catch (JsonProcessingException e) {
            // Create a simple JSON object containing the message
            ObjectNode detailsNode = objectMapper.createObjectNode();
            detailsNode.put("message", errorMessage);
            error.setDetails(detailsNode);
            log.debug("Error message was not JSON, wrapped in JSON object: {}", errorMessage);
        }        
        return error;
    }
    
    private String getSourceField(String targetField, Map<String, String> targetToSourceFieldMap) {
        return targetToSourceFieldMap.getOrDefault(targetField, targetField);
    }
    
    private TransactionInfo createTransactionInfo(Map<String, Object> header) {
        TransactionInfo transactionInfo = new TransactionInfo();
        transactionInfo.setCorrelationId((String) header.get("correlationId"));
        transactionInfo.setTransactionId((String) header.get("transactionId"));
        return transactionInfo;
    }
    
    public ErrorResponse createServerErrorResponse(Map<String, Object> header, String errorMessage, String details) {
        ErrorResponse response = new ErrorResponse();
        ErrorDetail error = new ErrorDetail();
        error.setSource("None");
        error.setMessage(errorMessage);
        
        // Convert error message to JsonNode
        error.setDetails(objectMapper.getNodeFactory().textNode(details));
        
        response.setErrorDetails(Collections.singletonList(error));
        response.setTransactionInfo(createTransactionInfo(header));
        return response;
    }
}