package gov.irs.jios.common.exception;

import org.springframework.http.HttpStatus;

public class TrResponseException extends RuntimeException {
    private final String responseBody;
    private final HttpStatus status;
    
    public TrResponseException(String responseBody, HttpStatus status) {
        this.responseBody = responseBody;
        this.status = status;
    }
    
    public String getResponseBody() {
        return responseBody;
    }
    
    public HttpStatus getStatus() {
        return status;
    }
}
