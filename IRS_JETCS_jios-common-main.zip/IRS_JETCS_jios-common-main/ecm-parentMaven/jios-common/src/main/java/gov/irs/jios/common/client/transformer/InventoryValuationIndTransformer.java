package gov.irs.jios.common.client.transformer;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;

/**
 * Author: Kaiwen Tsou
 **/

/**
 * Transforms ECM payload value to the appropriate TR ui checkbox item. 
 */
@Slf4j
public class InventoryValuationIndTransformer {
    
    private static final Map<String, Boolean> ECM_TO_TR_MAP = Map.of(
	    "TRUE", true,
	    "FALSE", false,
	    "1", true,
	    "0", false,
	    "X", true,
	    "", false
	);
	private static final Map<String, String> TR_TO_ECM_MAP = Map.of(
	    "C", "TRUE",
	    "L", "TRUE",
	    "D", "FALSE", // This should not actually come back. 
	    "O", "TRUE",
	    "", "FALSE"
	);
    /**
     * Maps to "C" for the Cost option of Inventory Valuation (1040 Schedule C) in the TR ui.
     * @param ecmIndicatorValue true or false
     * @return the value of the field to be sent to tr
     */
    public String transformClosingInventoryCostMethodIndEcmToTr(String ecmIndicatorValue) {
        try {
            if (ecmIndicatorValue == null) {
                ecmIndicatorValue = "";
            }
            Boolean isFieldTrue = ECM_TO_TR_MAP.get(ecmIndicatorValue.toUpperCase());
        
            // See TR Data Dictionary for Inventory Valuation radio button field for what the indvalue should be
            String trIndicator = getIndForTrueField(isFieldTrue, "C", "D");
            if (trIndicator == null) {
                throw new IllegalArgumentException("Invalid ECM Indicator value: " + ecmIndicatorValue);
            }
            return trIndicator;
        } catch (Exception e){
            log.warn("InventoryValuationIndTransformer: " + e.getMessage());
            return "";
        }
    
    }
    /**
     * Maps to "O" for the Other  option of Inventory Valuation (1040 Schedule C) in the TR ui.
     * @param ecmIndicatorValue true or false
     * @return the value of the field to be sent to tr
     */
    public String transformOtherClosingInventoryMethodIndEcmToTr(String ecmIndicatorValue) {
        try {
            if (ecmIndicatorValue == null) {
                ecmIndicatorValue = "";
            }
            Boolean isFieldTrue = ECM_TO_TR_MAP.get(ecmIndicatorValue.toUpperCase());
            // See TR Data Dictionary for Inventory Valuation radio button field for what the indvalue should be
            String trIndicator = getIndForTrueField(isFieldTrue, "O", "D");
            if (trIndicator == null) {
                throw new IllegalArgumentException("Invalid ECM Indicator value: " + ecmIndicatorValue);
            }
            return trIndicator;
        } catch (Exception e){
            log.warn("InventoryValuationIndTransformer: " + e.getMessage());
            return "";
        }
    }

    /**
     * Maps to "L" for the Lower of Cost or Market option of Inventory Valuation (1040 Schedule C) in the TR ui.
     * @param ecmIndicatorValue true or false
     * @return the value of the field to be sent to tr
     */
    public String transformLowerOfCostOrMarketMethodIndEcmToTr(String ecmIndicatorValue) {
        try {
            if (ecmIndicatorValue == null) {
                ecmIndicatorValue = "";
            }
            Boolean isFieldTrue = ECM_TO_TR_MAP.get(ecmIndicatorValue.toUpperCase());
        
            // See TR Data Dictionary for Inventory Valuation radio button field for what the indvalue should be
            String trIndicator = getIndForTrueField(isFieldTrue, "L", "D");
            if (trIndicator == null) {
                throw new IllegalArgumentException("Invalid ECM Indicator value: " + ecmIndicatorValue);
            }
            return trIndicator;
        } catch (Exception e){
            log.warn("InventoryValuationIndTransformer: " + e.getMessage());
            return "";
        }
    }
    public String transformTrToEcm(String trIndicatorValue) {
        try {
            String ecmIndicator = TR_TO_ECM_MAP.get(trIndicatorValue != null ? trIndicatorValue.toUpperCase() : "");
            if (ecmIndicator == null) {
                throw new IllegalArgumentException("Invalid TR Indicator value: " + trIndicatorValue);
            }
            return ecmIndicator;
        } catch (Exception e){
            log.warn("InventoryValuationIndTransformer: " + e.getMessage());
            return "";
        }
    }
    /**
     * @param isFieldTrue whether the field being mapped is denoted as 'true' by ECM
     * @param trueIndicatorToReturn the indicator value to use if the field is denoted as true
     * @return the indicator field value
     */
    private String getIndForTrueField(Boolean isFieldTrue, String trueIndicatorToReturn, String falseIndicatorToReturn){
        if (isFieldTrue){
            return trueIndicatorToReturn;
        }
        else{
            return falseIndicatorToReturn;
        }
    }
}