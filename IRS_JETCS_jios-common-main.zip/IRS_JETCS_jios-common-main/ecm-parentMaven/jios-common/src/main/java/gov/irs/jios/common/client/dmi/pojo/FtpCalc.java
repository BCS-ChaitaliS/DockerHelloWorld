package gov.irs.jios.common.client.dmi.pojo;

import lombok.Data;

@Data
public class FtpCalc {
    private String penaltySectionCd;
    private Integer installAgreeInd;
    private Integer fraudulentInd;
    private Integer returnIncomeInd;
    private Double assessmentAmt;
    private String assessmentDt;
    private Integer bankruptcyInd;
    private Double previouslyAssessedPenaltyAmt;
}
