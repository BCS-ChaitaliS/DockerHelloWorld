package gov.irs.jios.common.ecm.pojo;

import java.util.List;

import lombok.Data;

@Data
public class ValidationFieldsResponse {
    private ValidationGroupField groupField;
    private List<ValidationField> fields;
}
