package gov.irs.jios.common.client.transformer;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import lombok.extern.slf4j.Slf4j;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class MefValuesTransformer {
	static BiMap<String, String> ECM_TO_TR_MAP;
	static {
		Map<String, String> PRE_ECM_TO_TR_MAP = new HashMap<>();
		PRE_ECM_TO_TR_MAP.put("yes", "Y");
		PRE_ECM_TO_TR_MAP.put("sstb", "S");
		PRE_ECM_TO_TR_MAP.put("no", "N");
		PRE_ECM_TO_TR_MAP.put("passive", "B");
		PRE_ECM_TO_TR_MAP.put("material", "A");
		PRE_ECM_TO_TR_MAP.put("portfolio", "C");
		PRE_ECM_TO_TR_MAP.put("rentalpassive", "1");
		PRE_ECM_TO_TR_MAP.put("rentalactive", "2");
		PRE_ECM_TO_TR_MAP.put("rentalpro", "3");
		PRE_ECM_TO_TR_MAP.put("nonpassivetaxshelter", "G");
		PRE_ECM_TO_TR_MAP.put("passivenontax", "H");
		ECM_TO_TR_MAP = HashBiMap.create(PRE_ECM_TO_TR_MAP);
	}
	static BiMap<String, String> ECM_RNT_TO_TR_MAP;
	static {
		Map<String, String> PRE_ECM_RNT_TO_TR_MAP = new HashMap<>();
		PRE_ECM_RNT_TO_TR_MAP.put("passive", "");

		ECM_RNT_TO_TR_MAP = HashBiMap.create(PRE_ECM_RNT_TO_TR_MAP);
	}
	public static String transformEcmToTr(String ecmIndicatorValue) {
        try {
            if (ecmIndicatorValue == null) {
                ecmIndicatorValue = "";
            }
            String trIndicator = ECM_TO_TR_MAP.get(ecmIndicatorValue.toLowerCase());
            if (trIndicator == null) {
                throw new IllegalArgumentException("Invalid ECM Indicator value: " + ecmIndicatorValue);
            }
            return trIndicator;  
        } catch (IllegalArgumentException e){
        	log.warn("ChangingStatusNotValuesTransformer: Invalid ECM indicator: " + ecmIndicatorValue);
            return "";
        }
    }
	public static String transformEcmRntToTr(String ecmIndicatorValue) {
        try {
            if (ecmIndicatorValue == null || ecmIndicatorValue == "0") {
               return ecmIndicatorValue = "";
            }
            String trIndicator = ECM_RNT_TO_TR_MAP.get(ecmIndicatorValue.toLowerCase());
            if (trIndicator == null) {
                throw new IllegalArgumentException("Invalid ECM Indicator value: " + ecmIndicatorValue);
            }
            return trIndicator;  
        } catch (IllegalArgumentException e){
        	log.warn("ChangingStatusNotValuesTransformer: Invalid ECM indicator: " + ecmIndicatorValue);
            return "";
        }
    }
    public static String transformTrToEcm(String trIndicatorValue) {
        try {
            String ecmIndicator = ECM_TO_TR_MAP.inverse().get(trIndicatorValue != null ? trIndicatorValue.toUpperCase() : "");
            if (ecmIndicator == null) {
                throw new IllegalArgumentException("Invalid TR Indicator value: " + trIndicatorValue);
            }
            return ecmIndicator;
        } catch (IllegalArgumentException e){
        	log.warn("ChangingStatusNotValuesTransformer: Invalid TR indicator: " + trIndicatorValue);
            return "";
        }
    }
}
