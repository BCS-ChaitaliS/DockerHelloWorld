package gov.irs.jios.common.client.transformer;

import static gov.irs.jios.common.util.JiosCommonConstants.LINE_ITEMS;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_NAME_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.PER_RETURN_VALUE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.SEQUENCE_NUM;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FormIRS8839Transformer {
	
	public static final String IRS8839 = "IRS8839";
	
    public List<FieldMapping> transformFormIRS8839(Map<String, Object> formData, Map<String, Object> header) {
    	List<FieldMapping> fieldMappings = new ArrayList<>();

        if (formData == null || header == null) {
            log.warn("FormData or header is null. Returning empty field mappings.");
            return fieldMappings;
        }

        mapAdoptedChild(formData, fieldMappings);

        return fieldMappings;
    }
    
    @SuppressWarnings("unchecked")
    private void mapAdoptedChild(Map<String, Object> formData, List<FieldMapping> fieldMappings) {
        List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
        if (lineItems == null) {
            log.warn("No lineItems found in formData");
            return;
        }
        
        Properties properties = new Properties();
        try (InputStream is = getClass().getClassLoader().getResourceAsStream("common/application.properties")) {
			properties.load(is);
        } catch (Exception e) {
			log.error("Exception reading application.properties " + e.getMessage());
		}
        
        // TR target field varies depending on if data is for adopted Child1, Child2 or Child3
        Map<String, List<String>> ecmToTrMappings = new HashMap<String, List<String>>();
        ecmToTrMappings.put("/IRS8839/AdoptedChild/ChildBirthYr", List.of("F88.Y1", "F88.Y2", "F88.Y3"));
        ecmToTrMappings.put("/IRS8839/AdoptedChild/AdoptionCreditPriorYearAmt", List.of("F88.PRIOR1", "F88.PRIOR2", "F88.PRIOR3"));
        ecmToTrMappings.put("/IRS8839/AdoptedChild/QualifiedAdoptionExpenseAmt", List.of("F88.17", "F88.19", "F88.CHLD3CY"));
        ecmToTrMappings.put("/IRS8839/AdoptedChild/EmployerAdoptionBenefitsPYAmt", List.of("F88.PRIOREPB1", "F88.PRIOREPB2", "F88.CHLD3EMPPY"));
        ecmToTrMappings.put("/IRS8839/AdoptedChild/EmployerAdoptionBnftPerChldAmt", List.of("F88.19A", "F88.20", "F88.CHLD3EMPCY"));
        
        ecmToTrMappings.put("/IRS8839/AdoptedChild/PersonFirstNm", List.of("F88.F1", "F88.F2", "F88.F3"));
        ecmToTrMappings.put("/IRS8839/AdoptedChild/PersonLastNm", List.of("F88.L1", "F88.L2", "F88.L3"));
        ecmToTrMappings.put("/IRS8839/AdoptedChild/ChildSSN", List.of("F88.C1", "F88.C2", "F88.C3"));
        
        ecmToTrMappings.put("/IRS8839/AdoptedChild/DisabledChildOver18Ind", List.of("F88.11", "F88.12", "F88.CHLD3DIS"));
        ecmToTrMappings.put("/IRS8839/AdoptedChild/ChildWithSpecialNeedsInd", List.of("F88.13", "F88.14", "F88.CHLD3SP"));
        ecmToTrMappings.put("/IRS8839/AdoptedChild/ForeignChildInd", List.of("F88.15", "F88.16", "F88.CHLD3FOR"));
        ecmToTrMappings.put("/IRS8839/AdoptedChild/AdoptionFinalInd", List.of("X129.38.15", "X129.38.16", "F88.CHLD3FPY"));
        
        // Send mock data to TR for below fields
        // TODO - SAMPATH - Find better way of injecting only the properties this transformer requires, 
        // instead of loading the entire application.properties
        Map<String, String> mockFieldMappings = new HashMap<String, String>();
        mockFieldMappings.put("/IRS8839/AdoptedChild/PersonFirstNm", "mock.dependent.fname");
        mockFieldMappings.put("/IRS8839/AdoptedChild/PersonLastNm", "mock.dependent.lname");
        mockFieldMappings.put("/IRS8839/AdoptedChild/ChildSSN", "mock.dependent.taxpayer.ssn.formatted");
        
        // Below fields need to have Indicator Transformation applied
        List<String> indicatorFields = List.of("/IRS8839/AdoptedChild/DisabledChildOver18Ind", "/IRS8839/AdoptedChild/ChildWithSpecialNeedsInd", "/IRS8839/AdoptedChild/ForeignChildInd", "/IRS8839/AdoptedChild/AdoptionFinalInd");
        
        for (Map<String, Object> lineItem : lineItems) {
        	// Get the sequence number of the current adopted child data
            if ("/IRS8839/AdoptedChild".equals(lineItem.get(LINE_NAME_TXT))) {
                String sequenceNum = (String) lineItem.get(SEQUENCE_NUM);
                if (sequenceNum == null || sequenceNum.isEmpty()) {
                    log.warn("sequenceNum found but value is null or empty");
                    continue;
                }
                List<Map<String, Object>> adoptedChildLineItems = (List<Map<String, Object>>) lineItem.get(LINE_ITEMS);
                for (Map<String, Object> adoptedChildLineItem : adoptedChildLineItems) {
                	String ecmAttribute = (String) adoptedChildLineItem.get(LINE_NAME_TXT);
                	if (ecmToTrMappings.containsKey(ecmAttribute)) {
                		String targetField = ecmToTrMappings.get(ecmAttribute).get(Integer.valueOf(sequenceNum) - 1);
                		String ecmValue = (String) adoptedChildLineItem.get(PER_RETURN_VALUE_TXT);
                		// Update ECM target field value for Mock fields and Indicator fields
                		if(mockFieldMappings.containsKey(ecmAttribute)) {
                			ecmValue = properties.get(mockFieldMappings.get(ecmAttribute)) + sequenceNum;
                		} else if (indicatorFields.contains(ecmAttribute)) {
                			ecmValue = IndicatorFieldValueTransformer.transformEcmToTr(ecmValue);
                		}
                		addFieldMapping(fieldMappings, targetField, ecmValue);
                	}
                }
            }
        }
    }
    
    private void addFieldMapping(List<FieldMapping> mappings, String targetField, String targetFieldValue) {
        FieldMapping mapping = new FieldMapping();
        mapping.setSourceForm(IRS8839);
        mapping.setTargetField(targetField);
        mapping.setTargetFieldValue(targetFieldValue);
        mappings.add(mapping);
    }
}