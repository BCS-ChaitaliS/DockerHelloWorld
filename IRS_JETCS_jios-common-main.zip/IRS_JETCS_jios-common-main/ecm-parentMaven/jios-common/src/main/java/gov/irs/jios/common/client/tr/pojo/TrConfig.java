package gov.irs.jios.common.client.tr.pojo;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@ConfigurationProperties(prefix = "tr")
@Data
public class TrConfig {
    private String tokenUrl;
    private String locatorUrl;
    private String openSessionUrl;
    private String closeLocatorUrl;
    private String saveFieldsUrl;
    private String retrieveFieldsUrl;
    private String clientId;
    private String clientSecret;
    private String scopes;
    private String grantType;
    private String account;
    private String taxtype;
    private String returntype;
    private String snapshotOpenUrl;
    private String snapshotDownloadUrl;
}
