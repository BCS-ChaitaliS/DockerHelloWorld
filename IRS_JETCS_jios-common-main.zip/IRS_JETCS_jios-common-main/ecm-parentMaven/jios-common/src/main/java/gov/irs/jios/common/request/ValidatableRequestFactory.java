package gov.irs.jios.common.request;

public interface ValidatableRequestFactory {
    ValidatableRequest createRequest();
}
