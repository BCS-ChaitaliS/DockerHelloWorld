package gov.irs.jios.common.client.tr.service;

import static gov.irs.jios.common.util.JiosCommonConstants.AUTH_TOKEN;
import static gov.irs.jios.common.util.JiosCommonConstants.TAX_RETURN_SESSION_TOKEN;

import java.io.IOException;
import java.time.Duration;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import gov.irs.jios.common.client.tr.pojo.TrConfig;
//import gov.irs.jios.common.profiler.Profiled;
import lombok.extern.slf4j.Slf4j;
import reactor.util.retry.Retry;

@Service
@Slf4j
public class CloseLocatorService {
	
	@Value("${webclient.retry.max-attempts:3}")
	private int maxAttempts;

	@Value("${webclient.retry.interval:100}")
	private long retryInterval;
	
    private final WebClient webClient;

    public CloseLocatorService(WebClient.Builder webClientBuilder,
                             TrConfig trConfig) {
        this.webClient = webClientBuilder.baseUrl(trConfig.getCloseLocatorUrl()).build();
    }

    //@Profiled
    public void closeLocator(String token, Map<String, String> authTokenSessionToken) throws IOException {
    	log.info("Start CloseLocatorService");
    	try {
    		webClient.post()
            .headers(headers -> {
                headers.setBearerAuth(token);
                headers.set(AUTH_TOKEN, authTokenSessionToken.get(AUTH_TOKEN));
                headers.set(TAX_RETURN_SESSION_TOKEN, authTokenSessionToken.get(TAX_RETURN_SESSION_TOKEN));
            })
            .bodyValue("{'Test' : 'test'}")
            .retrieve()
            .bodyToMono(Void.class)
            .doOnSuccess(v -> log.info("Close Locator request successful"))
            .retryWhen(Retry.backoff(maxAttempts, Duration.ofMillis(retryInterval))
                .filter(throwable -> throwable instanceof WebClientResponseException &&
                                    ((WebClientResponseException) throwable).getStatusCode().is5xxServerError()))
            .block();
    	} catch(Exception e) {
    		log.error("Exception in Close Locator " + e.getMessage());
    		if(e.getMessage().contains("200 OK from POST") || e.getMessage().contains("The tax return might already be closed")) {
    			log.error("Temporary error from IRS API Gateway or Locator is already closed. Ignoring for now");
    		} else {
    			throw e;
    		}
    	}
    	
    	log.info("End CloseLocatorService");
    }
}