package gov.irs.jios.common.client.transformer;

import static java.util.Map.entry;

import java.util.Map;

public class StateAbbreviationCodeTransformer {
	
	private static final Map<String, String> ECM2TR_STATE_CODE_MAP = Map.ofEntries(
			entry("", "99"),
			entry("AL", "1"),
			entry("AK", "80"),
			entry("AZ", "3"),
			entry("AR", "4"),
			entry("CA", "5"),
			entry("CO", "7"),
			entry("CT", "8"),
			entry("DE", "9"),
			entry("DC", "10"),
			entry("FL", "81"),
			entry("GA", "12"),
			entry("HI", "13"),
			entry("ID", "14"),
			entry("IL", "15"),
			entry("IN", "17"),
			entry("IA", "18"),
			entry("KS", "19"),
			entry("KY", "20"),
			entry("LA", "21"),
			entry("ME", "22"),
			entry("MD", "23"),
			entry("MA", "24"),
			entry("MI", "25"),
			entry("MN", "26"),
			entry("MS", "27"),
			entry("MO", "28"),
			entry("MT", "29"),
			entry("NE", "30"),
			entry("NH", "32"),
			entry("NJ", "73"),
			entry("NM", "34"),
			entry("NY", "35"),
			entry("NC", "39"),
			entry("ND", "40"),
			entry("OH", "41"),
			entry("OK", "43"),
			entry("OR", "44"),
			entry("PA", "46"),
			entry("RI", "48"),
			entry("SC", "49"),
			entry("SD", "84"),
			entry("TN", "85"),
			entry("TX", "86"),
			entry("UT", "54"),
			entry("VT", "55"),
			entry("VA", "56"),
			entry("WA", "87"),
			entry("WV", "58"),
			entry("WI", "59"),
			entry("WY", "88"),
			entry("AS", "89"),
			entry("GU", "90"),
			entry("MP", "91"),
			entry("PR", "83"),
			entry("VI", "92"),
			entry("NV", "82"));
	
	private static final Map<String, String> TR2ECM_STATE_CODE_MAP = Map.ofEntries(
			entry("99", ""),
			entry("1", "AL"),
			entry("80","AK"),
			entry("3", "AZ"),
			entry("4", "AR"),
			entry("5", "CA"),
			entry("7", "CO"),
			entry("8", "CT"),
			entry("9", "DE"),
			entry("10", "DC"),
			entry("81", "FL"),
			entry("12", "GA"),
			entry("13", "HI"),
			entry("14", "ID"),
			entry("15", "IL"),
			entry("17", "IN"),
			entry("18", "IA"),
			entry("19", "KS"),
			entry("20", "KY"),
			entry("21", "LA"),
			entry("22", "ME"),
			entry("23", "MD"),
			entry("24", "MA"),
			entry("25", "MI"),
			entry("26", "MN"),
			entry("27", "MS"),
			entry("28", "MO"),
			entry("29", "MT"),
			entry("30", "NE"),
			entry("32", "NH"),
			entry("73", "NJ"),
			entry("34", "NM"),
			entry("35", "NY"),
			entry("39", "NC"),
			entry("40", "ND"),
			entry("41", "OH"),
			entry("43", "OK"),
			entry("44", "OR"),
			entry("46", "PA"),
			entry("48", "RI"),
			entry("49", "SC"),
			entry("84", "SD"),
			entry("85", "TN"),
			entry("86", "TX"),
			entry("54", "UT"),
			entry("55", "VT"),
			entry("56", "VA"),
			entry("87", "WA"),
			entry("58", "WV"),
			entry("59", "WI"),
			entry("88", "WY"),
			entry("89", "AS"),
			entry("90", "GU"),
			entry("91", "MP"),
			entry("83", "PR"),
			entry("92", "VI"),
			entry("82", "NV"));
	
		    public String transformEcmToTr(String ecmState) {
		    	if (ecmState == null) {
		    		ecmState = "";
		    	}
		        String trStatus = ECM2TR_STATE_CODE_MAP.get(ecmState);
		        if (trStatus == null) {
		            throw new IllegalArgumentException("Invalid ECM state: " + ecmState);
		        }
		        return trStatus;
		    }

		    public String transformTrToEcm(String trState) {
		    	if (trState == null) {
		    		trState = "99";
		    	}
		        String ecmStatus = TR2ECM_STATE_CODE_MAP.get(trState);
		        if (ecmStatus == null) {
		            throw new IllegalArgumentException("Invalid TR state: " + trState);
		        }
		        return ecmStatus;
		    }
}
