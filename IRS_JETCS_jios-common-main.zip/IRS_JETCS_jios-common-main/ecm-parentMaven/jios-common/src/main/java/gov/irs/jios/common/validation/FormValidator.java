package gov.irs.jios.common.validation;

import gov.irs.jios.common.client.tr.service.ErrorTransformationService;
import gov.irs.jios.common.request.ValidatableRequest;

public interface FormValidator {
    /**
     * Validates the request payload according to form-specific rules
     */
    void validateRequest(ValidatableRequest request, ErrorTransformationService errorTransformationService);
}
