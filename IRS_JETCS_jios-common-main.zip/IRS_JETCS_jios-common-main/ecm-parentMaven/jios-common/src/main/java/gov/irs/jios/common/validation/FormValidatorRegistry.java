package gov.irs.jios.common.validation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class FormValidatorRegistry {
    private final Map<String, FormValidator> validators = new HashMap<>();
    
    public FormValidatorRegistry(List<FormValidator> allValidators) {
        for (FormValidator validator : allValidators) {
            String formType = determineFormType(validator);
            validators.put(formType, validator);
        }
    }
    
    private String determineFormType(FormValidator validator) {
        // Extract form type from class name, e.g., "IRS8829Validator" -> "IRS8829"
        String className = validator.getClass().getSimpleName();
        return className.replace("Validator", "");
    }
    
    public FormValidator getValidator(String formType) {
        return validators.get(formType);
    }
    
    public List<FormValidator> getAllValidators() {
        return new ArrayList<>(validators.values());
    }
}
