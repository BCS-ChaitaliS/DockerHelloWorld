package gov.irs.jios.common.client.tr.util;

import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.irs.jios.common.client.tr.pojo.RetrieveFieldsResponseDTO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TrRetrieveResponseLineFinder {

	public static void populateTrResultMap(RetrieveFieldsResponseDTO response,
            Map<String, Map<String, String>> trResultMap, String calcType) {

        Map<String, String> responseSubMap = new HashMap<>();
        
        // Define field mappings
        Map<String, String> fieldMappings = new HashMap<>();
        if (calcType.equals(CALC_TYPE_PENALTY_AGR_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY) || 
            calcType.equals(CALC_TYPE_PENALTY_TOT_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY)) {
            fieldMappings.put("FED.TAXINC", "taxableIncomeAmt");
        } else {
            fieldMappings.put("FED.CREDLTAX", "totalTaxAmt");
        }
        
        // Add common field mappings
        fieldMappings.put("FED.EIC", "earnedIncomeCreditAmt");
        fieldMappings.put("FED.ADDCHLD", "additionalChildTaxCreditAmt");
        fieldMappings.put("X133.REFEDUCR", "refundableAmerOppCreditAmt");
        fieldMappings.put("X133.891.6", "totalOtherPaymentsRfdblCrAmt");
        
        fieldMappings.put("X133.938.4", "formW2WithheldTaxAmt");
        fieldMappings.put("X133.938.5", "form1099WithheldTaxAmt");
        fieldMappings.put("X133.938.6", "taxWithheldOtherAmt");
        fieldMappings.put("FED.TAXPYMTS", "estimatedTaxPaymentsAmt");
        fieldMappings.put("X95.217.8", "additionalMedicareTaxAmt");

        // Process all fields in one JSON parse
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode rootNode = objectMapper.readTree(response.getJsonResponse());
            JsonNode fieldsResponseArray = rootNode.get("fieldsResponse");
            
            if (fieldsResponseArray != null && fieldsResponseArray.isArray()) {
                for (JsonNode responseNode : fieldsResponseArray) {
                    JsonNode fieldsNode = responseNode.get("fields");
                    if (fieldsNode != null && fieldsNode.isArray()) {
                        for (JsonNode fieldNode : fieldsNode) {
                            String fieldId = fieldNode.get("fieldId").asText();
                            // If this is a field we're interested in
                            if (fieldMappings.containsKey(fieldId)) {
                                String value = TRCommonUtil.cleanTrValue(fieldNode.get("value").asText());
                                responseSubMap.put(fieldMappings.get(fieldId), value);
                            }
                        }
                    }
                }
            }
        } catch (JsonProcessingException e) {
            log.error("Error parsing JSON response: {}", e.getMessage());
            throw new RuntimeException("Error parsing JSON response", e);
        }

        trResultMap.put(calcType, responseSubMap);
    }
}
