package gov.irs.jios.common.client.transformer;

import static gov.irs.jios.common.util.JiosCommonConstants.PRIMARY_TIN;
import static gov.irs.jios.common.util.JiosCommonConstants.SECONDARY_TIN;
import static gov.irs.jios.common.util.JiosCommonConstants.TAX_PERIOD;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_ITEMS;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_NAME_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.PER_RETURN_VALUE_TXT;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import lombok.extern.slf4j.Slf4j;

/**
 * @author  Janet, ArunaValluru
 */

@Slf4j
public class FormIRS8885Transformer {
	public static final String IRS8885 = "IRS8885";
	public List<FieldMapping> transformFormIRS8885(Map<String, Object> formData, Map<String, Object> header) {
		List<FieldMapping> fieldMappings = new ArrayList<>();
		try { 
			String taxPeriod = (String) header.get(TAX_PERIOD);
			if (taxPeriod == null) {
				log.warn("TaxPeriod was null in header");
				return fieldMappings;
			}
			String taxYear = taxPeriod.substring(0, 4);
			if (Integer.parseInt(taxYear) > 2021) {
				log.warn("Form 8885 is only used in tax year 2021 and prior.");
				return fieldMappings;
			}
			if (formData == null || header == null) {
				log.warn("FormData or header is null. Returning empty field mappings.");
				return fieldMappings;
			}
			String ssn = extractSSN(formData);
			if (ssn == null) {
				log.warn("Unable to extract SSN from formData. Returning empty field mappings.");
				return fieldMappings;
			}
			String primaryTIN = (String) header.get(PRIMARY_TIN);
			String secondaryTIN = (String) header.get(SECONDARY_TIN);
			
			if (primaryTIN == null && secondaryTIN == null) {
				log.warn("Both primaryTIN and spouseTIN are null in header. Returning empty field mappings.");
				return fieldMappings;
			}
			@SuppressWarnings("unchecked")
			List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
			if (lineItems == null) {
				log.warn("No lineItems found in formData");
				return fieldMappings;
			}
			if (Objects.equals(ssn, primaryTIN)) {
				// log.info("8885 using primaryTIN");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrJanuaryInd", "X122.1498.1");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrFebruaryInd", "X122.1498.3");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrMarchInd", "X122.1498.5");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrAprilInd", "X122.1498.7");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrMayInd", "X122.1498.9");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrJuneInd", "X122.1498.11");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrJulyInd", "X122.1498.13");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrAugustInd", "MCR.AUGT");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrSeptemberInd", "MCR.SEPT");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrOctoberInd", "MCR.OCTT");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrNovemberInd", "MCR.NOVT");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrDecemberInd", "MCR.DECT");
				addFieldMapping(fieldMappings, "/IRS8885/HealthPlanPaidAmt", "X122.1498.15");
				addFieldMapping(fieldMappings, "/IRS8885/HealthPlanPaidWithMSAOrHSAAmt", "X122.1498.17");
			} else if (Objects.equals(ssn, secondaryTIN)) {
				// log.info("8885 using spouseTIN);
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrJanuaryInd", "X122.1498.2");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrFebruaryInd", "X122.1498.4");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrMarchInd", "X122.1498.6");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrAprilInd", "X122.1498.8");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrMayInd", "X122.1498.10");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrJuneInd", "X122.1498.12");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrJulyInd", "X122.1498.14");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrAugustInd", "MCR.AUGS");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrSeptemberInd", "MCR.SEPS");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrOctoberInd", "MCR.OCTS");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrNovemberInd", "MCR.NOVS");
				addFieldMapping(fieldMappings, "/IRS8885/HealthCvrTaxCrDecemberInd", "MCR.DECS");
				addFieldMapping(fieldMappings, "/IRS8885/HealthPlanPaidAmt", "X122.1498.16");
				addFieldMapping(fieldMappings, "/IRS8885/HealthPlanPaidWithMSAOrHSAAmt", "X122.1498.18");
			} else {
				log.warn("SSN for 8885 does not match primaryTIN {} or spouseTIN {}. Returning empty field mappings.");
			}
		} catch (Exception e) {
			List<FieldMapping> emptyFieldMappings = new ArrayList<>();
			return emptyFieldMappings;
		}
		return fieldMappings;
	}
	private String extractSSN(Map<String, Object> formData) {
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
		if (lineItems == null) {
			log.warn("No lineItems found in formData");
			return null;
		}
		for (Map<String, Object> lineItem : lineItems) {
			if ("/IRS8885/RecipientSSN".equals(lineItem.get(LINE_NAME_TXT))) {
				String ssn = (String) lineItem.get(PER_RETURN_VALUE_TXT);
				if (ssn == null || ssn.isEmpty()) {
					log.warn("SSN found but value is null or empty");
					return null;
				}
				return ssn;
			}
		}
		log.warn("No line item with lineNameTxt '/IRS8885/RecipientSSN' found");
		return null;
	}
	private void addFieldMapping(List<FieldMapping> mappings, String sourceField, String targetField,
			String targetFieldValue) {
		FieldMapping mapping = new FieldMapping();
		mapping.setSourceForm(IRS8885);
		mapping.setSourceField(sourceField);
		mapping.setTargetField(targetField);
		mapping.setTargetFieldValue(targetFieldValue);
		mappings.add(mapping);
	}
	private void addFieldMapping(List<FieldMapping> mappings, String sourceField, String targetField) {
		addFieldMapping(mappings, sourceField, targetField, null);
	}
}
