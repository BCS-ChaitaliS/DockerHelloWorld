package gov.irs.jios.common.client.tr.pojo;

import java.util.List;

import lombok.Data;

@Data
public class ResponseMapping {
    private List<FieldMapping> fieldMappings;
}
