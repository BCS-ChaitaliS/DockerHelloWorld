package gov.irs.jios.common.client.dmi.pojo;
import lombok.Data;

@Data
public class Ftp_FtfInfo {
	private String agreedPreviouslyAssessedFtpAmt;
	private String totalPreviouslyAssessedFtpAmt;
	private String agreedPreviouslyAssessedFtfAmt;
	private String totalPreviouslyAssessedFtfAmt;
	private String agreedNetFtpAmt;
	private String totalNetFtpAmt;
	private String agreedNetFtfAmt;
	private String totalNetFtfAmt;


}
