package gov.irs.jios.common.client.transformer;

import static gov.irs.jios.common.util.JiosCommonConstants.PRIMARY_TIN;
import static gov.irs.jios.common.util.JiosCommonConstants.SECONDARY_TIN;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_ITEMS;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_NAME_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.PER_RETURN_VALUE_TXT;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import lombok.extern.slf4j.Slf4j;

/** 

 * Author: Milan Patel

**/ 
@Slf4j
public class FormIRS5329Transformer {
	
	public static final String IRS5329 = "IRS5329";
	
    public List<FieldMapping> transformFormIRS5329(Map<String, Object> formData, Map<String, Object> header) {
    	List<FieldMapping> fieldMappings = new ArrayList<>();

        if (formData == null || header == null) {
            log.warn("FormData or header is null. Returning empty field mappings.");
            return fieldMappings;
        }

        String ssn = extractSSN(formData);
        if (ssn == null) {
            log.warn("Unable to extract SSN from formData. Returning empty field mappings.");
            return fieldMappings;
        }
        
        String primaryTIN = (String) header.get(PRIMARY_TIN);
        String secondaryTIN = (String) header.get(SECONDARY_TIN);

        if (primaryTIN == null && secondaryTIN == null) {
            log.warn("Both primaryTIN and spouseTIN are null in header. Returning empty field mappings.");
            return fieldMappings;
        }
        
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
        if (lineItems == null) {
            log.warn("No lineItems found in formData");
            return fieldMappings;
        }

        if (Objects.equals(ssn, primaryTIN)) {
        	// extracting the per return value txt from these sourceFields of the primary
			String earlyDistributionsAmt = extractTargetFieldValue(formData, "/IRS5329/EarlyDistributionsAmt");
			String earlyDistriExceptionReasonCd = extractTargetFieldValue(formData, "/IRS5329/EarlyDistriExceptionReasonCd");
			String earlyDistriNotSubjectToTaxAmt = extractTargetFieldValue(formData, "/IRS5329/EarlyDistriNotSubjectToTaxAmt");
			String educAcctDistriNotSubjToTaxAmt = extractTargetFieldValue(formData, "/IRS5329/EducAcctDistriNotSubjToTaxAmt");
			String IRAExcessContriPriorYearAmt = extractTargetFieldValue(formData, "/IRS5329/IRAExcessContriPriorYearAmt");
			String IRAExcessContriCreditAmt = extractTargetFieldValue(formData, "/IRS5329/IRAExcessContriCreditAmt");
			String IRADistriIncludedInIncomeAmt = extractTargetFieldValue(formData, "/IRS5329/IRADistriIncludedInIncomeAmt");
			String IRAExcessContriWithdrawnAmt = extractTargetFieldValue(formData, "/IRS5329/IRAExcessContriWithdrawnAmt");

			String IRAExcessContriCurrentYearAmt = extractTargetFieldValue(formData, "/IRS5329/IRAExcessContriCurrentYearAmt");
			String rothIRAExcessContriPriorYrAmt = extractTargetFieldValue(formData, "/IRS5329/RothIRAExcessContriPriorYrAmt");
			String rothIRAExcessContriCreditAmt = extractTargetFieldValue(formData, "/IRS5329/RothIRAExcessContriCreditAmt");
			String rothIRAExcessContriCYAmt = extractTargetFieldValue(formData, "/IRS5329/RothIRAExcessContriCYAmt");
			String ESAExcessContriPriorYearAmt = extractTargetFieldValue(formData, "/IRS5329/ESAExcessContriPriorYearAmt");
			String ESAExcessContriCreditAmt = extractTargetFieldValue(formData, "/IRS5329/ESAExcessContriCreditAmt");
			String ESAExcessContriCYAmt = extractTargetFieldValue(formData, "/IRS5329/ESAExcessContriCYAmt");

			String archerMSAExcessContriPrYrAmt = extractTargetFieldValue(formData, "/IRS5329/ArcherMSAExcessContriPrYrAmt");
			String archerMSAExcessContriCreditAmt = extractTargetFieldValue(formData, "/IRS5329/ArcherMSAExcessContriCreditAmt");
			String taxableArcherMSADistriAmt = extractTargetFieldValue(formData, "/IRS5329/TaxableArcherMSADistriAmt");
			String archerMSAExcessContriCYAmt = extractTargetFieldValue(formData, "/IRS5329/ArcherMSAExcessContriCYAmt");
			String HSAExcessContriPriorYearAmt = extractTargetFieldValue(formData, "/IRS5329/HSAExcessContriPriorYearAmt");
			String HSAExcessContriCreditAmt = extractTargetFieldValue(formData, "/IRS5329/HSAExcessContriCreditAmt");
			String taxableHSADistributionAmt = extractTargetFieldValue(formData, "/IRS5329/TaxableHSADistributionAmt");
			String HSAExcessContriCurrentYearAmt = extractTargetFieldValue(formData, "/IRS5329/HSAExcessContriCurrentYearAmt");
			String ABLEExcessContriCYAmt = extractTargetFieldValue(formData, "/IRS5329/ABLEExcessContriCYAmt");

			// adding the fields to the fieldMappings for the Primary
			addFieldMapping(fieldMappings, "/IRS5329/EarlyDistributionsAmt", "RET.TEARLY", earlyDistributionsAmt);
			addFieldMapping(fieldMappings, "/IRS5329/EarlyDistriExceptionReasonCd", "RET.TXNUM", earlyDistriExceptionReasonCd);
			addFieldMapping(fieldMappings, "/IRS5329/EarlyDistriNotSubjectToTaxAmt", "RET.TADLTAX", earlyDistriNotSubjectToTaxAmt);
			addFieldMapping(fieldMappings, "/IRS5329/EducAcctDistriNotSubjToTaxAmt", "RET.TEDEXCEPT", educAcctDistriNotSubjToTaxAmt);
			addFieldMapping(fieldMappings, "/IRS5329/IRAExcessContriPriorYearAmt", "X127.314.1", IRAExcessContriPriorYearAmt);
			addFieldMapping(fieldMappings, "/IRS5329/IRAExcessContriCreditAmt", "RET.TCONTCRED", IRAExcessContriCreditAmt);
			addFieldMapping(fieldMappings, "/IRS5329/IRADistriIncludedInIncomeAmt", "RET.TIRA", IRADistriIncludedInIncomeAmt);
			addFieldMapping(fieldMappings, "/IRS5329/IRAExcessContriWithdrawnAmt", "RET.TWITHD", IRAExcessContriWithdrawnAmt);

			addFieldMapping(fieldMappings, "/IRS5329/IRAExcessContriCurrentYearAmt", "RET.TXCSCONTOVR", IRAExcessContriCurrentYearAmt);
			addFieldMapping(fieldMappings, "/IRS5329/RothIRAExcessContriPriorYrAmt", "X127.314.3", rothIRAExcessContriPriorYrAmt);
			addFieldMapping(fieldMappings, "/IRS5329/RothIRAExcessContriCreditAmt", "X127.315.3", rothIRAExcessContriCreditAmt);
			addFieldMapping(fieldMappings, "/IRS5329/RothIRAExcessContriCYAmt", "X127.302.15", rothIRAExcessContriCYAmt);
			addFieldMapping(fieldMappings, "/IRS5329/ESAExcessContriPriorYearAmt", "X127.314.5", ESAExcessContriPriorYearAmt);
			addFieldMapping(fieldMappings, "/IRS5329/ESAExcessContriCreditAmt", "X127.315.11", ESAExcessContriCreditAmt);
			addFieldMapping(fieldMappings, "/IRS5329/ESAExcessContriCYAmt", "X127.302.17", ESAExcessContriCYAmt);

			addFieldMapping(fieldMappings, "/IRS5329/ArcherMSAExcessContriPrYrAmt", "X127.314.7", archerMSAExcessContriPrYrAmt);
			addFieldMapping(fieldMappings, "/IRS5329/ArcherMSAExcessContriCreditAmt", "X127.302.25", archerMSAExcessContriCreditAmt);
			addFieldMapping(fieldMappings, "/IRS5329/TaxableArcherMSADistriAmt", "X127.302.27", taxableArcherMSADistriAmt);
			addFieldMapping(fieldMappings, "/IRS5329/ArcherMSAExcessContriCYAmt", "RET.TMRDIST", archerMSAExcessContriCYAmt);
			addFieldMapping(fieldMappings, "/IRS5329/HSAExcessContriPriorYearAmt", "X127.HSAPYT", HSAExcessContriPriorYearAmt);
			addFieldMapping(fieldMappings, "/IRS5329/HSAExcessContriCreditAmt", "X127.HSACRT", HSAExcessContriCreditAmt);
			addFieldMapping(fieldMappings, "/IRS5329/TaxableHSADistributionAmt", "X127.HSADISTT", taxableHSADistributionAmt);
			addFieldMapping(fieldMappings, "/IRS5329/HSAExcessContriCurrentYearAmt", "X127.HSAT", HSAExcessContriCurrentYearAmt);
			addFieldMapping(fieldMappings, "/IRS5329/ABLEExcessContriCYAmt", "ABLEOT1", ABLEExcessContriCYAmt);

			
        } else if (Objects.equals(ssn, secondaryTIN)) {
        	
        	// extracting the per return value txt from these sourceFields of the spouse
			String earlyDistributionsAmt = extractTargetFieldValue(formData, "/IRS5329/EarlyDistributionsAmt");
			String earlyDistriExceptionReasonCd = extractTargetFieldValue(formData, "/IRS5329/EarlyDistriExceptionReasonCd");
			String earlyDistriNotSubjectToTaxAmt = extractTargetFieldValue(formData, "/IRS5329/EarlyDistriNotSubjectToTaxAmt");
			String educAcctDistriNotSubjToTaxAmt = extractTargetFieldValue(formData, "/IRS5329/EducAcctDistriNotSubjToTaxAmt");
			String IRAExcessContriPriorYearAmt = extractTargetFieldValue(formData, "/IRS5329/IRAExcessContriPriorYearAmt");
			String IRAExcessContriCreditAmt = extractTargetFieldValue(formData, "/IRS5329/IRAExcessContriCreditAmt");
			String IRADistriIncludedInIncomeAmt = extractTargetFieldValue(formData, "/IRS5329/IRADistriIncludedInIncomeAmt");
			String IRAExcessContriWithdrawnAmt = extractTargetFieldValue(formData, "/IRS5329/IRAExcessContriWithdrawnAmt");

			String IRAExcessContriCurrentYearAmt = extractTargetFieldValue(formData, "/IRS5329/IRAExcessContriCurrentYearAmt");
			String rothIRAExcessContriPriorYrAmt = extractTargetFieldValue(formData, "/IRS5329/RothIRAExcessContriPriorYrAmt");
			String rothIRAExcessContriCreditAmt = extractTargetFieldValue(formData, "/IRS5329/RothIRAExcessContriCreditAmt");
			String rothIRAExcessContriCYAmt = extractTargetFieldValue(formData, "/IRS5329/RothIRAExcessContriCYAmt");
			String ESAExcessContriPriorYearAmt = extractTargetFieldValue(formData, "/IRS5329/ESAExcessContriPriorYearAmt");
			String ESAExcessContriCreditAmt = extractTargetFieldValue(formData, "/IRS5329/ESAExcessContriCreditAmt");
			String ESAExcessContriCYAmt = extractTargetFieldValue(formData, "/IRS5329/ESAExcessContriCYAmt");

			String archerMSAExcessContriPrYrAmt = extractTargetFieldValue(formData, "/IRS5329/ArcherMSAExcessContriPrYrAmt");
			String archerMSAExcessContriCreditAmt = extractTargetFieldValue(formData, "/IRS5329/ArcherMSAExcessContriCreditAmt");
			String taxableArcherMSADistriAmt = extractTargetFieldValue(formData, "/IRS5329/TaxableArcherMSADistriAmt");
			String archerMSAExcessContriCYAmt = extractTargetFieldValue(formData, "/IRS5329/ArcherMSAExcessContriCYAmt");
			String HSAExcessContriPriorYearAmt = extractTargetFieldValue(formData, "/IRS5329/HSAExcessContriPriorYearAmt");
			String HSAExcessContriCreditAmt = extractTargetFieldValue(formData, "/IRS5329/HSAExcessContriCreditAmt");
			String taxableHSADistributionAmt = extractTargetFieldValue(formData, "/IRS5329/TaxableHSADistributionAmt");
			String HSAExcessContriCurrentYearAmt = extractTargetFieldValue(formData, "/IRS5329/HSAExcessContriCurrentYearAmt");
			String ABLEExcessContriCYAmt = extractTargetFieldValue(formData, "/IRS5329/ABLEExcessContriCYAmt");

			addFieldMapping(fieldMappings, "/IRS5329/EarlyDistributionsAmt", "RET.SEARLY", earlyDistributionsAmt);
			addFieldMapping(fieldMappings, "/IRS5329/EarlyDistriExceptionReasonCd", "RET.SXNUM", earlyDistriExceptionReasonCd);
			addFieldMapping(fieldMappings, "/IRS5329/EarlyDistriNotSubjectToTaxAmt", "RET.SADLTAX", earlyDistriNotSubjectToTaxAmt);
			addFieldMapping(fieldMappings, "/IRS5329/EducAcctDistriNotSubjToTaxAmt", "RET.SEDEXCEPT", educAcctDistriNotSubjToTaxAmt);
			addFieldMapping(fieldMappings, "/IRS5329/IRAExcessContriPriorYearAmt", "X127.314.2", IRAExcessContriPriorYearAmt);
			addFieldMapping(fieldMappings, "/IRS5329/IRAExcessContriCreditAmt", "RET.SCONTCRED", IRAExcessContriCreditAmt);
			addFieldMapping(fieldMappings, "/IRS5329/IRADistriIncludedInIncomeAmt", "RET.SIRA", IRADistriIncludedInIncomeAmt);
			addFieldMapping(fieldMappings, "/IRS5329/IRAExcessContriWithdrawnAmt", "RET.SWITHD", IRAExcessContriWithdrawnAmt);
			addFieldMapping(fieldMappings, "/IRS5329/IRAExcessContriCurrentYearAmt", "RET.SXCSCONTOVR", IRAExcessContriCurrentYearAmt);
			addFieldMapping(fieldMappings, "/IRS5329/RothIRAExcessContriPriorYrAmt", "X127.314.4", rothIRAExcessContriPriorYrAmt);
			addFieldMapping(fieldMappings, "/IRS5329/RothIRAExcessContriCreditAmt", "X127.315.4", rothIRAExcessContriCreditAmt);
			addFieldMapping(fieldMappings, "/IRS5329/RothIRAExcessContriCYAmt", "X127.302.16", rothIRAExcessContriCYAmt);
			addFieldMapping(fieldMappings, "/IRS5329/ESAExcessContriPriorYearAmt", "X127.314.6", ESAExcessContriPriorYearAmt);
			addFieldMapping(fieldMappings, "/IRS5329/ESAExcessContriCreditAmt", "X127.315.12", ESAExcessContriCreditAmt);
			addFieldMapping(fieldMappings, "/IRS5329/ESAExcessContriCYAmt", "X127.302.18", ESAExcessContriCYAmt);
			addFieldMapping(fieldMappings, "/IRS5329/ArcherMSAExcessContriPrYrAmt", "X127.314.8", archerMSAExcessContriPrYrAmt);
			addFieldMapping(fieldMappings, "/IRS5329/ArcherMSAExcessContriCreditAmt", "X127.302.26", archerMSAExcessContriCreditAmt);
			addFieldMapping(fieldMappings, "/IRS5329/TaxableArcherMSADistriAmt", "X127.302.28", taxableArcherMSADistriAmt);
			addFieldMapping(fieldMappings, "/IRS5329/ArcherMSAExcessContriCYAmt", "RET.SMRDIST", archerMSAExcessContriCYAmt);
			addFieldMapping(fieldMappings, "/IRS5329/HSAExcessContriPriorYearAmt", "X127.HSAPYS", HSAExcessContriPriorYearAmt);
			addFieldMapping(fieldMappings, "/IRS5329/HSAExcessContriCreditAmt", "X127.HSACRS", HSAExcessContriCreditAmt);
			addFieldMapping(fieldMappings, "/IRS5329/TaxableHSADistributionAmt", "X127.HSADISTS", taxableHSADistributionAmt);
			addFieldMapping(fieldMappings, "/IRS5329/HSAExcessContriCurrentYearAmt", "X127.HSAS", HSAExcessContriCurrentYearAmt);
			addFieldMapping(fieldMappings, "/IRS5329/ABLEExcessContriCYAmt", "ABLEOS1", ABLEExcessContriCYAmt);
			
        } else {
            log.warn("SSN does not match primaryTIN or spouseTIN. Returning empty field mappings.");
        }
        
        return fieldMappings;
    }
    
    @SuppressWarnings("unchecked")
	private String extractTargetFieldValue(Map<String, Object> formData, String sourceField) {
		List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
		if (lineItems == null) {
			log.warn("No lineItems found in formData");
			return null;
		}

		for (Map<String, Object> lineItem : lineItems) {
			if (sourceField.equals(lineItem.get(LINE_NAME_TXT))) {
				String returnValue = (String) lineItem.get(PER_RETURN_VALUE_TXT);
				if (returnValue == null || returnValue.isEmpty()) {
					log.warn("return value is null or empty");
					return null;
				}
				return returnValue;
			}
		}
		return "";
	}
    
    private String extractSSN(Map<String, Object> formData) {
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
        if (lineItems == null) {
            log.warn("No lineItems found in formData");
            return null;
        }

        for (Map<String, Object> lineItem : lineItems) {
            if ("/IRS5329/SSN".equals(lineItem.get(LINE_NAME_TXT))) {
                String ssn = (String) lineItem.get(PER_RETURN_VALUE_TXT);
                if (ssn == null || ssn.isEmpty()) {
                    log.warn("SSN found but value is null or empty");
                    return null;
                }
                return ssn;
            }
        }

        log.warn("No line item with lineNameTxt '/IRS5329/SSN' found");
        return null;
    }
    
    private void addFieldMapping(List<FieldMapping> mappings, String sourceField, String targetField, String targetFieldValue) {
        FieldMapping mapping = new FieldMapping();
        mapping.setSourceForm(IRS5329);
        mapping.setSourceField(sourceField);
        mapping.setTargetField(targetField);
        mapping.setTargetFieldValue(targetFieldValue);
        mappings.add(mapping);
    }
    
   
}