package gov.irs.jios.common.client.tr.pojo;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@ConfigurationProperties(prefix = "dmi")
@Data
public class DMIConfig {
	private String server;


}