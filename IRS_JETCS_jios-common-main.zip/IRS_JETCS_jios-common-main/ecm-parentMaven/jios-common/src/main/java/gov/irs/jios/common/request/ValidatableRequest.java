package gov.irs.jios.common.request;

import java.util.Map;

public interface ValidatableRequest {
	Map<String, Object> getHeader();
	void setHeader(Map<String, Object> header);
	Map<String, Object> getBody();
	void setBody(Map<String, Object> body);
}
