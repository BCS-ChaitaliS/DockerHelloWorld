package gov.irs.jios.common.util;

import java.math.BigDecimal;

import org.apache.commons.lang3.ObjectUtils;

public class CommonUtil {

    private static final int TAX_PERIOD_LENGTH = 6;
    private static final int MIN_VALID_YEAR = 1900;
    private static final int MAX_VALID_YEAR = 2100;

    private CommonUtil() {
        // Private constructor to prevent instantiation
    }

    /**
     * Extracts the tax year from a tax period string.
     * 
     * @param taxPrd The tax period in YYYYMM format
     * @return The extracted tax year
     * @throws IllegalArgumentException if the tax period is invalid
     */
    public static String extractTaxYear(String taxPrd) {
        if (taxPrd == null || taxPrd.length() != TAX_PERIOD_LENGTH) {
            throw new IllegalArgumentException("Invalid tax period. Expected format: YYYYMM");
        }

        String taxYear = taxPrd.substring(0, 4);
        try {
            int year = Integer.parseInt(taxYear);
            if (year < MIN_VALID_YEAR || year > MAX_VALID_YEAR) {
                throw new IllegalArgumentException("Invalid tax year: " + taxYear);
            }
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Unable to parse tax year from tax period: " + taxPrd, e);
        }

        return taxYear;
    }

    /**
     * Validates if the given tax period is in the correct format and represents a valid year.
     * 
     * @param taxPrd The tax period to validate
     * @return true if the tax period is valid, false otherwise
     */
    public static boolean isValidTaxPeriod(String taxPrd) {
        try {
            extractTaxYear(taxPrd);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
    
    public static boolean isEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }
    
    public static boolean isNumeric(String str) {
	    if (str == null) {
	        return false;
	    }
	    try {
	        Double.parseDouble(str);
	        return true;
	    } catch (NumberFormatException e) {
	        return false;
	    }
	}
    
    public static boolean isNonEmptyNonNumeric(String str) {
	    if (str == null || str.trim().length() == 0) {
	        return false;
	    }
	    try {
	        Double.parseDouble(str);
	        return false;
	    } catch (NumberFormatException e) {
	        return true;
	    }
	}
    
    public static String addTwoNumbers(String str1, String str2) {
	    if (str1 == null || str1 == null) {
	        return "";
	    }
	    try {
	    	BigDecimal value = new BigDecimal(str1).add(new BigDecimal(str2));
	    	if (value == null || value.compareTo(BigDecimal.ZERO) == 0) {
	            return "";
	        }
	        return value.toPlainString();
	    } catch (NumberFormatException e) {
	        return "";
	    }
	}
    
    public static String formatTIN(String originalTin) {
        if (originalTin == null || originalTin.length() != 9) {
            return originalTin; // Return original if invalid
        }
        
        return String.format("%s-%s-%s", 
            originalTin.substring(0, 3),
            originalTin.substring(3, 5),
            originalTin.substring(5, 9));
    }
    
    public static BigDecimal safeBigDecimal(String value) {
        return new BigDecimal(ObjectUtils.isNotEmpty(value) ? value : "0");
    }
}