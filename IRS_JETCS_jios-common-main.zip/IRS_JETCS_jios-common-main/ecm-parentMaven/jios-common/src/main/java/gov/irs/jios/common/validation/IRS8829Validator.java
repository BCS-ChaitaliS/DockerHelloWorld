package gov.irs.jios.common.validation;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import gov.irs.jios.common.client.tr.service.ErrorTransformationService;
import gov.irs.jios.common.ecm.pojo.ErrorResponse;
import gov.irs.jios.common.exception.ValidationException;
import gov.irs.jios.common.request.ValidatableRequest;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class IRS8829Validator implements FormValidator {
    
    private static final String FORM_IRS8829 = "IRS8829";
    private static final String FORM_IRS1040_SCHEDULE_C = "IRS1040ScheduleC";
    
    @Override
    @SuppressWarnings("unchecked")
    public void validateRequest(ValidatableRequest request, ErrorTransformationService errorTransformationService) {
        Map<String, Object> body = request.getBody();
        List<Map<String, Object>> forms = (List<Map<String, Object>>) body.get("forms");
        
        if (forms == null) {
            return;
        }
        
        boolean hasIRS8829 = false;
        int scheduleCount = 0;
        
        // Count the forms
        for (Map<String, Object> form : forms) {
            String formNum = (String) form.get("formNum");
            if (FORM_IRS8829.equals(formNum)) {
                hasIRS8829 = true;
            } else if (FORM_IRS1040_SCHEDULE_C.equals(formNum)) {
                scheduleCount++;
            }
        }
        
        // Validate the combination
        if (hasIRS8829 && scheduleCount > 1) {
            String details = "Input contains form 8829 along with more than one ScheduleC form which is not currently supported!";
            ErrorResponse errorResponse = errorTransformationService.createServerErrorResponse(
                request.getHeader(),
                "Form Validation Error",
                details
            );
            throw new ValidationException(errorResponse);
        }
    }
}