package gov.irs.jios.common.client.transformer;

import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

/**
 * Author: Kaiwen Tsou
 **/

@Slf4j
public class CountryNameToCountryCodeTransformer {

	private static final Map<String, String> ECM_TO_TR_MAP;

	static {
		ECM_TO_TR_MAP = new HashMap<>();
		initializeMap();
	}

	/**
	 * NOTE- Use the Python Script on the Sharepoint to regenerate this list if there are any problems.
	 * Also, the British Territory of Gibraltar is not mapped by TR. Every other country is.
	 */
	private static void initializeMap() {
		ECM_TO_TR_MAP.put("AF", "2");
		ECM_TO_TR_MAP.put("AX", "288");
		ECM_TO_TR_MAP.put("AL", "3");
		ECM_TO_TR_MAP.put("AG", "4");
		ECM_TO_TR_MAP.put("AQ", "18");
		ECM_TO_TR_MAP.put("AN", "6");
		ECM_TO_TR_MAP.put("AO", "7");
		ECM_TO_TR_MAP.put("AV", "8");
		ECM_TO_TR_MAP.put("AY", "9");
		ECM_TO_TR_MAP.put("AC", "10");
		ECM_TO_TR_MAP.put("AR", "11");
		ECM_TO_TR_MAP.put("AM", "12");
		ECM_TO_TR_MAP.put("AA", "13");
		ECM_TO_TR_MAP.put("AT", "14");
		ECM_TO_TR_MAP.put("AS", "15");
		ECM_TO_TR_MAP.put("AU", "16");
		ECM_TO_TR_MAP.put("AJ", "17");
		ECM_TO_TR_MAP.put("BF", "19");
		ECM_TO_TR_MAP.put("BA", "20");
		ECM_TO_TR_MAP.put("FQ", "21");
		ECM_TO_TR_MAP.put("BG", "23");
		ECM_TO_TR_MAP.put("BB", "24");
		ECM_TO_TR_MAP.put("BO", "26");
		ECM_TO_TR_MAP.put("BE", "27");
		ECM_TO_TR_MAP.put("BH", "28");
		ECM_TO_TR_MAP.put("BN", "29");
		ECM_TO_TR_MAP.put("BD", "30");
		ECM_TO_TR_MAP.put("BT", "31");
		ECM_TO_TR_MAP.put("BL", "32");
		ECM_TO_TR_MAP.put("BK", "34");
		ECM_TO_TR_MAP.put("BC", "35");
		ECM_TO_TR_MAP.put("BV", "36");
		ECM_TO_TR_MAP.put("BR", "37");
		ECM_TO_TR_MAP.put("IO", "38");
		ECM_TO_TR_MAP.put("VI", "267");
		ECM_TO_TR_MAP.put("BX", "39");
		ECM_TO_TR_MAP.put("BU", "40");
		ECM_TO_TR_MAP.put("UV", "41");
		ECM_TO_TR_MAP.put("BM", "42");
		ECM_TO_TR_MAP.put("BY", "43");
		ECM_TO_TR_MAP.put("CB", "44");
		ECM_TO_TR_MAP.put("CM", "45");
		ECM_TO_TR_MAP.put("CA", "46");
		ECM_TO_TR_MAP.put("CV", "48");
		ECM_TO_TR_MAP.put("CJ", "49");
		ECM_TO_TR_MAP.put("CT", "50");
		ECM_TO_TR_MAP.put("CD", "51");
		ECM_TO_TR_MAP.put("CI", "52");
		ECM_TO_TR_MAP.put("CH", "53");
		ECM_TO_TR_MAP.put("KT", "54");
		ECM_TO_TR_MAP.put("IP", "55");
		ECM_TO_TR_MAP.put("CK", "56");
		ECM_TO_TR_MAP.put("CO", "57");
		ECM_TO_TR_MAP.put("CN", "58");
		ECM_TO_TR_MAP.put("CF", "59");
		ECM_TO_TR_MAP.put("CG", "60");
		ECM_TO_TR_MAP.put("CW", "61");
		ECM_TO_TR_MAP.put("CR", "62");
		ECM_TO_TR_MAP.put("CS", "64");
		ECM_TO_TR_MAP.put("IV", "65");
		ECM_TO_TR_MAP.put("HR", "66");
		ECM_TO_TR_MAP.put("CU", "67");
		ECM_TO_TR_MAP.put("UC", "68");
		ECM_TO_TR_MAP.put("CY", "69");
		ECM_TO_TR_MAP.put("EZ", "70");
		ECM_TO_TR_MAP.put("DA", "71");
		ECM_TO_TR_MAP.put("DX", "300");
		ECM_TO_TR_MAP.put("DJ", "72");
		ECM_TO_TR_MAP.put("DO", "73");
		ECM_TO_TR_MAP.put("DR", "74");
		ECM_TO_TR_MAP.put("TT", "309");
		ECM_TO_TR_MAP.put("EC", "76");
		ECM_TO_TR_MAP.put("EG", "77");
		ECM_TO_TR_MAP.put("ES", "79");
		ECM_TO_TR_MAP.put("EK", "80");
		ECM_TO_TR_MAP.put("ER", "81");
		ECM_TO_TR_MAP.put("EN", "82");
		ECM_TO_TR_MAP.put("ET", "83");
		ECM_TO_TR_MAP.put("FK", "85");
		ECM_TO_TR_MAP.put("FO", "86");
		ECM_TO_TR_MAP.put("FM", "166");
		ECM_TO_TR_MAP.put("FJ", "87");
		ECM_TO_TR_MAP.put("FI", "88");
		ECM_TO_TR_MAP.put("FR", "89");
		ECM_TO_TR_MAP.put("FP", "91");
		ECM_TO_TR_MAP.put("FS", "92");
		ECM_TO_TR_MAP.put("GB", "93");
		ECM_TO_TR_MAP.put("GA", "94");
		ECM_TO_TR_MAP.put("GG", "96");
		ECM_TO_TR_MAP.put("GM", "97");
		ECM_TO_TR_MAP.put("GH", "98");
		ECM_TO_TR_MAP.put("GR", "102");
		ECM_TO_TR_MAP.put("GL", "103");
		ECM_TO_TR_MAP.put("GJ", "104");
		ECM_TO_TR_MAP.put("GQ", "106");
		ECM_TO_TR_MAP.put("GT", "107");
		ECM_TO_TR_MAP.put("GK", "108");
		ECM_TO_TR_MAP.put("GV", "109");
		ECM_TO_TR_MAP.put("PU", "110");
		ECM_TO_TR_MAP.put("GY", "111");
		ECM_TO_TR_MAP.put("HA", "112");
		ECM_TO_TR_MAP.put("HM", "113");
		ECM_TO_TR_MAP.put("VT", "290");
		ECM_TO_TR_MAP.put("HO", "114");
		ECM_TO_TR_MAP.put("HK", "115");
		ECM_TO_TR_MAP.put("HQ", "116");
		ECM_TO_TR_MAP.put("HU", "117");
		ECM_TO_TR_MAP.put("IC", "118");
		ECM_TO_TR_MAP.put("IN", "119");
		ECM_TO_TR_MAP.put("ID", "120");
		ECM_TO_TR_MAP.put("IR", "121");
		ECM_TO_TR_MAP.put("IZ", "122");
		ECM_TO_TR_MAP.put("EI", "123");
		ECM_TO_TR_MAP.put("IS", "125");
		ECM_TO_TR_MAP.put("IT", "126");
		ECM_TO_TR_MAP.put("JM", "127");
		ECM_TO_TR_MAP.put("JN", "128");
		ECM_TO_TR_MAP.put("JA", "129");
		ECM_TO_TR_MAP.put("DQ", "281");
		ECM_TO_TR_MAP.put("JE", "130");
		ECM_TO_TR_MAP.put("JQ", "131");
		ECM_TO_TR_MAP.put("JO", "132");
		ECM_TO_TR_MAP.put("KZ", "134");
		ECM_TO_TR_MAP.put("KE", "135");
		ECM_TO_TR_MAP.put("KQ", "136");
		ECM_TO_TR_MAP.put("KR", "137");
		ECM_TO_TR_MAP.put("KN", "138");
		ECM_TO_TR_MAP.put("KS", "139");
		ECM_TO_TR_MAP.put("KV", "282");
		ECM_TO_TR_MAP.put("KU", "141");
		ECM_TO_TR_MAP.put("KG", "142");
		ECM_TO_TR_MAP.put("LA", "143");
		ECM_TO_TR_MAP.put("LG", "144");
		ECM_TO_TR_MAP.put("LE", "145");
		ECM_TO_TR_MAP.put("LT", "146");
		ECM_TO_TR_MAP.put("LI", "147");
		ECM_TO_TR_MAP.put("LY", "148");
		ECM_TO_TR_MAP.put("LS", "149");
		ECM_TO_TR_MAP.put("LH", "150");
		ECM_TO_TR_MAP.put("LU", "151");
		ECM_TO_TR_MAP.put("MC", "152");
		ECM_TO_TR_MAP.put("MK", "153");
		ECM_TO_TR_MAP.put("MA", "154");
		ECM_TO_TR_MAP.put("MI", "155");
		ECM_TO_TR_MAP.put("MY", "156");
		ECM_TO_TR_MAP.put("MV", "157");
		ECM_TO_TR_MAP.put("ML", "158");
		ECM_TO_TR_MAP.put("MT", "159");
		ECM_TO_TR_MAP.put("IM", "124");
		ECM_TO_TR_MAP.put("RM", "160");
		ECM_TO_TR_MAP.put("MR", "162");
		ECM_TO_TR_MAP.put("MP", "163");
		ECM_TO_TR_MAP.put("MX", "165");
		ECM_TO_TR_MAP.put("MQ", "167");
		ECM_TO_TR_MAP.put("MD", "168");
		ECM_TO_TR_MAP.put("MN", "169");
		ECM_TO_TR_MAP.put("MG", "170");
		ECM_TO_TR_MAP.put("MJ", "171");
		ECM_TO_TR_MAP.put("MH", "172");
		ECM_TO_TR_MAP.put("MO", "173");
		ECM_TO_TR_MAP.put("MZ", "174");
		ECM_TO_TR_MAP.put("WA", "175");
		ECM_TO_TR_MAP.put("NR", "176");
		ECM_TO_TR_MAP.put("BQ", "177");
		ECM_TO_TR_MAP.put("NP", "178");
		ECM_TO_TR_MAP.put("NL", "179");
		ECM_TO_TR_MAP.put("NC", "181");
		ECM_TO_TR_MAP.put("NZ", "182");
		ECM_TO_TR_MAP.put("NU", "183");
		ECM_TO_TR_MAP.put("NG", "184");
		ECM_TO_TR_MAP.put("NI", "185");
		ECM_TO_TR_MAP.put("NE", "186");
		ECM_TO_TR_MAP.put("NF", "187");
		ECM_TO_TR_MAP.put("CQ", "189");
		ECM_TO_TR_MAP.put("NO", "190");
		ECM_TO_TR_MAP.put("MU", "191");
		ECM_TO_TR_MAP.put("OC", "278");
		ECM_TO_TR_MAP.put("PK", "192");
		ECM_TO_TR_MAP.put("PS", "193");
		ECM_TO_TR_MAP.put("LQ", "194");
		ECM_TO_TR_MAP.put("PM", "195");
		ECM_TO_TR_MAP.put("PP", "196");
		ECM_TO_TR_MAP.put("PF", "197");
		ECM_TO_TR_MAP.put("PA", "198");
		ECM_TO_TR_MAP.put("PE", "199");
		ECM_TO_TR_MAP.put("RP", "200");
		ECM_TO_TR_MAP.put("PC", "201");
		ECM_TO_TR_MAP.put("PL", "202");
		ECM_TO_TR_MAP.put("PO", "203");
		ECM_TO_TR_MAP.put("RQ", "204");
		ECM_TO_TR_MAP.put("QA", "205");
		ECM_TO_TR_MAP.put("RO", "208");
		ECM_TO_TR_MAP.put("RS", "209");
		ECM_TO_TR_MAP.put("RW", "210");
		ECM_TO_TR_MAP.put("TB", "302");
		ECM_TO_TR_MAP.put("RN", "303");
		ECM_TO_TR_MAP.put("WS", "286");
		ECM_TO_TR_MAP.put("SM", "217");
		ECM_TO_TR_MAP.put("TP", "218");
		ECM_TO_TR_MAP.put("SA", "220");
		ECM_TO_TR_MAP.put("SG", "221");
		ECM_TO_TR_MAP.put("RI", "222");
		ECM_TO_TR_MAP.put("SE", "223");
		ECM_TO_TR_MAP.put("SL", "224");
		ECM_TO_TR_MAP.put("SN", "225");
		ECM_TO_TR_MAP.put("NN", "219");
		ECM_TO_TR_MAP.put("LO", "226");
		ECM_TO_TR_MAP.put("SI", "227");
		ECM_TO_TR_MAP.put("BP", "228");
		ECM_TO_TR_MAP.put("SO", "229");
		ECM_TO_TR_MAP.put("SF", "230");
		ECM_TO_TR_MAP.put("SX", "231");
		ECM_TO_TR_MAP.put("OD", "211");
		ECM_TO_TR_MAP.put("SP", "232");
		ECM_TO_TR_MAP.put("PG", "233");
		ECM_TO_TR_MAP.put("CE", "234");
		ECM_TO_TR_MAP.put("SH", "212");
		ECM_TO_TR_MAP.put("SC", "213");
		ECM_TO_TR_MAP.put("ST", "214");
		ECM_TO_TR_MAP.put("SB", "215");
		ECM_TO_TR_MAP.put("VC", "216");
		ECM_TO_TR_MAP.put("SU", "235");
		ECM_TO_TR_MAP.put("NS", "236");
		ECM_TO_TR_MAP.put("SV", "237");
		ECM_TO_TR_MAP.put("WZ", "238");
		ECM_TO_TR_MAP.put("SW", "239");
		ECM_TO_TR_MAP.put("SZ", "240");
		ECM_TO_TR_MAP.put("SY", "241");
		ECM_TO_TR_MAP.put("TW", "242");
		ECM_TO_TR_MAP.put("TI", "243");
		ECM_TO_TR_MAP.put("TZ", "244");
		ECM_TO_TR_MAP.put("TH", "245");
		ECM_TO_TR_MAP.put("TO", "246");
		ECM_TO_TR_MAP.put("TL", "247");
		ECM_TO_TR_MAP.put("TN", "248");
		ECM_TO_TR_MAP.put("TD", "250");
		ECM_TO_TR_MAP.put("TS", "252");
		ECM_TO_TR_MAP.put("TU", "253");
		ECM_TO_TR_MAP.put("TX", "254");
		ECM_TO_TR_MAP.put("TK", "255");
		ECM_TO_TR_MAP.put("TV", "256");
		ECM_TO_TR_MAP.put("UG", "257");
		ECM_TO_TR_MAP.put("UP", "258");
		ECM_TO_TR_MAP.put("US", "280");
		ECM_TO_TR_MAP.put("AE", "259");
		ECM_TO_TR_MAP.put("UK", "260");
		ECM_TO_TR_MAP.put("UY", "261");
		ECM_TO_TR_MAP.put("UZ", "262");
		ECM_TO_TR_MAP.put("NH", "263");
		ECM_TO_TR_MAP.put("VE", "265");
		ECM_TO_TR_MAP.put("VM", "266");
		ECM_TO_TR_MAP.put("VQ", "268");
		ECM_TO_TR_MAP.put("WQ", "269");
		ECM_TO_TR_MAP.put("WF", "270");
		ECM_TO_TR_MAP.put("WI", "272");
		ECM_TO_TR_MAP.put("YM", "274");
		ECM_TO_TR_MAP.put("ZA", "276");
		ECM_TO_TR_MAP.put("ZI", "277");
	}

	public String transformEcmToTr(String ecmFilingCountryName) {
		try {
			String trCountryCode = ECM_TO_TR_MAP.get(ecmFilingCountryName);
			if (trCountryCode == null) {
				throw new IllegalArgumentException("Invalid ECM filing country name : " + ecmFilingCountryName);
			}
			return trCountryCode;
		} catch (Exception e) {
			log.warn("CountryNameToCountryCodeTransformer ecm to tr: {}", e.getMessage());
			return "";
		}
	}

}