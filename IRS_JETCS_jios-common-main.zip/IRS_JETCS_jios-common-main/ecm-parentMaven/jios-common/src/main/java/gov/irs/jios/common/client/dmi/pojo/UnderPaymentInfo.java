package gov.irs.jios.common.client.dmi.pojo;
import lombok.Data;

@Data
public class UnderPaymentInfo {
	
	private String agreedExcl6662AAmt;
	private String agreedNoPenaltyAmt;
    private String agreed20PctAmt;
    private String agreed40PctAmt;
    private String agreed75PctAmt;
    private String agreed6662AAmt;
    private String totalExcl6662AAmt;
    private String totalNoPenaltyAmt;
    private String total20PctAmt;
    private String total40PctAmt;
    private String total75PctAmt;
    private String total6662AAmt;
}
