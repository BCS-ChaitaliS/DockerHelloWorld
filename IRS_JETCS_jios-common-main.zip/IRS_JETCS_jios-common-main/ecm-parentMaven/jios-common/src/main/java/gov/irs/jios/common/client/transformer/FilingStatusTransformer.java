package gov.irs.jios.common.client.transformer;

import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;

public class FilingStatusTransformer {

    private static final BiMap<String, String> FILING_STATUS_MAP = ImmutableBiMap.of(
        "1", "X",  // Single
        "2", "B",  // Married Filing Jointly
        "3", "C",  // Married Filing Separately
        "4", "D",  // Head of Household
        "5", "E"   // Qualifying Widow(er)
    );

    public String transformEcmToTr(String ecmFilingStatus) {
        String trStatus = FILING_STATUS_MAP.get(ecmFilingStatus);
        if (trStatus == null) {
            throw new IllegalArgumentException("Invalid ECM filing status code: " + ecmFilingStatus);
        }
        return trStatus;
    }

    public String transformTrToEcm(String trFilingStatus) {
        String ecmStatus = FILING_STATUS_MAP.inverse().get(trFilingStatus != null ? trFilingStatus.toUpperCase() : "");
        if (ecmStatus == null) {
            throw new IllegalArgumentException("Invalid TR filing status code: " + trFilingStatus);
        }
        return ecmStatus;
    }
}
