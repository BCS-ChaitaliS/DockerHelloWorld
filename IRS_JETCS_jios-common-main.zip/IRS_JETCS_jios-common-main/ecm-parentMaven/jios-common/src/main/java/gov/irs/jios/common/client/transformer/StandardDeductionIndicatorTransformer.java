package gov.irs.jios.common.client.transformer;
import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;
import lombok.extern.slf4j.Slf4j;
@Slf4j
public class StandardDeductionIndicatorTransformer {
	private static final BiMap<String, String> STD_DED_IND_MAP = ImmutableBiMap.of("X", "B", // force itemized
																								// deductions
			"", "A" // force std ded amt
	);
	public String transformEcmToTr(String ecmStdDedIndicator) {
		String trStatus = STD_DED_IND_MAP.get(ecmStdDedIndicator);
		if (trStatus == null) {
			log.warn("Invalid ECM Standard Deduction Indicator code: " + ecmStdDedIndicator);
			return "";
		}
		return trStatus;
	}
	public String transformTrToECM(String trStdDedIndicator) {
		String ecmStatus = STD_DED_IND_MAP.inverse()
				.get(trStdDedIndicator != null ? trStdDedIndicator.toUpperCase() : "");
		if (ecmStatus == null) {
			log.warn("Invalid TR Standard Deduction Indicator code: " + trStdDedIndicator);
			return "";
		}
		return ecmStatus;
	}
}
