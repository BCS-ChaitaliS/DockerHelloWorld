package gov.irs.jios.common.client.tr.service;

import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PARTIAL;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_SEPARATOR;
import static gov.irs.jios.common.util.JiosCommonConstants.SECOND_CALL_FOR_PARTIAL_TAX_CALC;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.irs.jios.common.client.tr.pojo.RetrieveFieldsResponseDTO;
import gov.irs.jios.common.request.ValidatableRequest;
import gov.irs.jios.common.request.ValidatableRequestFactory;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class VarianceAnalysisService {
	
	@Autowired
    private AuthLocatorService authLocatorService;
    
    @Autowired
    private PingTokenService pingTokenService;
    
    @Autowired
    private OpenSessionService openSessionService;
    
    @Autowired
    private SaveFieldsService saveFieldsService;
    
    @Autowired
    private RetrieveFieldsService retrieveFieldsService;
    
    @Autowired
    private CloseLocatorService closeLocatorService;
    
    @Autowired
    private ObjectMapper objectMapper;
    
    @Autowired(required = false)
    private ValidatableRequestFactory requestFactory;
    
    @Value("${spring.profiles.active}")
	private String activeProfile;
    
    @Value("${should.make.tr.call:true}")
	private boolean shouldMakeTrCall;

    public static final String SBX = "sbx";
	public static final String LOCAL = "local";

	public RetrieveFieldsResponseDTO performVarianceAnalysisOrTaxCalc(ValidatableRequest request, MultipartFile file) throws IOException {
		
        log.info("Active Profile: {}", activeProfile);
        String token = null, locatorId = null;
        Map<String, String> authTokenSessionToken = null;
        
        if (shouldMakeTrCall) {
            token = LOCAL.equals(activeProfile)  || SBX.equals(activeProfile) ? authLocatorService.getToken() : pingTokenService.getAccessToken();
            log.info("token: {}", token);
            
            // If locatorId is present in the request header, do not create a new locatorId
            locatorId = ObjectUtils.isNotEmpty(request.getHeader().get("locatorId")) ? (String) request.getHeader().get("locatorId") : authLocatorService.createLocator(request.getHeader(), token);
            log.info("locatorId: {}", locatorId);
            
            // Call Open session only if snapshot is not present
            if (file == null) {
	            authTokenSessionToken = openSessionService.openSession(request.getHeader(), token, locatorId);
	            log.info("authTokenSessionToken from open session: {}", authTokenSessionToken);
            }
        }

        // Log the ECM request payload
    	try {
            String requestJson = objectMapper.writeValueAsString(request);
            log.info("saveFields - Request JSON from ECM: {}{}", LINE_SEPARATOR, requestJson);
        } catch (JsonProcessingException e) {
        	log.error("Error converting ECM Varaince Request payload to JSON", e);
        }
    	
    	// If snapshot is present, authTokenSessionToken will be the response from TR's open-snapshot call
    	authTokenSessionToken = saveFieldsService.saveFields(request, token, authTokenSessionToken, locatorId, file);
    	// Add the locatorId to request header so that it is populated in the response Header.
        request.getHeader().put("locatorId", locatorId);
        RetrieveFieldsResponseDTO response = retrieveFieldsService.retrieveFields(request, token, authTokenSessionToken);
        
        String calcTypeTxt = (String)request.getHeader().get(CALC_TYPE_TXT);
        if (CALC_TYPE_PARTIAL.equals(calcTypeTxt)) {
            // Make the second call for Partial calculation type
        	ValidatableRequest secondRequest = createSecondRequest(request, response);
            saveFieldsService.saveFields(secondRequest, token, authTokenSessionToken);
            response = retrieveFieldsService.retrieveFields(secondRequest, token, authTokenSessionToken);
        }
        
        // Close Locator after retrieveFields
		closeLocatorService.closeLocator(token, authTokenSessionToken);
		
		return response;
	}
	
	private ValidatableRequest createSecondRequest(ValidatableRequest originalRequest, RetrieveFieldsResponseDTO firstResponse) {
		
		ValidatableRequest secondRequest = requestFactory.createRequest();
    	Map<String, Object> headerMap = originalRequest.getHeader();
    	headerMap.put(SECOND_CALL_FOR_PARTIAL_TAX_CALC, true);
        secondRequest.setHeader(headerMap);
        
        // Update the body with the response from the first call
        Map<String, Object> newBody = new HashMap<>(originalRequest.getBody());
        newBody.put("forms", firstResponse.getStructuredResponse().get("forms"));
        secondRequest.setBody(newBody);

        return secondRequest;
    }
}
