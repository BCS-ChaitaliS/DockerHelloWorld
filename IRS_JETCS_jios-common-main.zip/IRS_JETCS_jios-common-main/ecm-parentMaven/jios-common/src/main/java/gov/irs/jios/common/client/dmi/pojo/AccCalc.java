package gov.irs.jios.common.client.dmi.pojo;

import lombok.Data;

@Data
public class AccCalc {
    private String penaltySectionCd;
    private String penaltyRt;
    private Double assessmentAmt;
    private String assessmentDt;
    private String previouslyAssessedPenaltyAmt;
}
