package gov.irs.jios.common.client.tr.pojo;

import java.util.Map;

import lombok.Data;

@Data
public class RetrieveFieldsResponseDTO {
	private String jsonResponse;
    private Map<String, Object> structuredResponse;
}
