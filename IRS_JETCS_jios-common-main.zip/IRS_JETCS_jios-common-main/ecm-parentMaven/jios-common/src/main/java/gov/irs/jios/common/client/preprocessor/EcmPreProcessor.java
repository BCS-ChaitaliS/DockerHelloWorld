package gov.irs.jios.common.client.preprocessor;

import java.util.List;

import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import gov.irs.jios.common.request.ValidatableRequest;

public interface EcmPreProcessor {
    void preProcess(ValidatableRequest request, List<FieldMapping> allMappings);
}
