package gov.irs.jios.common.client.transformer;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import lombok.extern.slf4j.Slf4j;


/**
 * Author: Kaiwen Tsou
 **/

/**
 * There are multiple date types in ECM. From what I've gathered, TR only has the single Date type, so we map to/from that. 
 * Be careful of possible alternative date types on TR. 
 */
@Slf4j
public class DateTransformers {
    public static String ECMDateTypeToTRDate(String ecmDateValue) {
        try {
            DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDate date = LocalDate.parse(ecmDateValue, inputFormatter);
            String outputFormattedDateForTR = date.format(outputFormatter);
            return outputFormattedDateForTR;
        } catch (DateTimeParseException e) {
            log.warn("Invalid date type (ECMDateTypeToTRDate)" + ecmDateValue);
            return "";
        } catch (Exception e) {
            log.warn("Other error returned from date transformation");
            return "";
        }

    }

    public String TRDateToECMDateType(String trDateValue) {
        try {
            DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate date = LocalDate.parse(trDateValue, inputFormatter);
            String outputFormattedDateForECM = date.format(outputFormatter);
            return outputFormattedDateForECM;
        } catch (DateTimeParseException e) {
            log.warn("Invalid date type (TRDateToECMDateType)" + trDateValue);
            return "";
        } catch (Exception e) {
            log.warn("Other error returned from date transformation");
            return "";
        }

    }

 public static String ECMYearMonthTypeToTRDate(String ecmDateValue) {
        try {
            DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM");
            YearMonth yearMonth = YearMonth.parse(ecmDateValue, inputFormatter);
            // TR expects the day, so we are arbitrarily giving it 1
            LocalDate date = yearMonth.atDay(1); 
            DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            
            return date.format(outputFormatter);
        } catch (DateTimeParseException e) {
            log.warn("Invalid date type (ECMYearMonthTypeToTRDate)" + ecmDateValue);
            return "";
        } catch (Exception e) {
            log.warn("Other error returned from date transformation");
            return "";
        }
    }
    public static String TRDateToECMYearMonth(String trDateValue) {
        try {
            DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy-MM");
            LocalDate date = LocalDate.parse(trDateValue, inputFormatter);
            String outputFormattedDateForECM = date.format(outputFormatter);

            return outputFormattedDateForECM;
        } catch (DateTimeParseException e) {
            log.warn("Invalid date type (TRDateToECMYearMonth)" + trDateValue);
            return "";
        } catch (Exception e) {
            log.warn("Other error returned from date transformation");
            return "";
        }
    }
}




