package gov.irs.jios.common.ecm.pojo;

import lombok.Data;

@Data
public class ValidationField {
	private String fieldId;
    private String value;
    private boolean isGroup;
    private boolean override;
    private ValidationStatus responseStatus;
}
