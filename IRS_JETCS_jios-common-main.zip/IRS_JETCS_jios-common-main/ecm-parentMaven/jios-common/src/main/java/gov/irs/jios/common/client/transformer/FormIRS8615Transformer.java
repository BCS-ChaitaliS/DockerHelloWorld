package gov.irs.jios.common.client.transformer;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_ITEMS;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_NAME_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.PER_RETURN_VALUE_TXT;
import java.time.Year;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FormIRS8615Transformer {
	public List<FieldMapping> transformFormIRS8615(Map<String, Object> formData, Map<String, Object> header) {
		List<FieldMapping> fieldMappings = new ArrayList<>();
		fieldMappings = addFilingStatus(formData, fieldMappings);
		fieldMappings = addDob(fieldMappings);
		return fieldMappings;
	}
	public List<FieldMapping> addDob(List<FieldMapping> fieldMappings) {
		int year = Year.now().getValue() - 18;
		addFieldMapping(fieldMappings, "IRS8615", "FED.TPBIRTH", "01/01/" + year, "");
		return fieldMappings;
	}
	public List<FieldMapping> addFilingStatus(Map<String, Object> formData, List<FieldMapping> fieldMappings) {
		{
			@SuppressWarnings("unchecked")
			List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
			for (Map<String, Object> lineItem : lineItems) {
				if ("/IRS8615/IndividualReturnFilingStatusCd".equals(lineItem.get(LINE_NAME_TXT))) {
					String val = (String) lineItem.get(PER_RETURN_VALUE_TXT);
					if (val.equals("1")) {
						addFieldMapping(fieldMappings, "IRS8615", "FED.ZFSNG", "X", "");
					} else if (val.equals("2")) {
						addFieldMapping(fieldMappings, "IRS8615", "FED.ZFMFJ", "X", "");
					} else if (val.equals("3")) {
						addFieldMapping(fieldMappings, "IRS8615", "FED.ZFMFS", "X", "");
					} else if (val.equals("4")) {
						addFieldMapping(fieldMappings, "IRS8615", "FED.ZFHH", "X", "");
					} else if (val.equals("5")) {
						addFieldMapping(fieldMappings, "IRS8615", "FED.ZFQW", "X", "");
					}
				}
			}
			return fieldMappings;
		}
	}
	private void addFieldMapping(List<FieldMapping> fieldMappings, String sourceForm, String targetField,
			String targetFieldValue, String groupField) {
		FieldMapping mapping = new FieldMapping();
		mapping.setSourceForm(sourceForm);
		mapping.setTargetField(targetField);
		mapping.setTargetFieldValue(targetFieldValue);
		if (!groupField.equals("")) {
			mapping.setGroupField(groupField);
		}
		fieldMappings.add(mapping);
	}
}