package gov.irs.jios.common.client.transformer;

import java.util.List;
import java.util.Map;

import static gov.irs.jios.common.util.JiosCommonConstants.PRIMARY_TIN;
import static gov.irs.jios.common.util.JiosCommonConstants.SECONDARY_TIN;
import gov.irs.jios.common.client.tr.pojo.Field;
import gov.irs.jios.common.pojo.FormIdentifier;
import gov.irs.jios.common.pojo.LineItemStructure;
import gov.irs.jios.common.request.ValidatableRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ScheduleSESequenceTransformer {
    private static final String SCHEDULE_SE_FORM = "IRS1040ScheduleSE";
    private static final String SSN_LINE_NAME = "/IRS1040ScheduleSE/SSN";

    public String determineSequence(String sourceField, Field field, Map<String, String> ssnMapping,
            Map<FormIdentifier, LineItemStructure> formStructureMap, ValidatableRequest request) {

        // Skip processing SSN fields themselves
        if (sourceField.endsWith("SSN")) {
            return null;
        }

        // Get original SSNs
        String primarySSN = ssnMapping.get(PRIMARY_TIN);
        String spouseSSN = ssnMapping.get(SECONDARY_TIN);
        
        log.debug("Determining sequence for sourceField: {}, primary SSN: {}, spouse SSN: {}", 
            sourceField, primarySSN, spouseSSN);

	// Find matching form based on SSN
        for (Map.Entry<FormIdentifier, LineItemStructure> entry : formStructureMap.entrySet()) {
            FormIdentifier identifier = entry.getKey();
            if (!SCHEDULE_SE_FORM.equals(identifier.getFormNum())) {
                continue;
            }

            LineItemStructure structure = entry.getValue();
            String formSSN = getSSNFromStructure(structure.getForm());
            log.debug("Form sequence: {}, Found SSN: {}", identifier.getSequenceNum(), formSSN);

            if (formSSN != null) {
                boolean isSpouseField = sourceField.contains(".S") || sourceField.equals("X95.159.12");
                boolean isPrimaryField = sourceField.contains(".T") || sourceField.equals("X95.2.12");
                
                if (isSpouseField && formSSN.equals(spouseSSN)) {
                    log.debug("Matched spouse SSN - returning sequence: {}", identifier.getSequenceNum());
                    return identifier.getSequenceNum();
                } else if (isPrimaryField && formSSN.equals(primarySSN)) {
                    log.debug("Matched primary SSN - returning sequence: {}", identifier.getSequenceNum());
                    return identifier.getSequenceNum();
                }
            }
        }

        log.debug("No matching sequence found for field: {}", sourceField);
        return null;
    }

    @SuppressWarnings("unchecked")
    private String getSSNFromStructure(Map<String, Object> form) {
        if (form == null) {
            log.debug("Form is null");
            return null;
        }

        List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get("lineItems");
        if (lineItems == null) {
            log.debug("No line items found in form");
            return null;
        }

        // Look directly through line items for SSN
        for (Map<String, Object> item : lineItems) {
            if (SSN_LINE_NAME.equals(item.get("lineNameTxt"))) {
                String ssn = (String) item.get("perReturnValueTxt");
                log.debug("Found SSN in line items: {}", ssn);
                return ssn;
            }
        }

        log.debug("No SSN found in form structure");
        return null;
    }
}
