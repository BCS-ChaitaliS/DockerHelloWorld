package gov.irs.jios.common.validation;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.irs.jios.common.request.ValidatableRequest;

public class GenericValidator {
    private static final Logger logger = LoggerFactory.getLogger(GenericValidator.class);
    private JsonNode validationRules;
    private ObjectMapper objectMapper;

    public GenericValidator(String configFileName) {
    	objectMapper = new ObjectMapper();
        // loadValidationRules(configFileName);
    }

    @SuppressWarnings("unused")
	private void loadValidationRules(String configFileName) {
        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream(configFileName)) {
            if (inputStream == null) {
                throw new IllegalArgumentException("Config file not found: " + configFileName);
            }
            validationRules = objectMapper.readTree(inputStream);
            logger.info("Validation rules loaded successfully");
        } catch (IOException e) {
            logger.error("Error loading validation rules: ", e);
            throw new RuntimeException("Error loading validation rules: " + e.getMessage(), e);
        }
    }

    public List<String> validate(Object object) {
        List<String> errors = new ArrayList<>();
        logger.debug("Starting validation");
        try {
            if (object instanceof Map) {
                validateMapStructure((Map<?, ?>) object, errors);
            } else if (object instanceof ValidatableRequest) {
                ValidatableRequest request = (ValidatableRequest) object;
                Map<String, Object> requestMap = new HashMap<>();
                if (request.getHeader() != null) {
                    requestMap.put("header", request.getHeader());
                }
                if (request.getBody() != null) {
                    requestMap.put("body", request.getBody());
                }
                validateMapStructure(requestMap, errors);
            } else {
                errors.add("Root object must be a Map or ValidatableRequest");
            }
        } catch (Exception e) {
            logger.error("Error during validation: ", e);
            errors.add("Internal validation error: " + e.getMessage());
        }
        logger.info("Validation complete. Errors: {}", errors);
        return errors;
    }

    private void validateMapStructure(Map<?, ?> rootMap, List<String> errors) {
        JsonNode validationNode = validationRules.get("validation");
        if (validationNode != null && validationNode.isObject()) {
            validationNode.fields().forEachRemaining(entry -> {
                String key = entry.getKey();
                JsonNode rules = entry.getValue();
                Object value = rootMap.get(key);
                if (value == null) {
                    errors.add(key + " object is required");
                } else {
                    validateObject(value, rules, key, errors);
                }
            });
        }
    }

    private void validateObject(Object object, JsonNode rules, String path, List<String> errors) {
    	logger.debug("Validating object at path: {}", path);
        if (rules == null) {
        	logger.info("No rules found for path: {}", path);
            return;
        }

        if (object == null) {
            errors.add(path + " is required");
            logger.info("Error: {} is required", path);
            return;
        }

        String type = rules.has("type") ? rules.get("type").asText() : null;
        logger.debug("Object type: {}", type);
        if ("object".equals(type) && object instanceof Map) {
            validateMap((Map<?, ?>) object, rules, path, errors);
        } else if ("array".equals(type) && object instanceof List) {
            validateList((List<?>) object, rules, path, errors);
        } else {
            validateField(object, rules, path, errors);
        }
    }

    private void validateMap(Map<?, ?> map, JsonNode rules, String path, List<String> errors) {
    	logger.debug("Validating map at path: {}", path);
        JsonNode properties = rules.get("properties");
        if (properties == null) {
        	logger.info("No properties found for map at path: {}", path);
            return;
        }

        properties.fields().forEachRemaining(entry -> {
            String fieldName = entry.getKey();
            JsonNode fieldRules = entry.getValue();
            Object value = map.get(fieldName);
            String fieldPath = path.isEmpty() ? fieldName : path + "." + fieldName;
            
            boolean isMandatory = fieldRules.has("mandatory") && fieldRules.get("mandatory").asBoolean();
            
            if (value == null) {
                if (isMandatory) {
                    errors.add(fieldPath + " is required");
                }
            } else {
                validateObject(value, fieldRules, fieldPath, errors);
            }
        });
    }

    private void validateList(List<?> list, JsonNode rules, String path, List<String> errors) {
    	logger.debug("Validating list at path: {}", path);
        if (rules.has("min-items")) {
            int minItems = rules.get("min-items").asInt();
            if (list.size() < minItems) {
                errors.add(path + " must have at least " + minItems + " item(s)");
                logger.info("Error: {} must have at least {} item(s)", path, minItems);
            }
        }

        JsonNode itemRules = rules.get("items");
        if (itemRules != null) {
            for (int i = 0; i < list.size(); i++) {
                validateObject(list.get(i), itemRules, path + "[" + i + "]", errors);
            }
        }
    }

    private void validateField(Object value, JsonNode rules, String path, List<String> errors) {
    	logger.debug("Validating field at path: {}", path);
        String fieldType = rules.has("field-type") ? rules.get("field-type").asText() : "";
        logger.info("Field type: {}", fieldType);

        switch (fieldType) {
            case "alphanumeric":
                if (!value.toString().matches("^[a-zA-Z0-9_-]*$")) {
                    errors.add(path + " must be alphanumeric");
                    logger.info("Error: {} must be alphanumeric", path);
                }
                break;
            case "number":
                if (!value.toString().matches("^\\d+$")) {
                    errors.add(path + " must be a number");
                    logger.info("Error: {} must be a number", path);
                }
                break;
            case "date":
                if (rules.has("format")) {
                    validateDate(value.toString(), rules.get("format").asText(), path, errors);
                }
                break;
        }

        if (rules.has("pattern")) {
            String pattern = rules.get("pattern").asText();
            if (!value.toString().matches(pattern)) {
                errors.add(path + " does not match the required pattern");
                logger.info("Error: {} does not match the required pattern", path);
            }
        }

        if (rules.has("allowed-values")) {
            List<String> allowedValues = objectMapper.convertValue(rules.get("allowed-values"), new TypeReference<List<String>>() {});
            if (!allowedValues.contains(value.toString())) {
                errors.add(path + " is not an allowed value. Allowed values are " + allowedValues);
                logger.info("Error: {} is not an allowed value. Allowed values are {}", path, allowedValues);
            }
        }
    }

    private void validateDate(String value, String format, String path, List<String> errors) {
        try {
        	/*
        	 * SimpleDateFormat does not validate year field accurately. So using DateTimeFormatter for date validation.
        	 * Rules file should have M/d/uuuu as date format.
        	 */
        	LocalDate.parse(value,
        	        DateTimeFormatter.ofPattern(format)
        	        .withResolverStyle(ResolverStyle.STRICT));
        } catch (Exception e) {
            errors.add(path + " is not a valid date in the format " + format);
            logger.info("Error: {} is not a valid date in the format {}", path, format);
        }
    }

    public void printLoadedRules() {
    	logger.debug("Loaded validation rules: {}", validationRules.toPrettyString());
    }
}