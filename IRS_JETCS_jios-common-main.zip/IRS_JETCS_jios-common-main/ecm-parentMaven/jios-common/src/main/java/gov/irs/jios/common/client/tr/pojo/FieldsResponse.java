package gov.irs.jios.common.client.tr.pojo;

import java.util.List;

import lombok.Data;

@Data
public class FieldsResponse {
    private GroupField groupField;
    private List<Field> fields;
}