package gov.irs.jios.common.client.transformer;

import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static gov.irs.jios.common.util.JiosCommonConstants.*;

@Slf4j

/**
 * Basically, if there is any prior year data, we have to mark an indicator field.
 */
public class FormIRS1040ScheduleJTransformer {

	public List<FieldMapping> transformFormIRS1040ScheduleJ(Map<String, Object> formData, Map<String, Object> header) {
		List<FieldMapping> fieldMappings = new ArrayList<>();
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);

		Set<String> checkForThese = Set.of(
				"/IRS1040ScheduleJ/TentativeTax3rdPYRtnAmt",
				"/IRS1040ScheduleJ/TentativeTax2ndPYRtnAmt",
				"/IRS1040ScheduleJ/TentativeTax1stPYRtnAmt",
				"/IRS1040ScheduleJ/ThirdPYTxblFarmIncmDetail",
				"/IRS1040ScheduleJ/SecondPYTxblFarmIncmDetail",
				"/IRS1040ScheduleJ/FirstPYTxblFarmIncmDetail"
		);

		boolean hasPYInfo = lineItems.stream().anyMatch(li -> checkForThese.contains(li.get(LINE_NAME_TXT)));

		/*
		"sourceForm": "IRS1040ScheduleJ",
		"targetField": "X89.348.15",
		"targetFieldValue": "X"
		 */
		if (hasPYInfo) {
			FieldMapping mapping = new FieldMapping();
			mapping.setSourceForm("IRS1040ScheduleJ");
			mapping.setTargetField("X89.348.15");
			mapping.setTargetFieldValue("X");
			fieldMappings.add(mapping);
		}

		return fieldMappings;
	}

}