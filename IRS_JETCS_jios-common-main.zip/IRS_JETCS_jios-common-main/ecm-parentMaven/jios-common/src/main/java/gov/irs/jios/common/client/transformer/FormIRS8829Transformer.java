package gov.irs.jios.common.client.transformer;

import static gov.irs.jios.common.util.JiosCommonConstants.PRIMARY_TIN;
import static gov.irs.jios.common.util.JiosCommonConstants.SECONDARY_TIN;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_ITEMS;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_NAME_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.PER_RETURN_VALUE_TXT;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FormIRS8829Transformer {
	
	public static final String IRS8829 = "IRS8829";
	
    public List<FieldMapping> transformFormIRS8829(Map<String, Object> formData, Map<String, Object> header) {
    	List<FieldMapping> fieldMappings = new ArrayList<>();

        if (formData == null || header == null) {
            log.warn("FormData or header is null. Returning empty field mappings.");
            return fieldMappings;
        }

        String ssn = extractSSN(formData);
        if (ssn == null) {
            log.warn("Unable to extract SSN from formData. Returning empty field mappings.");
            return fieldMappings;
        }
        
        String primaryTIN = (String) header.get(PRIMARY_TIN);
        String secondaryTIN = (String) header.get(SECONDARY_TIN);

        if (primaryTIN == null && secondaryTIN == null) {
            log.warn("Both primaryTIN and spouseTIN are null in header. Returning empty field mappings.");
            return fieldMappings;
        }
        
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
        if (lineItems == null) {
            log.warn("No lineItems found in formData");
            return fieldMappings;
        }

        if (Objects.equals(ssn, primaryTIN)) {
        	addFieldMapping(fieldMappings, "OIH.OWN", "T");
        } else if (Objects.equals(ssn, secondaryTIN)) {
			addFieldMapping(fieldMappings, "OIH.OWN", "S");
        } else {
            log.warn("SSN does not match primaryTIN or spouseTIN. Returning empty field mappings.");
        }
        
        return fieldMappings;
    }
    
    private String extractSSN(Map<String, Object> formData) {
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
        if (lineItems == null) {
            log.warn("No lineItems found in formData");
            return null;
        }

        for (Map<String, Object> lineItem : lineItems) {
            if ("/IRS8829/SSN".equals(lineItem.get(LINE_NAME_TXT))) {
                String ssn = (String) lineItem.get(PER_RETURN_VALUE_TXT);
                if (ssn == null || ssn.isEmpty()) {
                    log.warn("SSN found but value is null or empty");
                    return null;
                }
                return ssn;
            }
        }

        log.warn("No line item with lineNameTxt '/IRS5329/SSN' found");
        return null;
    }
    
    private void addFieldMapping(List<FieldMapping> mappings, String targetField, String targetFieldValue) {
        FieldMapping mapping = new FieldMapping();
        mapping.setSourceForm(IRS8829);
        mapping.setTargetField(targetField);
        mapping.setTargetFieldValue(targetFieldValue);
        mappings.add(mapping);
    }
    
   
}