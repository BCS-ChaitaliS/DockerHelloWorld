package gov.irs.jios.common.ecm.pojo;

import lombok.Data;

@Data
public class ValidationGroupField {
	private String fieldId;
    private String value;
    private Integer level;
    private Integer field;
    private ValidationGroupField child;
    private ValidationStatus responseStatus;
}
