package gov.irs.jios.common.client.preprocessor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import gov.irs.jios.common.request.ValidatableRequest;
import lombok.extern.slf4j.Slf4j;

import static gov.irs.jios.common.util.JiosCommonConstants.REMOVE_IT_LATER;

@Component
@Slf4j
public class LineItemCopyPreProcessor implements EcmPreProcessor {
    private static final String SHORT_TERM_GROUP = "/IRS8949/ShortTermCapitalGainAndLossGrp";
    private static final String LONG_TERM_GROUP = "/IRS8949/LongTermCapitalGainAndLossGrp";
    
    private static final List<String> SHORT_TERM_INDICATORS = Arrays.asList(
        SHORT_TERM_GROUP + "/TransRptOn1099BThatShowBssInd",
        SHORT_TERM_GROUP + "/TransRptOn1099BNotShowBasisInd",
        SHORT_TERM_GROUP + "/TransactionsNotRptedOn1099BInd"
    );
    
    private static final List<String> LONG_TERM_INDICATORS = Arrays.asList(
        LONG_TERM_GROUP + "/TransRptOn1099BThatShowBssInd",
        LONG_TERM_GROUP + "/TransRptOn1099BNotShowBasisInd",
        LONG_TERM_GROUP + "/TransactionsNotRptedOn1099BInd"
    );
    
    @Override
    public void preProcess(ValidatableRequest request, List<FieldMapping> allMappings) {
        log.info("Starting line item copy preprocessing");
        
        Map<String, Object> body = request.getBody();
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> forms = (List<Map<String, Object>>) body.get("forms");
        if (forms == null) {
            return;
        }
        
        for (Map<String, Object> form : forms) {
            if ("IRS8949".equals(form.get("formNum"))) {
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get("lineItems");
                if (lineItems != null) {
                    processCapitalGroups(lineItems, true);  // Process Short Term
                    processCapitalGroups(lineItems, false); // Process Long Term
                }
            }
        }
        for (Map<String, Object> form : forms) {
            if ("IRS8919".equals(form.get("formNum"))) {
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get("lineItems");
                if (lineItems != null) {
                    process8919(lineItems); 
                }
            }
        }
        
        log.info("Completed line item copy preprocessing");
    }
    
    @SuppressWarnings("unchecked")
    private void processCapitalGroups(List<Map<String, Object>> lineItems, boolean isShortTerm) {
        String groupPath = isShortTerm ? SHORT_TERM_GROUP : LONG_TERM_GROUP;
        List<String> indicators = isShortTerm ? SHORT_TERM_INDICATORS : LONG_TERM_INDICATORS;
        
        // Map to store the indicators by sequence number
        Map<String, Map<String, Object>> indicatorsBySequence = new HashMap<>();
        
        // First pass: Find all groups and their indicators
        for (Map<String, Object> item : lineItems) {
            String lineNameTxt = (String) item.get("lineNameTxt");
            String sequenceNum = (String) item.get("sequenceNum");
            
            if (lineNameTxt != null && lineNameTxt.equals(groupPath)) {
                // Found a capital group, now look for its indicators
                List<Map<String, Object>> groupLineItems = (List<Map<String, Object>>) item.get("lineItems");
                if (groupLineItems != null) {
                    for (Map<String, Object> groupItem : groupLineItems) {
                        String groupItemLineName = (String) groupItem.get("lineNameTxt");
                        if (groupItemLineName != null && indicators.contains(groupItemLineName)) {
                            indicatorsBySequence.put(sequenceNum, groupItem);
                            break; // Found the indicator for this sequence
                        }
                    }
                }
            }
        }
        
        // Second pass: Copy indicators to asset groups
        for (Map<String, Object> item : lineItems) {
            String lineNameTxt = (String) item.get("lineNameTxt");
            if (lineNameTxt != null && lineNameTxt.equals(groupPath)) {
                String sequenceNum = (String) item.get("sequenceNum");
                Map<String, Object> indicator = indicatorsBySequence.get(sequenceNum);
                
                if (indicator != null) {
                    // Find and process all asset groups under this sequence
                    List<Map<String, Object>> groupLineItems = (List<Map<String, Object>>) item.get("lineItems");
                    if (groupLineItems != null) {
                        for (Map<String, Object> groupItem : groupLineItems) {
                            String groupItemLineName = (String) groupItem.get("lineNameTxt");
                            if (groupItemLineName != null && 
                                groupItemLineName.endsWith("/CapitalGainAndLossAssetGrp")) {
                                
                                // Create and add the copied indicator
                                Map<String, Object> copiedIndicator = new LinkedHashMap<>(indicator);
                                
                                // Modify the lineNameTxt by appending to asset group path
                                String originalIndicatorName = (String) indicator.get("lineNameTxt");
                                String indicatorSuffix = originalIndicatorName.substring(originalIndicatorName.lastIndexOf("/"));
                                copiedIndicator.put("lineNameTxt", groupItemLineName + indicatorSuffix);
                                copiedIndicator.put(REMOVE_IT_LATER, true);
                                
                                List<Map<String, Object>> assetGroupLineItems = 
                                    (List<Map<String, Object>>) groupItem.get("lineItems");
                                if (assetGroupLineItems == null) {
                                    assetGroupLineItems = new ArrayList<>();
                                    groupItem.put("lineItems", assetGroupLineItems);
                                }
                                
                                assetGroupLineItems.add(copiedIndicator);
                                
                                log.debug("Copied indicator {} to asset group under sequence {}",
                                    originalIndicatorName, sequenceNum);
                            }
                        }
                    }
                }
            }
        }
    }
    
    @SuppressWarnings("unchecked")
    private void process8919(List<Map<String, Object>> lineItems) {
    	/*
    	 * There is only 1 social security number we are sending into each sequence
    	 * so we only need to grab the SSN indicator in this step
    	 */
        
        // Map to store the indicators by sequence number
        Map<String, Object> indicator = new HashMap<>();
        
        // First pass: Find all groups and their indicators
        for (Map<String, Object> item : lineItems) {
            String lineNameTxt = (String) item.get("lineNameTxt");
            
            if (lineNameTxt != null && lineNameTxt.equals("/IRS8919/SSN")) {
                indicator = item;
                break; // Found the indicator for this sequence
            }
        }
               
        // Second pass: Copy indicator to asset groups
        for (Map<String, Object> item : lineItems) {
            String lineNameTxt = (String) item.get("lineNameTxt");
            if (lineNameTxt != null && lineNameTxt.equals("/IRS8919/UncollectedSocSecMedTaxPerFirm")) {
                
                if (indicator != null) {
                	
                	// Create and add the copied indicator
                    Map<String, Object> copiedIndicator = new LinkedHashMap<>(indicator);
                    
                    // Modify the lineNameTxt by appending to asset group path
                    String originalIndicatorName = (String) indicator.get("lineNameTxt");
                    String indicatorSuffix = originalIndicatorName.substring(originalIndicatorName.lastIndexOf("/"));                    
                    
                    copiedIndicator.put("lineNameTxt", lineNameTxt + indicatorSuffix);
                    copiedIndicator.put(REMOVE_IT_LATER, true);
                    
                    List<Map<String, Object>> assetGroupLineItems = 
                        (List<Map<String, Object>>) item.get("lineItems");
                    if (assetGroupLineItems == null) {
                        assetGroupLineItems = new ArrayList<>();
                        item.put("lineItems", assetGroupLineItems);
                    }
                    
                    assetGroupLineItems.add(copiedIndicator);
                    
                    log.debug("Copied indicator {} to asset group",
                        originalIndicatorName);
	            }
	        }
	    }
	}
}