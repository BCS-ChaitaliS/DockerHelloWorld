package gov.irs.jios.common.client.tr.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import gov.irs.jios.common.request.ValidatableRequest;

public class EcmPayloadLineFinder {
	
    private static final String FORM_1040 = "IRS1040";
    private static final String FORM_8959 = "IRS8959";
    private static final Set<String> TARGET_LINE_NAMES = Set.of(
    	"/IRS1040/TotalTaxAmt",
        "/IRS1040/EarnedIncomeCreditAmt",
        "/IRS1040/AdditionalChildTaxCreditAmt",
        "/IRS1040/RefundableAmerOppCreditAmt",
        "/IRS1040/TotalOtherPaymentsRfdblCrAmt",
        "/IRS1040/FormW2WithheldTaxAmt",
        "/IRS1040/Form1099WithheldTaxAmt",
        "/IRS1040/TaxWithheldOtherAmt",
        "/IRS1040/EstimatedTaxPaymentsAmt",
        "/IRS8959/AdditionalTaxGrp/AdditionalMedicareTaxGrp/AdditionalMedicareTaxAmt"
    );
    
    @SuppressWarnings("unchecked")
    public static Map<String, Map<String, Object>> retrieveLineItems(ValidatableRequest inputPayload) {
        Map<String, Map<String, Object>> results = new HashMap<>();
        
        Map<String, Object> body = inputPayload.getBody();
        List<Map<String, Object>> forms = (List<Map<String, Object>>) body.get("forms");
        
        for (Map<String, Object> form : forms) {
            if (FORM_1040.equals(form.get("formNum")) || FORM_8959.equals(form.get("formNum"))) {
                List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get("lineItems");
                processLineItems(lineItems, results);
            }
        }
        return results;
    }
    
    @SuppressWarnings("unchecked")
    private static void processLineItems(List<Map<String, Object>> lineItems, Map<String, Map<String, Object>> results) {
        if (lineItems == null) return;
        
        for (Map<String, Object> lineItem : lineItems) {
            String lineNameTxt = (String) lineItem.get("lineNameTxt");
            if (TARGET_LINE_NAMES.contains(lineNameTxt)) {
                results.put(lineNameTxt, lineItem);
            }
            
            // Process nested line items if they exist
            List<Map<String, Object>> nestedItems = (List<Map<String, Object>>) lineItem.get("lineItems");
            if (nestedItems != null) {
                processLineItems(nestedItems, results);
            }
        }
    }
}
