package gov.irs.jios.common.pojo;

import java.util.Map;

import lombok.ToString;

@ToString
public class LineItemStructure {
    private final Map<String, Object> form;
    
    public LineItemStructure(Map<String, Object> form) {
        this.form = form;
    }
    
    public Map<String, Object> getLineItem(String lineNameTxt, String sequenceNum) {
        return LineItemFinder.findLineItem(form, lineNameTxt, sequenceNum);
    }
    
    public Map<String, Object> getForm() {
        return form;
    }
}