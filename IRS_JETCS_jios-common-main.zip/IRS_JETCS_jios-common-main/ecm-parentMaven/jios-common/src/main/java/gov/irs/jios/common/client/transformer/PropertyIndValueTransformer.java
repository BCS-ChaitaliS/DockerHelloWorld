package gov.irs.jios.common.client.transformer;

import java.util.Map;

/**
 * @author ArunaValluru
 */
		

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class PropertyIndValueTransformer {
    
	private static final Map<String, String> ECM_TO_TR_MAP = Map.of(
	    "TRUE", "Y",
	    "FALSE", "N",
	    "1", "Y",
	    "0", "N",
	    "", "B"
	);

	private static final Map<String, String> TR_TO_ECM_MAP = Map.of(
	    "Y", "TRUE",
	    "N", "FALSE"
	);

    public static String transformEcmToTr(String ecmIndicatorValue) {
        try {
            if (ecmIndicatorValue == null) {
                ecmIndicatorValue = "";
            }
            String trIndicator = ECM_TO_TR_MAP.get(ecmIndicatorValue.toUpperCase());
            if (trIndicator == null) {
                throw new IllegalArgumentException("Invalid ECM Indicator value: " + ecmIndicatorValue);
            }
            return trIndicator;  
        } catch (IllegalArgumentException e){
            log.warn("PropertyIndValueTransformer: Invalid ECM indicator: " + ecmIndicatorValue);
            return "";
        }

    }

    public static String transformTrToEcm(String trIndicatorValue) {
        try {
            String ecmIndicator = TR_TO_ECM_MAP.get(trIndicatorValue != null ? trIndicatorValue.toUpperCase() : "");
            if (ecmIndicator == null) {
                throw new IllegalArgumentException("Invalid TR Indicator value: " + trIndicatorValue);
            }
            return ecmIndicator;
        } catch (IllegalArgumentException e){
            log.warn("PropertyIndValueTransformer: Invalid TR indicator: " + trIndicatorValue);
            return "";
        }

    }
}
