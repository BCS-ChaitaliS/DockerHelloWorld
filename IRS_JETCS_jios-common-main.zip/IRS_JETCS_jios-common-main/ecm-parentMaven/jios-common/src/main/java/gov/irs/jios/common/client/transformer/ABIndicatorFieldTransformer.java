package gov.irs.jios.common.client.transformer;

import java.util.Map;

import lombok.extern.slf4j.Slf4j;

/**
 * Author: Kaiwen Tsou
 **/

@Slf4j
/**
 * For some reason, certain fields in TR map boolean indicators to A and B rather than X or Blank.
 */
public class ABIndicatorFieldTransformer {
    private static final Map<String, Boolean> ECM_TO_TR_MAP = Map.of(
	    "TRUE", true,
	    "FALSE", false,
	    "1", true,
	    "0", false,
	    "X", true, // Theoretically, only this type should be sent from ECM for the AtRisk fields.
	    "", false
	);
	private static final Map<String, String> TR_TO_ECM_MAP = Map.of(
	    "A", "TRUE",
	    "B", "FALSE", 
	    "", "FALSE" // This shouldn't happen
	);

    public static String transformEcmToTr(String ecmIndicatorValue) {
        try {
            if (ecmIndicatorValue == null) {
                ecmIndicatorValue = "";
            }
            String trIndicator = null;
            if(ECM_TO_TR_MAP.get(ecmIndicatorValue.toUpperCase())) {
                trIndicator = "A";
            } else if (!ECM_TO_TR_MAP.get(ecmIndicatorValue.toUpperCase())){
                trIndicator = "B";
            }
            if (trIndicator == null) {
                throw new IllegalArgumentException("Invalid ECM Indicator value: " + ecmIndicatorValue);
            }
            return trIndicator;
        } catch (Exception e){
            log.warn("ABIndicatorFieldTransformer: " + e.getMessage());
            return "";
        }
    }

    public static String transformTrToEcm(String trIndicatorValue) {
        try {
            String ecmIndicator = TR_TO_ECM_MAP.get(trIndicatorValue);
            if (ecmIndicator == null) {
                throw new IllegalArgumentException("Invalid TR Indicator value: " + trIndicatorValue);
            }
            return ecmIndicator;
        } catch (Exception e){
            log.warn("ABIndicatorFieldTransformer: " + e.getMessage());
            return "";
        }
    }
}
