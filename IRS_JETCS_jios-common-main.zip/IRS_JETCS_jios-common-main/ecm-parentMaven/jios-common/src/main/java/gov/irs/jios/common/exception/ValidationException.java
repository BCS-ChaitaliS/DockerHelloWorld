package gov.irs.jios.common.exception;

import java.util.List;

import gov.irs.jios.common.ecm.pojo.ErrorResponse;

public class ValidationException extends RuntimeException {
	private static final long serialVersionUID = 4445824228675076703L;
	private List<String> errors;
	private ErrorResponse errorResponse;

    public ValidationException(String message) {
        super(message);
        this.errors = List.of(message);
    }

    public ValidationException(List<String> errors) {
        super("Validation failed: " + String.join(", ", errors));
        this.errors = errors;
    }

    public ValidationException(ErrorResponse errorResponse) {
        this.errorResponse = errorResponse;
    }
    
    public List<String> getErrors() {
        return errors;
    }
    
    public ErrorResponse getErrorResponse() {
        return errorResponse;
    }
}