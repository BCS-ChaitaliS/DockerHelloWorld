package gov.irs.jios.common.ecm.pojo;

import java.util.List;

import lombok.Data;

@Data
public class ValidationResponse {
    private List<ValidationFieldsResponse> fieldsResponse;
}