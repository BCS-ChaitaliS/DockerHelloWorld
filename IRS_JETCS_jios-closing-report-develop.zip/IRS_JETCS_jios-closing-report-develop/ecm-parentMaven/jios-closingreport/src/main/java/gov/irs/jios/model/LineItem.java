package gov.irs.jios.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class LineItem {

	public LineItem(String lineNameTxt, String lineValueTxt, String sequenceNum){
		this.lineNameTxt = lineNameTxt;
		this.lineValueTxt = lineValueTxt;
		this.sequenceNum = sequenceNum;
	}
	@JsonInclude(Include.NON_NULL)
	private String lineItemReferenceKeyId;
	
	@JsonInclude(Include.NON_NULL)
	private String lineNameTxt;
	
	@JsonInclude(Include.NON_NULL)
	private String lineValueTxt;
	
	@JsonInclude(Include.NON_NULL)
	private String sequenceNum;

	@JsonInclude(Include.NON_NULL)
	private String totalAdjTaxCalcValueTxt;

	@JsonInclude(Include.NON_NULL)
	private String totalAdjustmentValueTxt;

	@JsonInclude(Include.NON_NULL)
	private String agreedAdjustmentValueTxt;
	@JsonInclude(Include.NON_NULL)
	private String agreedAdjTaxCalcValueTxt;
	@JsonInclude(Include.NON_NULL)
	private String adjustmentStatusCd;
	@JsonInclude(Include.NON_NULL)
	private String userAdjustedLineInd;
	@JsonInclude(Include.NON_NULL)
	private String statTotalAdjTaxCalcValueTxt;
	@JsonInclude(Include.NON_NULL)
	private String issuePenaltyAgreementStatusInd;
	@JsonInclude(Include.NON_NULL)
	private String statAgreedAdjTaxCalcValueTxt;
	@JsonInclude(Include.NON_NULL)
	private String perReturnValueTxt;
	@JsonInclude(Include.NON_NULL)
	private List<LineItem> lineItems;
}
