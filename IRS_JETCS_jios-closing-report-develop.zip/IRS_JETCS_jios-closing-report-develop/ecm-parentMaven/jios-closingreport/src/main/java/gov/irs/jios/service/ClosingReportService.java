package gov.irs.jios.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import gov.irs.jios.model.Form;
import gov.irs.jios.config.FormConstants;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class ClosingReportService {

	private final Form4549Service form4595Service;
    private final CommonWorksheetService commonWorksheetService;

	public List<Form> processForms(List<Form> forms, String taxYear, List<String> reportsRequested){
        List<Form> reports = new ArrayList<>();
		Iterator reportsList = reportsRequested.iterator();

		while(reportsList.hasNext()) {

			//for each report listed process forms and generate the report
			String report = reportsList.next().toString();

			switch (report) {
				case FormConstants.DIVWS_2020, FormConstants.DIVWS_2022,
						FormConstants.SCHDWS_2020, FormConstants.SCHDWS_2022:
					reports.add(commonWorksheetService.generateReportFromTaxCalcResponse(forms,taxYear, report));
					break;
				default:


			}
		}
     return reports;
	}




}
