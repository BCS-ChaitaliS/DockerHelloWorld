package gov.irs.jios.model;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class JiosHeader {
	
    @Pattern(regexp = "[a-zA-Z0-9\"/-]{0,250}", message = "{error.header.tax_period")
    private String taxPrd;
    
    @Pattern(regexp = "[a-zA-Z0-9\"/-]{0,250}", message = "{error.header.mft_code}")
    private String mftCd;
    
    @Pattern(regexp = "[a-zA-Z0-9\"/-]{0,250}", message = "{error.header.unique_calculation_id}")
    private String correlationId;
    
    @Pattern(regexp = "[a-zA-Z0-9\"/-]{0,250}", message = "{error.header.unique_calculation_id}")
    private String transactionId;
    
    @Pattern(regexp = "[a-zA-Z0-9\"/-]{0,250}", message = "{error.header.unique_calculation_id}")
    private String reportDt;

    @Pattern(regexp = "[a-zA-Z0-9\"/-]{0,250}", message = "{error.header.unique_calculation_id}")
    private String submitterId;

    private ArrayList<String> reportsRequested;


}
