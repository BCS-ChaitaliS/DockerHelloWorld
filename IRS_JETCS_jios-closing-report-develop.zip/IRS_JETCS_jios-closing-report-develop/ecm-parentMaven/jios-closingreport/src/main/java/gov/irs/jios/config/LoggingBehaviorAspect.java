package gov.irs.jios.config;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


@Aspect
@Component
public class LoggingBehaviorAspect {
	private static final Logger logger = LoggerFactory.getLogger(LoggingBehaviorAspect.class);
	
	/* Log INFO message Before method execution */
	@Before("execution(* gov.irs.jios..*(..))") 
	public void logBeforeMethodExecution(JoinPoint joinPoint) {
		logger.info("Method begins: {} with arguments: {}", joinPoint.getSignature().getName(), joinPoint.getArgs()); //joinPoint access method details(name,args,etc.)
	}
	
	/*Log INFO message After method execution*/
	@After("execution(* gov.irs.jios..*(..))")
	public void logAfterMethodExecution(JoinPoint joinPoint) {
		logger.info("Method ends: {}", joinPoint.getSignature().getName());
	}
	
	/* Log ERROR after method throws Exception */
	@AfterThrowing(pointcut = "execution(* gov.irs.jios..*(..))", throwing = "error")
	public void logAfterThrowing(JoinPoint joinPoint, Throwable error) {
		logger.error("Exception in method: {} with cause: {}", joinPoint.getSignature().getName(), error.getMessage());
	}
	
	/* Log and DEBUG level message around method execution
	 * Calculate execution time for performance profiling
	 * */
	@Around("execution(* gov.irs.jios..*(..))")
	public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
		long startTime=System.currentTimeMillis();
		Object result = joinPoint.proceed(); //Indicates the start of method execution
		
	    long methodExecutionTime = System.currentTimeMillis() - startTime;
	    logger.debug("Execution time of {} is {} ms", joinPoint.getSignature().getName(), methodExecutionTime);
	    
	    return result;
		
	}
}
