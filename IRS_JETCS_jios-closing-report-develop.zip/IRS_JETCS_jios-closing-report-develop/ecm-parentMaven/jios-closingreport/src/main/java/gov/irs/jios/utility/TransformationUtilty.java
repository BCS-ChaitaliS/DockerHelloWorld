package gov.irs.jios.utility;

import gov.irs.jios.model.Form;
import gov.irs.jios.model.LineItem;
import gov.irs.jios.config.FormConstants;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;


import java.util.ArrayList;
import java.util.List;


@Component
public class TransformationUtilty {

   private static final String SCHD_TAXWORKSHEET_YAML = "SchDTaxWorkSheet";

     /**
     * Method to transform a form to report with no nested line structure
     * @param form
     * @param taxYear
     * @return
     * @throws Exception
     */
    public static Form transformFormToReport(Form form , String taxYear) throws Exception{
        if(form!= null && !CollectionUtils.isEmpty(form.getLineItems())){
            Form report = Form.builder().formNum(form.getFormNum()).lineItems(new ArrayList<LineItem>()).build();
            report.setFormNum(form.getFormNum());
            //prepare line items
            List<LineItem> reportLineItems = new ArrayList<>();
            processLineItems(form.getLineItems(), reportLineItems);
            report.setLineItems(reportLineItems);
           return report;
        }
       return null;
    }

    /**
     * To Iteratively process the lineItems
     * @param lineItems
     * @param reportLineItems
     */
    private static void processLineItems(List<LineItem> lineItems, List<LineItem> reportLineItems){
        for(LineItem formLineItem: lineItems){
            LineItem lineItem = LineItem.builder().lineNameTxt(formLineItem.getLineNameTxt()).lineValueTxt(formLineItem.getTotalAdjTaxCalcValueTxt()).sequenceNum(formLineItem.getSequenceNum()).build();

            if(!CollectionUtils.isEmpty(lineItem.getLineItems())){
                List<LineItem> subReportLineItems =new ArrayList<>();
                processLineItems(lineItem.getLineItems(),subReportLineItems);
                lineItem.setLineItems(subReportLineItems);
            }
           reportLineItems.add(lineItem);
        }
    }
    private String getMappingYaml(String formName){
        switch (formName) {

            case FormConstants.SCHDWS_2020:
                return SCHD_TAXWORKSHEET_YAML;
            default:
                return formName;
        }
    }
}
