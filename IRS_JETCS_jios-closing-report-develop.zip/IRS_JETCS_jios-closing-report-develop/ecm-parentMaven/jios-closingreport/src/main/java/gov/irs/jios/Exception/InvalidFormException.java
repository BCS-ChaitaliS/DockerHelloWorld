package gov.irs.jios.Exception;

public class InvalidFormException extends RuntimeException{
    private static final long serialVersionUID = 2L;

    public InvalidFormException(String errorMessage) {
        super(errorMessage);
    }
}
