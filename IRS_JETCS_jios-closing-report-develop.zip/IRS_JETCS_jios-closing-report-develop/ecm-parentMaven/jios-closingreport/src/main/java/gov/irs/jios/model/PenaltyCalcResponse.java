package gov.irs.jios.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown =true)
@Builder
public class PenaltyCalcResponse {
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    MainResponse mainRes;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    AddedTransactions addedTxns;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    List<Object> reports;
}
