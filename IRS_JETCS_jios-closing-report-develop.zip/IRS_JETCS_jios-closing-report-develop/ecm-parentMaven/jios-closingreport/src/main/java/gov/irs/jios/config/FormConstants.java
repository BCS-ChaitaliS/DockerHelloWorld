package gov.irs.jios.config;

public class FormConstants {

    public static final String FORM4549 = "IRS4549";
    public static final String FORM1040 = "IRS1040";
    public static final String FORM4952 = "IRS4952";
    public static final String SCHDWS_2020 = "SchDWorksheet2020";

    public static final String SCHDWS_2022 = "SchDWorksheet2022";
    public static final String DIVWS_2020 = "DivWorksheet2020";
    public static final String DIVWS_2022 = "DivWorksheet2022";
}
