package gov.irs.jios.service;

import gov.irs.jios.config.LineNum4549;
import gov.irs.jios.model.Form;
import gov.irs.jios.model.LineItem;
import gov.irs.jios.utility.CommonUtility;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class Form4549Service {

    private static final String DELIMITER = "-";

    /**
     * Process Form4549 for line calculations
     * @param form4549
     * @param taxPeriod
     */
    public void processForm(Form form4549, String taxPeriod) {
        try {

           // Map<String, String> lineNameMap = CommonUtility.retrieveLineNamesFromYaml(form4549.getFormNum(), taxPeriod);
            Map<String, LineItem> lineItemMap = CommonUtility.transformLineItemsListToMap(form4549.getLineItems());
            //TODO: calculations
            // Line 2
            calculateTotalAdjustmentAmt(lineItemMap);


            form4549.setLineItems(lineItemMap.values().stream().toList());
        } catch (Exception e) {
           log.error("Failed to process 4595" + e.getMessage());
        }
    }

    /**
     * To Calculate Line 2 Total Adjustments Amt
     * @param lineItemMap
     */
    public void calculateTotalAdjustmentAmt(Map<String, LineItem> lineItemMap) {
        try {
             //LineItem lineItem1 = lineItemMap.containsKey(lineNameMap.get("LINE1"))?lineItemMap.get(lineNameMap.get("LINE1")):lineItemMap.get(lineNameMap.get("LINE1") + "_1");
            LineItem lineItem1 = lineItemMap.containsKey(LineNum4549.LINE1)?lineItemMap.get(LineNum4549.LINE1):lineItemMap.get(LineNum4549.LINE1+ "-1");

            System.out.println("lineItem1 " + lineItem1.getLineNameTxt());
            List<LineItem> lineItem1List = lineItem1.getLineItems();
            String lineItem2Name = lineItemMap.containsKey(LineNum4549.LINE2)?LineNum4549.LINE2:LineNum4549.LINE2 + "-1";
            List<LineItem> lineItem2List = lineItemMap.get(lineItem2Name).getLineItems();
            Map<String, LineItem> aggregateLine2Map = CommonUtility.transformLineItemsListToMap(lineItem2List);
            String amountLineName = LineNum4549.LINE1_AdjAmt;
            String aggregateAmountLineName =LineNum4549.LINE2_totAdjAmt;
            BigDecimal total_1 = BigDecimal.ZERO;
            BigDecimal total_2 = BigDecimal.ZERO;
            BigDecimal total_3 = BigDecimal.ZERO;

            if (!lineItem1List.isEmpty()) {
                //Iterate 1a through 1p
                lineItem1List.forEach(lineItemAdjustment -> {
                    List<LineItem> amountLineItems = lineItemAdjustment.getLineItems();
                    Map<String, LineItem> amountLineMap = CommonUtility.transformLineItemsListToMap(amountLineItems);
                    int column = 1;
                    //Iterate through amounts for each period to calculate the total for each of the tax period
                    while (amountLineMap.containsKey(amountLineName + DELIMITER + column)) {
                        BigDecimal total = new BigDecimal(aggregateLine2Map.get(aggregateAmountLineName + DELIMITER + column).getLineValueTxt());
                        total = total.add(new BigDecimal(amountLineMap.get(amountLineName + DELIMITER + column).getLineValueTxt()));
                        aggregateLine2Map.get(aggregateAmountLineName + DELIMITER + column).setLineValueTxt(String.valueOf(total));
                        column++;
                    }
                });
            }
            //set the Line2 Items back to the main linItemMap
            lineItemMap.get(lineItem2Name).setLineItems(aggregateLine2Map.values().stream().toList());
        } catch (Exception e) {
            log.error("Failed to calculate Line 2 "+e.getMessage()) ;
        }

    }
}