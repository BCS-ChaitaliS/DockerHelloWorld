package gov.irs.jios.config;

public class LineNum4549 {

    public static final String LINE1= "/IRS4549/adjustmentsToIncomeGroup";
    public static final String LINE2 = "/IRS4549/AdjustmentsToIncome/totaladjustmentAmtGroup";
    public static final String LINE1_AdjName= "/IRS4549/adjustmentsToIncomeGroup/issueNm";
    public static final String LINE1_AdjAmt = "/IRS4549/adjustmentsToIncomeGroup/adjustmentAmt";
    public static final String  LINE2_totAdjAmt = "/IRS4549/AdjustmentsToIncome/totalAdjustmentAmt";
}
