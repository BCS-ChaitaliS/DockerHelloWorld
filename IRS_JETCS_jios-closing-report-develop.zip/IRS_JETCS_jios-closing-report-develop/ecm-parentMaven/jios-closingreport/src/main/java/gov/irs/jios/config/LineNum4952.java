package gov.irs.jios.config;

public class LineNum4952 {
    private LineNum4952(){}

    public static final String LINE1="/IRS4952/InvestmentInterestExpenseAmt";
    public static final String LINE2="/IRS4952/PriorYrDisallowInvsmtIntExpAmt";
    public static final String LINE3="/IRS4952/TotalInvestmentInterestExpAmt";
    public static final String LINE4a="/IRS4952/InvestmentPropGrossIncomeAmt";
    public static final String LINE4b="/IRS4952/InvestmentPropQualDividendsAmt";
    public static final String LINE4c="/IRS4952/InvestmentPropNetGrossIncAmt";
    public static final String LINE4d="/IRS4952/InvestmentPropNetDispGainAmt";
    public static final String LINE4e="/IRS4952/PropertyDspstnCapGainInvIncAmt";
    public static final String LINE4f="/IRS4952/InvestmentNetGainLessSmallAmt";
    public static final String LINE4g="/IRS4952/InvestmentIncomeElectionAmt";
    public static final String LINE4h="/IRS4952/InvestmentIncomeAmt";
    public static final String LINE5="/IRS4952/InvestmentExpenseAmt";
    public static final String LINE6="/IRS4952/NetInvestmentIncomeAmt";
    public static final String LINE7="/IRS4952/DisallowedCarryForwardExpAmt";
    public static final String LINE8="/IRS4952/InvestmentInterestExpDeductAmt";
}
