package gov.irs.jios.service;

import gov.irs.jios.config.FormConstants;
import gov.irs.jios.model.Form;
import gov.irs.jios.model.LineItem;
import gov.irs.jios.model.TaxPeriod;
import gov.irs.jios.utility.CommonUtility;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
@ExtendWith(SpringExtension.class)
@Slf4j
public class ClosingReportServiceTest {

    @InjectMocks
    private ClosingReportService closingReportService;

    @Mock
    private Form4549Service form4549Service;

    @Mock
    private CommonWorksheetService commonWorksheetService;

    private static final String SCHD_TAXWORKSHEET_YAML = "SchDTaxWorkSheet";

    @Test
    public void testprocessForms(){
        List<TaxPeriod> taxPeriodList = prepareFormsList();

        when(commonWorksheetService.generateReportFromTaxCalcResponse(taxPeriodList.get(0).getForms(),"2020",FormConstants.SCHDWS_2020)).thenReturn(Form.builder().formNum("SchDWorksheet2020").build());
        List<Form> processedForms = closingReportService.processForms(taxPeriodList.get(0).getForms(), "2020", taxPeriodList.get(0).getReportsRequested());
        Map<String, Form> formMap = CommonUtility.transformFormsListToMap(processedForms);
        assertTrue( formMap.containsKey(FormConstants.SCHDWS_2020));

    }

    private List<TaxPeriod> prepareFormsList(){
        List<TaxPeriod> taxPeriods = new ArrayList<>();
        taxPeriods.add(getTaxPeriod());
        return taxPeriods;
    }

    private TaxPeriod getTaxPeriod(){
        try {
            return TaxPeriod.builder().taxPrd("2020").forms(List.of(prepareSchDWSheet())).sequenceNum("1").reportsRequested(List.of("accur2", "SchDWorksheet2020")).build();
        }catch(Exception e){
           log.error("Failed to prepare TaxPeriod object"+e.getMessage());
        }
        return null;
    }
    private Form prepareSchDWSheet() throws IOException {
        Form form = Form.builder().formNum(FormConstants.SCHDWS_2020).build();
        Map<String, String> lineMap = CommonUtility.retrieveLineNamesFromYaml(SCHD_TAXWORKSHEET_YAML,"202012" );

        List<LineItem> lineItemList = new ArrayList<>();
        for(String line : lineMap.keySet().stream().toList()){
            lineItemList.add(LineItem.builder().lineNameTxt(lineMap.get(line)).sequenceNum("1").perReturnValueTxt("2").totalAdjTaxCalcValueTxt("1000").build());
        }
        form.setLineItems(lineItemList);
        return form;
    }
}
