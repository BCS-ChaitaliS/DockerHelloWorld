package gov.irs.jios.utility;


import gov.irs.jios.config.FormConstants;
import gov.irs.jios.config.LineNum4549;
import gov.irs.jios.model.Form;
import gov.irs.jios.model.LineItem;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@ExtendWith(SpringExtension.class)
public class CommonUtilityTest {
    private static final String DELIMITER= "-";

    @Test
    public void testRetrieveLineNamesFromYaml() throws IOException {
       Map<String,String> lineNamesMap =  CommonUtility.retrieveLineNamesFromYaml(FormConstants.SCHDWS_2020, "2020");
       assertNotNull(lineNamesMap);
        assertEquals("/SchDWorksheet2020/f1040TxblIncomeExamAmt", lineNamesMap.get("LINE1"));
    }

    @Test
    public void testTransformFormsListToMap(){
       List<Form> forms = List.of(getForm4549());
       Map<String, Form> formsMap = CommonUtility.transformFormsListToMap(forms);
       assertNotNull(formsMap);
       assertTrue(formsMap.containsKey(FormConstants.FORM4549));
    }

    @Test
    public void testTransformLineItemsListToMap(){
         List<Form> forms = List.of(getForm4549());
        Map<String, LineItem> lineItemsMap = CommonUtility.transformLineItemsListToMap(forms.get(0).getLineItems());
        assertNotNull(lineItemsMap);
        assertTrue(lineItemsMap.containsKey("/IRS4549/adjustmentsToIncomeGroup"+DELIMITER+"1"));
    }

    private Form getForm4549() {
        List<LineItem> lineItems = new ArrayList<>();
        List<LineItem> subLineItemsList = new ArrayList<>();
        subLineItemsList.add(LineItem.builder().lineNameTxt(LineNum4549.LINE1_AdjName).sequenceNum("1")
                .lineItems(List.of(LineItem.builder().lineValueTxt("4000.00").lineNameTxt(LineNum4549.LINE1_AdjAmt).sequenceNum("1").build())).build());
        subLineItemsList.add(LineItem.builder().lineNameTxt(LineNum4549.LINE1_AdjName).sequenceNum("2")
                .lineItems(List.of(LineItem.builder().lineValueTxt("530.00").lineNameTxt(LineNum4549.LINE1_AdjAmt).sequenceNum("1").build())).build());

        lineItems.add(LineItem.builder().lineNameTxt(LineNum4549.LINE1).lineValueTxt("4000").sequenceNum("1").lineItems(subLineItemsList).build());
        lineItems.add(LineItem.builder().lineNameTxt(LineNum4549.LINE2).lineValueTxt("0").sequenceNum("1").lineItems(List.of(LineItem.builder().lineNameTxt(LineNum4549.LINE2_totAdjAmt).sequenceNum("1").lineValueTxt("0").build())).build());

        return Form.builder().formNum(FormConstants.FORM4549).lineItems(lineItems).build();
    }

}
