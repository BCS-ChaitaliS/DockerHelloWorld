package gov.irs.jios.service;

import gov.irs.jios.config.FormConstants;
import gov.irs.jios.config.LineNum4549;
import gov.irs.jios.model.Form;
import gov.irs.jios.model.LineItem;
import gov.irs.jios.utility.CommonUtility;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@ExtendWith(SpringExtension.class)
public class Form4549ServiceTest {

    @InjectMocks
    private Form4549Service form4549Service;

    @Test
    public void testProcessForm(){
        Form form = getForm4549();
        form4549Service.processForm(form, "2023");
        Map<String, LineItem> lineItemMap = CommonUtility.transformLineItemsListToMap(form.getLineItems());
        assertEquals("4530.00", lineItemMap.get(LineNum4549.LINE2+"-1").getLineItems().get(0).getLineValueTxt());

    }

    @Test
    public void testCalculateTotalAdjustmentAmt(){
        Form form = getForm4549();
        Map<String, LineItem> lineItemMap = CommonUtility.transformLineItemsListToMap(form.getLineItems());
        form4549Service.calculateTotalAdjustmentAmt(lineItemMap);

        assertEquals("4530.00", lineItemMap.get(LineNum4549.LINE2+"-1").getLineItems().get(0).getLineValueTxt());

    }

    private Form getForm4549() {
        List<LineItem> lineItems = new ArrayList<>();
        List<LineItem> subLineItemsList = new ArrayList<>();
        subLineItemsList.add(LineItem.builder().lineNameTxt(LineNum4549.LINE1_AdjName).sequenceNum("1")
                .lineItems(List.of(LineItem.builder().lineValueTxt("4000.00").lineNameTxt(LineNum4549.LINE1_AdjAmt).sequenceNum("1").build())).build());
        subLineItemsList.add(LineItem.builder().lineNameTxt(LineNum4549.LINE1_AdjName).sequenceNum("2")
                .lineItems(List.of(LineItem.builder().lineValueTxt("530.00").lineNameTxt(LineNum4549.LINE1_AdjAmt).sequenceNum("1").build())).build());

        lineItems.add(LineItem.builder().lineNameTxt(LineNum4549.LINE1).lineValueTxt("4000").sequenceNum("1").lineItems(subLineItemsList).build());
        lineItems.add(LineItem.builder().lineNameTxt(LineNum4549.LINE2).lineValueTxt("0").sequenceNum("1").lineItems(List.of(LineItem.builder().lineNameTxt(LineNum4549.LINE2_totAdjAmt).sequenceNum("1").lineValueTxt("0").build())).build());

        return Form.builder().formNum(FormConstants.FORM4549).lineItems(lineItems).build();
    }

}

