package gov.irs.jios.service;

import gov.irs.jios.config.FormConstants;
import gov.irs.jios.config.LineNum1040;
import gov.irs.jios.config.LineNum4952;
import gov.irs.jios.model.Form;
import gov.irs.jios.model.LineItem;
import gov.irs.jios.utility.CommonUtility;
import gov.irs.jios.utility.TransformationUtilty;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TransferQueue;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@ExtendWith(SpringExtension.class)
public class CommonWorksheetServiceTest {

    @InjectMocks
    private CommonWorksheetService commonWorksheetService;

      private Map<String,String> lineNames;

    private static final String SCHD_TAXWORKSHEET_YAML = "SchDTaxWorkSheet";
    private static final String DIVWS_TAXWORKSHEET_YAML = "DivWorksheet";
    @Before
    public void setUp(){
        try {
            lineNames = CommonUtility.retrieveLineNamesFromYaml("SchDTaxWorkSheet", "2020");
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @Test
    public void testGenerateReportFromTaxCalcResponse() throws IOException {
        List<Form> formsList = new ArrayList<>();
        formsList.add(prepareDivWSSheet());
        formsList.add(prepareSchDWSheet());
        Form divWSReport = commonWorksheetService.generateReportFromTaxCalcResponse(formsList, "2020", FormConstants.DIVWS_2020 );
        assertEquals(FormConstants.DIVWS_2020, divWSReport.getFormNum());
        assertEquals("1000", divWSReport.getLineItems().get(0).getLineValueTxt());
    }

    @Test
    public void testGenerateReportFromTaxCalcResponseSchDWS() throws IOException {
        List<Form> formsList = new ArrayList<>();
        formsList.add(prepareDivWSSheet());
        formsList.add(prepareSchDWSheet());
        Form divWSReport = commonWorksheetService.generateReportFromTaxCalcResponse(formsList, "2020", FormConstants.SCHDWS_2020);
        assertEquals(FormConstants.SCHDWS_2020, divWSReport.getFormNum());
        assertEquals("1000", divWSReport.getLineItems().get(0).getLineValueTxt());
    }
    @Test
    public void testProcessForm(){
         List<Form> formsList = new ArrayList<>();
         formsList.add(getForm1040());
         formsList.add(getForm4952());
         Form formschedulD = commonWorksheetService.processForm(formsList, "202012");
         assertEquals(FormConstants.SCHDWS_2020, formschedulD.getFormNum());

    }

    @Test
    public void testPopulateForm1040() {
        Form form1040 = getForm1040();
        Map<String, LineItem> wsLineMap = new HashMap<>();
        Map<String, LineItem> form1040Map = CommonUtility.transformLineItemsListToMap(form1040.getLineItems());
         commonWorksheetService.populateForm1040(form1040Map, wsLineMap, lineNames);
        assertEquals("1000", wsLineMap.get(lineNames.get("LINE1")).getLineValueTxt());
        assertEquals("4000", wsLineMap.get(lineNames.get("LINE2")).getLineValueTxt());
    }

    @Test
    public void testPopulateForm4952()  {
        Form form4952 = getForm4952();
        Map<String, LineItem> wsLineMap = new HashMap<>();
        Map<String, LineItem> form4952Map = CommonUtility.transformLineItemsListToMap(form4952.getLineItems());
        commonWorksheetService.populateForm4952(form4952Map, wsLineMap, lineNames);
        assertEquals("1000", wsLineMap.get(lineNames.get("LINE4")).getLineValueTxt());
        assertEquals("4000", wsLineMap.get(lineNames.get("LINE3")).getLineValueTxt());
    }

    @Test
    public void testCalculateschdWsL3MinusL4Amt()  {

        Map<String, LineItem> wsLineMap = new HashMap<>();
        wsLineMap.put(lineNames.get("LINE4"),LineItem.builder().lineValueTxt("1000").lineNameTxt(lineNames.get("LINE4")).sequenceNum("1").build());
        wsLineMap.put(lineNames.get("LINE3"),LineItem.builder().lineValueTxt("4000").lineNameTxt(lineNames.get("LINE3")).sequenceNum("1").build());
        commonWorksheetService.calculateschdWsL3MinusL4Amt( wsLineMap, lineNames);
        assertEquals("3000", wsLineMap.get(lineNames.get("LINE5")).getLineValueTxt());

    }

    private Form getForm1040() {
        List<LineItem> lineItems = new ArrayList<>();
        lineItems.add(LineItem.builder().lineNameTxt(LineNum1040.LINE15).sequenceNum("1").perReturnValueTxt("1000").build());
        lineItems.add(LineItem.builder().perReturnValueTxt("4000").lineNameTxt(LineNum1040.LINE3A).sequenceNum("1").build());
         return Form.builder().formNum(FormConstants.FORM1040).lineItems(lineItems).build();
    }
    private Form getForm4952() {
        List<LineItem> lineItems = new ArrayList<>();
        lineItems.add(LineItem.builder().lineNameTxt(LineNum4952.LINE4g).sequenceNum("1").perReturnValueTxt("4000").build());
        lineItems.add(LineItem.builder().perReturnValueTxt("1000").lineNameTxt(LineNum4952.LINE4e).sequenceNum("1").build());
        return Form.builder().formNum(FormConstants.FORM4952).lineItems(lineItems).build();
    }

    private Form prepareSchDWSheet() throws IOException {
        Form form = Form.builder().formNum(FormConstants.SCHDWS_2020).build();
        Map<String, String> lineMap = CommonUtility.retrieveLineNamesFromYaml(SCHD_TAXWORKSHEET_YAML,"202012" );

        List<LineItem> lineItemList = new ArrayList<>();
        for(String line : lineMap.keySet().stream().toList()){
            lineItemList.add(LineItem.builder().lineNameTxt(lineMap.get(line)).sequenceNum("1").perReturnValueTxt("2").totalAdjTaxCalcValueTxt("1000").build());
        }
        form.setLineItems(lineItemList);
        return form;
    }
    private Form prepareDivWSSheet() throws IOException {
        Form form = Form.builder().formNum(FormConstants.DIVWS_2020).build();
        Map<String, String> lineMap = CommonUtility.retrieveLineNamesFromYaml(DIVWS_TAXWORKSHEET_YAML,"202012" );

        List<LineItem> lineItemList = new ArrayList<>();
        for(String line : lineMap.keySet().stream().toList()){
            lineItemList.add(LineItem.builder().lineNameTxt(lineMap.get(line)).sequenceNum("1").perReturnValueTxt("2").totalAdjTaxCalcValueTxt("1000").build());
        }
        form.setLineItems(lineItemList);
        return form;
    }
}
