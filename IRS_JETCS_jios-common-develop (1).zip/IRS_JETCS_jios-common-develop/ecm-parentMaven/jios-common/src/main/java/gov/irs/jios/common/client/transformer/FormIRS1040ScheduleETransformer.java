package gov.irs.jios.common.client.transformer;

import static gov.irs.jios.common.util.JiosCommonConstants.LINE_ITEMS;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_NAME_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.PER_RETURN_VALUE_TXT;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FormIRS1040ScheduleETransformer {

	public static final String IRS1040ScheduleE = "IRS1040ScheduleE";
	public static final String GroupField = "RNT.PROP";

	public List<FieldMapping> transformFormIRS1040ScheduleE(Map<String, Object> formData, Map<String, Object> header) {
		List<FieldMapping> fieldMappings = new ArrayList<>();
		if (formData == null || header == null) {
			log.warn("FormData or header is null. Returning empty field mappings.");
			return fieldMappings;
		}

		mapRentsAmt(formData, fieldMappings);

		return fieldMappings;

	}

	@SuppressWarnings("unchecked")
	private void mapRentsAmt(Map<String, Object> formData, List<FieldMapping> fieldMappings) {

		List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
		if (lineItems == null) {
			log.warn("No lineItems found in formData");
			return;
		}

		Properties properties = new Properties();
		try (InputStream is = getClass().getClassLoader().getResourceAsStream("common/application.properties")) {
			properties.load(is);
		} catch (Exception e) {
			log.error("Exception reading application.properties " + e.getMessage());
		}

		for (Map<String, Object> lineItem : lineItems) {
			if ("/IRS1040ScheduleE/PropertyRealEstAndRoyaltyGroup".equals(lineItem.get(LINE_NAME_TXT))) {

				List<Map<String, Object>> grpPropertyLineItems = (List<Map<String, Object>>) lineItem.get(LINE_ITEMS);
				for (Map<String, Object> propertyLineItem : grpPropertyLineItems) {
					if ("/IRS1040ScheduleE/PropertyRealEstAndRoyaltyGroup/RentsReceivedAmt"
							.equals(propertyLineItem.get(LINE_NAME_TXT))) {
						String rentVal = (String) propertyLineItem.get(PER_RETURN_VALUE_TXT);
						if (rentVal != null && !rentVal.isEmpty()) {
							addFieldMapping(fieldMappings,
									"/IRS1040ScheduleE/PropertyRealEstAndRoyaltyGroup/RentsReceivedAmt", "X91.3583.1",
									rentVal);

							addFieldMapping(fieldMappings, "RNT.ROYCODE", properties.getProperty("mock.empty.string"));
						}

					} else if ("/IRS1040ScheduleE/PropertyRealEstAndRoyaltyGroup/TotalRoyaltiesReceivedAmt"
							.equals(propertyLineItem.get(LINE_NAME_TXT))) {
						String royaltyVal = (String) propertyLineItem.get(PER_RETURN_VALUE_TXT);
						if (royaltyVal != null && !royaltyVal.isEmpty()) {
							addFieldMapping(fieldMappings,
									"/IRS1040ScheduleE/PropertyRealEstAndRoyaltyGroup/TotalRoyaltiesReceivedAmt",
									"X91.3583.1", royaltyVal);

							addFieldMapping(fieldMappings, "RNT.ROYCODE",
									properties.getProperty("mock.schedulee.rent.roycode"));
						}

					}
				}
			}
		}

	}

	private List<FieldMapping> addFieldMapping(List<FieldMapping> mappings, String sourceField, String targetField,
			String targetFieldValue) {
		FieldMapping mapping = new FieldMapping();
		mapping.setSourceForm(IRS1040ScheduleE);
		mapping.setSourceField(sourceField);
		mapping.setTargetField(targetField);
		mapping.setTargetFieldValue(targetFieldValue);
		mapping.setGroupField(GroupField);
		mappings.add(mapping);
		return mappings;
	}

	private void addFieldMapping(List<FieldMapping> mappings, String targetField, String targetFieldValue) {
		addFieldMapping(mappings, null, targetField, targetFieldValue);
	}
}
