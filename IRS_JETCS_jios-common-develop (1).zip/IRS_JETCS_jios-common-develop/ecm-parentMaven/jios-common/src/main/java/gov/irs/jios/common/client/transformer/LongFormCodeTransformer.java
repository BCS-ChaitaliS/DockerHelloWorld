package gov.irs.jios.common.client.transformer;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

@Slf4j
/**
 * If ECM sends some sort of code as a long form string (see DueDiligenceCd for form 2441),
 * and TR accepts a different type, make a map and a method for it here.
 */
public class LongFormCodeTransformer {
	static BiMap<String, String> FORM_2441_DD_MAP;
	static {
		Map<String, String> PRE_ECM_TO_TR_MAP = new HashMap<>();
		PRE_ECM_TO_TR_MAP.put("A", "THE PROVIDER HAS MOVED AND I AM UNABLE TO FIND THE PROVIDER TO GET THE TIN");
		PRE_ECM_TO_TR_MAP.put("B", "THE PROVIDER HAS REFUSED TO GIVE ME THE TIN");
		PRE_ECM_TO_TR_MAP.put("C", ""); // This may be wrong
		FORM_2441_DD_MAP = HashBiMap.create(PRE_ECM_TO_TR_MAP);
	}
	public static String transformDueDiligenceCdECMToTR(String ecmIndicatorValue) {
		try {
			if (ecmIndicatorValue == null) {
				ecmIndicatorValue = "";
			}
			return FORM_2441_DD_MAP.inverse().get(ecmIndicatorValue);
		} catch (Exception e){
			log.warn("LongFormCodeTransformer: " + e.getMessage());
			return "";
		}
	}

	public static String transformDueDiligenceCdTRToECM(String trIndicatorValue) {
		try {
			String ecmIndicator = FORM_2441_DD_MAP.get(trIndicatorValue);
			if (ecmIndicator == null) {
				throw new IllegalArgumentException("Invalid TR Indicator value: " + trIndicatorValue);
			}
			return ecmIndicator;
		} catch (Exception e){
			log.warn("LongFormCodeTransformer: " + e.getMessage());
			return "";
		}
	}
}
