package gov.irs.jios.common.client.transformer;

import static gov.irs.jios.common.util.JiosCommonConstants.LINE_ITEMS;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_NAME_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.PER_RETURN_VALUE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.PRIMARY_TIN;
import static gov.irs.jios.common.util.JiosCommonConstants.SECONDARY_TIN;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FormIRS5695Transformer {

	public static final String IRS5695 = "IRS5695";

	public List<FieldMapping> transformFormIRS5695(Map<String, Object> formData, Map<String, Object> header) {
		List<FieldMapping> fieldMappings = new ArrayList<>();

		if (formData == null || header == null) {
			log.warn("FormData or header is null. Returning empty field mappings.");
			return fieldMappings;
		}

		String ssn = extractSSN(formData);

		if (ssn == null) {
			log.warn("Unable to extract SSN from formData. Returning empty field mappings.");
			return fieldMappings;
		}

		String primaryTIN = (String) header.get(PRIMARY_TIN);
		String secondaryTIN = (String) header.get(SECONDARY_TIN);

		if (primaryTIN == null && secondaryTIN == null) {
			log.warn("Both primaryTIN and spouseTIN are null in header. Returning empty field mappings.");
			return fieldMappings;
		}

		@SuppressWarnings("unchecked")
		List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
		if (lineItems == null) {
			log.warn("No lineItems found in formData");
			return fieldMappings;
		}

		if (Objects.equals(ssn, primaryTIN)) {
			
			//extracting the values for the primary 5695 form (sequence 1)
			String insulationOrSysHtGnLossCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/InsulationOrSysHtGnLossCostAmt");
			String mostExpnsExtrDoorCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/MostExpnsExtrDoorCostAmt");
			String otherQlfyExtrDoorsCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/OtherQlfyExtrDoorsCostAmt");
			String exteriorWndwOrSkylightCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/ExteriorWndwOrSkylightCostAmt");
			String centralAirCondCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/CentralAirCondCostAmt");
			String natGasPrpnOilWtrHtrCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/NatGasPrpnOilWtrHtrCostAmt");
			String natGasPrpnOilHotWtrBlrCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/NatGasPrpnOilHotWtrBlrCostAmt");
			String panelboardCktFeederCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/PanelboardCktFeederCostAmt");
			String mainHomeEgyAuditCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/MainHomeEgyAuditCostAmt");
			String elecGasHtPumpCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/ElecGasHtPumpCostAmt");
			String elecGasHtPumpWtrHeaterCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/ElecGasHtPumpWtrHeaterCostAmt");
			String bmssStoveBoilerCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/BmssStoveBoilerCostAmt"); 
			String homeLocatedInUSAInd = PropertyIndValueTransformer.transformEcmToTr(extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/HomeLocatedInUSAInd")); 
			String originalUserInd = PropertyIndValueTransformer.transformEcmToTr(extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/OriginalUserInd")); 
			String fiveYearUseExpectationInd = PropertyIndValueTransformer.transformEcmToTr(extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/FiveYearUseExpectationInd")); 
			String imprvRltdToConstMainHomeInd = PropertyIndValueTransformer.transformEcmToTr(extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/ImprvRltdToConstMainHomeInd")); 
			String qlfyEnergyPropCostsUSHomeInd = PropertyIndValueTransformer.transformEcmToTr(extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/QlfyEnergyPropCostsUSHomeInd"));
			String originallyPlacedInServiceInd = PropertyIndValueTransformer.transformEcmToTr(extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/OriginallyPlacedInServiceInd")); 
			String mainHomeEgyAuditCostInd = PropertyIndValueTransformer.transformEcmToTr(extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/MainHomeEgyAuditCostInd")); 
			
			//adding the fields to the fieldMappings for the Primary
			addFieldMapping(fieldMappings, "/IRS5695/ResidentialCleanEnergyCrGrp/SolarElecPropCostAmt", "X122.1799.1");
			addFieldMapping(fieldMappings, "/IRS5695/ResidentialCleanEnergyCrGrp/SolarWaterHtPropCostAmt","X122.1799.2");
			addFieldMapping(fieldMappings, "/IRS5695/ResidentialCleanEnergyCrGrp/SmallWindPropCostAmt", "X122.1799.6");
			addFieldMapping(fieldMappings, "/IRS5695/ResidentialCleanEnergyCrGrp/GeothrmlHtPumpPropCostAmt","X122.1799.8");
			addFieldMapping(fieldMappings, "/IRS5695/ResidentialCleanEnergyCrGrp/QlfyBatteryStorageTechCostsAmt","X122.1799.24");
			addFieldMapping(fieldMappings, "/IRS5695/ResidentialCleanEnergyCrGrp/FuelCellPropCostAmt", "X122.1799.3");
			addFieldMapping(fieldMappings, "/IRS5695/ResidentialCleanEnergyCrGrp/FuelCellPropKWCapAmt", "X122.1799.4");
			addFieldMapping(fieldMappings, "/IRS5695/ResidentialCleanEnergyCrGrp/PYCfwdRsdntlCleanEnergyCrAmt","X122.1799.5");
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/InsulationOrSysHtGnLossCostAmt","X122.2576.16", insulationOrSysHtGnLossCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/MostExpnsExtrDoorCostAmt", "X122.2576.18", mostExpnsExtrDoorCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/OtherQlfyExtrDoorsCostAmt", "X122.2576.20", otherQlfyExtrDoorsCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/ExteriorWndwOrSkylightCostAmt","X122.2576.22", exteriorWndwOrSkylightCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/CentralAirCondCostAmt", "X122.2577.8", centralAirCondCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/NatGasPrpnOilWtrHtrCostAmt", "X122.2577.10", natGasPrpnOilWtrHtrCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/NatGasPrpnOilHotWtrBlrCostAmt","X122.2577.12", natGasPrpnOilHotWtrBlrCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/PanelboardCktFeederCostAmt", "X122.2577.14", panelboardCktFeederCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/MainHomeEgyAuditCostAmt", "X122.2577.18", mainHomeEgyAuditCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/ElecGasHtPumpCostAmt", "X122.2577.20", elecGasHtPumpCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/ElecGasHtPumpWtrHeaterCostAmt","X122.2577.22", elecGasHtPumpWtrHeaterCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/BmssStoveBoilerCostAmt", "X122.2577.24", bmssStoveBoilerCostAmt);
			
			//adding Indicators fields to fieldMappings for Primary
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/HomeLocatedInUSAInd", "X122.2576.0", homeLocatedInUSAInd);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/OriginalUserInd", "X122.2576.2", originalUserInd);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/FiveYearUseExpectationInd", "X122.2576.4", fiveYearUseExpectationInd);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/ImprvRltdToConstMainHomeInd", "X122.2576.14", imprvRltdToConstMainHomeInd);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/QlfyEnergyPropCostsUSHomeInd", "X122.2577.0", qlfyEnergyPropCostsUSHomeInd);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/OriginallyPlacedInServiceInd", "X122.2577.2", originallyPlacedInServiceInd);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/MainHomeEgyAuditCostInd", "X122.2577.16", mainHomeEgyAuditCostInd);
			
		} else if (Objects.equals(ssn, secondaryTIN)) {
			
			//extracting the values from the spouse 5695 form (sequence 2)
			String insulationOrSysHtGnLossCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/InsulationOrSysHtGnLossCostAmt");
			String mostExpnsExtrDoorCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/MostExpnsExtrDoorCostAmt");
			String otherQlfyExtrDoorsCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/OtherQlfyExtrDoorsCostAmt");
			String exteriorWndwOrSkylightCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/ExteriorWndwOrSkylightCostAmt");
			String centralAirCondCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/CentralAirCondCostAmt");
			String natGasPrpnOilWtrHtrCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/NatGasPrpnOilWtrHtrCostAmt");
			String natGasPrpnOilHotWtrBlrCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/NatGasPrpnOilHotWtrBlrCostAmt");
			String panelboardCktFeederCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/PanelboardCktFeederCostAmt");
			String mainHomeEgyAuditCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/MainHomeEgyAuditCostAmt");
			String elecGasHtPumpCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/ElecGasHtPumpCostAmt");
			String elecGasHtPumpWtrHeaterCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/ElecGasHtPumpWtrHeaterCostAmt");
			String bmssStoveBoilerCostAmt = extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/BmssStoveBoilerCostAmt"); 
			
			//extracting and applying transformer for Spouse Transformer
			String homeLocatedInUSAInd = PropertyIndValueTransformer.transformEcmToTr(extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/HomeLocatedInUSAInd")); 
			String originalUserInd = PropertyIndValueTransformer.transformEcmToTr(extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/OriginalUserInd")); 
			String fiveYearUseExpectationInd = PropertyIndValueTransformer.transformEcmToTr(extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/FiveYearUseExpectationInd")); 
			String imprvRltdToConstMainHomeInd = PropertyIndValueTransformer.transformEcmToTr(extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/ImprvRltdToConstMainHomeInd")); 
			String qlfyEnergyPropCostsUSHomeInd = PropertyIndValueTransformer.transformEcmToTr(extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/QlfyEnergyPropCostsUSHomeInd")); 
			String originallyPlacedInServiceInd = PropertyIndValueTransformer.transformEcmToTr(extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/OriginallyPlacedInServiceInd")); 
			String mainHomeEgyAuditCostInd = PropertyIndValueTransformer.transformEcmToTr(extractTargetFieldValue(formData, "/IRS5695/EgyEffcntHmImprvCrGrp/MainHomeEgyAuditCostInd")); 
			
			
			//adding the fields to the fieldMappings for Spouse 
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/InsulationOrSysHtGnLossCostAmt","X122.2576.17", insulationOrSysHtGnLossCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/MostExpnsExtrDoorCostAmt", "X122.2576.19", mostExpnsExtrDoorCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/OtherQlfyExtrDoorsCostAmt", "X122.2576.21", otherQlfyExtrDoorsCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/ExteriorWndwOrSkylightCostAmt","X122.2576.23", exteriorWndwOrSkylightCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/CentralAirCondCostAmt", "X122.2577.9", centralAirCondCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/NatGasPrpnOilWtrHtrCostAmt", "X122.2577.11", natGasPrpnOilWtrHtrCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/NatGasPrpnOilHotWtrBlrCostAmt","X122.2577.13", natGasPrpnOilHotWtrBlrCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/PanelboardCktFeederCostAmt", "X122.2577.15", panelboardCktFeederCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/MainHomeEgyAuditCostAmt", "X122.2577.19", mainHomeEgyAuditCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/ElecGasHtPumpCostAmt", "X122.2577.21", elecGasHtPumpCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/ElecGasHtPumpWtrHeaterCostAmt","X122.2577.23", elecGasHtPumpWtrHeaterCostAmt);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/BmssStoveBoilerCostAmt", "X122.2577.25", bmssStoveBoilerCostAmt);
			
			//adding Indicators fields to fieldMappings for Spouse
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/HomeLocatedInUSAInd", "X122.2576.1", homeLocatedInUSAInd);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/OriginalUserInd", "X122.2576.3", originalUserInd);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/FiveYearUseExpectationInd", "X122.2576.5", fiveYearUseExpectationInd);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/ImprvRltdToConstMainHomeInd", "X122.2576.15", imprvRltdToConstMainHomeInd);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/QlfyEnergyPropCostsUSHomeInd", "X122.2577.1", qlfyEnergyPropCostsUSHomeInd);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/OriginallyPlacedInServiceInd", "X122.2577.3", originallyPlacedInServiceInd);
			addFieldMapping(fieldMappings, "/IRS5695/EgyEffcntHmImprvCrGrp/MainHomeEgyAuditCostInd", "X122.2577.17", mainHomeEgyAuditCostInd);
			
		} else {
			log.warn("SSN does not match primaryTIN or spouseTIN. Returning empty field mappings.");
		}

		return fieldMappings;
	}

	@SuppressWarnings("unchecked")
	private String extractTargetFieldValue(Map<String, Object> formData, String sourceField) {
		List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
		if (lineItems == null) {
            log.warn("No lineItems found in formData");
            return null;
        }
		
		for (Map<String, Object> lineItem : lineItems) {
			if ("/IRS5695/EgyEffcntHmImprvCrGrp".equals(lineItem.get(LINE_NAME_TXT))) {
				List<Map<String, Object>> nestedLineItems = (List<Map<String, Object>>) lineItem.get(LINE_ITEMS);
				for(Map<String, Object> nestedLineItem: nestedLineItems) {
					if(sourceField.equals(nestedLineItem.get(LINE_NAME_TXT))) {
						String returnValue = (String) nestedLineItem.get(PER_RETURN_VALUE_TXT);
						if(returnValue == null || returnValue.isEmpty()) {
							log.warn("return value is null or empty");
							return null;
						}
						return returnValue;
					}
				}
			}

		}
		return "";
	}

	private String extractSSN(Map<String, Object> formData) {
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
		if (lineItems == null) {
			log.warn("No lineItems found in formData");
			return null;
		}

		for (Map<String, Object> lineItem : lineItems) {
			if ("/IRS5695/SSN".equals(lineItem.get(LINE_NAME_TXT))) {
				String ssn = (String) lineItem.get(PER_RETURN_VALUE_TXT);
				if (ssn == null || ssn.isEmpty()) {
					log.warn("SSN found but value is null or empty");
					return null;
				}
				return ssn;
			}
		}

		log.warn("No line item with lineNameTxt '/IRS5695/SSN' found");
		return null;
	}

	private void addFieldMapping(List<FieldMapping> mappings, String sourceField, String targetField,
			String targetFieldValue) {
		FieldMapping mapping = new FieldMapping();
		mapping.setSourceForm(IRS5695);
		mapping.setSourceField(sourceField);
		mapping.setTargetField(targetField);
		mapping.setTargetFieldValue(targetFieldValue);
		mappings.add(mapping);
	}

	private void addFieldMapping(List<FieldMapping> mappings, String sourceField, String targetField) {
		addFieldMapping(mappings, sourceField, targetField, null);
	}

}
