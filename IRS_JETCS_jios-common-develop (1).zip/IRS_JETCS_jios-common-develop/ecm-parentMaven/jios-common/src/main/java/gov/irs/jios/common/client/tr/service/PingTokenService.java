package gov.irs.jios.common.client.tr.service;

import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import gov.irs.jios.common.client.tr.pojo.PingConfig;
import gov.irs.jios.common.client.tr.pojo.PingTokenResponse;

@Component
public class PingTokenService {
	
	private final WebClient webClient;
	private final PingConfig pingConfig;
	
	//Initialize WebClient in the constructor
	public PingTokenService(WebClient.Builder webClientBuilder, PingConfig pingConfig) {
		this.pingConfig = pingConfig;
		this.webClient = webClientBuilder.baseUrl(pingConfig.getSslEndpoint()).build();
	}
	
	public String getAccessToken() {
		return webClient.post()
				.uri("/as/token.oauth2")
				.header("Content-Type", "application/x-www-form-urlencoded")
				.bodyValue("grant_type=client_credentials&client_id=" + pingConfig.getSslClientId() + "&client_secret=" + pingConfig.getSslClientSecret())
				.retrieve()
				.bodyToMono(PingTokenResponse.class)
				.map(PingTokenResponse::getAccessToken).block();
		
	}

}