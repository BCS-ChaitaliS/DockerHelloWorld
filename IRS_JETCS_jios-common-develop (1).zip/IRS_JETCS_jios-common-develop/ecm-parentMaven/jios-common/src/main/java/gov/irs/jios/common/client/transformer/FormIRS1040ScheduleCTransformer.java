package gov.irs.jios.common.client.transformer;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_ITEMS;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_NAME_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.PER_RETURN_VALUE_TXT;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import lombok.extern.slf4j.Slf4j;

@Slf4j

/**
 * This needs a little save-field logic regarding field X87.650.7
 * This is what the hard coded mapping looked like before
 * {
 *     "sourceForm": "IRS1040ScheduleC",
 *     "targetField": "X87.650.7",
 *     "targetFieldValue": "B",
 *     "groupField": "BUS.PROPNUMBER"
 * },
 */
public class FormIRS1040ScheduleCTransformer {

	public List<FieldMapping> transformFormIRS1040ScheduleC(Map<String, Object> formData, Map<String, Object> header) {
		List<FieldMapping> fieldMappings = new ArrayList<>();
		List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);

		// Find BUS.PARTICIPATE
		boolean busParticValue = false;
		for (Map<String, Object> lineItem : lineItems) {
			if ("/IRS1040ScheduleC/MaterialParticipationInCYInd"
					.equals(lineItem.get(LINE_NAME_TXT))) {
				String busParticValueStr = (String) lineItem.get(PER_RETURN_VALUE_TXT);
				busParticValue = Boolean.parseBoolean(busParticValueStr);
				break;
			}
		}

		if (busParticValue){
			addFieldMapping(
					fieldMappings,
					"IRS1040ScheduleC",
					"X87.650.7",
					"N",
					"BUS.PROPNUMBER"
			);
		} else {
			addFieldMapping(fieldMappings, "IRS1040ScheduleC", "X87.650.7", "B", "BUS.PROPNUMBER");
		}
		/* fieldMappings = addGrossReceiptsAmt(fieldMappings, lineItems); */
		return fieldMappings;
	}
	/*
	 * private List<FieldMapping> addGrossReceiptsAmt(List<FieldMapping>
	 * fieldMappings, List<Map<String, Object>> lineItems) { boolean
	 * isStatuaryEmplFromW2IndPresent = false; String amt =
	 * findGrossReceiptsAmt(lineItems); if (!amt.equals("")) { for (Map<String,
	 * Object> lineItem : lineItems) { if
	 * ("/IRS1040ScheduleC/StatutoryEmployeeFromW2Ind".equals(lineItem.get(
	 * LINE_NAME_TXT))) { String val = (String) lineItem.get(PER_RETURN_VALUE_TXT);
	 * if (val.equals("X") || val.toUpperCase().equals("TRUE") || val.equals("1")) {
	 * addFieldMapping(fieldMappings, "IRS1040ScheduleC", "X87.407.8", amt,
	 * "BUS.PROPNUMBER"); } else { addFieldMapping(fieldMappings,
	 * "IRS1040ScheduleC", "BUS.TOTRECEIPTS", amt, "BUS.PROPNUMBER"); }
	 * isStatuaryEmplFromW2IndPresent = true; break; } } }
	 * if(!isStatuaryEmplFromW2IndPresent) { addFieldMapping(fieldMappings,
	 * "IRS1040ScheduleC", "BUS.TOTRECEIPTS", amt, "BUS.PROPNUMBER"); } return
	 * fieldMappings; } private String findGrossReceiptsAmt(List<Map<String,
	 * Object>> lineItems) { for (Map<String, Object> lineItem : lineItems) { if
	 * ("/IRS1040ScheduleC/TotalGrossReceiptsAmt".equals(lineItem.get(LINE_NAME_TXT)
	 * )) { return (String) lineItem.get(PER_RETURN_VALUE_TXT); } } return ""; }
	 */
	
	private void addFieldMapping(List<FieldMapping> fieldMappings, String sourceForm, String targetField,
			String targetFieldValue, String groupField) {
		FieldMapping mapping = new FieldMapping();
		mapping.setSourceForm(sourceForm);
		mapping.setTargetField(targetField);
		mapping.setTargetFieldValue(targetFieldValue);
		mapping.setGroupField(groupField);
		fieldMappings.add(mapping);
	}

}