package gov.irs.jios.common.exception;

public class TransformationException extends RuntimeException {

	private static final long serialVersionUID = -2385788835584284019L;

	public TransformationException(String message) {
        super(message);
    }

    public TransformationException(String message, Throwable cause) {
        super(message, cause);
    }
}
