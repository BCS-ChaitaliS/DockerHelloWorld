package gov.irs.jios.common.client.tr.service;

import static gov.irs.jios.common.util.JiosCommonConstants.ADJUSTMENT_STATUS_CD;
import static gov.irs.jios.common.util.JiosCommonConstants.AGREED_ADJ_TAX_CALC_VALUE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.AGREED_ADJ_VALUE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_AGREED;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_NO_CHANGE;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_TOTAL;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PARTIAL;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_UNAGREED;
import static gov.irs.jios.common.util.JiosCommonConstants.EMPTY_STRING;
import static gov.irs.jios.common.util.JiosCommonConstants.EXCLUDE_PENALTY_TYPES1;
import static gov.irs.jios.common.util.JiosCommonConstants.EXCLUDE_PENALTY_TYPES2;
import static gov.irs.jios.common.util.JiosCommonConstants.FORMS;
import static gov.irs.jios.common.util.JiosCommonConstants.FORM_NUM;
import static gov.irs.jios.common.util.JiosCommonConstants.ISSUE_PNLTY_AGREMNT_STATUS_IND;
import static gov.irs.jios.common.util.JiosCommonConstants.ISSUE_PNLTY_TYPE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_ITEMS;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_ITEM_REFERENCE_KEY_ID;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_NAME_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.PCT_20_PENALTY_TYPES;
import static gov.irs.jios.common.util.JiosCommonConstants.PCT_40_PENALTY_TYPES;
import static gov.irs.jios.common.util.JiosCommonConstants.PCT_75_PENALTY_TYPES;
import static gov.irs.jios.common.util.JiosCommonConstants.PER_RETURN_VALUE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.REMOVE_IT_LATER;
import static gov.irs.jios.common.util.JiosCommonConstants.SECOND_CALL_FOR_PARTIAL_TAX_CALC;
import static gov.irs.jios.common.util.JiosCommonConstants.SEQUENCE_NUM;
import static gov.irs.jios.common.util.JiosCommonConstants.STAT_AGREED_ADJ_TAX_CALC_VALUE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.STAT_TOTAL_ADJ_TAX_CALC_VALUE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.TAX_CALCULATOR_VALUE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.TAX_PERIOD;
import static gov.irs.jios.common.util.JiosCommonConstants.TOTAL_ADJ_TAX_CALC_VALUE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.TOTAL_ADJ_VALUE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.USER_ADJ_LINE_IND;
import static gov.irs.jios.common.util.JiosCommonConstants.VARIANCE_VALUE_TXT;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import gov.irs.jios.common.client.config.DynamicMappingConfigLoader;
import gov.irs.jios.common.client.tr.pojo.Field;
import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import gov.irs.jios.common.client.tr.pojo.FieldsRequest;
import gov.irs.jios.common.client.tr.pojo.FieldsResponse;
import gov.irs.jios.common.client.tr.pojo.GroupField;
import gov.irs.jios.common.client.tr.pojo.MappingConfig;
import gov.irs.jios.common.client.tr.pojo.RetrieveFieldsRequest;
import gov.irs.jios.common.client.tr.pojo.RetrieveFieldsResponse;
import gov.irs.jios.common.client.tr.pojo.SaveFieldsRequest;
import gov.irs.jios.common.client.tr.util.TRCommonUtil;
import gov.irs.jios.common.client.transformer.Form1040ScheduleBTransformer;
import gov.irs.jios.common.client.transformer.FormIRS1040ScheduleCTransformer;
import gov.irs.jios.common.client.transformer.FormIRS1040ScheduleETransformer;
import gov.irs.jios.common.client.transformer.FormIRS1040Transformer;
import gov.irs.jios.common.client.transformer.FormIRS4797Transformer;
import gov.irs.jios.common.client.transformer.FormIRS5329Transformer;
import gov.irs.jios.common.client.transformer.FormIRS8839Transformer;
import gov.irs.jios.common.client.transformer.FormIRS8863Transformer;
import gov.irs.jios.common.client.transformer.FormIRS5695Transformer;
import gov.irs.jios.common.exception.ConfigurationException;
import gov.irs.jios.common.pojo.FormIdentifier;
import gov.irs.jios.common.pojo.FormStructureBuilder;
import gov.irs.jios.common.pojo.LineItemStructure;
import gov.irs.jios.common.request.ValidatableRequest;
import gov.irs.jios.common.util.CommonUtil;
import gov.irs.jios.common.util.RequestOverrider;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class TransformationService {
	
    private final ThreadLocal<MappingConfig> currentConfig = new ThreadLocal<>();
    private final DynamicMappingConfigLoader configLoader;
    private final Environment environment;
    private final ConcurrentHashMap<String, Map<String, String>> perReturnValueToTargetFieldMap = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Class<?>> formTransformers = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Integer> groupFieldIndexCounter = new ConcurrentHashMap<>();
    private final ThreadLocal<Map<String, String>> ssnMappingStore = new ThreadLocal<>();
    private String calcTypeTxt;
    
    public TransformationService(DynamicMappingConfigLoader configLoader, Environment environment) {
        this.configLoader = configLoader;
        this.environment = environment;
        // Register form-specific transformers
        formTransformers.put("IRS5329", FormIRS5329Transformer.class);
        formTransformers.put("IRS8839", FormIRS8839Transformer.class);
        formTransformers.put("IRS8863", FormIRS8863Transformer.class);
        formTransformers.put("IRS1040", FormIRS1040Transformer.class);
        formTransformers.put("IRS1040ScheduleE", FormIRS1040ScheduleETransformer.class);
		formTransformers.put("IRS1040ScheduleC", FormIRS1040ScheduleCTransformer.class);
		formTransformers.put("IRS1040ScheduleB", Form1040ScheduleBTransformer.class);
		formTransformers.put("IRS4797", FormIRS4797Transformer.class);
		formTransformers.put("IRS5695", FormIRS5695Transformer.class);
    }
    
    public SaveFieldsRequest transformEcmToTrSaveFields(ValidatableRequest request) {
        log.info("Starting ECM to TR transformation for save fields operation");
        try {
        	groupFieldIndexCounter.clear();
            validateRequest(request);
            initializeConfig(request.getHeader());
            boolean isSecondCallForPartialTaxCalc = false;
            
            // Store SSN mapping for future use
            Map<String, String> ssnMapping = new HashMap<>();
            ssnMapping.put("PRIMARY", (String) request.getHeader().get("primaryTIN"));
            ssnMapping.put("SPOUSE", (String) request.getHeader().get("secondaryTIN"));
            ssnMappingStore.set(ssnMapping);
            
            List<FieldMapping> allMappings = getConfig().getSaveFields().getRequestMapping().getFieldMappings();
            preprocessRequest(request, allMappings);
            
            // Extract calcTypeTxt from the header, if present
            this.calcTypeTxt = (String) request.getHeader().get(CALC_TYPE_TXT);
            if (calcTypeTxt != null) {
            	if (request.getHeader().containsKey(SECOND_CALL_FOR_PARTIAL_TAX_CALC)) {
            		isSecondCallForPartialTaxCalc = (Boolean)request.getHeader().get(SECOND_CALL_FOR_PARTIAL_TAX_CALC);
            	}
            	log.info("Calculation type: {} is second call for Partial Tax Calc: {}", calcTypeTxt, isSecondCallForPartialTaxCalc);
            }

            Map<String, List<Map<String, Object>>> formMap = createFormMap(request.getBody());
            log.info("Created form map with {} unique form types", formMap.size());
            
            List<FieldMapping> fieldMappings = loadRelevantFieldMappings(formMap, request.getHeader(), allMappings);
            log.info("Loaded {} relevant field mappings", fieldMappings.size());
            
            SaveFieldsRequest saveFieldsRequest = new SaveFieldsRequest();
            List<FieldsRequest> fieldsRequests = processAllFields(fieldMappings, formMap, request, isSecondCallForPartialTaxCalc);
            
			RequestOverrider requestOverrider = new RequestOverrider();
			requestOverrider.flagForms(formMap);
			// fieldsRequests should be refactored to avoid reassigning itself.
			fieldsRequests = requestOverrider.customTransformOverFieldsRequests(
					fieldsRequests,
					formTransformers,
					formMap
			);

            postProcessRequest(request);
            
            saveFieldsRequest.setFieldsRequest(fieldsRequests);
            
            log.info("Completed ECM to TR transformation");
            return saveFieldsRequest;
        } finally {
            clearConfig();
        }
    }
    
	private void preprocessRequest(ValidatableRequest request, List<FieldMapping> allMappings) {
        preprocessRelatedFields(request, allMappings);
	}
	
	private void postProcessRequest(ValidatableRequest request) {
        postProcessRelatedFields(request);
	}

	@SuppressWarnings("unchecked")
    private void preprocessRelatedFields(ValidatableRequest request, List<FieldMapping> allMappings) {
        log.info("Starting preprocessing of related fields");
        
        // Build map of related source field mappings
        Map<String, FieldMapping> relatedSourceFieldMappings = new HashMap<>();
        
        // First pass: collect all mappings that have related source fields
        for (FieldMapping mapping : allMappings) {
            if (mapping.getRelatedSourceFields() != null && !mapping.getRelatedSourceFields().isEmpty()) {
                relatedSourceFieldMappings.put(mapping.getSourceField(), mapping);
                log.debug("Added mapping for source field: {} with related fields: {}", 
                    mapping.getSourceField(), mapping.getRelatedSourceFields());
            }
        }

        if (relatedSourceFieldMappings.isEmpty()) {
            log.debug("No related source fields found for preprocessing");
            return;
        }

        // Get forms from request
        Map<String, Object> body = request.getBody();
        List<Map<String, Object>> forms = (List<Map<String, Object>>) body.get(FORMS);
        if (forms == null) {
            log.warn("No forms found in request body");
            return;
        }

        // Process each form
        for (Map<String, Object> form : forms) {
            String formNum = (String) form.get(FORM_NUM);

            // Process each source field that has related fields
            for (String sourceField : relatedSourceFieldMappings.keySet()) {
                FieldMapping mapping = relatedSourceFieldMappings.get(sourceField);
                
                if (!formNum.equals(mapping.getSourceForm())) {
                	continue;
                }
                
                List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get(LINE_ITEMS);
                if (lineItems == null) {
                	continue;
                }
                processFormForRelatedFields(lineItems, mapping, relatedSourceFieldMappings);
            }
        }
        
        log.info("Completed preprocessing of related fields");
    }

    @SuppressWarnings("unchecked")
    private void processFormForRelatedFields(List<Map<String, Object>> lineItems, 
            FieldMapping mapping, Map<String, FieldMapping> relatedSourceFieldMappings) {
        
        // Process current level
        for (int i = 0; i < lineItems.size(); i++) {
            Map<String, Object> lineItem = lineItems.get(i);
                if (lineItem.get(REMOVE_IT_LATER) != null) { //skip as this was added by the framework
                	continue;
                }
            String lineNameTxt = (String) lineItem.get(LINE_NAME_TXT);
            
            if (mapping.getSourceField().equals(lineNameTxt)) {
                // Found matching line item, process its related fields
                for (String relatedSourceField : mapping.getRelatedSourceFields()) {
                    FieldMapping companionMapping = relatedSourceFieldMappings.get(relatedSourceField);
                    if (companionMapping != null) {
                        // Create companion line item using createBasicLineItem
                        Map<String, Object> companionLineItem = createBasicLineItem(
                            companionMapping.getSourceField(), 
                            "false",
                            calcTypeTxt != null
                        );
                        // Add sequence number from original item
                        companionLineItem.put(SEQUENCE_NUM, lineItem.get(SEQUENCE_NUM));
                        // Add flag for post-processing
                        companionLineItem.put(REMOVE_IT_LATER, true);
                        
                        // Insert after current item
                        lineItems.add(i + 1, companionLineItem);
                        i++; // Skip the newly inserted item in next iteration
                        
                        log.debug("Inserted companion line item for {} after {}", 
                            companionMapping.getSourceField(), lineNameTxt);
                    }
                }
            }
            
            // Recursively process nested line items
            List<Map<String, Object>> nestedLineItems = (List<Map<String, Object>>) lineItem.get(LINE_ITEMS);
            if (nestedLineItems != null) {
                processFormForRelatedFields(nestedLineItems, mapping, relatedSourceFieldMappings);
            }
        }
    }
    
    private List<FieldsRequest> processAllFields(List<FieldMapping> fieldMappings, Map<String, List<Map<String, Object>>> formMap, 
    		ValidatableRequest request, boolean isSecondCallForPartialTaxCalc) {
        log.info("Processing all fields");
        List<FieldsRequest> fieldsRequests = new ArrayList<>();
        Map<String, List<FieldsRequest>> groupedFieldsRequests = new HashMap<>();
        Map<String, Map<String, Integer>> groupFieldIndexMap = new HashMap<>();

        // Create a single FieldsRequest for non-grouped fields
        FieldsRequest nonGroupedFieldsRequest = new FieldsRequest();
        nonGroupedFieldsRequest.setGroupField(null);
        nonGroupedFieldsRequest.setFields(new ArrayList<>());

        for (FieldMapping mapping : fieldMappings) {
            if (mapping.getGroupField() == null) {
                processNonGroupedField(mapping, formMap, nonGroupedFieldsRequest.getFields(), request, isSecondCallForPartialTaxCalc);
            } else {
                processGroupedField(mapping, formMap, groupedFieldsRequests, groupFieldIndexMap, request, isSecondCallForPartialTaxCalc);
            }
        }

        // Add the non-grouped FieldsRequest only if it has fields
        if (!nonGroupedFieldsRequest.getFields().isEmpty()) {
            fieldsRequests.add(nonGroupedFieldsRequest);
            log.info("Added {} non-grouped fields", nonGroupedFieldsRequest.getFields().size());
        }

        // Add all grouped fields requests to the main list
        for (List<FieldsRequest> groupRequests : groupedFieldsRequests.values()) {
            fieldsRequests.addAll(groupRequests);
        }

        // Sort the fieldsRequests list
        fieldsRequests.sort((fr1, fr2) -> {
            if (fr1.getGroupField() == null && fr2.getGroupField() == null) {
                return 0;
            }
            if (fr1.getGroupField() == null) {
                return -1;
            }
            if (fr2.getGroupField() == null) {
                return 1;
            }
            int fieldIdComparison = fr1.getGroupField().getFieldId().compareTo(fr2.getGroupField().getFieldId());
            if (fieldIdComparison != 0) {
                return fieldIdComparison;
            }
            return Integer.compare(fr1.getGroupField().getIndex(), fr2.getGroupField().getIndex());
        });

        log.info("Sorted {} field requests", fieldsRequests.size());

        return fieldsRequests;
    }

    private void processNonGroupedField(FieldMapping mapping, Map<String, List<Map<String, Object>>> formMap, List<Field> fields, 
    		ValidatableRequest request, boolean isSecondCallForPartialTaxCalc) {
        if (mapping.getSourceForm() != null && mapping.getSourceField() != null) {
			 // This is a regular mapping
            processNonGroupedFieldMapping(mapping, formMap, fields, request, isSecondCallForPartialTaxCalc);
        } else if (mapping.getTargetFieldValue() != null) {
			// This is a mock value mapping
            Field field = createField(mapping, null, null, 0, request);
            if (field != null) {
                fields.add(field);
                log.debug("Added single mock field: {} with value: {}", field.getFieldId(), field.getValue());
            }
        } else {
            log.warn("Invalid field mapping: {}", mapping);
        }
    }

    private void processGroupedField(FieldMapping mapping, Map<String, List<Map<String, Object>>> formMap,
            Map<String, List<FieldsRequest>> groupedFieldsRequests, Map<String, Map<String, Integer>> groupFieldIndexMap, 
            ValidatableRequest request, boolean isSecondCallForPartialTaxCalc) {
        String groupField = mapping.getGroupField();
        String sourceForm = mapping.getSourceForm();
        String targetField = mapping.getTargetField();
        String sourceField = mapping.getSourceField();
        String groupingKey = mapping.getGroupingKey();
        if (groupingKey == null) {
        	log.debug("Processing grouped field: {} for group: {} in form: {}", targetField, groupField, sourceForm);
        } else {
        	log.debug("Processing grouped field: {} for group: {} with key: {} in form: {}", targetField, groupField, groupingKey, sourceForm);
        }

        int groupIndex = groupFieldIndexCounter.computeIfAbsent(groupField, k -> 0);
        log.debug("Current groupIndex for {}: {}", groupField, groupIndex);

        List<Map<String, Object>> formInstances = formMap.get(sourceForm);
        if (formInstances == null || formInstances.isEmpty()) {
        	log.debug("No form instances found for {}", sourceForm);
            if (mapping.getTargetFieldValue() != null) {
                String groupKey = createGroupKey(groupField, groupingKey, 0);
                List<FieldsRequest> groupRequests = groupedFieldsRequests.computeIfAbsent(groupKey, k -> new ArrayList<>());
                processGroupWithoutFormData(mapping, groupRequests, groupFieldIndexMap.computeIfAbsent(groupKey, k -> new HashMap<>()), 
                		groupIndex, request, isSecondCallForPartialTaxCalc);
                groupFieldIndexCounter.put(groupField, groupIndex + 1);
                log.debug("Processed group without form data. New groupIndex for {}: {}", groupField, groupIndex + 1);
            }
        } else {
            log.debug("Processing {} form instances for {}", formInstances.size(), sourceForm);
            for (int formIndex = 0; formIndex < formInstances.size(); formIndex++) {
                Map<String, Object> form = formInstances.get(formIndex);
                String groupKey = createGroupKey(groupField, groupingKey, formIndex);
                List<FieldsRequest> groupRequests = groupedFieldsRequests.computeIfAbsent(groupKey, k -> new ArrayList<>());
                
                List<Map<String, Object>> sourceFieldInstances = findSourceFieldInstances(form, sourceField);
                if (sourceField != null) {
                	log.debug("Found {} sourceFieldInstances for {} in form index {}", sourceFieldInstances.size(), sourceField, formIndex);
                }
                if (sourceFieldInstances.isEmpty() && mapping.getTargetFieldValue() != null) {
                    sourceFieldInstances.add(new HashMap<>());
                    log.debug("Added empty map for target field value");
                }
                
                if (!sourceFieldInstances.isEmpty()) {
                    FieldsRequest groupedFieldsRequest;
                    if (groupRequests.isEmpty()) {
                        groupedFieldsRequest = getOrCreateGroupedFieldsRequest(groupRequests, groupField, groupIndex, mapping, form, isSecondCallForPartialTaxCalc);
                        groupFieldIndexCounter.put(groupField, groupIndex + 1);
                        log.debug("Created new group. New groupIndex for {}: {}", groupField, groupIndex + 1);
                        groupIndex++;
                    } else {
                        groupedFieldsRequest = groupRequests.get(0);
                        log.debug("Reusing existing group with index: {}", groupedFieldsRequest.getGroupField().getIndex());
                    }
                    
                    Map<String, Integer> fieldIndexMap = groupFieldIndexMap.computeIfAbsent(groupKey, k -> new HashMap<>());
                    
                    for (int i = 0; i < sourceFieldInstances.size(); i++) {
                        processFieldForGroup(mapping, sourceFieldInstances.get(i), groupedFieldsRequest, fieldIndexMap, request, isSecondCallForPartialTaxCalc);
                    }
                } else {
                    log.debug("Skipped processing for empty sourceFieldInstances");
                }
            }
        }
        log.debug("Finished processing grouped field: {}. Final groupIndex: {}", groupField, groupFieldIndexCounter.get(groupField));
    }
    
    private void processGroupWithoutFormData(FieldMapping mapping, List<FieldsRequest> groupRequests, 
            Map<String, Integer> fieldIndexMap, int groupIndex, ValidatableRequest request, boolean isSecondCallForPartialTaxCalc) {
        // Create at least one instance for fields without form data
        FieldsRequest groupedFieldsRequest = getOrCreateGroupedFieldsRequest(groupRequests, mapping.getGroupField(), groupIndex, mapping, null, isSecondCallForPartialTaxCalc);
        processFieldForGroup(mapping, null, groupedFieldsRequest, fieldIndexMap, request, isSecondCallForPartialTaxCalc);
    }
    
    private List<Map<String, Object>> findSourceFieldInstances(Map<String, Object> form, String sourceField) {
        List<Map<String, Object>> result = new ArrayList<>();
        if (sourceField != null) {
            findSourceFieldInstancesRecursive(form, sourceField, result);
        } else {
            result.add(form);
        }
        return result;
    }

    private void findSourceFieldInstancesRecursive(Object obj, String sourceField, List<Map<String, Object>> result) {
        if (obj instanceof Map) {
            @SuppressWarnings("unchecked")
            Map<String, Object> map = (Map<String, Object>) obj;
            if (sourceField.equals(map.get(LINE_NAME_TXT))) {
                result.add(map);
            }
            for (Object value : map.values()) {
                findSourceFieldInstancesRecursive(value, sourceField, result);
            }
        } else if (obj instanceof List) {
            for (Object item : (List<?>) obj) {
                findSourceFieldInstancesRecursive(item, sourceField, result);
            }
        }
    }
    
    private String createGroupKey(String groupField, String groupingKey, int formIndex) {
        StringBuilder keyBuilder = new StringBuilder(groupField);
        if (groupingKey != null && !groupingKey.isEmpty()) {
            keyBuilder.append("_").append(groupingKey);
        }
        keyBuilder.append("_").append(formIndex);
        return keyBuilder.toString();
    }

    private FieldsRequest getOrCreateGroupedFieldsRequest(List<FieldsRequest> groupRequests, String groupField, 
            int groupIndex, FieldMapping mapping, Map<String, Object> form, boolean isSecondCallForPartialTaxCalc) {
        log.debug("getOrCreateGroupedFieldsRequest called for {} with index {}", groupField, groupIndex);
        if (groupRequests.isEmpty()) {
            FieldsRequest newRequest = new FieldsRequest();
            GroupField groupFieldObj = new GroupField();
            groupFieldObj.setFieldId(groupField);
            groupFieldObj.setIndex(groupIndex);
            groupFieldObj.setValue(deriveGroupFieldValue(mapping, form, groupIndex, isSecondCallForPartialTaxCalc));
            
            // Add child field handling
            if (mapping.getChildField() != null && mapping.getChildFieldValue() != null) {
                GroupField childField = new GroupField();
                childField.setFieldId(mapping.getChildField());
                childField.setIndex(groupIndex);
                childField.setValue(resolveMockValue(mapping.getChildFieldValue(), groupIndex + 1));
                groupFieldObj.setChild(childField);
                log.debug("Created child field: {} with value: {} for parent group: {}", 
                    mapping.getChildField(), childField.getValue(), groupField);
            }
            
            newRequest.setGroupField(groupFieldObj);
            newRequest.setFields(new ArrayList<>());
            groupRequests.add(newRequest);
            log.debug("Created group field: {} with value: {} with index {}", groupField, groupFieldObj.getValue(), groupIndex);
            return newRequest;
        } else {
            log.debug("Returning existing group field: {} with index {}", groupField, groupRequests.get(0).getGroupField().getIndex());
            return groupRequests.get(0);
        }
    }
    
	private void processFieldForGroup(FieldMapping mapping, Map<String, Object> form, FieldsRequest groupedFieldsRequest, 
			Map<String, Integer> fieldIndexMap, ValidatableRequest request, boolean isSecondCallForPartialTaxCalc) {
	    String targetField = mapping.getTargetField();

	    // Skip processing if the targetField is the same as the groupField for group field creation
	    if (targetField.equals(groupedFieldsRequest.getGroupField().getFieldId())) {
	        return;
	    }

	    List<String> values = findFieldValuesRecursive(form, mapping.getSourceField(), isSecondCallForPartialTaxCalc);
	    List<String> dependentValues = mapping.getDependentSourceField() != null
	            ? findFieldValuesRecursive(form, mapping.getDependentSourceField(), isSecondCallForPartialTaxCalc)
	            : Collections.emptyList();

	    int maxSize = Math.max(values.size(), dependentValues.size());
	    maxSize = Math.max(maxSize, 1); // Ensure at least one iteration for mock values

	    for (int i = 0; i < maxSize; i++) {
	        String value = getValue(values, i, mapping);
	        String dependentValue = getValue(dependentValues, i, null);
	        
	        if (value == null && dependentValue == null) {
	            return;
	        }

	        String resolvedTargetField = resolveTargetField(mapping, value, dependentValue);
	        if (resolvedTargetField != null) {
	            int fieldIndex = fieldIndexMap.getOrDefault(resolvedTargetField, 0);
	            Field field = createField(mapping, value, dependentValue, fieldIndex, request);
                    //Send the field value as empty string for the lineItem that is mapped in the mapping-config but missing in the ECM payload
	            if (field.getValue() == null) {
	                field.setValue(EMPTY_STRING);
	            }
	            field.setFieldId(resolvedTargetField);
	            groupedFieldsRequest.getFields().add(field);
	            fieldIndexMap.put(resolvedTargetField, fieldIndex + 1);
	            log.debug("Added field: {} with value: {}, index: {}", resolvedTargetField, value, fieldIndex);
	        }
	    }
	}

	private String getValue(List<String> values, int index, FieldMapping mapping) {
	    if (index < values.size()) {
	        return values.get(index);
	    }
	    if (mapping != null && mapping.getTargetFieldValue() != null) {
	        return resolveMockValue(mapping.getTargetFieldValue(), index);
	    }
	    return null;
	}

	private String resolveTargetField(FieldMapping mapping, String value, String dependentValue) {
        if (mapping.isDynamicTargetField()) {
            String keyToUse = dependentValue != null ? dependentValue : value;
            String resolvedField = resolveDynamicTargetField(mapping, value, dependentValue);
            if (resolvedField != null) {
                log.debug("Resolved dynamic target field: {} for value: {}", resolvedField, keyToUse);
                return resolvedField;
            }
            log.warn("No dynamic target field found for sourceField: {} and value: {}. Skipping this field.", 
                     mapping.getSourceField(), keyToUse);
            return null;
        }
        return mapping.getTargetField();
    }
    
	private void processNonGroupedFieldMapping(FieldMapping mapping, Map<String, List<Map<String, Object>>> formMap, List<Field> fields, 
			ValidatableRequest request, boolean isSecondCallForPartialTaxCalc) {
	    String sourceForm = mapping.getSourceForm();
	    String sourceField = mapping.getSourceField();

	    if (sourceForm == null && sourceField == null && mapping.getTargetFieldValue() != null) {
	        // This is a mock field without source, process it directly
	        createAndAddField(mapping, null, null, 0, fields, request);
	        return;
	    }

	    if (formMap.containsKey(sourceForm)) {
	        List<Map<String, Object>> formInstances = formMap.get(sourceForm);
	        for (int formIndex = 0; formIndex < formInstances.size(); formIndex++) {
	            Map<String, Object> form = formInstances.get(formIndex);
	            List<String> values = findFieldValuesRecursive(form, sourceField, isSecondCallForPartialTaxCalc);
	            
                List<String> dependentValues = mapping.getDependentSourceField() != null ?
                        findFieldValuesRecursive(form, mapping.getDependentSourceField(), isSecondCallForPartialTaxCalc) : Collections.emptyList();
	                
	            if (!values.isEmpty() || !dependentValues.isEmpty()) {
	                int maxSize = Math.max(values.size(), dependentValues.size());

	                for (int valueIndex = 0; valueIndex < maxSize; valueIndex++) {
	                	String value = values.get(valueIndex);
	                    String dependentValue = valueIndex < dependentValues.size() ? dependentValues.get(valueIndex) : null;
	                    createAndAddField(mapping, value, dependentValue, valueIndex, fields, request);
	                }
	            }
	        }
	    }
	}
    
	private void createAndAddField(FieldMapping mapping, String value, String dependentValue, int index, List<Field> fields, ValidatableRequest request) {
        String resolvedTargetField = resolveTargetField(mapping, value, dependentValue);
        if (resolvedTargetField != null) {
            Field field = createField(mapping, value, dependentValue, index, request);
            if (field == null) {
            	return;
            }
            //Send the field value as empty string for the lineItem that is mapped in the mapping-config buy missing in the ECM payload
            if (field.getValue() == null) {
            	field.setValue(EMPTY_STRING);
            }
            field.setFieldId(resolvedTargetField);
            fields.add(field);
            log.debug("Added field: {} with value: {}, index: {}", resolvedTargetField, value, index);
        }
    }
    
	@SuppressWarnings("unchecked")
    private List<String> findFieldValuesRecursive(Map<String, Object> item, String sourceField, boolean isSecondCallForPartialTaxCalc) {
        List<String> values = new ArrayList<>();

        if (item == null || sourceField == null) {
            return values;
        }

        // Check if the current item matches the sourceField
        if (sourceField.equals(item.get(LINE_NAME_TXT))) {
            String value = getAppropriateValue(item, isSecondCallForPartialTaxCalc);
            if (value != null) {
                values.add(value);
            }
        }

        // Recursively check nested items
        for (Map.Entry<String, Object> entry : item.entrySet()) {
            if (entry.getValue() instanceof Map) {
                values.addAll(findFieldValuesRecursive((Map<String, Object>) entry.getValue(), sourceField, isSecondCallForPartialTaxCalc));
            } else if (entry.getValue() instanceof List) {
                for (Object listItem : (List<?>) entry.getValue()) {
                    if (listItem instanceof Map) {
                        values.addAll(findFieldValuesRecursive((Map<String, Object>) listItem, sourceField, isSecondCallForPartialTaxCalc));
                    }
                }
            }
        }

        return values;
    }

    private String getAppropriateValue(Map<String, Object> item, boolean isSecondCallForPartialTaxCalc) {
    	
    	String perReturnValueTxt = (String) item.get(PER_RETURN_VALUE_TXT);
    	if (perReturnValueTxt != null && perReturnValueTxt.isEmpty()) {
    		perReturnValueTxt = "0";
    	}
    	String agreedAdjValue = (String) item.get(AGREED_ADJ_VALUE_TXT);
    	if (agreedAdjValue != null && agreedAdjValue.isEmpty()) {
    		agreedAdjValue = "0";
    	}
    	String totalAdjustmentValue = (String) item.get(TOTAL_ADJ_VALUE_TXT);
    	if (totalAdjustmentValue != null && totalAdjustmentValue.isEmpty()) {
    		totalAdjustmentValue = "0";
    	}
    	
        if (calcTypeTxt == null) {
            return perReturnValueTxt;
        }

        switch (calcTypeTxt) {
        	case CALC_TYPE_NO_CHANGE:
        		return perReturnValueTxt;
            case CALC_TYPE_AGREED:
            case CALC_TYPE_UNAGREED:
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(totalAdjustmentValue)) {
    	            return new BigDecimal(perReturnValueTxt).add(new BigDecimal(totalAdjustmentValue)).toPlainString();
    	        }
            	return perReturnValueTxt;
            case CALC_TYPE_PARTIAL:
            case CALC_TYPE_TOTAL:
            	if (isSecondCallForPartialTaxCalc) {
	            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(agreedAdjValue)) {
	    	            return new BigDecimal(perReturnValueTxt).add(new BigDecimal(agreedAdjValue)).toPlainString();
	    	        }
	            } else {
	            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(totalAdjustmentValue)) {
	    	            return new BigDecimal(perReturnValueTxt).add(new BigDecimal(totalAdjustmentValue)).toPlainString();
	    	        }
	            }
            	return perReturnValueTxt;
                
            // Penalty Calculation - Step 3 - Calculate Amounts Subject to Penalty (6662A) - Agreed
            case CALC_TYPE_PENALTY_AGR_UNDRPYMNT_EXCL_6662A:
            	String issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES1.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Agreed Adj when (issuePenaltyAgreementStatusInd = 'Y' or "")
            	String issuePenaltyAgreementStatusInd = null;
            	if (item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND) != null) {
            		issuePenaltyAgreementStatusInd = (String) item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND);
            	}
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(agreedAdjValue) && 
            		issuePenaltyAgreementStatusInd != null && ("Y".equals(issuePenaltyAgreementStatusInd) || EMPTY_STRING.equals(issuePenaltyAgreementStatusInd))) {
   	            		return new BigDecimal(perReturnValueTxt).add(new BigDecimal(agreedAdjValue)).toPlainString();
    	        }
                return perReturnValueTxt;
                
            // Penalty Calculation - Step 4 - Calculate Amounts Subject to Penalty (6662A) - Total
            case CALC_TYPE_PENALTY_TOT_UNDRPYMNT_EXCL_6662A:
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES1.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Total Adj
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(totalAdjustmentValue)) {
   	            	return new BigDecimal(perReturnValueTxt).add(new BigDecimal(totalAdjustmentValue)).toPlainString();
    	        }
            	return perReturnValueTxt;

            // Penalty Calculation - Step 5 - Calculate Amounts Subject to No Penalty - Agreed
            case CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A:
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES1.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	issuePenaltyAgreementStatusInd = null;
            	if (item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND) != null) {
            		issuePenaltyAgreementStatusInd = (String) item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND);
            	}
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Send Per Return + Agreed Adj when (issuePenaltyAgreementStatusInd = 'Y' or "") and "issuePenaltyTypeTxt" = ""
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(agreedAdjValue) && 
        			issuePenaltyAgreementStatusInd != null && ("Y".equals(issuePenaltyAgreementStatusInd) || EMPTY_STRING.equals(issuePenaltyAgreementStatusInd)) &&
        			issuePenaltyTypeTxt != null && EMPTY_STRING.equals(issuePenaltyTypeTxt)) {
	            		return new BigDecimal(perReturnValueTxt).add(new BigDecimal(agreedAdjValue)).toPlainString();
    	        }
            	return perReturnValueTxt;

            // Penalty Calculation - Step 6 - Calculate Amounts Subject to No Penalty - Total
            case CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A:
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES1.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Total Adj when "issuePenaltyTypeTxt" = ""
	            if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(totalAdjustmentValue) &&
        			issuePenaltyTypeTxt != null && EMPTY_STRING.equals(issuePenaltyTypeTxt)) {
	            		return new BigDecimal(perReturnValueTxt).add(new BigDecimal(totalAdjustmentValue)).toPlainString();
            	}
            	return perReturnValueTxt;
            	
            // Penalty Calculation - Step 7 - Calculate Amounts Subject to 20% Penalty - Agreed
            case CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A:
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES1.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Agreed Adj when (issuePenaltyAgreementStatusInd = 'Y' or "") and ("issuePenaltyTypeTxt" = "" or a 20% Penalty)
            	issuePenaltyAgreementStatusInd = null;
            	if (item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND) != null) {
            		issuePenaltyAgreementStatusInd = (String) item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND);
            	}
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(agreedAdjValue) && 
        			issuePenaltyAgreementStatusInd != null && ("Y".equals(issuePenaltyAgreementStatusInd) || EMPTY_STRING.equals(issuePenaltyAgreementStatusInd)) && 
        			issuePenaltyTypeTxt != null && (
    					EMPTY_STRING.equals(issuePenaltyTypeTxt) ||
    					PCT_20_PENALTY_TYPES.contains(issuePenaltyTypeTxt)
        			)) {
  	            	return new BigDecimal(perReturnValueTxt).add(new BigDecimal(agreedAdjValue)).toPlainString();
    	        }
            	return perReturnValueTxt;

            // Penalty Calculation - Step 8 - Calculate Amounts Subject to 20% Penalty - Total
            case CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A:
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES1.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Total Adj and ("issuePenaltyTypeTxt" = "" or a 20% Penalty)
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(totalAdjustmentValue) &&
        			issuePenaltyTypeTxt != null && (
    					EMPTY_STRING.equals(issuePenaltyTypeTxt) ||
    					PCT_20_PENALTY_TYPES.contains(issuePenaltyTypeTxt)
        			)) {
	            	return new BigDecimal(perReturnValueTxt).add(new BigDecimal(totalAdjustmentValue)).toPlainString();
    	        }
            	return perReturnValueTxt;
            	
            // Penalty Calculation - Step 9 - Calculate Amounts Subject to 40% Penalty - Agreed
            case CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A:
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES1.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Agreed Adj when (issuePenaltyAgreementStatusInd = 'Y' or "") and ("issuePenaltyTypeTxt" = "" or a 20% Penalty or a 40% Penalty)
            	issuePenaltyAgreementStatusInd = null;
            	if (item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND) != null) {
            		issuePenaltyAgreementStatusInd = (String) item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND);
            	}
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(agreedAdjValue) && 
        			issuePenaltyAgreementStatusInd != null && ("Y".equals(issuePenaltyAgreementStatusInd) || EMPTY_STRING.equals(issuePenaltyAgreementStatusInd)) && 
        			issuePenaltyTypeTxt != null && (
    					EMPTY_STRING.equals(issuePenaltyTypeTxt) ||
    					PCT_20_PENALTY_TYPES.contains(issuePenaltyTypeTxt) ||
    					PCT_40_PENALTY_TYPES.contains(issuePenaltyTypeTxt)
            		)) {
    	            return new BigDecimal(perReturnValueTxt).add(new BigDecimal(agreedAdjValue)).toPlainString();
    	        }
            	return perReturnValueTxt;

            // Penalty Calculation - Step 10 - Calculate Amounts Subject to 40% Penalty - Total
            case CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A:
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES1.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Total Adj and ("issuePenaltyTypeTxt" = "" or a 20% Penalty or a 40% Penalty)
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(totalAdjustmentValue) &&
        			issuePenaltyTypeTxt != null && (
    					EMPTY_STRING.equals(issuePenaltyTypeTxt) ||
    					PCT_20_PENALTY_TYPES.contains(issuePenaltyTypeTxt) ||
    					PCT_40_PENALTY_TYPES.contains(issuePenaltyTypeTxt)
        			)) {
	            	return new BigDecimal(perReturnValueTxt).add(new BigDecimal(totalAdjustmentValue)).toPlainString();
    	        }
            	return perReturnValueTxt;
            	
            // Penalty Calculation - Step 11 - Calculate Amounts Subject to 75% Penalty - Agreed
            case CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A:
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES1.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Agreed Adj when (issuePenaltyAgreementStatusInd = 'Y' or "") and ("issuePenaltyTypeTxt" = "" or a 20% Penalty or a 40% Penalty or a 75% Penalty)
            	issuePenaltyAgreementStatusInd = null;
            	if (item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND) != null) {
            		issuePenaltyAgreementStatusInd = (String) item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND);
            	}
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(agreedAdjValue) && 
        			issuePenaltyAgreementStatusInd != null && ("Y".equals(issuePenaltyAgreementStatusInd) || EMPTY_STRING.equals(issuePenaltyAgreementStatusInd)) && 
        			issuePenaltyTypeTxt != null && (
    					EMPTY_STRING.equals(issuePenaltyTypeTxt) ||
    					PCT_20_PENALTY_TYPES.contains(issuePenaltyTypeTxt) ||
    					PCT_40_PENALTY_TYPES.contains(issuePenaltyTypeTxt) ||
    					PCT_75_PENALTY_TYPES.contains(issuePenaltyTypeTxt)
        			)) {
    	            return new BigDecimal(perReturnValueTxt).add(new BigDecimal(agreedAdjValue)).toPlainString();
    	        }
            	return perReturnValueTxt;

            // Penalty Calculation - Step 12 - Calculate Amounts Subject to 75% Penalty - Total
            case CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A:
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES1.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Total Adj and "issuePenaltyTypeTxt" = (No Value or a 20% Penalty or a 40% Penalty or a 75% Penalty)
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(totalAdjustmentValue) &&
        			issuePenaltyTypeTxt != null && (
    					EMPTY_STRING.equals(issuePenaltyTypeTxt) ||
    					PCT_20_PENALTY_TYPES.contains(issuePenaltyTypeTxt) ||
    					PCT_40_PENALTY_TYPES.contains(issuePenaltyTypeTxt) ||
    					PCT_75_PENALTY_TYPES.contains(issuePenaltyTypeTxt)
        			)) {
	            	return new BigDecimal(perReturnValueTxt).add(new BigDecimal(totalAdjustmentValue)).toPlainString();
    	        }
            	return perReturnValueTxt;
            	
            // Penalty Calculation - Step 13 - for use in calculation of 6662A Underpayment Penalty - Agreed
            case CALC_TYPE_PENALTY_AGR_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY:
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES2.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Agreed Adj when ("issuePenaltyTypeTxt" = "" or a 20% Penalty or a 40% Penalty or a 75% Penalty)
            	issuePenaltyAgreementStatusInd = null;
            	if (item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND) != null) {
            		issuePenaltyAgreementStatusInd = (String) item.get(ISSUE_PNLTY_AGREMNT_STATUS_IND);
            	}
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(agreedAdjValue) && 
        			issuePenaltyTypeTxt != null && (
    					EMPTY_STRING.equals(issuePenaltyTypeTxt) ||
    					PCT_20_PENALTY_TYPES.contains(issuePenaltyTypeTxt) ||
    					PCT_40_PENALTY_TYPES.contains(issuePenaltyTypeTxt) ||
    					PCT_75_PENALTY_TYPES.contains(issuePenaltyTypeTxt)
        			)) {
	            	return new BigDecimal(perReturnValueTxt).add(new BigDecimal(agreedAdjValue)).toPlainString();
    	        }
            	return perReturnValueTxt;

            // Penalty Calculation - Step 14 - for use in calculation of 6662A Underpayment Penalty - Total
            case CALC_TYPE_PENALTY_TOT_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY:
            	issuePenaltyTypeTxt = null;
            	if (item.get(ISSUE_PNLTY_TYPE_TXT) != null) {
            		issuePenaltyTypeTxt = (String) item.get(ISSUE_PNLTY_TYPE_TXT);
            	}
            	// Excluding any lineItem that has issuePenaltyTypeTxt: "6662A" or "6676" (Send perReturn)
            	if (issuePenaltyTypeTxt != null && EXCLUDE_PENALTY_TYPES2.contains(issuePenaltyTypeTxt)) {
            		return perReturnValueTxt;
            	}
            	// Send Per Return + Total Adj and ("issuePenaltyTypeTxt" = "" or a 20% Penalty or a 40% Penalty or a 75% Penalty)
            	if (CommonUtil.isNumeric(perReturnValueTxt) && CommonUtil.isNumeric(totalAdjustmentValue) &&
        			issuePenaltyTypeTxt != null && (
    					EMPTY_STRING.equals(issuePenaltyTypeTxt) ||
    					PCT_20_PENALTY_TYPES.contains(issuePenaltyTypeTxt) ||
    					PCT_40_PENALTY_TYPES.contains(issuePenaltyTypeTxt) ||
    					PCT_75_PENALTY_TYPES.contains(issuePenaltyTypeTxt)
        			)) {
	            	return new BigDecimal(perReturnValueTxt).add(new BigDecimal(totalAdjustmentValue)).toPlainString();
    	        }
            	return perReturnValueTxt;
        }

        // If no specific value found for calcTypeTxt, fall back to perReturnValueTxt
        return perReturnValueTxt;
    }
    
    public static Map<String, Integer> createPenaltyRatesMap() {
        Map<String, Integer> rates = new HashMap<>();
        
        // 20% penalty rates
        PCT_20_PENALTY_TYPES.forEach(code -> rates.put(code, 20));

        // 40% penalty rates
        PCT_40_PENALTY_TYPES.forEach(code -> rates.put(code, 40));
        
        // 75% penalty rates
        PCT_75_PENALTY_TYPES.forEach(code -> rates.put(code, 75));
        
        return Collections.unmodifiableMap(rates);
    }
    
    private String deriveGroupFieldValue(FieldMapping mapping, Map<String, Object> form, int formIndex, boolean isSecondCallForPartialTaxCalc) {
        if (mapping.getTargetFieldValue() != null) {
            String groupField = mapping.getGroupField();
            int index = groupFieldIndexCounter.computeIfAbsent(groupField, k -> 0);
            String value = resolveMockValue(mapping.getTargetFieldValue(), index);
            groupFieldIndexCounter.put(groupField, index + 1);
            return value;
        }
        List<String> values = findFieldValuesRecursive(form, mapping.getSourceField(), isSecondCallForPartialTaxCalc);
        if (values != null && !values.isEmpty()) {
            return values.get(0);
        }
        return "Group " + (formIndex + 1); // Default value if no other logic applies
    }

    private Map<String, List<Map<String, Object>>> createFormMap(Map<String, Object> body) {
        @SuppressWarnings("unchecked")
		List<Map<String, Object>> forms = (List<Map<String, Object>>) body.get(FORMS);
        return forms.stream()
                .collect(Collectors.groupingBy(form -> (String) form.get(FORM_NUM)));
    }
    
    private void validateRequest(ValidatableRequest request) {
        if (request == null || request.getHeader() == null || request.getBody() == null) {
            log.error("Invalid request: request is null or missing header/body");
            throw new IllegalArgumentException("Invalid request for transformEcmToTrSaveFields");
        }
    }
    
    private void initializeConfig(Map<String, Object> header) {
        String taxPrd = (String) header.get(TAX_PERIOD);
        if (taxPrd == null) {
            log.error("taxPrd is missing in the header");
            throw new IllegalArgumentException("taxPrd is missing in the header");
        }
        
        try {
            String taxYear = CommonUtil.extractTaxYear(taxPrd);
            log.info("Initializing configuration for tax year: {}", taxYear);
            MappingConfig config = configLoader.loadMappingConfig(taxYear);
            currentConfig.set(config);
            initializePerReturnValueToTargetFieldMap(config);
        } catch (IllegalArgumentException e) {
            log.error("Invalid tax period in header: {}", e.getMessage());
            throw new ConfigurationException("Invalid tax period in header: " + e.getMessage());
        }
    }
    
    private MappingConfig getConfig() {
        return Optional.ofNullable(currentConfig.get())
                .orElseThrow(() -> new IllegalStateException("Configuration not initialized"));
    }
    
    private void clearConfig() {
        currentConfig.remove();
        log.debug("Configuration cleared for current thread");
    }
    
    private synchronized void initializePerReturnValueToTargetFieldMap(MappingConfig config) {
        perReturnValueToTargetFieldMap.clear();
        if (config != null && config.getSaveFields() != null && config.getSaveFields().getRequestMapping() != null) {
            List<FieldMapping> fieldMappings = config.getSaveFields().getRequestMapping().getFieldMappings();
            if (fieldMappings != null) {
                for (FieldMapping fieldMapping : fieldMappings) {
                    if (fieldMapping != null && fieldMapping.isDynamicTargetField() && fieldMapping.getPerReturnValueToTargetField() != null) {
                        perReturnValueToTargetFieldMap.put(fieldMapping.getSourceField(), 
                            new ConcurrentHashMap<>(fieldMapping.getPerReturnValueToTargetField()));
                    }
                }
            }
        }
        log.info("Initialized perReturnValueToTargetFieldMap with {} entries", perReturnValueToTargetFieldMap.size());
    }
    
    private List<FieldMapping> loadRelevantFieldMappings(Map<String, List<Map<String, Object>>> formMap, Map<String, Object> header, List<FieldMapping> allMappings) {
        Set<String> relevantForms = formMap.keySet();
        
        List<FieldMapping> relevantMappings = allMappings.stream()
                .filter(fm -> fm.getSourceForm() == null || relevantForms.contains(fm.getSourceForm()))
                .collect(Collectors.toList());

        // Apply form-specific transformations
        for (Map.Entry<String, Class<?>> entry : formTransformers.entrySet()) {
            String formNum = entry.getKey();
            if (relevantForms.contains(formNum)) {
                Class<?> transformerClass = entry.getValue();
                try {
                    Object transformer = transformerClass.getDeclaredConstructor().newInstance();
                    Method transformMethod = transformerClass.getMethod("transformForm" + formNum, Map.class, Map.class);
                    
                    for (Map<String, Object> form : formMap.get(formNum)) {
                        @SuppressWarnings("unchecked")
                        List<FieldMapping> additionalMappings = (List<FieldMapping>) transformMethod.invoke(transformer, form, header);
                        relevantMappings.addAll(additionalMappings);
                    }
                } catch (Exception e) {
                    log.error("Error applying form-specific transformation for form {}: {}", formNum, e.getMessage());
                }
            }
        }

        log.info("Loaded {} relevant field mappings including form-specific transformations", relevantMappings.size());
        return relevantMappings;
    }
    
    private Field createField(FieldMapping mapping, String value, String dependentValue, Integer index, ValidatableRequest request) {
        if (mapping == null) {
            log.warn("Null FieldMapping provided to createField");
            return null;
        }

        Field field = new Field();
        field.setFieldId(mapping.getTargetField());
        
        if (mapping.getTargetFieldValue() != null) {
            field.setValue(resolveMockValue(mapping.getTargetFieldValue(), index));
        } else if (mapping.getTransformationClass() != null && mapping.getTransformationMethod() != null) {
            field.setValue(applyTransformation(mapping, value, request));
        } else if (mapping.isDynamicTargetField()) {
            String dynamicTargetField = resolveDynamicTargetField(mapping, value, dependentValue);
            if (dynamicTargetField != null) {
                field.setFieldId(dynamicTargetField);
                field.setValue(value);
            } else {
                log.warn("Unable to resolve dynamic target field for mapping: {}", mapping);
                return null;
            }
        } else {
            field.setValue(value);
        }
        
        //Overwriting value from zero to empty string for all fieldIds as TR does not like zeros for some of the fieldIds.
        if(field.getValue() == null || "0".equals(field.getValue())) {
        	field.setValue(EMPTY_STRING);
        }
        
        if (mapping.isIndex()) {
            field.setGroup(true);
            field.setIndex(String.valueOf(index));
        }
        
        log.debug("Created field: {}", field);
        return field;
    }
    
    private String resolveMockValue(String mockValue, Integer index) {
        if (mockValue == null || mockValue.isEmpty()) {
            return null;
        }
        if (mockValue.startsWith("${") && mockValue.endsWith("}")) {
            String propertyKey = mockValue.substring(2, mockValue.length() - 1);
            boolean appendIndex = propertyKey.endsWith("+INDEX");
            
            if (appendIndex) {
                propertyKey = propertyKey.substring(0, propertyKey.length() - 6);
            }
            
            String value = environment.getProperty(propertyKey);
            if (value == null) {
                log.warn("Environment property not found for key: {}. Using default value.", propertyKey);
                value = "DEFAULT_" + propertyKey;
            }
            
            if (appendIndex) {
                String resolvedValue = value + index;
                log.debug("Resolved indexed mock value: {} to {}", mockValue, resolvedValue);
                return resolvedValue;
            } else {
                log.debug("Resolved non-indexed mock value: {} to {}", mockValue, value);
                return value;
            }
        }
        return mockValue;
    }
    
    private String applyTransformation(FieldMapping mapping, String value, ValidatableRequest request) {
    	    
	    log.debug("Applying transformation: class={}, method={}, type={}", 
	    	mapping.getTransformationClass(), mapping.getTransformationMethod(), mapping.getTransformationType());
	    if (mapping.getTransformationClass() == null || mapping.getTransformationMethod() == null) {
	        log.warn("Null transformationClass or transformationMethod in applyTransformation");
	        return value;
	    }

	    try {
	        Class<?> clazz = Class.forName(mapping.getTransformationClass());
	        Object transformer = clazz.getDeclaredConstructor().newInstance();
	        String transformationType = mapping.getTransformationType();
	        if (transformationType == null) {
	        	transformationType = "";
	        }
	        switch(transformationType) {
	            case "REQUEST":
	                Method requestMethod = clazz.getMethod(mapping.getTransformationMethod(), 
	                    String.class, ValidatableRequest.class);
	                return (String) requestMethod.invoke(transformer, value, request);
	                
	            default:
	                Method stringMethod = clazz.getMethod(mapping.getTransformationMethod(), String.class);
	                return (String) stringMethod.invoke(transformer, value);
	        }
	    } catch (Exception e) {
	        log.error("Error applying transformation: {}", e.getMessage());
	        throw new RuntimeException("Error applying transformation", e);
	    }
	}

    private String resolveDynamicTargetField(FieldMapping mapping, String value, String dependentValue) {
        if (mapping.getSourceField() == null || value == null) {
            return null;
        }
        Map<String, String> dynamicFieldMap = perReturnValueToTargetFieldMap.get(mapping.getSourceField());
        if (dynamicFieldMap != null) {
            return dynamicFieldMap.get(dependentValue != null ? dependentValue : value);
        }
        return null;
    }
    
    @SuppressWarnings("unchecked")
    private void postProcessRelatedFields(ValidatableRequest request) {
        log.info("Starting post-processing to remove temporary line items");
        
        Map<String, Object> body = request.getBody();
        List<Map<String, Object>> forms = (List<Map<String, Object>>) body.get(FORMS);
        if (forms == null) {
            log.debug("No forms found for post-processing");
            return;
        }
        
        for (Map<String, Object> form : forms) {
            List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get(LINE_ITEMS);
            if (lineItems != null) {
                removeTemporaryLineItems(lineItems);
            }
        }
        
        log.info("Completed post-processing");
    }

    @SuppressWarnings("unchecked")
    private void removeTemporaryLineItems(List<Map<String, Object>> lineItems) {
        // Remove items marked for removal at current level
        lineItems.removeIf(item -> Boolean.TRUE.equals(item.get(REMOVE_IT_LATER)));
        
        // Process nested line items
        for (Map<String, Object> lineItem : lineItems) {
            List<Map<String, Object>> nestedLineItems = (List<Map<String, Object>>) lineItem.get(LINE_ITEMS);
            if (nestedLineItems != null) {
                removeTemporaryLineItems(nestedLineItems);
            }
        }
    }

    public Map<String, Object> transformTrToEcm(ValidatableRequest originalRequest, RetrieveFieldsResponse trResponse) {
        log.info("Starting TR to ECM transformation");
        try {
            validateRequest(originalRequest, trResponse);
            initializeConfig(originalRequest.getHeader());
            
            Map<String, FieldMapping> sourceFieldToRespMapping = createSourceFieldMapping();
            Map<FormIdentifier, LineItemStructure> formToLineNameToLineItemMap = createFormLineItemMapping(originalRequest);
            Map<String, Integer> lineNameTxtToCount = new HashMap<>();
            
            Map<String, Object> updatedPayload = processTrResponse(
                originalRequest,
                trResponse,
                sourceFieldToRespMapping,
                formToLineNameToLineItemMap,
                lineNameTxtToCount
            );
            
            log.info("Completed TR to ECM transformation");
            return Collections.unmodifiableMap(updatedPayload);
            
        } catch (Exception e) {
            log.error("Error in transformTrToEcm: ", e);
            throw e;
        } finally {
            clearConfig();
            ssnMappingStore.remove();
        }
    }

    private void validateRequest(ValidatableRequest originalRequest, RetrieveFieldsResponse trResponse) {
        if (originalRequest == null || originalRequest.getHeader() == null || originalRequest.getBody() == null) {
            throw new IllegalArgumentException("Invalid request for transformTrToEcm: originalRequest is null or incomplete");
        }
        if (trResponse == null || trResponse.getFieldsResponse() == null) {
            throw new IllegalArgumentException("Invalid request for transformTrToEcm: trResponse is null or incomplete");
        }
    }
    
    private Map<String, FieldMapping> createSourceFieldMapping() {
        List<FieldMapping> responseMapping = getConfig().getRetrieveFields().getResponseMapping().getFieldMappings();
        Map<String, FieldMapping> sourceFieldToRespMapping = new HashMap<>();
        
        for (FieldMapping mapping : responseMapping) {
            if (mapping != null && mapping.getSourceField() != null) {
                sourceFieldToRespMapping.put(mapping.getSourceField(), mapping);
            }
        }
        
        log.info("Created source field mapping with {} entries", sourceFieldToRespMapping.size());
        return sourceFieldToRespMapping;
    }

    @SuppressWarnings("unchecked")
    private Map<FormIdentifier, LineItemStructure> createFormLineItemMapping(ValidatableRequest request) {
        Map<FormIdentifier, LineItemStructure> formStructureMap = new HashMap<>();
        List<Map<String, Object>> forms = (List<Map<String, Object>>) request.getBody().get(FORMS);
        
        if (forms != null) {
            for (Map<String, Object> form : forms) {
                String formNum = (String) form.get(FORM_NUM);
                String sequenceNum = (String) form.get(SEQUENCE_NUM);
                FormIdentifier identifier = new FormIdentifier(formNum, sequenceNum);
                
                LineItemStructure structure = new LineItemStructure(form);
                processLineItemsForStructure((List<Map<String, Object>>) form.get(LINE_ITEMS), structure);
                
                formStructureMap.put(identifier, structure);
            }
        }
        
        return formStructureMap;
    }

    private void processLineItemsForStructure(List<Map<String, Object>> lineItems, 
            LineItemStructure structure) {
        if (lineItems == null) return;
        
        for (Map<String, Object> lineItem : lineItems) {
            String lineNameTxt = (String) lineItem.get(LINE_NAME_TXT);
            String sequenceNum = (String) lineItem.get(SEQUENCE_NUM);
            
            if (lineNameTxt != null && sequenceNum != null) {
                structure.addLineItem(lineNameTxt, sequenceNum, lineItem);
            }
            
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> nestedItems = (List<Map<String, Object>>) lineItem.get(LINE_ITEMS);
            if (nestedItems != null) {
                processLineItemsForStructure(nestedItems, structure);
            }
        }
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> processTrResponse(
        ValidatableRequest originalRequest,
        RetrieveFieldsResponse trResponse,
        Map<String, FieldMapping> sourceFieldToRespMapping,
        Map<FormIdentifier, LineItemStructure> formToLineNameToLineItemMap,
        Map<String, Integer> lineNameTxtToCount) {
        
        Map<String, Object> updatedPayload = new HashMap<>(originalRequest.getBody());
        List<Map<String, Object>> forms = (List<Map<String, Object>>) updatedPayload.get(FORMS);
        
        if (forms == null) {
            forms = new ArrayList<>();
            updatedPayload.put(FORMS, forms);
        }
        
        for (FieldsResponse fieldsResponse : trResponse.getFieldsResponse()) {
            if (fieldsResponse == null || fieldsResponse.getFields() == null) {
            	continue;
            }
            
            for (Field field : fieldsResponse.getFields()) {
                if (field == null || field.getFieldId() == null) {
                	continue;
                }
                
                FieldMapping mapping = sourceFieldToRespMapping.get(field.getFieldId());
                if (mapping == null) {
                    log.warn("No mapping found for field ID: {}", field.getFieldId());
                    continue;
                }
                
                processField(field, mapping, formToLineNameToLineItemMap, lineNameTxtToCount, forms, originalRequest);
            }
        }
        
        return updatedPayload;
    }

    @SuppressWarnings("unchecked")
    private void processField(
            Field field,
            FieldMapping mapping,
            Map<FormIdentifier, LineItemStructure> formStructureMap,
            Map<String, Integer> lineNameTxtToCount,
            List<Map<String, Object>> forms,
            ValidatableRequest originalRequest) {
        
        String targetField = mapping.getTargetField();
        String formNum = mapping.getTargetForm();
        String cleanedValue = TRCommonUtil.cleanTrValue(field.getValue());
        log.debug("Processing sourceField: {} targetField: {}", mapping.getSourceField(), targetField);
        
        if (cleanedValue == null || cleanedValue.isEmpty()) {
            log.debug("Skipping empty value for field: {}", targetField);
            return;
        }
        
        String formSequence = applyReverseTransformation(mapping, field, formStructureMap, originalRequest);
        if (formSequence == null) {
            log.info("Could not determine form sequence for mapping: {}", mapping.getSourceField());
            return;
        }
        
        // Update counter for this specific form sequence
        String counterKey = targetField + "_" + formSequence;
        int count = lineNameTxtToCount.compute(counterKey, (k, v) -> v == null ? 1 : v + 1);
        String sequenceNum = String.valueOf(count);
        
        FormIdentifier identifier = new FormIdentifier(formNum, formSequence);
        LineItemStructure structure = formStructureMap.get(identifier);
        
        if (structure == null) {
            // Create new form structure
            FormStructureBuilder builder = new FormStructureBuilder(formNum, formSequence);
            List<Map<String, Object>> currentList = (List<Map<String, Object>>) builder.build().get(LINE_ITEMS);
            createNestedStructure(currentList, targetField, cleanedValue, calcTypeTxt != null);
            
            Map<String, Object> newForm = builder.build();
            forms.add(newForm);
            structure = new LineItemStructure(newForm);
            formStructureMap.put(identifier, structure);
        } else {
            // Update existing structure
            Map<String, Object> existingLineItem = structure.getLineItem(targetField, sequenceNum);
            if (existingLineItem == null) {
                // Add new line item to existing form
                List<Map<String, Object>> currentList = (List<Map<String, Object>>) structure.getForm().get(LINE_ITEMS);
                createNestedStructure(currentList, targetField, cleanedValue, calcTypeTxt != null);
                
                // Find the newly created line item and add it to the structure
                findAndAddToStructure(currentList, targetField, sequenceNum, structure);
            } else {
                // Update existing line item
                boolean isSecondCallForPartialTaxCalc = originalRequest.getHeader().containsKey(SECOND_CALL_FOR_PARTIAL_TAX_CALC) && 
                    (Boolean)originalRequest.getHeader().get(SECOND_CALL_FOR_PARTIAL_TAX_CALC);
                updateLineItemValue(existingLineItem, mapping, targetField, cleanedValue, isSecondCallForPartialTaxCalc);
            }
        }
    }
    
    private String applyReverseTransformation(FieldMapping mapping, Field field, 
            Map<FormIdentifier, LineItemStructure> formStructureMap, ValidatableRequest request) {
        
        // First try sequence transformer if configured
        if (mapping.getTransformationClass() != null && mapping.getTransformationMethod() != null) {
            try {
                Class<?> transformerClass = Class.forName(mapping.getTransformationClass());
                Object transformer = transformerClass.getDeclaredConstructor().newInstance();
                
                Method method = transformerClass.getMethod(mapping.getTransformationMethod(), 
                    String.class,    // sourceField
                    Field.class,     // field
                    Map.class,       // ssnMapping
                    Map.class,       // formStructureMap
                    ValidatableRequest.class  // original request
                );
                
                return (String) method.invoke(transformer, 
                    mapping.getSourceField(),
                    field,
                    ssnMappingStore.get(),
                    formStructureMap,
                    request
                );
            } catch (Exception e) {
                log.error("Error applying sequence transformation: {}", e.getMessage());
            }
        }
        
        // Default to index-based sequence if no transformer or transformer failed
        return field.getIndex() != null ? String.valueOf(Integer.parseInt(field.getIndex()) + 1) : "1";
    }

    @SuppressWarnings("unchecked")
    private void createNestedStructure(List<Map<String, Object>> currentList, String targetField, String value, boolean isCalcType) {
        String[] paths = targetField.split("/");
        
        if (paths.length <= 2) {
            currentList.add(createBasicLineItem(targetField, value, isCalcType));
            return;
        }
        
        // Build parent paths and create/find parent structures
        for (int i = 2; i < paths.length - 1; i++) {
            StringBuilder parentPath = new StringBuilder();
            for (int j = 1; j <= i; j++) {
                parentPath.append("/").append(paths[j]);
            }
            String currentParentPath = parentPath.toString();
            
            // Find or create parent at this level
            Map<String, Object> parent = findLineItem(currentList, currentParentPath);
            if (parent == null) {
                parent = createParentItem(currentParentPath);
                currentList.add(parent);
            }
            currentList = (List<Map<String, Object>>) parent.get(LINE_ITEMS);
        }
        
        // Add the actual line item
        currentList.add(createBasicLineItem(targetField, value, isCalcType));
    }

    private Map<String, Object> findLineItem(List<Map<String, Object>> items, String lineNameTxt) {
        return items.stream()
            .filter(item -> lineNameTxt.equals(item.get(LINE_NAME_TXT)))
            .findFirst()
            .orElse(null);
    }

    private Map<String, Object> createParentItem(String parentPath) {
        LinkedHashMap<String, Object> parent = new LinkedHashMap<>();
        parent.put(LINE_ITEM_REFERENCE_KEY_ID, parentPath);
        parent.put(LINE_NAME_TXT, parentPath);
        parent.put(SEQUENCE_NUM, "1");
        parent.put(LINE_ITEMS, new ArrayList<Map<String, Object>>());
        return parent;
    }

    private Map<String, Object> createBasicLineItem(String targetField, String value, boolean isCalcType) {
        LinkedHashMap<String, Object> lineItem = new LinkedHashMap<>();
        lineItem.put(LINE_ITEM_REFERENCE_KEY_ID, targetField);
        lineItem.put(LINE_NAME_TXT, targetField);
        lineItem.put(SEQUENCE_NUM, "1");
        lineItem.put(PER_RETURN_VALUE_TXT, EMPTY_STRING);
        lineItem.put(TAX_CALCULATOR_VALUE_TXT, isCalcType ? null : value);
        lineItem.put(VARIANCE_VALUE_TXT, EMPTY_STRING);
        
        if (isCalcType) {
            lineItem.put(TOTAL_ADJ_VALUE_TXT, EMPTY_STRING);
            lineItem.put(AGREED_ADJ_VALUE_TXT, EMPTY_STRING);
            lineItem.put(ADJUSTMENT_STATUS_CD, EMPTY_STRING);
            lineItem.put(USER_ADJ_LINE_IND, "N");
            lineItem.put(ISSUE_PNLTY_TYPE_TXT, EMPTY_STRING);
            lineItem.put(TOTAL_ADJ_TAX_CALC_VALUE_TXT, value);
            lineItem.put(AGREED_ADJ_TAX_CALC_VALUE_TXT, value);
            lineItem.put(STAT_TOTAL_ADJ_TAX_CALC_VALUE_TXT, EMPTY_STRING);
            lineItem.put(STAT_AGREED_ADJ_TAX_CALC_VALUE_TXT, EMPTY_STRING);
        }
        
        return lineItem;
    }

    @SuppressWarnings("unchecked")
    private void findAndAddToStructure(List<Map<String, Object>> items, String targetField, String sequenceNum, LineItemStructure structure) {
        for (Map<String, Object> item : items) {
            if (targetField.equals(item.get(LINE_NAME_TXT))) {
                structure.addLineItem(targetField, sequenceNum, item);
                return;
            }
            List<Map<String, Object>> nestedItems = (List<Map<String, Object>>) item.get(LINE_ITEMS);
            if (nestedItems != null) {
                findAndAddToStructure(nestedItems, targetField, sequenceNum, structure);
            }
        }
    }
    
    private void updateLineItemValue(Map<String, Object> lineItem, FieldMapping mapping, String targetField,
            String cleanedTrValue, boolean isSecondCallForPartialTaxCalc) {
        String userAdjustedLineInd = (String) lineItem.get(USER_ADJ_LINE_IND);
        String perReturnValueTxt = (String) lineItem.get(PER_RETURN_VALUE_TXT);

        if (calcTypeTxt != null) {
            switch (calcTypeTxt) {
                case CALC_TYPE_AGREED:
                case CALC_TYPE_UNAGREED:
                    lineItem.put(TOTAL_ADJ_TAX_CALC_VALUE_TXT, cleanedTrValue);
                    if ("N".equals(userAdjustedLineInd)) {
                        calculateAndSetStatValue(lineItem, TOTAL_ADJ_TAX_CALC_VALUE_TXT, 
                            STAT_TOTAL_ADJ_TAX_CALC_VALUE_TXT, perReturnValueTxt);
                    }
                    break;
                case CALC_TYPE_PARTIAL:
                    if (isSecondCallForPartialTaxCalc) {
                        if (lineItem.containsKey(AGREED_ADJ_TAX_CALC_VALUE_TXT)) {
                            lineItem.put(AGREED_ADJ_TAX_CALC_VALUE_TXT, cleanedTrValue);
                            if ("N".equals(userAdjustedLineInd)) {
                                calculateAndSetStatValue(lineItem, AGREED_ADJ_TAX_CALC_VALUE_TXT, 
                                    STAT_AGREED_ADJ_TAX_CALC_VALUE_TXT, perReturnValueTxt);
                            }
                        }
                    } else {
                        if (lineItem.containsKey(TOTAL_ADJ_TAX_CALC_VALUE_TXT)) {
                            lineItem.put(TOTAL_ADJ_TAX_CALC_VALUE_TXT, cleanedTrValue);
                            if ("N".equals(userAdjustedLineInd)) {
                                calculateAndSetStatValue(lineItem, TOTAL_ADJ_TAX_CALC_VALUE_TXT, 
                                    STAT_TOTAL_ADJ_TAX_CALC_VALUE_TXT, perReturnValueTxt);
                            }
                        }
                    }
                    break;
                case CALC_TYPE_NO_CHANGE:
                    lineItem.put(TAX_CALCULATOR_VALUE_TXT, cleanedTrValue);
                    break;
                default:
                    lineItem.put(TAX_CALCULATOR_VALUE_TXT, cleanedTrValue);
                    break;
            }
        } else {
            // Original behavior when calcTypeTxt is not present
            lineItem.put(TAX_CALCULATOR_VALUE_TXT, cleanedTrValue);
            
            // Calculate variance if needed
            if (mapping.isCalculateVariance()) {
                String varianceValueTxt = calculateVariance(
                    cleanedTrValue.isEmpty() ? "0" : cleanedTrValue,
                    perReturnValueTxt != null && perReturnValueTxt.isEmpty() ? "0" : perReturnValueTxt
                );
                lineItem.put(VARIANCE_VALUE_TXT, varianceValueTxt);
                log.debug("Calculated variance for {}: {}", targetField, varianceValueTxt);
            }
        }
    }

	private void calculateAndSetStatValue(Map<String, Object> lineItem, String sourceField, String targetField, String perReturnValueTxt) {
	    String sourceValue = (String) lineItem.get(sourceField);
	    if (sourceValue != null && !sourceValue.isEmpty() && perReturnValueTxt != null && !perReturnValueTxt.isEmpty()) {
	        try {
	            BigDecimal source = new BigDecimal(sourceValue);
	            BigDecimal perReturn = new BigDecimal(perReturnValueTxt);
	            String statValue = source.subtract(perReturn).toString();
	            lineItem.put(targetField, statValue);
	            log.debug("Calculated {} = {} - {} = {} for {}", targetField, sourceValue, perReturnValueTxt, statValue, lineItem.get(LINE_NAME_TXT));
	        } catch (NumberFormatException e) {
	            log.error("Error calculating {}: Invalid number format", targetField, e);
	        }
	    } else {
	        log.warn("Unable to calculate {}: Missing {} or {}", targetField, sourceField, PER_RETURN_VALUE_TXT);
	    }
	}

    private String calculateVariance(String taxCalculatorValue, String perReturnValue) {
        log.debug("Calculating variance between taxCalculatorValue: {} and perReturnValue: {}", taxCalculatorValue, perReturnValue);
        if (taxCalculatorValue == null || perReturnValue == null) {
            log.warn("Null input in calculateVariance");
            return EMPTY_STRING;
        }
        try {
            BigDecimal taxCalc = new BigDecimal(taxCalculatorValue);
            BigDecimal perReturn = new BigDecimal(perReturnValue);
            String variance = taxCalc.subtract(perReturn).toString();
            log.debug("Calculated variance: {}", variance);
            return variance;
        } catch (NumberFormatException e) {
            log.error("Error calculating variance: {}", e.getMessage());
            return EMPTY_STRING;
        }
    }
    
    public RetrieveFieldsRequest generateRetrieveFieldsPayload(ValidatableRequest request) {
        log.info("Generating retrieve fields payload");
        try {
            if (request == null || request.getHeader() == null) {
                throw new IllegalArgumentException("Invalid input for generateRetrieveFieldsPayload");
            }
            initializeConfig(request.getHeader());
            
            RetrieveFieldsRequest retrieveFieldsRequest = new RetrieveFieldsRequest();
            List<FieldsRequest> fieldsRequests = new ArrayList<>();

            // Get request mappings from configuration
            List<FieldMapping> requestMapping = getConfig().getRetrieveFields().getRequestMapping().getFieldMappings();
            log.info("Retrieved {} request mappings from configuration", requestMapping.size());

            FieldsRequest fieldsRequest = new FieldsRequest();
            fieldsRequest.setGroupField(null);
            fieldsRequest.setFields(new ArrayList<>());

            if (requestMapping != null) {
                for (FieldMapping mapping : requestMapping) {
                    if (mapping != null && mapping.getSourceField() != null) {
                        Field field = new Field();
                        field.setGroup(true);
                        field.setFieldId(mapping.getSourceField());
                        fieldsRequest.getFields().add(field);
                    }
                }
            }

            fieldsRequests.add(fieldsRequest);
            retrieveFieldsRequest.setFieldsRequest(Collections.unmodifiableList(fieldsRequests));
            log.info("Generated retrieve fields payload with {} fields", fieldsRequest.getFields().size());
            return retrieveFieldsRequest;
        } finally {
            clearConfig();
        }
    }
}