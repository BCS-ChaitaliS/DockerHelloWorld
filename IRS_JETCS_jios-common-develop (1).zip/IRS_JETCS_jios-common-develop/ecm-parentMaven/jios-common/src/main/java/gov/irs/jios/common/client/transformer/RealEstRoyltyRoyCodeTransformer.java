package gov.irs.jios.common.client.transformer;

import static gov.irs.jios.common.util.JiosCommonConstants.FORMS;
import static gov.irs.jios.common.util.JiosCommonConstants.FORM_NUM;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_ITEMS;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_NAME_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.SEQUENCE_NUM;
import static gov.irs.jios.common.util.JiosCommonConstants.PER_RETURN_VALUE_TXT;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import gov.irs.jios.common.request.ValidatableRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RealEstRoyltyRoyCodeTransformer {

    public static String transformEcmToTr(String value, ValidatableRequest request, Integer groupIndex) {
		if (request == null || request.getBody() == null) {
			log.warn("request or request's body is null.");
			return "";
		}
		Map<String, List<Map<String, Object>>> formMap = createFormMap(request.getBody());
		List<Map<String, Object>> forms = formMap.get("IRS1040ScheduleE");
		if (forms == null || forms.isEmpty()) {
			log.warn("Form IRS1040ScheduleE not present in the payload.");
			return "";
		}
		return deriveRoyCode(forms.get(0), groupIndex);
    }
    
    @SuppressWarnings("unchecked")
	private static String deriveRoyCode(Map<String, Object> formData, Integer groupIndex) {

		List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
		if (lineItems == null) {
			log.warn("No lineItems found in formData");
			return "";
		}

		for (Map<String, Object> lineItem : lineItems) {
			if ("/IRS1040ScheduleE/PropertyRealEstAndRoyaltyGroup".equals(lineItem.get(LINE_NAME_TXT))) {
				String sequenceNum = (String)lineItem.get(SEQUENCE_NUM);
				if (sequenceNum != null) {
					Integer sequenceNo = Integer.valueOf(sequenceNum);
					if (--sequenceNo == groupIndex) {
						List<Map<String, Object>> grpPropertyLineItems = (List<Map<String, Object>>) lineItem.get(LINE_ITEMS);
						for (Map<String, Object> propertyLineItem : grpPropertyLineItems) {
							if ("/IRS1040ScheduleE/PropertyRealEstAndRoyaltyGroup/RentsReceivedAmt"
									.equals(propertyLineItem.get(LINE_NAME_TXT))) {
								String rentVal = (String) propertyLineItem.get(PER_RETURN_VALUE_TXT);
								if (rentVal != null && !rentVal.isEmpty()) {
									return "";
								}

							} else if ("/IRS1040ScheduleE/PropertyRealEstAndRoyaltyGroup/TotalRoyaltiesReceivedAmt"
									.equals(propertyLineItem.get(LINE_NAME_TXT))) {
								String royaltyVal = (String) propertyLineItem.get(PER_RETURN_VALUE_TXT);
								if (royaltyVal != null && !royaltyVal.isEmpty()) {
									return "C";
								}
							}
						}
					}
				}
			}
		}
		return "";
	}
    
    private static Map<String, List<Map<String, Object>>> createFormMap(Map<String, Object> body) {
        @SuppressWarnings("unchecked")
		List<Map<String, Object>> forms = (List<Map<String, Object>>) body.get(FORMS);
        return forms.stream()
                .collect(Collectors.groupingBy(form -> (String) form.get(FORM_NUM)));
    }

    public static String transformTrToEcm(String trIndicatorValue) {
        return "";
    }
}
