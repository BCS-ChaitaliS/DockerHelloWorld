package gov.irs.jios.common.client.transformer;

import java.util.Map;

import gov.irs.jios.common.client.tr.pojo.Field;
import gov.irs.jios.common.pojo.FormIdentifier;
import gov.irs.jios.common.pojo.LineItemStructure;
import gov.irs.jios.common.request.ValidatableRequest;

public class ScheduleSESequenceTransformer {
    private static final String SCHEDULE_SE_FORM = "IRS1040ScheduleSE";
    private static final String SSN_LINE_NAME = "/IRS1040ScheduleSE/SSN";
    
    public String determineSequence(String sourceField, Field field, Map<String, String> ssnMapping, 
            Map<FormIdentifier, LineItemStructure> formStructureMap, ValidatableRequest request) {
        
        // Skip processing SSN fields themselves
        if (sourceField.endsWith("SSN")) {
            return null;
        }
        
        // Get original SSNs
        String primarySSN = ssnMapping.get("PRIMARY");
        String spouseSSN = ssnMapping.get("SPOUSE");
        
        // Find matching form based on SSN
        for (Map.Entry<FormIdentifier, LineItemStructure> entry : formStructureMap.entrySet()) {
            FormIdentifier identifier = entry.getKey();
            if (!SCHEDULE_SE_FORM.equals(identifier.getFormNum())) {
                continue;
            }
            
            LineItemStructure structure = entry.getValue();
            String formSSN = getSSNFromStructure(structure);
            
            if (formSSN != null) {
                if ((sourceField.contains(".T") || sourceField.equals("X95.2.12")) && formSSN.equals(primarySSN)) {
                    return identifier.getSequenceNum();
                } else if ((sourceField.contains(".S") || sourceField.equals("X95.159.12")) && formSSN.equals(spouseSSN)) {
                    return identifier.getSequenceNum();
                }
            }
        }
        
        return null;
    }
    
    private String getSSNFromStructure(LineItemStructure structure) {
        Map<String, Object> lineItem = structure.getLineItem(SSN_LINE_NAME, "1");
        return lineItem != null ? (String) lineItem.get("perReturnValueTxt") : null;
    }
}
