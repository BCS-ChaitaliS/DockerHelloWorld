package gov.irs.jios.common.util;

import java.util.Arrays;
import java.util.List;

public class JiosCommonConstants {
	
	public static final String EMPTY_STRING = "";
	public static final String PRIMARY_TIN = "primaryTIN";
	public static final String SPOUSE_TIN = "spouseTIN";
	public static final String SECONDARY_TIN = "secondaryTIN";
	
	public static final String TOKEN = "token";
	public static final String LOCATOR_ID = "LocatorId";
	public static final String AUTH_TOKEN = "authToken";
	public static final String TAX_RETURN_SESSION_TOKEN = "taxReturnSessionToken";
	public static final String ENCODED_LOCATOR_DETAILS = "encodedLocatorDetails";
	public static final String LOCATOR_TOKEN = "locatorToken";
	public static final String API_SERVER_COOKIE = "apiServerCookie";
	
	public static final String TAX_PERIOD = "taxPrd";
	public static final String TAX_YEAR = "taxYr";
	public static final String TAX_MONTH = "taxMonthNum";
	public static final String FORM_NUM = "formNum";
	public static final String FORMS = "forms";
	public static final String LINE_ITEMS = "lineItems";
	public static final String LINE_NAME_TXT = "lineNameTxt";
	public static final String LINE_ITEM_REFERENCE_KEY_ID = "lineItemReferenceKeyId";
	public static final String PER_RETURN_VALUE_TXT = "perReturnValueTxt";
	public static final String TAX_CALCULATOR_VALUE_TXT = "taxCalculatorValueTxt";
	public static final String VARIANCE_VALUE_TXT = "varianceValueTxt";
	public static final String SEQUENCE_NUM = "sequenceNum";
	public static final String TOTAL_ADJ_VALUE_TXT = "totalAdjustmentValueTxt";
    public static final String TOTAL_ADJ_TAX_CALC_VALUE_TXT = "totalAdjTaxCalcValueTxt";
    public static final String STAT_TOTAL_ADJ_TAX_CALC_VALUE_TXT = "statTotalAdjTaxCalcValueTxt";
    public static final String AGREED_ADJ_VALUE_TXT = "agreedAdjustmentValueTxt";
    public static final String AGREED_ADJ_TAX_CALC_VALUE_TXT = "agreedAdjTaxCalcValueTxt";
    public static final String ADJUSTMENT_STATUS_CD = "adjustmentStatusCd";
    public static final String STAT_AGREED_ADJ_TAX_CALC_VALUE_TXT = "statAgreedAdjTaxCalcValueTxt";
    public static final String USER_ADJ_LINE_IND = "userAdjustedLineInd";
    public static final String ISSUE_PNLTY_AGREMNT_STATUS_IND = "issuePenaltyAgreementStatusInd";
    public static final String ISSUE_PNLTY_TYPE_TXT = "issuePenaltyTypeTxt";
    public static final String REMOVE_IT_LATER = "removeItLater";
    public static final String CALC_INFO = "CalcInfo";
    
    public static final String CALC_TYPE_TXT = "calcTypeTxt";
    public static final String CALC_TYPE_AGREED = "Agreed";
    public static final String CALC_TYPE_UNAGREED = "Unagreed";
    public static final String CALC_TYPE_PARTIAL = "Partial";
    public static final String CALC_TYPE_TOTAL = "Total";
    public static final String CALC_TYPE_NO_CHANGE = "NoChange";
    public static final String CALC_TYPE_NO_CHANGE_WITH_ADJUSTMENT = "NoChangeWithAdjustment";
    public static final String SECOND_CALL_FOR_PARTIAL_TAX_CALC = "secondCallForPartialTaxCalc";

    public static final String CALC_TYPE_PENALTY_AGREED_ADJ = "penaltyAgreedAdj";
    public static final String CALC_TYPE_PENALTY_TOTAL_ADJ = "penaltyTotalAdj";
    public static final String CALC_TYPE_PENALTY_AGR_UNDRPYMNT_EXCL_6662A = "penaltyAgreedUndrpymntExcl6662A";
    public static final String CALC_TYPE_PENALTY_TOT_UNDRPYMNT_EXCL_6662A = "penaltyTotalUndrpymntExcl6662A";
    public static final String CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A = "penaltyAgrUndrpymntSubjNoPnltyExcl6662A";
    public static final String CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A = "penaltyTotUndrpymntSubjNoPnltyExcl6662A";
    public static final String CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A = "penaltyAgrUndrpymntSubj20PctExcl6662A";
    public static final String CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A = "penaltyTotUndrpymntSubj20PctExcl6662A";
    public static final String CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_30PCT_EXCL_6662A = "penaltyAgrUndrpymntSubj30PctExcl6662A";
    public static final String CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_30PCT_EXCL_6662A = "penaltyTotUndrpymntSubj30PctExcl6662A";
    public static final String CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A = "penaltyAgrUndrpymntSubj40PctExcl6662A";
    public static final String CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A = "penaltyTotUndrpymntSubj40PctExcl6662A";
    public static final String CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A = "penaltyAgrUndrpymntSubj75PctExcl6662A";
    public static final String CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A = "penaltyTotUndrpymntSubj75PctExcl6662A";
    public static final String CALC_TYPE_PENALTY_AGR_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY = "penaltyAgrUndrpymnt6662AUndrpymntPnlty";
    public static final String CALC_TYPE_PENALTY_TOT_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY = "penaltyTotUndrpymnt6662AUndrpymntPnlty";
    
    public static final List<String> EXCLUDE_PENALTY_TYPES1 = Arrays.asList("6662A (a)", "6662A (c)", "6676");
    public static final List<String> EXCLUDE_PENALTY_TYPES2 = Arrays.asList("6662A (a)", "6662A (c)");
    public static final List<String> DELINQUENCY_PENALTY_TYPES = Arrays.asList("6651 (a)(1)", "6651 (a)(2)", "6651 (a)(3)", "6654");
    public static final List<String> PENALTY_TYPES_6662As = Arrays.asList("6662A (a)", "6662A (c)");
    
    public static final List<String> PCT_20_PENALTY_TYPES = Arrays.asList("6662 (a)", "6662 (c)", "6662 (d)", "6662 (e)", "6662 (b)(6)");
    public static final List<String> PCT_30_PENALTY_TYPES = Arrays.asList("6662A (c)");
    public static final List<String> PCT_40_PENALTY_TYPES = Arrays.asList("6662 (h)", "6662 (i)", "6662 (j)");
    public static final List<String> PCT_75_PENALTY_TYPES = Arrays.asList("6663", "6651 (f)");
}
