package gov.irs.jios.common.client.dmi.pojo;
import lombok.Data;

@Data
public class EstInd_Calc {
	private String penaltySectionCd;
	private String assessmentDt;
	private String currYearTaxAmt;
	private String agiExceedsInd;
	private String priorYearReturnInd;
	private String marriedFiliingSeperateInd;
	private String nrAlienInd;
	private String deathInd;
	private String deathDt;
	private String priorYearTaxAmt;
	private String monthsInPeriodNum;
	private String agricultureInd;
	private String jointReturnInd;
	private String otherTaxAmt;
	private String earnedIncomeCreditAmt;
	private String childTaxCreditAmt;
	private String fuelTaxCreditAmt;
	private String healthInsuranceAmt;
	private String previouslyAssessedPenaltyAmt;
}
