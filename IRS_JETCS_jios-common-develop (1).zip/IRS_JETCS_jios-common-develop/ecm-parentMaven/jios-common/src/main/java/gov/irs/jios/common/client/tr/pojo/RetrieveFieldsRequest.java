package gov.irs.jios.common.client.tr.pojo;

import java.util.List;

import lombok.Data;

@Data
public class RetrieveFieldsRequest {
	private List<FieldsRequest> fieldsRequest;
}