package gov.irs.jios.common.client.tr.pojo;

import java.util.List;
import java.util.Map;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FieldMapping {
	private String sourceForm;
	private String sourceField;
    private String targetField;
    private String targetFieldValue;
    private String generateIndex; // value would be true or false
    private String groupField;
    private String childField;
    private String childFieldValue;
    private String calculateVariance; // value would boolean
    private String targetForm;
    private String transformationClass;
    private String transformationMethod;
    private String transformationType;
    private String dynamicTargetField; // value would be boolean
    private Map<String, String> perReturnValueToTargetField;
    private String groupingKey;
    private String dependentSourceField;
    private List<String> relatedSourceFields;
    private String groupFieldMapping; // value would be boolean
    private String doNotSendIfSnapshotPresents; // value would be boolean
    
    // Set it to true for fields for which getAppropriateValue should not send perReturn + AdjustmentValue. 
    // For instance, /IRS1040/IndividualReturnFilingStatusCd
    private String doNotAddAdjmntValue;  // value would be boolean
    
    public FieldMapping(String sourceForm, String sourceField) {
        this.sourceForm = sourceForm;
        this.sourceField = sourceField;
    }
}