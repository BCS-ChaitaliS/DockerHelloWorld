package gov.irs.jios.common.client.tr.pojo;

import lombok.Data;

@Data
public class MappingConfig {
	private SaveFields saveFields;
    private RetrieveFields retrieveFields;
}
