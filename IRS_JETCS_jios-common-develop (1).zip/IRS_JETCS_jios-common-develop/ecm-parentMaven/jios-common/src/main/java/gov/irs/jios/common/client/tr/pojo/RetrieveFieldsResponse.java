package gov.irs.jios.common.client.tr.pojo;

import java.util.List;

import lombok.Data;

@Data
public class RetrieveFieldsResponse {
	private List<FieldsResponse> fieldsResponse;

}
