package gov.irs.jios.common.client.tr.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Field {
    private String fieldId;
    private String value;
    private String index;
    
    @JsonProperty("isGroup")
    @JsonInclude(JsonInclude.Include.NON_DEFAULT)
    private boolean group;
}
