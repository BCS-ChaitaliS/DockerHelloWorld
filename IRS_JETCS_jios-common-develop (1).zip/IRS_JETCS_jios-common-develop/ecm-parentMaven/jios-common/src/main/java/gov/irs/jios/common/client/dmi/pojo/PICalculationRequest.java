package gov.irs.jios.common.client.dmi.pojo;

import java.util.List;

import lombok.Data;

@Data
public class PICalculationRequest {
    private String AgreedCd;
    private CalcInfo CalcInfo;
    private List<PenMain> PenMain;
    private List<FtpCalc> FTP_Calc;
    private List<Object> FTP_Not;
    private List<Object> FTP_Agreements;
    private List<AccCalc> Acc_Calc;
}
