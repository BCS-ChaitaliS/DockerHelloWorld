package gov.irs.jios.common.client.transformer;

import static gov.irs.jios.common.util.JiosCommonConstants.LINE_ITEMS;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_NAME_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.PER_RETURN_VALUE_TXT;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import gov.irs.jios.common.client.tr.pojo.Field;
import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import gov.irs.jios.common.client.tr.pojo.FieldsRequest;
import gov.irs.jios.common.client.tr.pojo.GroupField;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FormIRS1040Transformer {

	public static final String IRS1040 = "IRS1040";

	// TODO We should make the transformers implement interfaces.
	// TODO formMap should be available here, as some transformations require us to query other forms.
	public List<FieldMapping> transformFormIRS1040(Map<String, Object> formData, Map<String, Object> header) {
		List<FieldMapping> fieldMappings = new ArrayList<>();
		if (formData == null || header == null) {
			log.warn("FormData or header is null. Returning empty field mappings.");
			return fieldMappings;
		}

		fieldMappings = lumpSumElectionMethodIndMapping(formData, fieldMappings);
		fieldMappings = checkFilingStatusCode(formData, fieldMappings);
		return fieldMappings;

	}

	/**
	 * Allows you to directly manipulate the object sent to TR as a POJO.
	 * Useful if TR is expecting some unusual structure not handled by the framework.
	 * Runs once per instance of the given form (i.e. runs 4 times if you pass 4 IRS1040ScheduleC's)
	 * See branch https://bitbucket.org/vibrantech/jios-common/branch/example/customer-override-and-source-form-generation
	 *
	 * formMap is available here as a read-only, if you need to query other forms in a payload.
	 * Changes to formMap here will not be correctly parsed by the framework.
	 * For that, use overrideFormMap.
	 */
	public List<FieldsRequest> customSaveFieldTROverride(
			List<FieldsRequest> fieldsRequests,
			Map<String, Object> formData,
			Map<String, List<Map<String, Object>>> formMap
	){
		Boolean isIRADistributionExits = false;
		Boolean isIRSPensionExits = false;
		String iraDistributionsAmt = getTargetValue(formData, "/IRS1040/IRADistributionsAmt");
		String taxableIRAAmt = getTargetValue(formData, "/IRS1040/TaxableIRAAmt");
		if(iraDistributionsAmt != "" || taxableIRAAmt !="")
			isIRADistributionExits = true;
	
		fieldsRequests = append1099RTrGroup(fieldsRequests, iraDistributionsAmt, taxableIRAAmt, "4", isIRADistributionExits);

		// 5a 5b
		if(!isIRADistributionExits)
			isIRSPensionExits = true;
		String pensionsAnnuitiesAmt = getTargetValue(formData, "/IRS1040/PensionsAnnuitiesAmt");
		String totalTaxablePensionsAmt = getTargetValue(formData, "/IRS1040/TotalTaxablePensionsAmt");
		fieldsRequests = append1099RTrGroup(fieldsRequests, pensionsAnnuitiesAmt, totalTaxablePensionsAmt, "5", isIRSPensionExits);

		// TODO When the appropriate framework change is made, move the SCH-B code to the normal transform method.

		fieldsRequests = applyScheduleBRequestQuery(
				fieldsRequests,
				formData,
				formMap
		);

		return fieldsRequests;
	}

	/**
	 * If no schedule B is included, we apply these directly to the 1040. But,
	 * if a schedule B is included, we put these values there instead.
	 * See JETC-737 for more information.
	 */
	public List<FieldsRequest> applyScheduleBRequestQuery(
			List<FieldsRequest> fieldsRequests,
			Map<String, Object> formData,
			Map<String, List<Map<String, Object>>> formMap
	){
		try {
			List<Field> targetList = null;
			for ( FieldsRequest fieldsRequest : fieldsRequests){
				// Note- we are assuming we only send TR EXACTLY ONE ungrouped fieldsRequest.
				// If somehow we sent more, something went wrong.
				if (fieldsRequest.getGroupField() == null) {
					targetList = fieldsRequest.getFields();
					break;
				}
			}

			if (targetList == null) throw new NullPointerException("No ungrouped FieldsRequest found");

			if (formMap.keySet().contains("IRS1040ScheduleB")) {
				// Do nothing, as the SchB contains the necessary info already
				// And TR should auto populate the form
			} else {
				// Add these in manually, since TR doesn't do it
				Field taxableInterestAmt = generateNewField(
						"INT.INTINC", getTargetValue(formData, "/IRS1040/TaxableInterestAmt"), null, false);
				Field ordinaryDividendsAmt = generateNewField(
						"DIV.ORD", getTargetValue(formData, "/IRS1040/OrdinaryDividendsAmt"), null, false);
				targetList.add(taxableInterestAmt);
				targetList.add(ordinaryDividendsAmt);
			}
		} catch (NullPointerException e) {
			log.error("NPE in 1040 checks for Schedule B transformation: {}", e.getMessage());
		} catch (Exception e) {
			log.error("Unexpected error in 1040 checks for Schedule B transformation: {}", e.getMessage(), e);
		}
		return fieldsRequests;
	}

	private List<FieldMapping> lumpSumElectionMethodIndMapping(Map<String, Object> formData,
			List<FieldMapping> fieldMappings) {
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
		if (lineItems == null) {
			log.warn("No lineItems found in formData");
			return null;
		}

		for (Map<String, Object> lineItem : lineItems) {
			// No X case: 6a is mapped to MIS.TSAMT (for primary) and MIS.SSPMT (for
			// secondary).
			if ("/IRS1040/LumpSumElectionMethodInd".equals(lineItem.get(LINE_NAME_TXT))) {
				String LumpSumElectionMethodInd = (String) lineItem.get(PER_RETURN_VALUE_TXT);
				if (!LumpSumElectionMethodInd.toUpperCase().equals("X")) {
					String val = get6aVal(lineItems);
					fieldMappings = addFieldMapping(fieldMappings, "/IRS1040/SocSecBnftAmt", "MIS.TSAMT", val);
					fieldMappings = addFieldMapping(fieldMappings, "/IRS1040/SocSecBnftAmt", "MIS.SSPMT", val);
				} else {
					// X case: the values from 6a: map it to X133.678.21, take the value from 6b:
					// map it to X133.678.22.
					String val6A = get6aVal(lineItems);
					String val6B = get6bVal(lineItems);
					fieldMappings = addFieldMapping(fieldMappings, "/IRS1040/SocSecBnftAmt", "X133.678.21", val6A);
					fieldMappings = addFieldMapping(fieldMappings, "/IRS1040/TaxableSocSecAmt", "X133.678.22", val6B);
				}
			}
		}
		return fieldMappings;
	}

	// extracting the value from SocSecBnftAmt (line 6a)
	public String get6aVal(List<Map<String, Object>> lineItems) {

		String val = "";
		for (Map<String, Object> lineItem : lineItems) {
			if ("/IRS1040/SocSecBnftAmt".equals(lineItem.get(LINE_NAME_TXT))) {
				val = (String) lineItem.get(PER_RETURN_VALUE_TXT);
				return val;
			}
		}
		return val;
	}

	// extracting the value from TaxableSocSecAmt (line 6b)
	public String get6bVal(List<Map<String, Object>> lineItems) {

		String val = "";
		for (Map<String, Object> lineItem : lineItems) {
			if ("/IRS1040/TaxableSocSecAmt".equals(lineItem.get(LINE_NAME_TXT))) {
				val = (String) lineItem.get(PER_RETURN_VALUE_TXT);
				return val;
			}
		}
		return val;
	}

	// method checks if filing status is 2 (spouse (Married Filing Jointly))
	public List<FieldMapping> checkFilingStatusCode(Map<String, Object> formData, List<FieldMapping> fieldMappings) {
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
		if (lineItems == null) {
			log.warn("No lineItems found in formData");
			return null;
		}
		for (Map<String, Object> lineItem : lineItems) {
			// add SP.SSN and SP.BIRTH and store with the mock data
			if ("/IRS1040/IndividualReturnFilingStatusCd".equals(lineItem.get(LINE_NAME_TXT))) {
				String filingStatusCd = (String) lineItem.get(PER_RETURN_VALUE_TXT);
				if (filingStatusCd.equals("2")) {
					fieldMappings = addFieldMapping(fieldMappings, "FED.SPSSN", "111223334");
					fieldMappings = addFieldMapping(fieldMappings, "FED.SPBIRTH", "12/12/1985");
				}

			}
			// if the  /IRS1040/CapitalDistributionInd value 'X' then present /IRS1040/CapitalGainLossAmt 'X101.956.30'
			if ("/IRS1040/CapitalDistributionInd".equals(lineItem.get(LINE_NAME_TXT))) {
				String distributionInd = (String) lineItem.get(PER_RETURN_VALUE_TXT);
				if (distributionInd.toUpperCase().equals("X")) {
					String capitalAmt = getCapitalGainLossAmt(lineItems);
					fieldMappings = addFieldMapping(fieldMappings, "/IRS1040/CapitalGainLossAmt", "X101.956.30",capitalAmt);
				}

			}
		}
		return fieldMappings;
	}
	
	// extracting the value from getCapitalGainLossAmt
		public String getCapitalGainLossAmt(List<Map<String, Object>> lineItems) {

			String val = "";
			for (Map<String, Object> lineItem : lineItems) {
				if ("/IRS1040/CapitalGainLossAmt".equals(lineItem.get(LINE_NAME_TXT))) {
					val = (String) lineItem.get(PER_RETURN_VALUE_TXT);
					return val;
				}
			}
			return val;
		}

	private List<FieldsRequest> append1099RTrGroup(List<FieldsRequest> fieldsRequests,
									  String aField,
									  String bField,
									  String glyph, Boolean isIRAIndexAdded)
	{
		// We only generate the new form if any data exists in either required field.
		if (aField.isEmpty() && bField.isEmpty()) return fieldsRequests;
		Integer i = 0;
		if(!isIRAIndexAdded)
			//if index 0 has already added make i as 1
			i=1;
		FieldsRequest fr = new FieldsRequest();
		fr.setGroupField(new GroupField(i, "IRA.PAYER", "MOCK_PAYER_" + i, null));

		// TODO give Field an all-args constructor to make this more readable.
		List<Field> listOfFields = new ArrayList<>();
		fr.setFields(listOfFields);

		switch (glyph) {
			case "4":
				addFieldToListOfFields(listOfFields,"IRA.BOX1",aField,null,false);
				addFieldToListOfFields(listOfFields,"IRA.BOX2A",bField,null,false);
				addFieldToListOfFields(listOfFields,"IRA.TIRA","X",null,false);
				break;
			case "5":
				addFieldToListOfFields(listOfFields,"IRA.BOX1",aField,null,false);
				addFieldToListOfFields(listOfFields,"IRA.BOX2A",bField,null,false);
				addFieldToListOfFields(listOfFields,"IRA.BOX7","7",null,false);
				break;
		}

		fieldsRequests.add(fr);

		return fieldsRequests;
	}

	/**
	 * @param sourceField The lineNameTxt you expect to be sent in the ECM payload.
	 * The limitation here is that this should only be used on items that are guaranteed to be sent
	 * exactly once in the ECM payload. Do NOT use this if ECM may send a payload containing
	 * multiple instances of the desired sourceField.
	 */
	private String getTargetValue(Map<String, Object> formData, String sourceField){
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);

		for (Map<String, Object> lineItem : lineItems) {
			if (sourceField.equals(lineItem.get(LINE_NAME_TXT))) {
				return (String) lineItem.get(PER_RETURN_VALUE_TXT);
			}
		}

		return "";
	}

	private List<FieldMapping> addFieldMapping(List<FieldMapping> mappings, String sourceField, String targetField,
			String targetFieldValue) {
		FieldMapping mapping = new FieldMapping();
		mapping.setSourceForm(IRS1040);
		mapping.setSourceField(sourceField);
		mapping.setTargetField(targetField);
		mapping.setTargetFieldValue(targetFieldValue);
		mappings.add(mapping);
		return mappings;
	}

	private List<FieldMapping> addFieldMapping(List<FieldMapping> mappings, String targetField,
			String targetFieldValue) {
		FieldMapping mapping = new FieldMapping();
		mapping.setSourceForm(IRS1040);
		mapping.setTargetField(targetField);
		mapping.setTargetFieldValue(targetFieldValue);
		mappings.add(mapping);
		return mappings;
	}

	private void addFieldToListOfFields(
			List<Field> listOfFields,
			String fieldId,
			String value,
			String index,
			boolean group
	){
		Field f = new Field();
		f.setFieldId(fieldId);
		f.setValue(value);
		f.setIndex(index);
		f.setGroup(group);
		listOfFields.add(f);
	}

	private Field generateNewField(
			String fieldId,
			String value,
			String index,
			boolean group
	){
		Field f = new Field();
		f.setFieldId(fieldId);
		f.setValue(value);
		f.setIndex(index);
		f.setGroup(group);
		return f;
	}
}
