package gov.irs.jios.common.client.tr.util;

import static gov.irs.jios.common.util.JiosCommonConstants.EMPTY_STRING;

import java.util.List;
import java.util.Map;

import gov.irs.jios.common.request.ValidatableRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TRCommonUtil {
	
	public static String cleanTrValue(String trValue) {
	    if (trValue == null) {
	        return null;
	    }
	    if (trValue.trim().equals("NONE")) {
	        return "0";
	    }
	    // Remove trailing spaces, commas, and period
	    String cleaned = trValue.trim().replaceAll("[,\\s]+$", EMPTY_STRING).replaceAll("\\.$", EMPTY_STRING);
	    
	    // Remove commas from the middle of the string (for proper numeric parsing)
	    cleaned = cleaned.replace(",", EMPTY_STRING);
	    //log.debug("Cleaned TR value from '{}' to '{}'", trValue, cleaned);
	    
	    return cleaned;
	}
	
	@SuppressWarnings("unchecked")
    public static String findTotalTaxAmount(ValidatableRequest inputPayload) {
        Map<String, Object> body = inputPayload.getBody();
        List<Map<String, Object>> forms = (List<Map<String, Object>>) body.get("forms");
        
        for (Map<String, Object> form : forms) {
            if (!"IRS1040".equals(form.get("formNum"))) {
                continue;
            }
            
            List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get("lineItems");
            for (Map<String, Object> lineItem : lineItems) {
                String lineNameTxt = (String) lineItem.get("lineNameTxt");
                if ("/IRS1040/TotalTaxAmt".equals(lineNameTxt)) {
                    return (String) lineItem.get("perReturnValueTxt");
                }
            }
        }
        return "0";
    }
}
