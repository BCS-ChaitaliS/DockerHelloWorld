package gov.irs.jios.common.client.transformer;

/**
 * Sometimes, TR expects "NONE" instead of "0", so this handles that.
 */
public class ZeroToNoneTransformer {

    public static String transformEcmToTr(String value) {
    	if (value.equals("0")) {
    		return "NONE";
    	} else {
			return value;
		}
    }

    public static String transformTrToEcm(String value) {
		if (value.equals("NONE")) {
			return "0";
		} else {
			return value;
		}
    }
}
