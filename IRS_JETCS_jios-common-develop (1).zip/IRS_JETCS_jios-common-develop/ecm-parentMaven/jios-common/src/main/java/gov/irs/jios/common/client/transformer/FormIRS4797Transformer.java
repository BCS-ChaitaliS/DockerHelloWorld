package gov.irs.jios.common.client.transformer;

import static gov.irs.jios.common.util.JiosCommonConstants.LINE_ITEMS;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_NAME_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.PER_RETURN_VALUE_TXT;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FormIRS4797Transformer {

	public static final String IRS4797 = "IRS4797";
	public static final String SLSODES = "SLS.ODES";
	

	public List<FieldMapping> transformFormIRS4797(Map<String, Object> formData, Map<String, Object> header) {
		List<FieldMapping> fieldMappings = new ArrayList<>();
		if (formData == null || header == null) {
			log.warn("FormData or header is null. Returning empty field mappings.");
			return fieldMappings;
		}

		mapSalesOfBusinessProperty(formData, fieldMappings);

		return fieldMappings;

	}

	@SuppressWarnings("unchecked")
	private void mapSalesOfBusinessProperty(Map<String, Object> formData, List<FieldMapping> fieldMappings) {

		List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
		if (lineItems == null) {
			log.warn("No lineItems found in formData");
			return;
		}

		Properties properties = new Properties();
		try (InputStream is = getClass().getClassLoader().getResourceAsStream("common/application.properties")) {
			properties.load(is);
		} catch (Exception e) {
			log.error("Exception reading application.properties " + e.getMessage());
		}
		
		 List<String> dateFields = List.of("/IRS4797/PropertySaleOrExchange/AcquiredDt", "/IRS4797/PropertySaleOrExchange/SoldDt", 
				 "/IRS4797/OrdinaryGainLoss/AcquiredDt", "/IRS4797/OrdinaryGainLoss/SoldDt","/IRS4797/PropertyDispositionGain/SoldDt",
				 "/IRS4797/PropertyDispositionGain/AcquiredDt");
	        
		Map<String, String> ecmToTrMappings = ecmToTrMapping();
		
		for (Map<String, Object> lineItem : lineItems) {

			if ("/IRS4797/PropertySaleOrExchange".equals(lineItem.get(LINE_NAME_TXT))) {

				addFieldMapping(fieldMappings, "SLS.OTYPE", properties.getProperty("mock.4797.1231.otype"));
				gainAndLossMapping(ecmToTrMappings, lineItem, dateFields, fieldMappings);
			}
			if ("/IRS4797/OrdinaryGainLoss".equals(lineItem.get(LINE_NAME_TXT))) {

				addFieldMapping(fieldMappings, "SLS.OTYPE", properties.getProperty("mock.4797.ordinary.otype"));
				gainAndLossMapping(ecmToTrMappings, lineItem, dateFields, fieldMappings);

			}
			if ("/IRS4797/PropertyDispositionGain".equals(lineItem.get(LINE_NAME_TXT))) {

				addFieldMapping(fieldMappings, "SLS.OTYPE", properties.getProperty("mock.4797.1250.otype"));
				gainAndLossMapping(ecmToTrMappings, lineItem, dateFields, fieldMappings);

			}
		}

	}
	
	@SuppressWarnings("unchecked")
	private void gainAndLossMapping(Map<String, String> ecmToTrMappings, Map<String, Object> lineItem,
			 List<String> dateFields, List<FieldMapping> fieldMappings) {
		
		List<Map<String, Object>> gainAndLossGrpLineItems = (List<Map<String, Object>>) lineItem.get(LINE_ITEMS);
		for (Map<String, Object> gainAndLossLineItem : gainAndLossGrpLineItems) {
			String ecmAttribute = (String) gainAndLossLineItem.get(LINE_NAME_TXT);
			if (ecmToTrMappings.containsKey(ecmAttribute)) {
				String targetField = ecmToTrMappings.get(ecmAttribute);
				String ecmValue = (String) gainAndLossLineItem.get(PER_RETURN_VALUE_TXT);
				if (dateFields.contains(ecmAttribute)) {
					ecmValue = DateTransformers.ECMDateTypeToTRDate(ecmValue);
				}
				addFieldMapping(fieldMappings, targetField, ecmValue);
			}
		}
		
	}

	
	private Map<String, String> ecmToTrMapping() {

		Map<String, String> ecmToTrMappings = new HashMap<String, String>();
	
		ecmToTrMappings.put("/IRS4797/PropertySaleOrExchange/AcquiredDt", "SLS.ODATEA");
		ecmToTrMappings.put("/IRS4797/PropertySaleOrExchange/DateAcquiredInheritedCd", "X100.3205.17");
		ecmToTrMappings.put("/IRS4797/PropertySaleOrExchange/SoldDt", "SLS.ODATES");
		ecmToTrMappings.put("/IRS4797/PropertySaleOrExchange/VariousCd", "X100.3205.16");
		ecmToTrMappings.put("/IRS4797/PropertySaleOrExchange/GrossSalesPriceAmt", "SLS.OSALE");
		ecmToTrMappings.put("/IRS4797/PropertySaleOrExchange/DepreciationAllowedAmt", "SLS.OAD");
		ecmToTrMappings.put("/IRS4797/PropertySaleOrExchange/CostOrOtherBasisAmt", "SLS.OCOST");	
		
		ecmToTrMappings.put("/IRS4797/OrdinaryGainLoss/AcquiredDt", "SLS.ODATEA");
		ecmToTrMappings.put("/IRS4797/OrdinaryGainLoss/DateAcquiredInheritedCd", "X100.3205.17");
		ecmToTrMappings.put("/IRS4797/OrdinaryGainLoss/SoldDt", "SLS.ODATES");
		ecmToTrMappings.put("/IRS4797/OrdinaryGainLoss/VariousCd", "X100.3205.16");
		ecmToTrMappings.put("/IRS4797/OrdinaryGainLoss/GrossSalesPriceAmt", "SLS.OSALE");
		ecmToTrMappings.put("/IRS4797/OrdinaryGainLoss/DepreciationAllowedAmt", "SLS.OAD");
		ecmToTrMappings.put("/IRS4797/OrdinaryGainLoss/CostOrOtherBasisAmt", "SLS.OCOST");
		
		ecmToTrMappings.put("/IRS4797/PropertyDispositionGain/AcquiredDt", "SLS.ODATEA");
		ecmToTrMappings.put("/IRS4797/PropertyDispositionGain/DateAcquiredInheritedCd", "X100.3205.17");
		ecmToTrMappings.put("/IRS4797/PropertyDispositionGain/SoldDt", "SLS.ODATES");
		ecmToTrMappings.put("/IRS4797/PropertyDispositionGain/VariousCd", "X100.3205.16");
		ecmToTrMappings.put("/IRS4797/PropertyDispositionGain/GrossSalesPriceAmt", "SLS.OSALE");
		ecmToTrMappings.put("/IRS4797/PropertyDispositionGain/CostOrOtherBasisExpenseSaleAmt", "SLS.OAD");
		ecmToTrMappings.put("/IRS4797/PropertyDispositionGain/DepreciationDepletionAllwAmt", "SLS.OCOST");
		ecmToTrMappings.put("/IRS4797/PropertyDispositionGain/AddnlDepreciationAfter1975Amt", "SLS.OPOST");
		ecmToTrMappings.put("/IRS4797/PropertyDispositionGain/AddnlDepreciation1969To1976Amt", "SLS.OPRE");
		ecmToTrMappings.put("/IRS4797/PropertyDispositionGain/SoilWaterLandClearExpenseAmt", "SLS.OSOIL");
		ecmToTrMappings.put("/IRS4797/PropertyDispositionGain/IntangibleDrillingDevCostAmt", "SLS.OIDC");
		ecmToTrMappings.put("/IRS4797/PropertyDispositionGain/ApplcblPctPaymentExcludedAmt", "SLS.O126");
		
		
		return ecmToTrMappings;

	}

	
	private List<FieldMapping> addFieldMapping(List<FieldMapping> mappings, String sourceField, String targetField,
			String targetFieldValue) {
		FieldMapping mapping = new FieldMapping();
		mapping.setSourceForm(IRS4797);
		mapping.setSourceField(sourceField);
		mapping.setTargetField(targetField);
		mapping.setTargetFieldValue(targetFieldValue);
		mapping.setGroupField(SLSODES);
		mappings.add(mapping);
		return mappings;
	}
	
	private void addFieldMapping(List<FieldMapping> mappings, String targetField, String targetFieldValue) {
		addFieldMapping(mappings, null, targetField, targetFieldValue);
	}
	
	
}
