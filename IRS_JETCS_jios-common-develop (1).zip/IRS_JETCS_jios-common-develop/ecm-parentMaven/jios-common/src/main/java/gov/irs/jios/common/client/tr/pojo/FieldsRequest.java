package gov.irs.jios.common.client.tr.pojo;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class FieldsRequest {
    private GroupField groupField;
    private List<Field> fields;
    @JsonIgnore
    private Map<String, Object> sourceInstance;
}