package gov.irs.jios.common.client.tr.service;

import static gov.irs.jios.common.util.JiosCommonConstants.AUTH_TOKEN;
import static gov.irs.jios.common.util.JiosCommonConstants.TAX_PERIOD;
import static gov.irs.jios.common.util.JiosCommonConstants.TAX_RETURN_SESSION_TOKEN;

import java.io.IOException;
import java.rmi.ServerException;
import java.time.Duration;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.irs.jios.common.client.config.DynamicMappingConfigLoader;
import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import gov.irs.jios.common.client.tr.pojo.SaveFieldsRequest;
import gov.irs.jios.common.client.tr.pojo.TrConfig;
import gov.irs.jios.common.ecm.pojo.ErrorResponse;
import gov.irs.jios.common.exception.ValidationException;
import gov.irs.jios.common.request.ValidatableRequest;
import gov.irs.jios.common.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

@Service
@Slf4j
public class SaveFieldsService {
	
	@Value("${webclient.retry.max-attempts:3}")
	private int maxAttempts;

	@Value("${webclient.retry.interval:100}")
	private long retryInterval;
	
	@Value("${should.make.tr.call:true}")
	private boolean shouldMakeTrCall;
	
	@Autowired
	private DynamicMappingConfigLoader configLoader;
	
	@Autowired
    private ErrorTransformationService errorTransformationService;
	 
	@Autowired
    private OpenSnapshotService openSnapshotService;

    private final WebClient webClient;
    private final TransformationService transformationService;
    private final ObjectMapper objectMapper;

    public SaveFieldsService(WebClient.Builder webClientBuilder,
                             TrConfig trConfig,
                             TransformationService transformationService,
                             ObjectMapper objectMapper) {
        this.webClient = webClientBuilder.baseUrl(trConfig.getSaveFieldsUrl()).build();
        this.transformationService = transformationService;
        this.objectMapper = objectMapper;
    }
    
    // Adding this method for backward compatibility with other services still using this signature of saveFields
    //@Profiled - commented out by Mani as this is causing some issue for calcType partial
    public Map<String, String> saveFields(ValidatableRequest request, String token, Map<String, String> authTokenSessionToken) throws IOException {
    	return saveFields(request, token, authTokenSessionToken, null, null);
    }

    //@Profiled - commented out by Mani as this is causing some issue for calcType partial
    public Map<String, String> saveFields(ValidatableRequest request, String token, Map<String, String> authTokenSessionToken, String locatorId, MultipartFile file) throws ValidationException, IOException {
    	
    	transformationService.setSnapShotPresent(file != null);
    	
    	String taxYear = extractTaxYear(request);
        List<FieldMapping> fieldMappings = configLoader.getSaveRequestFieldsMappings(taxYear);
		SaveFieldsRequest saveFieldsRequest = transformationService.transformEcmToTrSaveFields(request, fieldMappings);
		
		//This section is only for printing the TR request payload
		try {
			String sfRequestsJson = objectMapper.writeValueAsString(saveFieldsRequest);
			log.info("saveFields - Request JSON to TR: {}", sfRequestsJson);
		} catch (JsonProcessingException e) {
			log.error("Error converting TR SaveFields Request payload to JSON", e);
		}
        
		if(shouldMakeTrCall) {
			if(file != null) {
                // Open the snapshot in TR
                authTokenSessionToken = openSnapshotService.openSnapshot(token, taxYear, locatorId, file);
                log.info("authTokenSessionToken from open snapshot: {}", authTokenSessionToken);
			}
			sendSaveFieldsRequest(request, saveFieldsRequest, token, authTokenSessionToken, taxYear).block(); // Blocking call
		}
		return authTokenSessionToken;
    }

    @SuppressWarnings("serial")
    private Mono<Void> sendSaveFieldsRequest(ValidatableRequest request, SaveFieldsRequest saveFieldsRequest, 
            String token, Map<String, String> authTokenSessionToken, String taxYear) {
        return webClient.post()
            .headers(headers -> {
                headers.setBearerAuth(token);
                headers.set(AUTH_TOKEN, authTokenSessionToken.get(AUTH_TOKEN));
                headers.set(TAX_RETURN_SESSION_TOKEN, authTokenSessionToken.get(TAX_RETURN_SESSION_TOKEN));
            })
            .bodyValue(saveFieldsRequest)
            .retrieve()
            .onStatus(httpStatus -> httpStatus.value() == 207, response ->
                response.bodyToMono(String.class)
                    .flatMap(body -> {
                        ErrorResponse errorResponse = errorTransformationService.transformTrValidationError(request.getHeader(), body, taxYear);
                        try {
                            String responseJson = objectMapper.writeValueAsString(errorResponse);
                            return Mono.error(new ValidationException(responseJson) {
                                @Override
                                public void printStackTrace() {}
                            });
                        } catch (JsonProcessingException e) {
                            log.error("JsonProcessingException occurred during TR Validation: {}", e.toString());
                            return Mono.error(e);
                        }
                    })
            )
            .onStatus(HttpStatusCode::is5xxServerError, response ->
                response.bodyToMono(String.class)
                    .flatMap(body -> {
                        ErrorResponse errorResponse = errorTransformationService.createServerErrorResponse(request.getHeader(), body);
                        try {
                            String responseJson = objectMapper.writeValueAsString(errorResponse);
                            return Mono.error(new ServerException(responseJson) {
                                @Override
                                public void printStackTrace() {}
                            });
                        } catch (JsonProcessingException e) {
                            log.error("JsonProcessingException occurred during Server Error handling: {}", e.toString());
                            return Mono.error(e);
                        }
                    })
            )
            .bodyToMono(Void.class)
            .doOnSuccess(v -> log.info("Save fields request was successful!"))
            .onErrorResume(WebClientResponseException.class, e -> {
                if (e.getStatusCode().is2xxSuccessful()) {
                    log.info("Save fields request was successful with empty response");
                    return Mono.empty();
                }
                return Mono.error(e);
            })
            .retryWhen(Retry.backoff(maxAttempts, Duration.ofMillis(retryInterval))
                .filter(throwable -> throwable instanceof WebClientResponseException &&
                                   ((WebClientResponseException) throwable).getStatusCode().is5xxServerError()));
    }
    
    private String extractTaxYear(ValidatableRequest request) {
        String taxPrd = (String) request.getHeader().get(TAX_PERIOD);
        if (taxPrd == null) {
            throw new IllegalArgumentException("taxPrd is missing in the header");
        }
        return CommonUtil.extractTaxYear(taxPrd);
    }
}