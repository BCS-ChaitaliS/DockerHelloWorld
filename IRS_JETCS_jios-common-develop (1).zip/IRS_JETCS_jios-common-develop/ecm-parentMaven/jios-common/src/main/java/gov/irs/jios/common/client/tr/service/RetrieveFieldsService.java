package gov.irs.jios.common.client.tr.service;

import static gov.irs.jios.common.util.JiosCommonConstants.AUTH_TOKEN;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.SECOND_CALL_FOR_PARTIAL_TAX_CALC;
import static gov.irs.jios.common.util.JiosCommonConstants.TAX_RETURN_SESSION_TOKEN;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.irs.jios.common.client.tr.pojo.RetrieveFieldsRequest;
import gov.irs.jios.common.client.tr.pojo.RetrieveFieldsResponse;
import gov.irs.jios.common.client.tr.pojo.RetrieveFieldsResponseDTO;
import gov.irs.jios.common.client.tr.pojo.TrConfig;
import gov.irs.jios.common.request.ValidatableRequest;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

@Service
@Slf4j
public class RetrieveFieldsService {

    @Value("${webclient.retry.max-attempts:3}")
    private int maxAttempts;

    @Value("${webclient.retry.interval:100}")
    private long retryInterval;
    
    @Value("${should.make.tr.call:true}")
	private boolean shouldMakeTrCall;

    private final WebClient webClient;
    private final TransformationService transformationService;
    private final ObjectMapper objectMapper;

    public RetrieveFieldsService(WebClient.Builder webClientBuilder,
                                 TrConfig trConfig,
                                 TransformationService transformationService,
                                 ObjectMapper objectMapper) {
        this.webClient = webClientBuilder.baseUrl(trConfig.getRetrieveFieldsUrl()).build();
        this.transformationService = transformationService;
        this.objectMapper = objectMapper;
    }

    public RetrieveFieldsResponseDTO retrieveFields(ValidatableRequest request, String token, Map<String, String> authTokenSessionToken) {

    	RetrieveFieldsRequest retrieveFieldsRequest = transformationService.generateRetrieveFieldsPayload(request);

        //This section is only for printing the request payload
    	try {
            String requestJson = objectMapper.writeValueAsString(retrieveFieldsRequest);
            log.info("retrieveFields - Request JSON to TR: {}", requestJson);
        } catch (JsonProcessingException e) {
            log.error("retrieveFields - Error converting request payload to JSON", e);
        }
    	
  		RetrieveFieldsResponseDTO response = new RetrieveFieldsResponseDTO();
  		Map<String, Object> responseBody = null;
        String responseJson = null;

        try {
        	if (shouldMakeTrCall) {
        		RetrieveFieldsResponse retrieveFieldsResponse = sendRetrieveFieldsRequest(retrieveFieldsRequest, token, authTokenSessionToken).block(); // Blocking call

                //This section is only for printing the response payload
          		try {
          			String rfResponseJson = objectMapper.writeValueAsString(retrieveFieldsResponse);
          			log.info("retrieveFields - Response JSON from TR: {}", rfResponseJson);

          			String calcTypeTxt = (String) request.getHeader().get(CALC_TYPE_TXT);
                    if (calcTypeTxt != null && calcTypeTxt.startsWith("penalty")) {
                    	log.info("Reverse mapping is skipped as this is a Penalty Call.");
                    	response.setJsonResponse(rfResponseJson);
                    	return response;
                    }
          		} catch (JsonProcessingException e) {
          			log.error("retrieveFields - Error converting TR Response payload to JSON", e);
          		}
          		
          		responseBody = transformationService.transformTrToEcm(request, retrieveFieldsResponse);
          		if(request.getHeader().containsKey(SECOND_CALL_FOR_PARTIAL_TAX_CALC)) {
          			request.getHeader().remove(SECOND_CALL_FOR_PARTIAL_TAX_CALC);
          		}

                //This section is only for printing the response payload
          		try {
          			responseJson = objectMapper.writeValueAsString(request);
          			log.info("retrieveFields - Response JSON to ECM: {}", responseJson);
          			
          		} catch (JsonProcessingException e) {
          			log.error("retrieveFields - Error converting ECM Response payload to JSON", e);
          		}
        	}
        	else {
        		responseBody = new HashMap<>();
        		responseBody.put("forms", new ArrayList<Map<String, Object>>());
        	}
        	
        	response.setStructuredResponse(responseBody);
            response.setJsonResponse(responseJson); // Set the original JSON response

        } catch (Exception e) {
        	log.error("Error sending RetrieveField request: {}", e.toString());
        }
        return response;
    }

    private Mono<RetrieveFieldsResponse> sendRetrieveFieldsRequest(RetrieveFieldsRequest request, String token, Map<String, String> authTokenSessionToken) {
    	return webClient.post()
                .headers(headers -> {
                    headers.setBearerAuth(token);
                    headers.set(AUTH_TOKEN, authTokenSessionToken.get(AUTH_TOKEN));
                    headers.set(TAX_RETURN_SESSION_TOKEN, authTokenSessionToken.get(TAX_RETURN_SESSION_TOKEN));
                })
                .bodyValue(request)
                .retrieve()
                .bodyToMono(RetrieveFieldsResponse.class)
                .retryWhen(Retry.backoff(maxAttempts, Duration.ofMillis(retryInterval))
                        .filter(throwable -> throwable instanceof WebClientException));
    }
}