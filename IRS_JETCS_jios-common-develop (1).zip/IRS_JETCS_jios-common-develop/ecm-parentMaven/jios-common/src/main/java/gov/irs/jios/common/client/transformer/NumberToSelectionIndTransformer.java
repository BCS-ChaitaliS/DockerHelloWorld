package gov.irs.jios.common.client.transformer;

import lombok.extern.slf4j.Slf4j;

@Slf4j
/**
 * Let's say ECM sends a number, like 7500. This may be mapped to a TR field that is expecting some sort of indicator,
 * such as X for a number > 4000 and Blank for a number < 4000. This transformer holds methods that
 * handle that, as well as any other sort of numerical COMPARISON.
 *
 * Define a transformer method here that handles your particular case.
 */
public class NumberToSelectionIndTransformer {

    public String transformMaxQlfyCmrclCleanVehCrAmtEcmToTr(String ecmPayloadValue) {
        try {
            if (ecmPayloadValue == null) {
                ecmPayloadValue = "";
            }

            float value = Float.parseFloat(ecmPayloadValue);

            String trIndicator = null;

			/*
             * ECM should be sending numbers in "7000" type format, not "7,000" format (i.e. no comma)
			 */
            if (value == 7500){
                trIndicator =  "";
            } else if (value == 40000){
				trIndicator =  "X";
			} else {
				trIndicator =  "";
			}

            return trIndicator;
        } catch (Exception e){
            log.warn("InventoryValuationIndTransformer: " + e.getMessage());
            return "";
        }
    }

}