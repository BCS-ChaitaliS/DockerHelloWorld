package gov.irs.jios.common.client.tr.service;

import java.time.Duration;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.irs.jios.common.client.tr.pojo.LocatorRequest;
import gov.irs.jios.common.client.tr.pojo.TrConfig;
import gov.irs.jios.common.exception.ConfigurationException;
import gov.irs.jios.common.profiler.Profiled;
import gov.irs.jios.common.util.CommonUtil;
import static gov.irs.jios.common.util.JiosCommonConstants.*;
import lombok.extern.slf4j.Slf4j;
import reactor.util.retry.Retry;

@Slf4j
@Service
public class AuthLocatorService {

	@Value("${webclient.retry.max-attempts:3}")
	private int maxAttempts;

	@Value("${webclient.retry.interval:100}")
	private long retryInterval;
	
	@Value("${mock.primary.taxpayer.fname:John}")
	private String tpFirstName;
	
	@Value("${mock.primary.taxpayer.lname:Doe}")
	private String tpLastName;

	private final WebClient webClient;
	private final TrConfig trConfig;
	private final ObjectMapper objectMapper;

	public AuthLocatorService(WebClient.Builder webClientBuilder, TrConfig trConfig, ObjectMapper objectMapper) {
		this.webClient = webClientBuilder.build();
		this.trConfig = trConfig;
		this.objectMapper = objectMapper;
	}

	@Profiled("GetToken")
	public String getToken() {
		Map<String, String> requestBody = createTokenRequestBody();
		log.info("trConfig: {}", trConfig);
		return webClient.post()
			.uri(trConfig.getTokenUrl())
			.contentType(MediaType.APPLICATION_JSON)
			.bodyValue(requestBody)
			.retrieve()
			.bodyToMono(String.class)
			.retryWhen(Retry.backoff(maxAttempts, Duration.ofMillis(retryInterval))
					.filter(throwable -> throwable instanceof WebClientException))
			.map(this::parseTokenResponse)
			.block();
	}

	protected Map<String, String> createTokenRequestBody() {
		return Map.of("client_id", trConfig.getClientId(), "client_secret", trConfig.getClientSecret(), "scopes",
				trConfig.getScopes(), "grant_type", trConfig.getGrantType());
	}

	protected String parseTokenResponse(String responseBody) {
		try {
			Map<String, Object> responseMap = objectMapper.readValue(responseBody,
					new TypeReference<Map<String, Object>>() {
					});
			return (String) responseMap.get(TOKEN);
		} catch (JsonProcessingException e) {
			throw new RuntimeException("Failed to parse token response", e);
		}
	}

	@Profiled("createLocator")
	public String createLocator(Map<String, Object> header, String token) {
		String taxPrd = (String) header.get(TAX_PERIOD);
        if (taxPrd == null) {
            throw new IllegalArgumentException("taxPrd is missing in the header");
        }
        String taxYear;
        try {
            taxYear = CommonUtil.extractTaxYear(taxPrd);
        } catch (IllegalArgumentException e) {
            throw new ConfigurationException("Invalid tax period in header: " + e.getMessage());
        }
		LocatorRequest request = buildLocatorRequest(taxYear);

		return webClient.post()
			.uri(trConfig.getLocatorUrl())
			.contentType(MediaType.APPLICATION_JSON)
			.headers(headers -> headers.setBearerAuth(token))
			.bodyValue(request)
			.retrieve().bodyToMono(String.class)
			.retryWhen(Retry.backoff(maxAttempts, Duration.ofMillis(retryInterval))
					.filter(throwable -> throwable instanceof WebClientException))
			.map(this::parseLocatorResponse)
			.block();
	}

	protected String parseLocatorResponse(String responseBody) {
		try {
			Map<String, String> responseMap = objectMapper.readValue(responseBody,
					new TypeReference<Map<String, String>>() {
					});
			String locatorId = responseMap.get(LOCATOR_ID);
			if (locatorId != null) {
				return locatorId;
			}
			throw new RuntimeException("LocatorId not found in response");
		} catch (JsonProcessingException e) {
			throw new RuntimeException("Failed to parse locator response", e);
		}
	}

	private LocatorRequest buildLocatorRequest(String taxYear) {
		return LocatorRequest.builder().account(trConfig.getAccount()).taxyear(taxYear)
			.taxtype(trConfig.getTaxtype()).returntype(trConfig.getReturntype())
			.taxPayer(new LocatorRequest.TaxPayer(tpFirstName, "", tpLastName, ""))
			.spouse(new LocatorRequest.TaxPayer("", "", "", "")).entitytype("").datasource("").entityname("")
			.password("").clientPrefix("").appType("GRS") // TODO - should come from property file - Need a task for a developer
			.clientnote("").clientcode("").fein("").PreparerValue(new LocatorRequest.PreparerValue("", ""))
			.ReviewerValue(new LocatorRequest.PreparerValue("", ""))
			.ManagerValue(new LocatorRequest.PreparerValue("", ""))
			.PartnerValue(new LocatorRequest.PreparerValue("", ""))
			.GroupsAssignment(List.of(new LocatorRequest.GroupAssignment("", Collections.emptyList()),
					new LocatorRequest.GroupAssignment("", Collections.emptyList())))
			.build();
	}
}