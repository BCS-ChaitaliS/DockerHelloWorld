package gov.irs.jios.common.client.dmi.pojo;

import lombok.Data;

@Data
public class FtpCalc {
    private String penaltySectionCd;
    private String installAgreeInd;
    private String fraudulentInd;
    private String returnIncomeInd;
    private double assessmentAmt;
    private String assessmentDt;
    private String bankruptcyInd;
    private String previouslyAssessedPenaltyAmt;
}
