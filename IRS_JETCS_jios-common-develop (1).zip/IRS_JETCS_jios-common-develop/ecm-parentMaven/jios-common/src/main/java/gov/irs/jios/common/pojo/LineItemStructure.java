package gov.irs.jios.common.pojo;

import java.util.HashMap;
import java.util.Map;

import static gov.irs.jios.common.util.JiosCommonConstants.SEQUENCE_NUM;

public class LineItemStructure {
    private final Map<String, Map<String, Object>> lineNameToLineItemMap = new HashMap<>();
    private final Map<String, Object> form;
    private final String formSequenceNum;
    
    public LineItemStructure(Map<String, Object> form) {
        this.form = form;
        this.formSequenceNum = (String) form.get(SEQUENCE_NUM);
    }
    
    public void addLineItem(String lineNameTxt, String sequenceNum, Map<String, Object> lineItem) {
        // Use form's sequence number for lookup key
        lineNameToLineItemMap.put(lineNameTxt + "_" + formSequenceNum, lineItem);
    }
    
    public Map<String, Object> getLineItem(String lineNameTxt, String sequenceNum) {
        // Use form's sequence number for lookup
        return lineNameToLineItemMap.get(lineNameTxt + "_" + formSequenceNum);
    }
    
    public Map<String, Object> getForm() {
        return form;
    }
}