package gov.irs.jios.common.client.tr.pojo;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class LocatorRequest {
    private String account;
    private String taxyear;
    private String taxtype;
    private TaxPayer taxPayer;
    private TaxPayer spouse;
    private String returntype;
    private String entitytype;
    private String datasource;
    private String entityname;
    private String password;
    private String clientPrefix;
    private String appType;
    private String clientnote;
    private String clientcode;
    private String fein;
    private PreparerValue PreparerValue;
    private PreparerValue ReviewerValue;
    private PreparerValue ManagerValue;
    private PreparerValue PartnerValue;
    private List<GroupAssignment> GroupsAssignment;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TaxPayer {
        private String firstname;
        private String middleinitial;
        private String lastname;
        private String suffix;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PreparerValue {
        private String location;
        private String loginId;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class GroupAssignment {
        private String location;
        private List<String> groups;
    }
}

