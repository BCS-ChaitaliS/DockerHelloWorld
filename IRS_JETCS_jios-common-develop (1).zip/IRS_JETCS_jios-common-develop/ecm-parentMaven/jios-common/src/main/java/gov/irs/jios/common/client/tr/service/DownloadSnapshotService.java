package gov.irs.jios.common.client.tr.service;

import static gov.irs.jios.common.util.JiosCommonConstants.AUTH_TOKEN;
import static gov.irs.jios.common.util.JiosCommonConstants.TAX_RETURN_SESSION_TOKEN;

import java.io.IOException;
import java.time.Duration;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import gov.irs.jios.common.client.tr.pojo.TrConfig;
import gov.irs.jios.common.profiler.Profiled;
import lombok.extern.slf4j.Slf4j;
import reactor.util.retry.Retry;

@Service
@Slf4j
public class DownloadSnapshotService {
	
	@Value("${webclient.retry.max-attempts:3}")
	private int maxAttempts;

	@Value("${webclient.retry.interval:100}")
	private long retryInterval;
	
    private final WebClient webClient;
    
    public DownloadSnapshotService(WebClient.Builder webClientBuilder,
                             TrConfig trConfig) {
        this.webClient = webClientBuilder.baseUrl(trConfig.getSnapshotDownloadUrl()).build();
    }

    @Profiled
    public ResponseEntity<byte[]> downloadSnapshot(String token, Map<String, String> authTokenSessionToken) 
    					throws IOException {
    	
       	return webClient.get()
	       		     .headers(headers -> {
	                     headers.setBearerAuth(token);
	                     headers.set(AUTH_TOKEN, authTokenSessionToken.get(AUTH_TOKEN));
	                     headers.set(TAX_RETURN_SESSION_TOKEN, authTokenSessionToken.get(TAX_RETURN_SESSION_TOKEN));
	                 })
       		        .retrieve()
       		        .toEntity(byte[].class)
       		        .doOnSuccess(v -> log.info("TR Download snapshot request successful"))
       		        .retryWhen(Retry.backoff(maxAttempts, Duration.ofMillis(retryInterval))
       	                .filter(throwable -> throwable instanceof WebClientResponseException &&
       	                  ((WebClientResponseException) throwable).getStatusCode().is5xxServerError()))
       		        .block();
    }
    
}