package gov.irs.jios.common.client.transformer;

import static gov.irs.jios.common.util.JiosCommonConstants.LINE_ITEMS;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_NAME_TXT;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import gov.irs.jios.common.client.tr.pojo.Field;
import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import gov.irs.jios.common.client.tr.pojo.FieldsRequest;
import gov.irs.jios.common.client.tr.pojo.GroupField;
import gov.irs.jios.common.client.tr.service.TransformationService;

public class Form1040ScheduleBTransformer {
	
	public List<FieldMapping> transformForm1040ScheduleB(Map<String, Object> formData, Map<String, Object> header) {
		return null;
	}

	/**
	 * Allows you to directly manipulate the object sent to TR as a POJO. Useful if
	 * TR is expecting some unusual structure not handled by the framework. Runs
	 * once per instance of the given form (i.e. runs 4 times if you pass 4
	 * IRS1040ScheduleC's See branch
	 * https://bitbucket.org/vibrantech/jios-common/branch/example/customer-override-and-source-form-generation
	 *
	 * formMap is available here as a read-only, if you need to query other forms in
	 * a payload. Changes to formMap here will not be correctly parsed by the
	 * framework. For that, use overrideFormMap.
	 */
	public List<FieldsRequest> customSaveFieldTROverride(List<FieldsRequest> fieldsRequests, Map<String, Object> formData, 
			Map<String, List<Map<String, Object>>> formMap, Boolean isSecondCallForPartialTaxCalc, String calcTypeTxt) {
		
		// Interest Mapping to 1099INT
		List<String> interestAmts = getIntTargetValues(formData, "/IRS1040ScheduleB/Form1040SchBPartIGroup2/InterestAmt", isSecondCallForPartialTaxCalc, calcTypeTxt);
		String accruedMarketDiscountAmt = getTargetValue(formData, "/IRS1040ScheduleB/AccruedMarketDiscountAmt", isSecondCallForPartialTaxCalc, calcTypeTxt);
		String amortizableBondPremAdjAmt = getTargetValue(formData, "/IRS1040ScheduleB/AmortizableBondPremAdjAmt", isSecondCallForPartialTaxCalc, calcTypeTxt);
		int index = 0;

		if (!interestAmts.isEmpty()) {
			for (String interestAmt : interestAmts) {
				fieldsRequests = append1099IntGroup(fieldsRequests, interestAmt, "INT.INTINC", false, index);
				index++;
			}
		}
		if (!accruedMarketDiscountAmt.isEmpty()) {
			fieldsRequests = append1099IntGroup(fieldsRequests, accruedMarketDiscountAmt, "X97.482.2", false, index);
			index++;
		}
		if (!amortizableBondPremAdjAmt.isEmpty()) {
			fieldsRequests = append1099IntGroup(fieldsRequests, amortizableBondPremAdjAmt, "X97.482.3", false, index);
		}

		// Dividend mapping to 1099DIV
		List<String> dividendAmts = getDivTargetValues(formData, "/IRS1040ScheduleB/Form1040SchBPartII/DividendAmt", isSecondCallForPartialTaxCalc, calcTypeTxt);
		Map<String, Object> Form1040Data = formMap.get("IRS1040").get(0);
		String qualDiv = getTargetValue(Form1040Data, "/IRS1040/QualifiedDividendsAmt", isSecondCallForPartialTaxCalc, calcTypeTxt);
		int j = 0;

		if (!qualDiv.isEmpty()) {
			if (qualDiv.equals("0")) qualDiv = "NONE";
			fieldsRequests = append1099DivGroup(fieldsRequests, qualDiv, "INT.DQUALDIV", false, j);
			j++;
		}
		if (!dividendAmts.isEmpty()) {
			for (String divAmt : dividendAmts) {
				if (divAmt.equals("0")) divAmt = "NONE";
				fieldsRequests = append1099DivGroup(fieldsRequests, divAmt, "DIV.ORD", false, j);
				j++;
			}
		}
		return fieldsRequests;
	}

	// appending and building a 1099-INT form
	private List<FieldsRequest> append1099IntGroup(List<FieldsRequest> fieldsRequests, String amount, String placement, boolean isGroup, int i) {
		
		// We only generate the new form if any data exists in either required field.
		if (amount.isEmpty()) {
			return fieldsRequests;
		}
		
		FieldsRequest fr = new FieldsRequest();
		List<Field> listOfFields = new ArrayList<>();

		// creating groups for each payer name
		fr.setGroupField(new GroupField(i, "INT.PAYRNAME", "MOCK_PAYER_" + i, null));
		fr.setFields(listOfFields);
		addFieldToListOfFields(listOfFields, placement, amount, null, isGroup);
		fieldsRequests.add(fr);

		return fieldsRequests;
	}

	// appending and building a 1099-DIV form
	private List<FieldsRequest> append1099DivGroup(List<FieldsRequest> fieldsRequests, String amount, String placement, boolean isGroup, int i) {
	
		if (amount.isEmpty()) {
			return fieldsRequests;
		}
		
		FieldsRequest fr = new FieldsRequest();
		List<Field> listOfFields = new ArrayList<>();

		// creating groups for each payer name
		fr.setGroupField(new GroupField(i, "DIV.PAYER", "MOCK_PAYER_" + i, null));
		fr.setFields(listOfFields);
		addFieldToListOfFields(listOfFields, placement, amount, null, isGroup);
		fieldsRequests.add(fr);

		return fieldsRequests;
	}

	@SuppressWarnings("unchecked")
	private String getTargetValue(Map<String, Object> formData, String sourceField, Boolean isSecondCallForPartialTaxCalc, String calcTypeTxt) {
		List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);

		for (Map<String, Object> lineItem : lineItems) {
			if (sourceField.equals(lineItem.get(LINE_NAME_TXT))) {
				return TransformationService.getAppropriateValue(lineItem, isSecondCallForPartialTaxCalc, calcTypeTxt);
			}
		}
		return "";
	}

	@SuppressWarnings("unchecked")
	private List<String> getIntTargetValues(Map<String, Object> formData, String sourceField, Boolean isSecondCallForPartialTaxCalc, String calcTypeTxt) {
		List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
		List<String> interestAmts = new ArrayList<>();
		for (Map<String, Object> lineItem : lineItems) {
			if ("/IRS1040ScheduleB/Form1040SchBPartIGroup2".equals(lineItem.get(LINE_NAME_TXT))) {
				List<Map<String, Object>> nestedLineItems = (List<Map<String, Object>>) lineItem.get(LINE_ITEMS);
				for (Map<String, Object> nestedlineItem : nestedLineItems) {
					if ("/IRS1040ScheduleB/Form1040SchBPartIGroup2/InterestAmt".equals(nestedlineItem.get(LINE_NAME_TXT))) {
						String value = TransformationService.getAppropriateValue(nestedlineItem, isSecondCallForPartialTaxCalc, calcTypeTxt);
						interestAmts.add(value);
					}
				}
			}
		}
		return interestAmts;
	}

	@SuppressWarnings("unchecked")
	private List<String> getDivTargetValues(Map<String, Object> formData, String sourceField, Boolean isSecondCallForPartialTaxCalc, String calcTypeTxt) {
		List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
		List<String> dividendAmts = new ArrayList<>();
		for (Map<String, Object> lineItem : lineItems) {
			if ("/IRS1040ScheduleB/Form1040SchBPartII".equals(lineItem.get(LINE_NAME_TXT))) {
				List<Map<String, Object>> nestedLineItems = (List<Map<String, Object>>) lineItem.get(LINE_ITEMS);
				for (Map<String, Object> nestedlineItem : nestedLineItems) {
					if ("/IRS1040ScheduleB/Form1040SchBPartII/DividendAmt".equals(nestedlineItem.get(LINE_NAME_TXT))) {
						String value = TransformationService.getAppropriateValue(nestedlineItem, isSecondCallForPartialTaxCalc, calcTypeTxt);
						dividendAmts.add(value);
					}
				}
			}
		}
		return dividendAmts;
	}

	private void addFieldToListOfFields(List<Field> listOfFields, String fieldId, String value, String index, boolean group) {
		Field f = new Field();
		f.setFieldId(fieldId);
		f.setValue(value);
		f.setIndex(index);
		f.setGroup(group);
		listOfFields.add(f);
	}
}