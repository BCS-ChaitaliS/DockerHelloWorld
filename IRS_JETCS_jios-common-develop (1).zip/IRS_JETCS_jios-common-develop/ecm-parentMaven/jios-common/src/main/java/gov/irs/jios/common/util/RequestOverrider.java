package gov.irs.jios.common.util;

import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import gov.irs.jios.common.client.tr.pojo.FieldsRequest;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Method;
import java.util.*;

/**
 * This class checks each form for a relevant transformer class,
 * and if found, applies the customSaveFieldTROverride method
 * on it.
 */
@Slf4j
public class RequestOverrider {
	Set<String> setOfForms = new HashSet<>();

	public List<FieldsRequest> customTransformOverFieldsRequests(
			List<FieldsRequest> fieldsRequests,
			Map<String, Class<?>> formTransformers,
			Map<String, List<Map<String, Object>>> formMap
	){
		// For each form, search for the appropriate transformer
		// and apply it once per form instance.
		outerLoop:
		for (List<Map<String, Object>> formList : formMap.values()) { // formMap values are Lists containing a Form as a Map
			for (Map<String, Object> formData : formList){ // Each Map contains a Form (formData) with LineItems
				try { //TODO Transformers should implement interfaces.
					// Find appropriate transformer for this form
					String formName = (String) formData.get("formNum");
					Class<?> transformerClass = formTransformers.get(formName);
					if (transformerClass == null) continue outerLoop;
					Object transformer = transformerClass.getDeclaredConstructor().newInstance();
					Method customSaveFieldTROverride = transformerClass.getMethod("customSaveFieldTROverride", List.class, Map.class, Map.class);
					fieldsRequests = (List<FieldsRequest>) customSaveFieldTROverride.invoke(transformer, fieldsRequests, formData, formMap);
					log.info("Applied Custom Override on TR Save Field for form {}", formName);
				} catch (NoSuchMethodException e){
					log.warn("Save Field TR Override method, skipping | {}", e.getMessage());
				} catch (Exception e) {
					log.error("Error applying Save Field TR Override method: {}", e.getMessage());
				}

			}
		}

		return fieldsRequests;
	}

	/**
	 * Add each form into setOfForms, so that only the appropriate form transformers are used.
	 * @param formMap the map of forms sent by ECM
	 */
	public void flagForms(Map<String, List<Map<String, Object>>> formMap){
		setOfForms.addAll(formMap.keySet());
	}
}
