package gov.irs.jios.common.util;

import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import gov.irs.jios.common.client.tr.pojo.FieldsRequest;
import lombok.extern.slf4j.Slf4j;

/**
 * This class checks each form for a relevant transformer class,
 * and if found, applies the customSaveFieldTROverride method
 * on it.
 */
@Slf4j
public class RequestOverrider {
	Set<String> setOfForms = new HashSet<>();

	@SuppressWarnings("unchecked")
	public List<FieldsRequest> customTransformOverFieldsRequests(
			List<FieldsRequest> fieldsRequests,
			Map<String, Class<?>> formTransformers,
			Map<String, List<Map<String, Object>>> formMap,
			Boolean isSecondCallForPartialTaxCalc,
			String calcTypeTxt){
		
		// For each form, search for the appropriate transformer
		// and apply it once per form instance.
		outerLoop:
		for (List<Map<String, Object>> formList : formMap.values()) { // formMap values are Lists containing a Form as a Map
			for (Map<String, Object> formData : formList){ // Each Map contains a Form (formData) with LineItems
				try { //TODO Transformers should implement interfaces.
					// Find appropriate transformer for this form
					String formName = (String) formData.get("formNum");
					Class<?> transformerClass = formTransformers.get(formName);
					if (transformerClass == null) continue outerLoop;
					Object transformer = transformerClass.getDeclaredConstructor().newInstance();
					Method customSaveFieldTROverride = transformerClass.getMethod("customSaveFieldTROverride", List.class, Map.class, Map.class, Boolean.class, String.class);
					fieldsRequests = (List<FieldsRequest>) customSaveFieldTROverride.invoke(transformer, fieldsRequests, formData, formMap, isSecondCallForPartialTaxCalc, calcTypeTxt);
					log.info("Applied Custom Override on TR Save Field for form {}", formName);
				} catch (NoSuchMethodException e){
					log.info("Save Field TR Override method, skipping | {}", e.getMessage());
				} catch (Exception e) {
					log.error("Error applying Save Field TR Override method: {}", e.getMessage());
				}

			}
		}
		return fieldsRequests;
	}

	/**
	 * Add each form into setOfForms, so that only the appropriate form transformers are used.
	 * @param formMap the map of forms sent by ECM
	 */
	public void flagForms(Map<String, List<Map<String, Object>>> formMap){
		setOfForms.addAll(formMap.keySet());
	}
}