package gov.irs.jios.common.client.transformer;

import static gov.irs.jios.common.util.JiosCommonConstants.LINE_ITEMS;
import static gov.irs.jios.common.util.JiosCommonConstants.LINE_NAME_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.PER_RETURN_VALUE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.PRIMARY_TIN;
import static gov.irs.jios.common.util.JiosCommonConstants.SECONDARY_TIN;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FormIRS8863Transformer {

	public static final String IRS8863 = "IRS8863";

	@SuppressWarnings("unchecked")
	public List<FieldMapping> transformFormIRS8863(Map<String, Object> formData, Map<String, Object> header) {
		List<FieldMapping> fieldMappings = new ArrayList<>();

		if (formData == null || header == null) {
			log.warn("FormData or header is null. Returning empty field mappings.");
			return fieldMappings;
		}

		String primaryTIN = (String) header.get(PRIMARY_TIN);
		String secondaryTIN = (String) header.get(SECONDARY_TIN);

		if (primaryTIN == null && secondaryTIN == null) {
			log.warn("Both primaryTIN and spouseTIN are null in header. Returning empty field mappings.");
			return fieldMappings;
		}

		Properties properties = new Properties();
        try (InputStream is = getClass().getClassLoader().getResourceAsStream("common/application.properties")) {
			properties.load(is);
        } catch (Exception e) {
			log.error("Exception reading application.properties " + e.getMessage());
		}

		Map<String, String> primaryEcmToTrMappings = primaryMapping();
		Map<String, String> secondaryEcmToTrMappings = secondaryMapping();
		Map<String, String> childEcmToTrMappings = childMapping();
		Map<String, String> mockFieldMappings = mockFieldMappings();
		List<String> indicatorfields = indicatorFields();
		String ssn = null;

		List<Map<String, Object>> lineItems = (List<Map<String, Object>>) formData.get(LINE_ITEMS);
		if (lineItems == null) {
			log.warn("No lineItems found in formData");
			return fieldMappings;
		}

		for (Map<String, Object> lineItem : lineItems) {
			List<Map<String, Object>> grpLineItems = (List<Map<String, Object>>) lineItem.get(LINE_ITEMS);
			for (Map<String, Object> grpChildLineItem : grpLineItems) {
				if ("/IRS8863/StudentAndEducationalInstnGrp/StudentSSN".equals(grpChildLineItem.get(LINE_NAME_TXT))) {
					ssn = (String) grpChildLineItem.get(PER_RETURN_VALUE_TXT);
					if (ssn == null || ssn.isEmpty()) {
						log.warn("ssn found but value is null or empty");
						continue;
					}

					List<Map<String, Object>> eduCreditLineItems = (List<Map<String, Object>>) lineItem.get(LINE_ITEMS);
					for (Map<String, Object> studentChildLineItem : eduCreditLineItems) {
						String ecmAttribute = (String) studentChildLineItem.get(LINE_NAME_TXT);
						if (ssn.equals(primaryTIN)) {
							primaryQalifiedExpenseAmount(ecmAttribute, studentChildLineItem, mockFieldMappings);
							creditTypeMapping(primaryEcmToTrMappings, mockFieldMappings, properties, fieldMappings);
							if (primaryEcmToTrMappings.containsKey(ecmAttribute)) {
								String targetField = primaryEcmToTrMappings.get(ecmAttribute);
								String ecmValue = (String) studentChildLineItem.get(PER_RETURN_VALUE_TXT);
								addFieldMapping(fieldMappings, targetField, ecmValue);
							} else if ("/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup"
									.equals(ecmAttribute)) {
								List<Map<String, Object>> eduInstitutegrpItem = (List<Map<String, Object>>) studentChildLineItem
										.get(LINE_ITEMS);
								for (Map<String, Object> eduInstituteItem : eduInstitutegrpItem) {
									String eduEcmAttribute = (String) eduInstituteItem.get(LINE_NAME_TXT);
									primaryYr1098Ind(eduEcmAttribute, eduInstituteItem, primaryEcmToTrMappings);
									if (primaryEcmToTrMappings.containsKey(eduEcmAttribute)) {
										String targetField = primaryEcmToTrMappings.get(eduEcmAttribute);
										String eduEcmValue = (String) eduInstituteItem.get(PER_RETURN_VALUE_TXT);
										if (mockFieldMappings.containsKey(eduEcmAttribute)) {
											eduEcmValue = (String) properties
													.get(mockFieldMappings.get(eduEcmAttribute));
										} else if (indicatorfields.contains(eduEcmAttribute)) {
											eduEcmValue = (String) properties.get(mockFieldMappings.get("indicator"));

										}
										addFieldMapping(fieldMappings, targetField, eduEcmValue);
									} else {
										addressfieldMapping(eduEcmAttribute, eduInstituteItem, primaryEcmToTrMappings,
												fieldMappings, mockFieldMappings, properties);
									}
								}

							}

						} else if (ssn.equals(secondaryTIN)) {

							secondaryQalifiedExpenseAmount(ecmAttribute, studentChildLineItem, mockFieldMappings);
							creditTypeMapping(secondaryEcmToTrMappings, mockFieldMappings, properties, fieldMappings);
							if (secondaryEcmToTrMappings.containsKey(ecmAttribute)) {
								String targetField = secondaryEcmToTrMappings.get(ecmAttribute);
								String ecmValue = (String) studentChildLineItem.get(PER_RETURN_VALUE_TXT);
								addFieldMapping(fieldMappings, targetField, ecmValue);
							} else if ("/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup"
									.equals(ecmAttribute)) {
								List<Map<String, Object>> eduInstitutegrpItem = (List<Map<String, Object>>) studentChildLineItem
										.get(LINE_ITEMS);
								for (Map<String, Object> eduInstituteItem : eduInstitutegrpItem) {
									String eduEcmAttribute = (String) eduInstituteItem.get(LINE_NAME_TXT);
									secondaryYr1098Ind(eduEcmAttribute, eduInstituteItem, secondaryEcmToTrMappings);
									if (secondaryEcmToTrMappings.containsKey(eduEcmAttribute)) {
										String targetField = secondaryEcmToTrMappings.get(eduEcmAttribute);
										String eduEcmValue = (String) eduInstituteItem.get(PER_RETURN_VALUE_TXT);
										if (mockFieldMappings.containsKey(eduEcmAttribute)) {
											eduEcmValue = (String) properties
													.get(mockFieldMappings.get(eduEcmAttribute));
										} else if (indicatorfields.contains(eduEcmAttribute)) {
											eduEcmValue = (String) properties.get(mockFieldMappings.get("indicator"));
										}
										addFieldMapping(fieldMappings, targetField, eduEcmValue);
									} else {
										addressfieldMapping(eduEcmAttribute, eduInstituteItem, secondaryEcmToTrMappings,
												fieldMappings, mockFieldMappings, properties);
									}
								}

							}

						} else {
							childclaimInd(ecmAttribute, studentChildLineItem, childEcmToTrMappings);
							dependentQalifiedExpenseAmount(ecmAttribute, studentChildLineItem, mockFieldMappings);
							creditTypeMapping(childEcmToTrMappings, mockFieldMappings, properties, fieldMappings);
							if (childEcmToTrMappings.containsKey(ecmAttribute)) {
								String targetField = childEcmToTrMappings.get(ecmAttribute);
								String ecmValue = (String) studentChildLineItem.get(PER_RETURN_VALUE_TXT);
								if (indicatorfields.contains(ecmAttribute)) {
									ecmValue = (String) properties.get(mockFieldMappings.get("indicator"));
								}
								addFieldMapping(fieldMappings, targetField, ecmValue);
							}
						}
					}
				}
			}
		}

		return fieldMappings;
	}

	private void primaryYr1098Ind(String ecmAtrribute, Map<String, Object> eduInstituteItem,
			Map<String, String> primaryEcmToTrMappings) {
		if ("/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/CurrentYear1098TReceivedInd"
				.equals(ecmAtrribute)) {
			String eduEcmValue = (String) eduInstituteItem.get(PER_RETURN_VALUE_TXT);
			if (valuecheckInd(eduEcmValue)) {
				primaryEcmToTrMappings.put(
						"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/CurrentYear1098TReceivedInd",
						"X129.77.134");
			} else {
				primaryEcmToTrMappings.put(
						"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/CurrentYear1098TReceivedInd",
						"X129.77.135");
			}
		} else if ("/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/PriorYear1098TReceivedInd"
				.equals(ecmAtrribute)) {
			String eduEcmValue = (String) eduInstituteItem.get(PER_RETURN_VALUE_TXT);
			if (valuecheckInd(eduEcmValue)) {
				primaryEcmToTrMappings.put(
						"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/PriorYear1098TReceivedInd",
						"X129.77.136");
			} else {
				primaryEcmToTrMappings.put(
						"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/PriorYear1098TReceivedInd",
						"X129.77.137");
			}
		}
	}

	private void secondaryYr1098Ind(String ecmAtrribute, Map<String, Object> eduInstituteItem,
			Map<String, String> EcmToTrMappings) {
		if ("/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/CurrentYear1098TReceivedInd"
				.equals(ecmAtrribute)) {
			String eduEcmValue = (String) eduInstituteItem.get(PER_RETURN_VALUE_TXT);
			if (valuecheckInd(eduEcmValue)) {
				EcmToTrMappings.put(
						"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/CurrentYear1098TReceivedInd",
						"X129.90.134");
			} else {
				EcmToTrMappings.put(
						"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/CurrentYear1098TReceivedInd",
						"X129.90.135");
			}
		} else if ("/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/PriorYear1098TReceivedInd"
				.equals(ecmAtrribute)) {
			String eduEcmValue = (String) eduInstituteItem.get(PER_RETURN_VALUE_TXT);
			if (valuecheckInd(eduEcmValue)) {
				EcmToTrMappings.put(
						"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/PriorYear1098TReceivedInd",
						"X129.90.136");
			} else {
				EcmToTrMappings.put(
						"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/PriorYear1098TReceivedInd",
						"X129.90.137");
			}
		}
	}

	private void childclaimInd(String ecmAtrribute, Map<String, Object> eduInstituteItem,
			Map<String, String> EcmToTrMappings) {
		if ("/IRS8863/StudentAndEducationalInstnGrp/PriorYearCreditClaimedInd".equals(ecmAtrribute)) {
			String eduEcmValue = (String) eduInstituteItem.get(PER_RETURN_VALUE_TXT);
			if (valuecheckInd(eduEcmValue)) {
				EcmToTrMappings.put("/IRS8863/StudentAndEducationalInstnGrp/PriorYearCreditClaimedInd", "X129.79.130");
			} else {
				EcmToTrMappings.put("/IRS8863/StudentAndEducationalInstnGrp/PriorYearCreditClaimedInd", "X129.79.131");
			}
		} else if ("/IRS8863/StudentAndEducationalInstnGrp/AcademicPdEligibleStudentInd".equals(ecmAtrribute)) {
			String eduEcmValue = (String) eduInstituteItem.get(PER_RETURN_VALUE_TXT);
			if (valuecheckInd(eduEcmValue)) {
				EcmToTrMappings.put("/IRS8863/StudentAndEducationalInstnGrp/AcademicPdEligibleStudentInd",
						"X129.79.132");
			} else {
				EcmToTrMappings.put("/IRS8863/StudentAndEducationalInstnGrp/AcademicPdEligibleStudentInd",
						"X129.79.133");
			}
		} else if ("/IRS8863/StudentAndEducationalInstnGrp/PostSecondaryEducationInd".equals(ecmAtrribute)) {
			String eduEcmValue = (String) eduInstituteItem.get(PER_RETURN_VALUE_TXT);
			if (valuecheckInd(eduEcmValue)) {
				EcmToTrMappings.put("/IRS8863/StudentAndEducationalInstnGrp/PostSecondaryEducationInd", "X129.79.134");
			} else {
				EcmToTrMappings.put("/IRS8863/StudentAndEducationalInstnGrp/PostSecondaryEducationInd", "X129.79.135");
			}
		} else if ("/IRS8863/StudentAndEducationalInstnGrp/DrugFelonyConvictionInd".equals(ecmAtrribute)) {
			String eduEcmValue = (String) eduInstituteItem.get(PER_RETURN_VALUE_TXT);
			if (valuecheckInd(eduEcmValue)) {
				EcmToTrMappings.put("/IRS8863/StudentAndEducationalInstnGrp/DrugFelonyConvictionInd", "X129.79.136");
			} else {
				EcmToTrMappings.put("/IRS8863/StudentAndEducationalInstnGrp/DrugFelonyConvictionInd", "X129.79.137");
			}
		}
	}

	private boolean valuecheckInd(String value) {
		return (value.equalsIgnoreCase("YES") || value.equalsIgnoreCase("Y") || value.equalsIgnoreCase("X")
				|| value.equalsIgnoreCase("1") || value.equalsIgnoreCase("TRUE"));
	}

	private void addressfieldMapping(String eduEcmAttribute, Map<String, Object> eduInstituteItem,
			Map<String, String> ecmToTrMappings, List<FieldMapping> fieldMappings,
			Map<String, String> mockFieldMappings, Properties properties) {
		if ("/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/ForeignAddress"
				.equals(eduEcmAttribute)) {

			addressfieldCommonMapping(eduInstituteItem, ecmToTrMappings, fieldMappings, mockFieldMappings, properties);
		} else if ("/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/InstitutionName"
				.equals(eduEcmAttribute)) {

			addressfieldCommonMapping(eduInstituteItem, ecmToTrMappings, fieldMappings, mockFieldMappings, properties);

		} else if ("/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/USAddress"
				.equals(eduEcmAttribute)) {

			addressfieldCommonMapping(eduInstituteItem, ecmToTrMappings, fieldMappings, mockFieldMappings, properties);

		}
	}

	@SuppressWarnings("unchecked")
	private void addressfieldCommonMapping(Map<String, Object> eduInstituteItem, Map<String, String> ecmToTrMappings,
			List<FieldMapping> fieldMappings, Map<String, String> mockFieldMappings, Properties properties) {

		List<Map<String, Object>> addressgrpItem = (List<Map<String, Object>>) eduInstituteItem.get(LINE_ITEMS);
		for (Map<String, Object> addressItem : addressgrpItem) {
			String addressEcmAttribute = (String) addressItem.get(LINE_NAME_TXT);
			if (ecmToTrMappings.containsKey(addressEcmAttribute)) {
				String targetField = ecmToTrMappings.get(addressEcmAttribute);
				String eduEcmValue = (String) addressItem.get(PER_RETURN_VALUE_TXT);
				if (mockFieldMappings.containsKey(addressEcmAttribute)) {
					eduEcmValue = (String) properties.get(mockFieldMappings.get(addressEcmAttribute));
				}
				addFieldMapping(fieldMappings, targetField, eduEcmValue);
			}
		}
	}

	private void primaryQalifiedExpenseAmount(String ecmAtrribute, Map<String, Object> studentChildLineItem,
			Map<String, String> mockFieldMappings) {

		if ("/IRS8863/StudentAndEducationalInstnGrp/AmerOppQualifiedExpensesAmt".equals(ecmAtrribute)) {
			String ecmValue = (String) studentChildLineItem.get(PER_RETURN_VALUE_TXT);
			if (ecmValue != null && !ecmValue.isEmpty()) {
				mockFieldMappings.put("X129.106.1", "mock.8863.americanOpp.credit");
			}

		} else if ("/IRS8863/StudentAndEducationalInstnGrp/LifetimeQualifiedExpensesAmt".equals(ecmAtrribute)) {
			String ecmValue = (String) studentChildLineItem.get(PER_RETURN_VALUE_TXT);
			if (ecmValue != null && !ecmValue.isEmpty()) {
				mockFieldMappings.put("X129.106.1", "mock.8863.lifetime.credit");
			}

		}
	}

	private void secondaryQalifiedExpenseAmount(String ecmAtrribute, Map<String, Object> studentChildLineItem,
			Map<String, String> mockFieldMappings) {

		if ("/IRS8863/StudentAndEducationalInstnGrp/AmerOppQualifiedExpensesAmt".equals(ecmAtrribute)) {
			String ecmValue = (String) studentChildLineItem.get(PER_RETURN_VALUE_TXT);
			if (ecmValue != null && !ecmValue.isEmpty()) {
				mockFieldMappings.put("X129.106.7", "mock.8863.americanOpp.credit");
			}

		} else if ("/IRS8863/StudentAndEducationalInstnGrp/LifetimeQualifiedExpensesAmt".equals(ecmAtrribute)) {
			String ecmValue = (String) studentChildLineItem.get(PER_RETURN_VALUE_TXT);
			if (ecmValue != null && !ecmValue.isEmpty()) {
				mockFieldMappings.put("X129.106.7", "mock.8863.lifetime.credit");
			}

		}
	}

	private void dependentQalifiedExpenseAmount(String ecmAtrribute, Map<String, Object> studentChildLineItem,
			Map<String, String> mockFieldMappings) {

		if ("/IRS8863/StudentAndEducationalInstnGrp/AmerOppQualifiedExpensesAmt".equals(ecmAtrribute)) {
			String ecmValue = (String) studentChildLineItem.get(PER_RETURN_VALUE_TXT);
			if (ecmValue != null && !ecmValue.isEmpty()) {
				mockFieldMappings.put("X129.106.128", "mock.8863.americanOpp.credit");
			}

		} else if ("/IRS8863/StudentAndEducationalInstnGrp/LifetimeQualifiedExpensesAmt".equals(ecmAtrribute)) {
			String ecmValue = (String) studentChildLineItem.get(PER_RETURN_VALUE_TXT);
			if (ecmValue != null && !ecmValue.isEmpty()) {
				mockFieldMappings.put("X129.106.128", "mock.8863.lifetime.credit");
			}

		}
	}

	private void creditTypeMapping(Map<String, String> EcmToTrMappings, Map<String, String> mockFieldMappings,
			Properties properties, List<FieldMapping> fieldMappings) {
		if (EcmToTrMappings.containsKey("PrimaryCredits")) {
			String targetField = EcmToTrMappings.get("PrimaryCredits");
			creditFieldMapping(targetField, mockFieldMappings, properties, fieldMappings);
		} else if (EcmToTrMappings.containsKey("SecondayCredits")) {
			String targetField = EcmToTrMappings.get("SecondayCredits");
			creditFieldMapping(targetField, mockFieldMappings, properties, fieldMappings);
		} else if (EcmToTrMappings.containsKey("DependentCredits")) {
			String targetField = EcmToTrMappings.get("DependentCredits");
			creditFieldMapping(targetField, mockFieldMappings, properties, fieldMappings);
		}

	}

	private void creditFieldMapping(String targetField, Map<String, String> mockFieldMappings, Properties properties,
			List<FieldMapping> fieldMappings) {
		if (mockFieldMappings.containsKey(targetField)) {
			String eduEcmValue = (String) properties.get(mockFieldMappings.get(targetField));
			addFieldMapping(fieldMappings, targetField, eduEcmValue);
		}
	}

	private Map<String, String> mockFieldMappings() {
		Map<String, String> mockFieldMappings = new HashMap<String, String>();

		mockFieldMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/USAddress/AddressLine1Txt",
				"mock.us.address.addressln1");
		mockFieldMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/USAddress/AddressLine2Txt",
				"mock.us.address.addressln2");
		mockFieldMappings.put("/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/USAddress/CityNm",
				"mock.us.address.city");
		mockFieldMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/USAddress/StateAbbreviationCd",
				"ock.usaddress.statecd");
		mockFieldMappings.put("/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/USAddress/ZIPCd",
				"mock.us.address.zipcd");
		mockFieldMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/ForeignAddress/AddressLine1Txt",
				"mock.empty.string");
		mockFieldMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/ForeignAddress/AddressLine2Txt",
				"mock.empty.string");
		mockFieldMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/ForeignAddress/CityNm",
				"mock.empty.string");
		mockFieldMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/ForeignAddress/ProvinceOrStateNm",
				"mock.empty.string");
		mockFieldMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/ForeignAddress/CountryCd",
				"mock.empty.string");
		mockFieldMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/ForeignAddress/ForeignPostalCd",
				"mock.empty.string");
		mockFieldMappings.put("/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/EIN",
				"mock.employer.ein.formatted");
		mockFieldMappings.put("indicator", "mock.8863.indicator.value");

		return mockFieldMappings;

	}

	private List<String> indicatorFields() {
		List<String> indicatorList = List.of("/IRS8863/StudentAndEducationalInstnGrp/PriorYearCreditClaimedInd",
				"/IRS8863/StudentAndEducationalInstnGrp/AcademicPdEligibleStudentInd",
				"/IRS8863/StudentAndEducationalInstnGrp/PostSecondaryEducationInd",
				"/IRS8863/StudentAndEducationalInstnGrp/DrugFelonyConvictionInd",
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/CurrentYear1098TReceivedInd",
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/PriorYear1098TReceivedInd");
		return indicatorList;
	}

	private Map<String, String> primaryMapping() {

		Map<String, String> primaryEcmToTrMappings = new HashMap<String, String>();
		primaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/InstitutionName/BusinessNameLine1Txt",
				"X129.77.128");
		primaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/USAddress/AddressLine1Txt",
				"X129.77.129");
		primaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/USAddress/AddressLine2Txt",
				"X129.77.130");
		primaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/USAddress/CityNm", "X129.77.131");
		primaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/USAddress/StateAbbreviationCd",
				"X129.77.132");
		primaryEcmToTrMappings.put("/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/USAddress/ZIPCd",
				"X129.77.133");

		primaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/ForeignAddress/AddressLine1Txt",
				"X129.110.129");
		primaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/ForeignAddress/AddressLine2Txt",
				"X129.110.130");
		primaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/ForeignAddress/CityNm",
				"X129.110.131");
		primaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/ForeignAddress/ProvinceOrStateNm",
				"X129.110.132");
		primaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/ForeignAddress/CountryCd",
				"X129.110.133");
		primaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/ForeignAddress/ForeignPostalCd",
				"X129.110.134");

		primaryEcmToTrMappings.put("/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/EIN",
				"X129.77.138");
		primaryEcmToTrMappings.put("/IRS8863/StudentAndEducationalInstnGrp/AmerOppQualifiedExpensesAmt",
				"X129.HOPELLCT");
		primaryEcmToTrMappings.put("/IRS8863/StudentAndEducationalInstnGrp/LifetimeQualifiedExpensesAmt",
				"X129.HOPELLCT");
		primaryEcmToTrMappings.put("PrimaryCredits", "X129.106.1");

		return primaryEcmToTrMappings;

	}

	private Map<String, String> secondaryMapping() {

		Map<String, String> secondaryEcmToTrMappings = new HashMap<String, String>();

		secondaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/InstitutionName/BusinessNameLine1Txt",
				"X129.90.128");
		secondaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/USAddress/AddressLine1Txt",
				"X129.90.129");
		secondaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/USAddress/AddressLine2Txt",
				"X129.90.130");
		secondaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/USAddress/CityNm", "X129.90.131");
		secondaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/USAddress/StateAbbreviationCd",
				"X129.90.132");
		secondaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/USAddress/ZIPCd", "X129.90.133");
		secondaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/ForeignAddress/AddressLine1Txt",
				"X129.112.129");
		secondaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/ForeignAddress/AddressLine2Txt",
				"X129.112.130");
		secondaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/ForeignAddress/CityNm",
				"X129.112.131");
		secondaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/ForeignAddress/ProvinceOrStateNm",
				"X129.112.132");
		secondaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/ForeignAddress/CountryCd",
				"X129.112.133");
		secondaryEcmToTrMappings.put(
				"/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/ForeignAddress/ForeignPostalCd",
				"X129.112.134");
		secondaryEcmToTrMappings.put("/IRS8863/StudentAndEducationalInstnGrp/EducationalInstitutionGroup/EIN",
				"X129.90.138");
		secondaryEcmToTrMappings.put("/IRS8863/StudentAndEducationalInstnGrp/AmerOppQualifiedExpensesAmt",
				"X129.HOPELLCS");
		secondaryEcmToTrMappings.put("/IRS8863/StudentAndEducationalInstnGrp/LifetimeQualifiedExpensesAmt",
				"X129.HOPELLCS");

		secondaryEcmToTrMappings.put("SecondayCredits", "X129.106.7");

		return secondaryEcmToTrMappings;

	}

	private Map<String, String> childMapping() {

		Map<String, String> childMapping = new HashMap<String, String>();

		childMapping.put("/IRS8863/StudentAndEducationalInstnGrp/AmerOppQualifiedExpensesAmt", "X129.HOPELLCD");
		childMapping.put("/IRS8863/StudentAndEducationalInstnGrp/LifetimeQualifiedExpensesAmt", "X129.HOPELLCD");
		childMapping.put("DependentCredits", "X129.106.128");

		return childMapping;

	}

	private void addFieldMapping(List<FieldMapping> mappings, String sourceField, String targetField,
			String targetFieldValue) {
		FieldMapping mapping = new FieldMapping();
		mapping.setSourceForm(IRS8863);
		mapping.setSourceField(sourceField);
		mapping.setTargetField(targetField);
		mapping.setTargetFieldValue(targetFieldValue);
		mappings.add(mapping);
	}

	private void addFieldMapping(List<FieldMapping> mappings, String targetField, String targetFieldValue) {
		addFieldMapping(mappings, null, targetField, targetFieldValue);
	}

}