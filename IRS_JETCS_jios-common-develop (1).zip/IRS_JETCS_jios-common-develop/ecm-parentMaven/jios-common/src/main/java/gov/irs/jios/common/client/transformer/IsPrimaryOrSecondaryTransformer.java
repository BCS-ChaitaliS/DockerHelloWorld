package gov.irs.jios.common.client.transformer;

import gov.irs.jios.common.request.ValidatableRequest;

public class IsPrimaryOrSecondaryTransformer {

    public static String transformEcmToTr(String value, ValidatableRequest request, Integer groupIndex) {
    	if (request == null || request.getHeader() == null) {
    		return "";
    	}
    	String primaryTIN = (String) request.getHeader().get("primaryTIN");
    	String spouseTIN = (String) request.getHeader().get("spouseTIN");
    	String secondaryTIN = (String) request.getHeader().get("secondaryTIN");
    	
    	if (primaryTIN != null && primaryTIN.equals(value)) {
        	return "T";
    	} else if ((spouseTIN != null && spouseTIN.equals(value)) || (secondaryTIN != null && secondaryTIN.equals(value))) {
    		return "S";
    	} else {
    		return "";
    	}
    }

    public static String transformTrToEcm(String trIndicatorValue) {
        return "";
    }
}
