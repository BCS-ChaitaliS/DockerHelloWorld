package gov.irs.jios.common.client.transformer;

import java.util.Map;

public class AdjustmentsToGainOrLossCdValueTransformer {
    
	private static final Map<String, String> ECM_TO_TR_MAP = Map.ofEntries(
	    Map.entry("B", "X"),
	    Map.entry("C", "X"),
	    Map.entry("D", "X"),
	    Map.entry("E", "X"),
	    Map.entry("H", "X"),
	    Map.entry("L", "X"),
	    Map.entry("M", "X"),
	    Map.entry("N", "X"),
	    Map.entry("O", "X"),
	    Map.entry("Q", "X"),
	    Map.entry("R", "X"),
	    Map.entry("S", "X"),
	    Map.entry("T", "X"),
	    Map.entry("W", "X"),
	    Map.entry("X", "X"),
	    Map.entry("Y", "X"),
	    Map.entry("Z", "X")
	);

	private static final Map<String, String> TR_TO_ECM_MAP = Map.of(
	    "X", "TRUE",
	    "", "FALSE"
	);

    public String transformEcmToTr(String ecmIndicatorValue) {
    	if (ecmIndicatorValue == null) {
    		ecmIndicatorValue = "";
    	}
        String trIndicator = ECM_TO_TR_MAP.get(ecmIndicatorValue.toUpperCase());
        if (trIndicator == null) {
            throw new IllegalArgumentException("Invalid ECM AdjustmentsToGainOrLossCd value, " + ecmIndicatorValue);
        }
        return trIndicator;
    }

    public String transformTrToEcm(String trIndicatorValue) {
        String ecmIndicator = TR_TO_ECM_MAP.get(trIndicatorValue != null ? trIndicatorValue.toUpperCase() : "");
        if (ecmIndicator == null) {
            throw new IllegalArgumentException("Invalid TR AdjustmentsToGainOrLossCd value, " + trIndicatorValue);
        }
        return ecmIndicator;
    }
}
