package gov.irs.jios.common.client.tr.service;

import java.io.IOException;
import java.time.Duration;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import gov.irs.jios.common.client.tr.pojo.TrConfig;
import gov.irs.jios.common.profiler.Profiled;
import lombok.extern.slf4j.Slf4j;
import reactor.util.retry.Retry;

@Service
@Slf4j
public class OpenSnapshotService {
	
	@Value("${webclient.retry.max-attempts:3}")
	private int maxAttempts;

	@Value("${webclient.retry.interval:100}")
	private long retryInterval;
	
	@Value("${should.make.tr.call:true}")
	private boolean shouldMakeTrCall;

    private final WebClient webClient;
    
    private final String account;

    public OpenSnapshotService(WebClient.Builder webClientBuilder,
                             TrConfig trConfig) {
        this.webClient = webClientBuilder.baseUrl(trConfig.getSnapshotOpenUrl()).build();
        this.account = trConfig.getAccount();
    }

    @Profiled
    public Map<String, String> openSnapshot(String token, String taxYear, String locatorId, MultipartFile file) 
    					throws IOException {
    	
    	if(file.getOriginalFilename() == null || file.getOriginalFilename().indexOf(locatorId) < 0) {
    		throw new IllegalArgumentException("Snapshot file name does not contain locatorId");
    	}
    	MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
    	body.add("account", account);
    	body.add("taxYear", taxYear);
    	body.add("taxReturnId", locatorId);
    	body.add("fileName", file.getOriginalFilename());
    	
    	ByteArrayResource snapshotZip = new ByteArrayResource(file.getBytes()) {
            @Override
            public String getFilename() {
                return file.getOriginalFilename(); // Filename has to be returned in order to be able to post.
            }
        };
    	body.add("file", snapshotZip);
    	
		log.info("Call TR Open Snapshot");
		return sendOpenSnapshot(token, body);
    }

    private Map<String, String> sendOpenSnapshot(String token, MultiValueMap<String, Object> body) {
        return webClient.post()
      		     .headers(headers -> {
                     headers.setBearerAuth(token);
                 })
       		    .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
   		        .retrieve()
   		        .bodyToMono(new ParameterizedTypeReference<Map<String, String>>() {})
   		        .doOnSuccess(v -> log.info("TR Open snapshot request successful"))
   		        .retryWhen(Retry.backoff(maxAttempts, Duration.ofMillis(retryInterval))
   	                .filter(throwable -> throwable instanceof WebClientResponseException &&
   	                  ((WebClientResponseException) throwable).getStatusCode().is5xxServerError()))
   		        .block();
    }
}