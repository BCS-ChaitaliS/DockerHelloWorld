package gov.irs.jios.common.ecm.pojo;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ErrorResponse {
    private List<ErrorDetail> errorDetails;
    private TransactionInfo transactionInfo;
}