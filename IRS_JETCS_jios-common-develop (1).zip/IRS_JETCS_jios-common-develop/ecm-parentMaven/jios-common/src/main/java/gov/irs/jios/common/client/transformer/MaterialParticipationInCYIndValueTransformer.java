package gov.irs.jios.common.client.transformer;

import java.util.Map;

public class MaterialParticipationInCYIndValueTransformer {
    
    private static final Map<String, String> ECM_TO_TR_MAP = Map.of(
	    "TRUE", "A",
	    "FALSE", "B",
	    "1", "A",
	    "0", "B",
	    "X", "A",
	    "", "B"
	);

	private static final Map<String, String> TR_TO_ECM_MAP = Map.of(
	    "A", "TRUE",
	    "B", "FALSE"
	);

    public String transformEcmToTr(String ecmIndicatorValue) {
    	if (ecmIndicatorValue == null) {
    		ecmIndicatorValue = "B";
    	}
        String trIndicator = ECM_TO_TR_MAP.get(ecmIndicatorValue.toUpperCase());
        if (trIndicator == null) {
            throw new IllegalArgumentException("Invalid ECM Indicator value: " + ecmIndicatorValue);
        }
        return trIndicator;
    }

    public String transformTrToEcm(String trIndicatorValue) {
        String ecmIndicator = TR_TO_ECM_MAP.get(trIndicatorValue != null ? trIndicatorValue.toUpperCase() : "");
        if (ecmIndicator == null) {
            throw new IllegalArgumentException("Invalid TR Indicator value: " + trIndicatorValue);
        }
        return ecmIndicator;
    }
}
