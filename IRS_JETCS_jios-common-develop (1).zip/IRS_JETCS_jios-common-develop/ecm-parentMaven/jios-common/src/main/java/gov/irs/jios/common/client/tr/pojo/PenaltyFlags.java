package gov.irs.jios.common.client.tr.pojo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PenaltyFlags {
    public boolean isReturnRelated;
    public boolean isIssueRelated;
    public boolean isAgreed;
    public boolean isTotal;
}