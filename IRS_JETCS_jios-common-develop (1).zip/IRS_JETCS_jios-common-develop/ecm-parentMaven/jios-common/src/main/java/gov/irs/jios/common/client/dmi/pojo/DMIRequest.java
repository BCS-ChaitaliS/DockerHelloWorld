package gov.irs.jios.common.client.dmi.pojo;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DMIRequest {
	private String SEID;
    private String agreedCd;
    private CalcInfo calcInfo;
    private List<PenMain> penMain;
    private List<AccCalc> acc_Calc;
    private List<Object> ftp_Not;
    private List<Object> ftp_Agreements;
    private List<FtpCalc> ftp_Calc;
    private List<EstInd_Calc> estInd_Calc;
    private UnderPaymentInfo underPaymentInfo;
}
