package gov.irs.jios.common.client.transformer;

import java.util.Map;

/**
 * ECM is sending a BooleanType here.
 */
public class VehiclePoweredByGasOrDieselIndTransformer {
    
	private static final Map<String, String> ECM_TO_TR_MAP = Map.of(
	    "TRUE", "",
	    "FALSE", "N",
	    "1", "",
	    "0", "N",
	    "X", "",
	    "", "N"
	);

	private static final Map<String, String> TR_TO_ECM_MAP = Map.of(
	    "", "TRUE",
	    "N", "FALSE"
	);

    public static String transformEcmToTr(String ecmIndicatorValue) {
    	if (ecmIndicatorValue == null) {
    		ecmIndicatorValue = "";
    	}
        String trIndicator = ECM_TO_TR_MAP.get(ecmIndicatorValue.toUpperCase());
        if (trIndicator == null) {
            throw new IllegalArgumentException("Invalid ECM Indicator value: " + ecmIndicatorValue);
        }
        return trIndicator;
    }

    public static String transformTrToEcm(String trIndicatorValue) {
        String ecmIndicator = TR_TO_ECM_MAP.get(trIndicatorValue != null ? trIndicatorValue.toUpperCase() : "");
        if (ecmIndicator == null) {
            throw new IllegalArgumentException("Invalid TR Indicator value: " + trIndicatorValue);
        }
        return ecmIndicator;
    }
}
