package gov.irs.jios.common.client.tr.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
public class GroupField {
	private Integer index;
    private String fieldId;
    private String value;
    private GroupField child;
}
