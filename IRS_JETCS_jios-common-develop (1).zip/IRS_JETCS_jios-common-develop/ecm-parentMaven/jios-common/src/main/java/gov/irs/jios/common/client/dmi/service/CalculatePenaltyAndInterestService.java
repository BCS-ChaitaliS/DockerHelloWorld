package gov.irs.jios.common.client.dmi.service;

import static gov.irs.jios.common.client.tr.util.EcmPayloadLineFinder.retrieveLineItems;
import static gov.irs.jios.common.client.tr.util.TrRetrieveResponseLineFinder.populateTrResultMap;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_INFO;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.EXCLUDE_PENALTY_TYPES1;
import static gov.irs.jios.common.util.JiosCommonConstants.EXCLUDE_PENALTY_TYPES2;
import static gov.irs.jios.common.util.JiosCommonConstants.PCT_20_PENALTY_TYPES;
import static gov.irs.jios.common.util.JiosCommonConstants.PCT_40_PENALTY_TYPES;
import static gov.irs.jios.common.util.JiosCommonConstants.PCT_75_PENALTY_TYPES;
import static gov.irs.jios.common.util.JiosCommonConstants.TAX_MONTH;
import static gov.irs.jios.common.util.JiosCommonConstants.TAX_PERIOD;
import static gov.irs.jios.common.util.JiosCommonConstants.TAX_YEAR;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import gov.irs.jios.common.client.dmi.pojo.AccCalc;
import gov.irs.jios.common.client.dmi.pojo.CalcInfo;
import gov.irs.jios.common.client.dmi.pojo.DMIRequest;
import gov.irs.jios.common.client.dmi.pojo.FtpCalc;
import gov.irs.jios.common.client.dmi.pojo.PenMain;
import gov.irs.jios.common.client.tr.pojo.PenaltyFlags;
import gov.irs.jios.common.client.tr.pojo.RetrieveFieldsResponseDTO;
import gov.irs.jios.common.client.tr.service.AuthLocatorService;
import gov.irs.jios.common.client.tr.service.OpenSessionService;
import gov.irs.jios.common.client.tr.service.PingTokenService;
import gov.irs.jios.common.client.tr.service.RetrieveFieldsService;
import gov.irs.jios.common.client.tr.service.SaveFieldsService;
import gov.irs.jios.common.request.ValidatableRequest;
import gov.irs.jios.common.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CalculatePenaltyAndInterestService {
    
    private final WebClient webClient;
    
    @Autowired
    private ObjectMapper objectMapper;
    
    @Autowired
    private AuthLocatorService authLocatorService;
    
    @Autowired
    private PingTokenService pingTokenService;
    
    @Autowired
    private OpenSessionService openSessionService;
    
    @Autowired
    private SaveFieldsService saveFieldsService;

    @Autowired
    private RetrieveFieldsService retrieveFieldsService;
    
    @Value("${mock.penalty.response.path:penalty-calc-response.json}")
    private String mockResponsePath;

    @Value("${should.make.tr.call:true}")
	private boolean shouldMakeTrCall;
    
    public static final List<String> DELINQUENCY_PENALTY_TYPES = Arrays.asList(
        "6651 (a)(1)", "6651 (a)(2)", "6651 (a)(3)", "6654"
    );

    public CalculatePenaltyAndInterestService(
            WebClient.Builder webClientBuilder,
            @Value("${pi.calculation.api.url:\"\"}") String apiUrl) {
        this.webClient = webClientBuilder.baseUrl(apiUrl).build();
    }

    public JsonNode calculateReturnRelatedPenaltyInterest(ValidatableRequest inputPayload) {
       	DMIRequest request = createReturnRelatedRequest(inputPayload);
        logRequest(request);
        return sendRequest(request);
    }
    
    public JsonNode calculateIssueRelatedPenaltyInterest(ValidatableRequest inputPayload, 
            Map<String, Map<String, Map<String, String>>> underPaymentMap, Set<String> penaltyTypes) {
        DMIRequest request = createIssueRelatedRequest(inputPayload, underPaymentMap, penaltyTypes);
        logRequest(request);
        return sendRequest(request);
    }
    
    public ObjectNode calculateIssueRelatedPenalties(ValidatableRequest request,
			Map<String, Map<String, Map<String, String>>> underPaymentMap, Set<String> penaltyTypes) {
    	
    	List<JsonNode> responses = new ArrayList<>();
    	
    	// Process "Total" if it exists in underPaymentMap
        if (underPaymentMap.containsKey("Total")) {
        	Map<String, Map<String, Map<String, String>>> totalMap = new HashMap<>();
            totalMap.put("Total", underPaymentMap.get("Total"));
            JsonNode totalResponse = calculateIssueRelatedPenaltyInterest(request, totalMap, penaltyTypes);
            responses.add(totalResponse);
        }
        
        // Process "Agreed" if it exists in underPaymentMap
        if (underPaymentMap.containsKey("Agreed")) {
        	Map<String, Map<String, Map<String, String>>> agreedMap = new HashMap<>();
            agreedMap.put("Agreed", underPaymentMap.get("Agreed"));
            JsonNode agreedResponse = calculateIssueRelatedPenaltyInterest(request, agreedMap, penaltyTypes);
            responses.add(agreedResponse);
        }
        
        // Combine responses into PenaltyReport array
        try {
            ObjectNode combinedResponse = objectMapper.createObjectNode();
            ArrayNode penaltyReportArray = combinedResponse.putArray("PenaltyReport");
            
            for (JsonNode response : responses) {
            	penaltyReportArray.add(response);
            }
            
            return combinedResponse;
        } catch (Exception e) {
            log.error("Error combining penalty responses", e);
            throw new RuntimeException("Error combining penalty responses", e);
        }
	}

	public void computeTaxPrd(ValidatableRequest request) {
        Map<String, Object> header = request.getHeader();
        @SuppressWarnings("unchecked")
        Map<String, Object> calcInfo = (Map<String, Object>) header.get(CALC_INFO);
        
        if (calcInfo != null) {
            String taxYr = (String) calcInfo.get(TAX_YEAR);
            String taxMonthNum = (String) calcInfo.get(TAX_MONTH);
            
            if (taxYr != null && taxMonthNum != null) {
                String taxPrd = taxYr + taxMonthNum;
                header.put(TAX_PERIOD, taxPrd);
                log.info("Added {}: {} to header", TAX_PERIOD, taxPrd);
            } else {
                log.warn("Unable to create {}: {} or {} is missing in {}", TAX_PERIOD, TAX_YEAR, TAX_MONTH, CALC_INFO);
            }
        } else {
            log.warn("{} is missing in the header", CALC_INFO);
        }
    }
    
	@SuppressWarnings("unchecked")
	public Set<String> analyzePenaltyRequest(ValidatableRequest request, PenaltyFlags flags) {
	    Map<String, Object> header = request.getHeader();
	    
	    // Get Penalties object from header
	    Map<String, List<String>> penalties = (Map<String, List<String>>) header.get("Penalties");
	    
	    if (penalties == null) {
	        throw new IllegalArgumentException("No Penalties object found in header");
	    }
	    
	    // Process ReturnPenaltyCd array
	    List<String> returnPenalties = penalties.get("ReturnPenaltyCd");
	    if (returnPenalties != null && !returnPenalties.isEmpty()) {
	        // Filter out DELINQUENCY_PENALTY_TYPES
	        Set<String> filteredReturnPenalties = returnPenalties.stream()
	            .filter(penalty -> !DELINQUENCY_PENALTY_TYPES.contains(penalty))
	            .collect(Collectors.toSet());
	            
	        if (!filteredReturnPenalties.isEmpty()) {
	            flags.setReturnRelated(true);
	        }
	    }
	    
	    // Process IssuePenaltyCd array
	    List<String> issuePenalties = penalties.get("IssuePenaltyCd");
	    if (issuePenalties != null && !issuePenalties.isEmpty()) {
	        flags.setIssueRelated(true);
	    }

	    // Get PenaltyRequest array to extract penalty types
	    List<Map<String, Object>> penaltyRequests = (List<Map<String, Object>>) header.get("PenaltyRequest");
	    
	    if (penaltyRequests == null || penaltyRequests.isEmpty()) {
	        throw new IllegalArgumentException("No PenaltyRequest array found in header");
	    }
	    
	    // Find Total request to get the complete set of penalty types
	    Map<String, Object> totalRequest = penaltyRequests.stream()
	        .filter(pr -> "Total".equals(pr.get("AgreedCd")))
	        .findFirst()
	        .orElse(null);

	    Set<String> totalPenalties = null;
	    if (totalRequest != null) {
	        totalPenalties = ((List<String>) totalRequest.get("interestPenaltyCd")).stream()
	            .filter(penalty -> !"interest".equals(penalty))
	            .collect(Collectors.toSet());
	    }

	    // Analyze forms for mismatches between total and agreed adjustments
	    List<Map<String, Object>> forms = (List<Map<String, Object>>) request.getBody().get("forms");
	    boolean hasMismatch = analyzeFormsForMismatch(forms);
	    
	    if (hasMismatch) {
	        flags.setAgreed(true);
	        flags.setTotal(true);
	    } else {
	        flags.setAgreed(true);
	    }

	    return totalPenalties;
	}

	private boolean analyzeFormsForMismatch(List<Map<String, Object>> forms) {
	    if (forms == null || forms.isEmpty()) {
	        return false;
	    }

	    for (Map<String, Object> form : forms) {
	        @SuppressWarnings("unchecked")
			List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get("lineItems");
	        if (lineItems != null && !lineItems.isEmpty()) {
	            if (analyzeLineItemsForMismatch(lineItems)) {
	                return true;
	            }
	        }
	    }
	    return false;
	}

	private boolean analyzeLineItemsForMismatch(List<Map<String, Object>> lineItems) {
	    for (Map<String, Object> lineItem : lineItems) {
	        // Check current line item for mismatch
	        String totalAdjustment = (String) lineItem.get("totalAdjustmentValueTxt");
	        String agreedAdjustment = (String) lineItem.get("agreedAdjustmentValueTxt");
	        
	        // If both values are present, compare them
	        if (totalAdjustment != null && agreedAdjustment != null 
	            && !totalAdjustment.equals(agreedAdjustment)) {
	            return true;
	        }

	        // Recursively check nested line items
	        @SuppressWarnings("unchecked")
			List<Map<String, Object>> nestedLineItems = (List<Map<String, Object>>) lineItem.get("lineItems");
	        if (nestedLineItems != null && !nestedLineItems.isEmpty()) {
	            if (analyzeLineItemsForMismatch(nestedLineItems)) {
	                return true;
	            }
	        }
	    }
	    return false;
	}
    
    public void processIssueRelatedPenalty(ValidatableRequest request, Map<String, Map<String, String>> trResultMap, PenaltyFlags flags, 
    		Set<String> penaltyTypes, String activeProfile) throws Exception {
        
        String token = null;
        Map<String, String> authTokenSessionToken = null;
        if (shouldMakeTrCall) {
            token = "local".equals(activeProfile) ? authLocatorService.getToken() : pingTokenService.getAccessToken();
            log.info("token: {}", token);
            
            String locatorId = authLocatorService.createLocator(request.getHeader(), token);
            log.info("locatorId: {}", locatorId);
            
            authTokenSessionToken = openSessionService.openSession(request.getHeader(), token, locatorId);
            log.info("authTokenSessionToken: {}", authTokenSessionToken);
        }
        
        if (hasExcludedPenaltyType1(penaltyTypes)) {
	        if (flags.isAgreed) {
	            // Step 3: Process agreed underpayment calculations excluding 6662A
	        	RetrieveFieldsResponseDTO response = callTrToSaveAndRetrieveFields(request, token, authTokenSessionToken,
	                CALC_TYPE_PENALTY_AGR_UNDRPYMNT_EXCL_6662A);
	            populateTrResultMap(response, trResultMap, CALC_TYPE_PENALTY_AGR_UNDRPYMNT_EXCL_6662A);
	        } 
	        if (flags.isTotal) {
	            // Step 4: Process total underpayment calculations excluding 6662A
	        	RetrieveFieldsResponseDTO response = callTrToSaveAndRetrieveFields(request, token, authTokenSessionToken,
	                CALC_TYPE_PENALTY_TOT_UNDRPYMNT_EXCL_6662A);
	            populateTrResultMap(response, trResultMap, CALC_TYPE_PENALTY_TOT_UNDRPYMNT_EXCL_6662A);
	        }
        }

        if (flags.isAgreed) {
            // Step 5: Process agreed underpayment subject to no penalty excluding 6662A
        	RetrieveFieldsResponseDTO response = callTrToSaveAndRetrieveFields(request, token, authTokenSessionToken,
                CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A);
        	populateTrResultMap(response, trResultMap, CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A);
        } 
        if (flags.isTotal) {
            // Step 6: Process total underpayment subject to no penalty excluding 6662A
        	RetrieveFieldsResponseDTO response = callTrToSaveAndRetrieveFields(request, token, authTokenSessionToken,
                CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A);
        	populateTrResultMap(response, trResultMap, CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A);
        }
        
        if (hasPct20PenaltyType(penaltyTypes)) {
            if (flags.isAgreed) {
                // Step 7: Process agreed underpayment subject to 20% penalty excluding 6662A
            	RetrieveFieldsResponseDTO response = callTrToSaveAndRetrieveFields(request, token, authTokenSessionToken,
                    CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A);
            	populateTrResultMap(response, trResultMap, CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A);
            } 
            if (flags.isTotal) {
                // Step 8: Process total underpayment subject to 20% penalty excluding 6662A
            	RetrieveFieldsResponseDTO response = callTrToSaveAndRetrieveFields(request, token, authTokenSessionToken,
                    CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A);
            	populateTrResultMap(response, trResultMap, CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A);
            }
        }
        
        /*if (hasPct30PenaltyType(penaltyTypes)) {
            if (flags.isAgreed) {
                // Step 9: Process agreed underpayment subject to 30% penalty excluding 6662A
            	RetrieveFieldsResponseDTO response = processCalculationStep(request, token, authTokenSessionToken,
                    CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_30PCT_EXCL_6662A);
                populateTrResultMap(response, trResultMap, CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_30PCT_EXCL_6662A);
            } 
            if (flags.isTotal) {
                // Step 10: Process total underpayment subject to 30% penalty excluding 6662A
            	RetrieveFieldsResponseDTO response = processCalculationStep(request, token, authTokenSessionToken,
                    CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_30PCT_EXCL_6662A);
                populateTrResultMap(response, trResultMap, CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_30PCT_EXCL_6662A);
            }
        }*/
        
        if (hasPct40PenaltyType(penaltyTypes)) {
            if (flags.isAgreed) {
                // Step 9: Process agreed underpayment subject to 40% penalty excluding 6662A
            	RetrieveFieldsResponseDTO response = callTrToSaveAndRetrieveFields(request, token, authTokenSessionToken,
                    CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A);
            	populateTrResultMap(response, trResultMap, CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A);
            } 
            if (flags.isTotal) {
                // Step 10: Process total underpayment subject to 40% penalty excluding 6662A
            	RetrieveFieldsResponseDTO response = callTrToSaveAndRetrieveFields(request, token, authTokenSessionToken,
                    CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A);
            	populateTrResultMap(response, trResultMap, CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A);
            }
        }
        
        if (hasPct75PenaltyType(penaltyTypes)) {
            if (flags.isAgreed) {
                // Step 11: Process agreed underpayment subject to 75% penalty excluding 6662A
            	RetrieveFieldsResponseDTO response = callTrToSaveAndRetrieveFields(request, token, authTokenSessionToken,
                    CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A);
            	populateTrResultMap(response, trResultMap, CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A);
            } 
            if (flags.isTotal) {
                // Step 12: Process total underpayment subject to 75% penalty excluding 6662A
            	RetrieveFieldsResponseDTO response = callTrToSaveAndRetrieveFields(request, token, authTokenSessionToken,
                    CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A);
            	populateTrResultMap(response, trResultMap, CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A);
            }
        }
        
        if (hasExcludedPenaltyType2(penaltyTypes)) {
	        if (flags.isAgreed) {
	            // Step 13: Process agreed underpayment for use in calculation of 6662A
	        	RetrieveFieldsResponseDTO response = callTrToSaveAndRetrieveFields(request, token, authTokenSessionToken,
	        		CALC_TYPE_PENALTY_AGR_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY);
	        	populateTrResultMap(response, trResultMap, CALC_TYPE_PENALTY_AGR_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY);
	        } 
	        if (flags.isTotal) {
	            // Step 14: Process total underpayment for use in calculation of 6662A
	        	RetrieveFieldsResponseDTO response = callTrToSaveAndRetrieveFields(request, token, authTokenSessionToken,
	        		CALC_TYPE_PENALTY_TOT_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY);
	        	populateTrResultMap(response, trResultMap, CALC_TYPE_PENALTY_TOT_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY);
	        }
        }
    }
    
    @SuppressWarnings({ "unchecked", "unused" })
    private void collectPenaltyTypesFromBody(Map<String, Object> body, Set<String> penaltyTypes) {
        List<Map<String, Object>> forms = (List<Map<String, Object>>) body.get("forms");
        if (forms != null) {
            for (Map<String, Object> form : forms) {
                List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get("lineItems");
                if (lineItems != null) {
                    collectPenaltyTypesFromLineItems(lineItems, penaltyTypes);
                }
            }
        }
    }
    
    public Map<String, Map<String, Map<String, String>>> calculateUnderPayments(ValidatableRequest request, 
            Map<String, Map<String, String>> trResultMap, Set<String> penaltyTypes, PenaltyFlags flags) {
        
    	Map<String, Map<String, Map<String, String>>> underPaymentMap = new HashMap<>();
        
    	try {
            Map<String, Map<String, Object>> form1040LineItems = retrieveLineItems(request);
            String taxShownInReturn = (String) form1040LineItems.get("/IRS1040/TotalTaxAmt").get("perReturnValueTxt");
            underPaymentMap.put("Agreed", new LinkedHashMap<>());
            underPaymentMap.put("Total", new LinkedHashMap<>());
            
            if (hasExcludedPenaltyType1(penaltyTypes)) {
	            // Step 3: Compute agreed underpayment calculations excluding 6662A
	            Map<String, String> trExcl6662AMap = trResultMap.get(CALC_TYPE_PENALTY_AGR_UNDRPYMNT_EXCL_6662A);
	            if (trExcl6662AMap != null) {
	                BigDecimal w = computeW(form1040LineItems, trExcl6662AMap, true);
	                BigDecimal[] xy = computeXY(form1040LineItems, trExcl6662AMap, taxShownInReturn, true);
	                if (w != null) {
	                	BigDecimal xySummed = xy[0].add(xy[1]);
	                	BigDecimal underPayment = w.subtract(xySummed); 
	                    Map<String, Map<String, String>> agreedMap = underPaymentMap.get("Agreed");
	                    Map<String, String> subMap = new HashMap<>();
	                    subMap.put("underPayment", underPayment.toString());
	                    subMap.put("w", w.toString());
	                    agreedMap.put("excluding6662A", subMap);
	                }
	            }
	
	            // Step 4: Compute total underpayment calculations excluding 6662A
	            trExcl6662AMap = trResultMap.get(CALC_TYPE_PENALTY_TOT_UNDRPYMNT_EXCL_6662A);
	            if (trExcl6662AMap != null) {
	            	BigDecimal w = computeW(form1040LineItems, trExcl6662AMap, false);
	            	BigDecimal[] xy = computeXY(form1040LineItems, trExcl6662AMap, taxShownInReturn, false);
	                if (w != null) {
	                	BigDecimal xySummed = xy[0].add(xy[1]);
	                	BigDecimal underPayment = w.subtract(xySummed); 
	                    Map<String, Map<String, String>> totalMap = underPaymentMap.get("Total");
	                    Map<String, String> subMap = new HashMap<>();
	                    subMap.put("underPayment", underPayment.toString());
	                    subMap.put("w", w.toString());
	                    totalMap.put("excluding6662A", subMap);
	                }
	            }
            }

            // Step 5: Compute agreed underpayment subject to no penalty excluding 6662A
            Map<String, String> trNoPenaltyMap = trResultMap.get(CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A);
            if (trNoPenaltyMap != null) {
            	BigDecimal w = computeW(form1040LineItems, trNoPenaltyMap, true);
            	BigDecimal[] xy = computeXY(form1040LineItems, trNoPenaltyMap, taxShownInReturn, true);
                if (w != null) {
                	BigDecimal xySummed = xy[0].add(xy[1]);
                	BigDecimal underPayment = w.subtract(xySummed); 
                    Map<String, Map<String, String>> agreedMap = underPaymentMap.get("Agreed");
                    Map<String, String> subMap = new HashMap<>();
                    subMap.put("underPayment", underPayment.toString());
                    subMap.put("w", w.toString());
                    agreedMap.put("noPenalty", subMap);
                }
            }

            // Step 6: Compute total underpayment subject to no penalty excluding 6662A
            trNoPenaltyMap = trResultMap.get(CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A);
            if (trNoPenaltyMap != null) {
            	BigDecimal w = computeW(form1040LineItems, trNoPenaltyMap, false);
            	BigDecimal[] xy = computeXY(form1040LineItems, trNoPenaltyMap, taxShownInReturn, false);
                if (w != null) {
                	BigDecimal xySummed = xy[0].add(xy[1]);
                	BigDecimal underPayment = w.subtract(xySummed); 
                    Map<String, Map<String, String>> totalMap = underPaymentMap.get("Total");
                    Map<String, String> subMap = new HashMap<>();
                    subMap.put("underPayment", underPayment.toString());
                    subMap.put("w", w.toString());
                    totalMap.put("noPenalty", subMap);
                }
            }

            // Step 7 & 8: Compute agreed & total underpayment subject to 20% penalty excluding 6662A
            if (hasPct20PenaltyType(penaltyTypes)) {
                calculate20PctPenalties(trResultMap, form1040LineItems, underPaymentMap, penaltyTypes, taxShownInReturn);
            }
            
            // Step 9 & 10: Compute agreed & total underpayment subject to 40% penalty excluding 6662A
            if (hasPct40PenaltyType(penaltyTypes)) {
                calculate40PctPenalties(trResultMap, form1040LineItems, underPaymentMap, penaltyTypes, taxShownInReturn);
            }
            
            // Step 11 & 12: Compute agreed & total underpayment subject to 75% penalty excluding 6662A
            if (hasPct75PenaltyType(penaltyTypes)) {
                calculate75PctPenalties(trResultMap, form1040LineItems, underPaymentMap, penaltyTypes, taxShownInReturn);
            }
            
            if (hasExcludedPenaltyType2(penaltyTypes)) {
	            // Step 13: Process agreed underpayment for use in calculation of 6662A
	        	String agreedAdjTaxCalcValueTxt = findAgreedTaxableIncomeAmount(request);
	        	Map<String, String> tr6662AMap = trResultMap.get(CALC_TYPE_PENALTY_AGR_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY);
	            if (tr6662AMap != null) {
	                String taxableIncomeAmt = tr6662AMap.get("taxableIncomeAmt");
	                if (taxableIncomeAmt != null && !taxableIncomeAmt.isEmpty() && agreedAdjTaxCalcValueTxt != null && !agreedAdjTaxCalcValueTxt.isEmpty()) {
	                    BigDecimal difference = new BigDecimal(agreedAdjTaxCalcValueTxt).subtract(new BigDecimal(taxableIncomeAmt));
	            	    Map<String, Map<String, String>> agreedMap = underPaymentMap.get("Agreed");
	            	    Map<String, String> mapFor6662ACalc = new HashMap<>();
	            	    mapFor6662ACalc.put("6662ACalc", difference.toString());
	            	    agreedMap.put("6662A", mapFor6662ACalc);
	                }
	            }
	
	            // Step 14: Process total underpayment for use in calculation of 6662A
	        	String totalAdjTaxCalcValueTxt = findTotalTaxableIncomeAmount(request);
	        	tr6662AMap = trResultMap.get(CALC_TYPE_PENALTY_TOT_UNDRPYMNT_6662A_UNDRPYMNT_PNLTY);
	            if (tr6662AMap != null) {
	                String taxableIncomeAmt = tr6662AMap.get("taxableIncomeAmt");
	                if (taxableIncomeAmt != null && !taxableIncomeAmt.isEmpty() && totalAdjTaxCalcValueTxt != null && !totalAdjTaxCalcValueTxt.isEmpty()) {
	                	BigDecimal difference = new BigDecimal(totalAdjTaxCalcValueTxt).subtract(new BigDecimal(taxableIncomeAmt));
	            	    Map<String, Map<String, String>> totalMap = underPaymentMap.get("Total");
	            	    Map<String, String> mapFor6662ACalc = new HashMap<>();
	            	    mapFor6662ACalc.put("6662ACalc", difference.toString());
	            	    totalMap.put("6662A", mapFor6662ACalc);
	                }
	            }
            }
            return underPaymentMap;
        } catch (Exception e) {
            log.error("Error calculating under payments values: {}", e.getMessage());
            throw new RuntimeException("Error calculating under payments values", e);
        }
    }
    
    public BigDecimal computeW(Map<String, Map<String, Object>> form1040LineItems, Map<String, String> trResultMap, boolean isAgreed) {
    	BigDecimal w = new BigDecimal(0);

    	String totalTaxAmtStr = trResultMap.get("totalTaxAmt");
        if (CommonUtil.isNumeric(totalTaxAmtStr)) {
        	w = w.add(new BigDecimal(totalTaxAmtStr));
        	
 	       	String userAdjustedLineInd = null;
        	Map<String, Object> lineItem = form1040LineItems.get("/IRS8959/AdditionalTaxGrp/AdditionalMedicareTaxGrp/AdditionalMedicareTaxAmt");
 	       	if (lineItem != null) {
 	       		userAdjustedLineInd = (String) lineItem.get("userAdjustedLineInd");
 	       	}
 	       	if (userAdjustedLineInd != null) {
 	       		if (userAdjustedLineInd.equals("Y")) {
 	       			String adjustmentValueFromLineItem = null;
 	       			if (isAgreed) {
 	       				adjustmentValueFromLineItem = (String) lineItem.get("agreedAdjustmentValueTxt");
 	       			} else {
 					   adjustmentValueFromLineItem = (String) lineItem.get("totalAdjustmentValueTxt");
 	       			}
 	       			if (CommonUtil.isNumeric(adjustmentValueFromLineItem)) {
 	    			    w = w.subtract(new BigDecimal(adjustmentValueFromLineItem));
 	       			}
 	       		} else if (userAdjustedLineInd.equals("N")) {
 				   String perReturnValueTxt = (String) lineItem.get("perReturnValueTxt");
				   BigDecimal perReturnValue = new BigDecimal(0);
				   if (CommonUtil.isNumeric(perReturnValueTxt)) {
					   perReturnValue = new BigDecimal(perReturnValueTxt);
				   }
 				   String taxCalcValueTxt = (String) trResultMap.get("additionalMedicareTaxAmt");
 				   BigDecimal taxCalcValue = new BigDecimal(0);
 				   if (CommonUtil.isNumeric(taxCalcValueTxt)) {
 					   taxCalcValue = new BigDecimal(taxCalcValueTxt);
 				   }
 				   BigDecimal statTaxCalcValue = perReturnValue.subtract(taxCalcValue);
 				   w = w.subtract(statTaxCalcValue);
 	       		}
 	       	}
        	
	    	BigDecimal valueToBeSubtracted = new BigDecimal(0);
	    	String earnedIncomeCreditAmt = trResultMap.get("earnedIncomeCreditAmt");
	        if (CommonUtil.isNumeric(earnedIncomeCreditAmt)) {
	        	valueToBeSubtracted.add(new BigDecimal(earnedIncomeCreditAmt));
	        }
	        String additionalChildTaxCreditAmt = trResultMap.get("additionalChildTaxCreditAmt");
	        if (CommonUtil.isNumeric(additionalChildTaxCreditAmt)) {
	        	valueToBeSubtracted.add(new BigDecimal(additionalChildTaxCreditAmt));
	        }
	        String refundableAmerOppCreditAmt = trResultMap.get("refundableAmerOppCreditAmt");
	        if (CommonUtil.isNumeric(refundableAmerOppCreditAmt)) {
	        	valueToBeSubtracted.add(new BigDecimal(refundableAmerOppCreditAmt));
	        }
	        String totalOtherPaymentsRfdblCrAmt = trResultMap.get("totalOtherPaymentsRfdblCrAmt");
	        if (CommonUtil.isNumeric(totalOtherPaymentsRfdblCrAmt)) {
	        	valueToBeSubtracted.add(new BigDecimal(totalOtherPaymentsRfdblCrAmt));
	        }
	        w = w.subtract(valueToBeSubtracted);
	        return w;
        }
        return null;
	}
    
    public BigDecimal[] computeXY(Map<String, Map<String, Object>> form1040LineItems,
    	       Map<String, String> trResultMap, String taxShownInReturn, boolean isAgreed) {

	   BigDecimal x = new BigDecimal(0);
	   BigDecimal y = new BigDecimal(0);
	   
	   String totalTaxAmtPerReturnValue = (String) form1040LineItems.get("/IRS1040/TotalTaxAmt").get("perReturnValueTxt");
	   if (CommonUtil.isNumeric(totalTaxAmtPerReturnValue)) {
	       x = new BigDecimal(totalTaxAmtPerReturnValue);

	       String earnedIncomeCreditAmtPerRtnVal = null;
	       Map<String, Object> lineItem = form1040LineItems.get("/IRS1040/EarnedIncomeCreditAmt");
	       if (lineItem != null) {
	    	   earnedIncomeCreditAmtPerRtnVal = (String) lineItem.get("perReturnValueTxt");
	       }
	       if (CommonUtil.isNumeric(earnedIncomeCreditAmtPerRtnVal)) {
	           BigDecimal earnedIncomeCrdtAmt = new BigDecimal(earnedIncomeCreditAmtPerRtnVal);
	           x = x.subtract(earnedIncomeCrdtAmt);
	       }
	       
	       String additionalChildTaxCreditAmtPerRtnVal = null;
	       lineItem = form1040LineItems.get("/IRS1040/AdditionalChildTaxCreditAmt");
	       if (lineItem != null) {
	    	   additionalChildTaxCreditAmtPerRtnVal = (String) lineItem.get("perReturnValueTxt");
	       }
	       if (CommonUtil.isNumeric(additionalChildTaxCreditAmtPerRtnVal)) {
	           BigDecimal additionalChildTaxCreditAmt = new BigDecimal(additionalChildTaxCreditAmtPerRtnVal);
	           x = x.subtract(additionalChildTaxCreditAmt);
	       }
	       
	       String refundableAmerOppCreditAmtPerRtnVal = null;
	       lineItem = form1040LineItems.get("/IRS1040/RefundableAmerOppCreditAmt");
	       if (lineItem != null) {
	    	   refundableAmerOppCreditAmtPerRtnVal = (String) lineItem.get("perReturnValueTxt");
	       }
	       if (CommonUtil.isNumeric(refundableAmerOppCreditAmtPerRtnVal)) {
	           BigDecimal refundableAmerOppCreditAmt = new BigDecimal(refundableAmerOppCreditAmtPerRtnVal);
	           x = x.subtract(refundableAmerOppCreditAmt);
	       }
	       
	       String totalOtherPaymentsRfdblCrAmtPerRtnVal = null;
	       lineItem = form1040LineItems.get("/IRS1040/TotalOtherPaymentsRfdblCrAmt");
	       if (lineItem != null) {
	    	   totalOtherPaymentsRfdblCrAmtPerRtnVal = (String) lineItem.get("perReturnValueTxt");
	       }
	       if (CommonUtil.isNumeric(totalOtherPaymentsRfdblCrAmtPerRtnVal)) {
	           BigDecimal totalOtherPaymentsRfdblCrAmt = new BigDecimal(totalOtherPaymentsRfdblCrAmtPerRtnVal);
	           x = x.subtract(totalOtherPaymentsRfdblCrAmt);
	       }

	       lineItem = form1040LineItems.get("/IRS1040/FormW2WithheldTaxAmt");
	       String userAdjustedLineInd = null;
	       if (lineItem != null) {
	    	   userAdjustedLineInd = (String) lineItem.get("userAdjustedLineInd");
	       }
		   if (userAdjustedLineInd != null) {
			   if (userAdjustedLineInd.equals("Y")) {
				   String adjustmentValueFromLineItem = null;
	    		   if (isAgreed) {
					   adjustmentValueFromLineItem = (String) lineItem.get("agreedAdjustmentValueTxt");
				   } else {
					   adjustmentValueFromLineItem = (String) lineItem.get("totalAdjustmentValueTxt");
				   }
	    		   if (CommonUtil.isNumeric(adjustmentValueFromLineItem)) {
	    			   BigDecimal adjustmentValFromLineItem = new BigDecimal(adjustmentValueFromLineItem);
	    	    	   if (adjustmentValFromLineItem.signum() < 0) {
	    	    		   x = x.add(adjustmentValFromLineItem);
	    	    	   } else {
	    	    		   y = y.add(adjustmentValFromLineItem);
	    	    	   }
	    		   }
			   } else if (userAdjustedLineInd.equals("N")) {
				   String adjTaxCalcValueTxt = (String) trResultMap.get("formW2WithheldTaxAmt");
				   BigDecimal adjTaxCalcValue = new BigDecimal(0);
				   if (CommonUtil.isNumeric(adjTaxCalcValueTxt)) {
					   adjTaxCalcValue = new BigDecimal(adjTaxCalcValueTxt);
				   }
				   String perReturnValueTxt = (String) lineItem.get("perReturnValueTxt");
				   BigDecimal perReturnValue = new BigDecimal(0);
				   if (CommonUtil.isNumeric(perReturnValueTxt)) {
					   perReturnValue = new BigDecimal(perReturnValueTxt);
				   }
				   BigDecimal statAdjTaxCalcValue = adjTaxCalcValue.subtract(perReturnValue);
				   if (statAdjTaxCalcValue.signum() < 0) {
    	    		   x = x.add(statAdjTaxCalcValue);
    	    	   } else {
    	    		   y = y.add(statAdjTaxCalcValue);
    	    	   }
			   }
    	   }
		   
		   lineItem = form1040LineItems.get("/IRS1040/Form1099WithheldTaxAmt");
	       userAdjustedLineInd = null;
	       if (lineItem != null) {
	    	   userAdjustedLineInd = (String) lineItem.get("userAdjustedLineInd");
	       }
		   if (userAdjustedLineInd != null) {
			   if (userAdjustedLineInd.equals("Y")) {
				   String adjustmentValueFromLineItem = null;
	    		   if (isAgreed) {
					   adjustmentValueFromLineItem = (String) lineItem.get("agreedAdjustmentValueTxt");
				   } else {
					   adjustmentValueFromLineItem = (String) lineItem.get("totalAdjustmentValueTxt");
				   }
	    		   if (CommonUtil.isNumeric(adjustmentValueFromLineItem)) {
	    			   BigDecimal adjustmentValFromLineItem = new BigDecimal(adjustmentValueFromLineItem);
	    	    	   if (adjustmentValFromLineItem.signum() < 0) {
	    	    		   x = x.add(adjustmentValFromLineItem);
	    	    	   } else {
	    	    		   y = y.add(adjustmentValFromLineItem);
	    	    	   }
	    		   }
			   } else if (userAdjustedLineInd.equals("N")) {
				   String adjTaxCalcValueTxt = (String) trResultMap.get("form1099WithheldTaxAmt");
				   BigDecimal adjTaxCalcValue = new BigDecimal(0);
				   if (CommonUtil.isNumeric(adjTaxCalcValueTxt)) {
					   adjTaxCalcValue = new BigDecimal(adjTaxCalcValueTxt);
				   }
				   String perReturnValueTxt = (String) lineItem.get("perReturnValueTxt");
				   BigDecimal perReturnValue = new BigDecimal(0);
				   if (CommonUtil.isNumeric(perReturnValueTxt)) {
					   perReturnValue = new BigDecimal(perReturnValueTxt);
				   }
				   BigDecimal statAdjTaxCalcValue = adjTaxCalcValue.subtract(perReturnValue);
				   if (statAdjTaxCalcValue.signum() < 0) {
    	    		   x = x.add(statAdjTaxCalcValue);
    	    	   } else {
    	    		   y = y.add(statAdjTaxCalcValue);
    	    	   }
			   }
		   }
		   
		   lineItem = form1040LineItems.get("/IRS1040/TaxWithheldOtherAmt");
	       userAdjustedLineInd = null;
	       if (lineItem != null) {
	    	   userAdjustedLineInd = (String) lineItem.get("userAdjustedLineInd");
	       }
		   if (userAdjustedLineInd != null) {
			   if (userAdjustedLineInd.equals("Y")) {
				   String adjustmentValueFromLineItem = null;
	    		   if (isAgreed) {
					   adjustmentValueFromLineItem = (String) lineItem.get("agreedAdjustmentValueTxt");
				   } else {
					   adjustmentValueFromLineItem = (String) lineItem.get("totalAdjustmentValueTxt");
				   }
	    		   if (CommonUtil.isNumeric(adjustmentValueFromLineItem)) {
	    			   BigDecimal adjustmentValFromLineItem = new BigDecimal(adjustmentValueFromLineItem);
	    	    	   if (adjustmentValFromLineItem.signum() < 0) {
	    	    		   x = x.add(adjustmentValFromLineItem);
	    	    	   } else {
	    	    		   y = y.add(adjustmentValFromLineItem);
	    	    	   }
	    		   }
			   } else if (userAdjustedLineInd.equals("N")) {
				   String adjTaxCalcValueTxt = (String) trResultMap.get("taxWithheldOtherAmt");
				   BigDecimal adjTaxCalcValue = new BigDecimal(0);
				   if (CommonUtil.isNumeric(adjTaxCalcValueTxt)) {
					   adjTaxCalcValue = new BigDecimal(adjTaxCalcValueTxt);
				   }
				   String perReturnValueTxt = (String) lineItem.get("perReturnValueTxt");
				   BigDecimal perReturnValue = new BigDecimal(0);
				   if (CommonUtil.isNumeric(perReturnValueTxt)) {
					   perReturnValue = new BigDecimal(perReturnValueTxt);
				   }
				   BigDecimal statAdjTaxCalcValue = adjTaxCalcValue.subtract(perReturnValue);
				   if (statAdjTaxCalcValue.signum() < 0) {
    	    		   x = x.add(statAdjTaxCalcValue);
    	    	   } else {
    	    		   y = y.add(statAdjTaxCalcValue);
    	    	   }
			   }
		   }
		   
		   lineItem = form1040LineItems.get("/IRS1040/EstimatedTaxPaymentsAmt");
	       userAdjustedLineInd = null;
	       if (lineItem != null) {
	    	   userAdjustedLineInd = (String) lineItem.get("userAdjustedLineInd");
	       }
		   if (userAdjustedLineInd != null) {
			   if (userAdjustedLineInd.equals("Y")) {
				   String adjustmentValueFromLineItem = null;
	    		   if (isAgreed) {
					   adjustmentValueFromLineItem = (String) lineItem.get("agreedAdjustmentValueTxt");
				   } else {
					   adjustmentValueFromLineItem = (String) lineItem.get("totalAdjustmentValueTxt");
				   }
	    		   if (CommonUtil.isNumeric(adjustmentValueFromLineItem)) {
	    			   BigDecimal adjustmentValFromLineItem = new BigDecimal(adjustmentValueFromLineItem);
	    	    	   if (adjustmentValFromLineItem.signum() < 0) {
	    	    		   x = x.add(adjustmentValFromLineItem);
	    	    	   } else {
	    	    		   y = y.add(adjustmentValFromLineItem);
	    	    	   }
	    		   }
			   } else if (userAdjustedLineInd.equals("N")) {
				   String adjTaxCalcValueTxt = (String) trResultMap.get("estimatedTaxPaymentsAmt");
				   BigDecimal adjTaxCalcValue = new BigDecimal(0);
				   if (CommonUtil.isNumeric(adjTaxCalcValueTxt)) {
					   adjTaxCalcValue = new BigDecimal(adjTaxCalcValueTxt);
				   }
				   String perReturnValueTxt = (String) lineItem.get("perReturnValueTxt");
				   BigDecimal perReturnValue = new BigDecimal(0);
				   if (CommonUtil.isNumeric(perReturnValueTxt)) {
					   perReturnValue = new BigDecimal(perReturnValueTxt);
				   }
				   BigDecimal statAdjTaxCalcValue = adjTaxCalcValue.subtract(perReturnValue);
				   if (statAdjTaxCalcValue.signum() < 0) {
    	    		   x = x.add(statAdjTaxCalcValue);
    	    	   } else {
    	    		   y = y.add(statAdjTaxCalcValue);
    	    	   }
			   }
		   }
	   }
	   return new BigDecimal[] { x, y };
	}

    public void calculate20PctPenalties(Map<String, Map<String, String>> trResultMap, Map<String, Map<String, Object>> form1040LineItems,
            Map<String, Map<String, Map<String, String>>> underPaymentMap, Set<String> penaltyTypes, String taxShownInReturn) {
    	
        // For Agreed
        Map<String, String> tr20pctMap = trResultMap.get(CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A);
        if (tr20pctMap != null) {
            String wStr = null;
            BigDecimal w = computeW(form1040LineItems, tr20pctMap, true);
            Map<String, Map<String, String>> agreedMap = underPaymentMap.get("Agreed");
            Map<String, String> subMap = null;
            if (w != null) {
            	if (agreedMap != null) {
            		subMap = agreedMap.get("noPenalty");
            		if (subMap != null) {
            			wStr = subMap.get("w");
            		}
            	}
            	BigDecimal x = new BigDecimal(0);
                BigDecimal[] xy = computeXY(form1040LineItems, tr20pctMap, taxShownInReturn, true);
            	if (wStr != null) {
            		x = new BigDecimal(wStr);
            	}
            	BigDecimal xySummed = x.add(xy[1]);
            	BigDecimal underPayment = w.subtract(xySummed);
            	subMap = new HashMap<>();
            	if (subMap != null) {
            		subMap.put("underPayment", underPayment.toString());
            		subMap.put("w", w.toString());
            	}
                agreedMap.put("20", subMap);
            }
        }

        // For Total
        tr20pctMap = trResultMap.get(CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A);
        if (tr20pctMap != null) {
            String wStr = null;
            BigDecimal w = computeW(form1040LineItems, tr20pctMap, false);
            Map<String, Map<String, String>> totalMap = underPaymentMap.get("Total");
            Map<String, String> subMap = null;
            if (w != null) {
            	if (totalMap != null) {
            		subMap = totalMap.get("noPenalty");
            		if (subMap != null) {
            			wStr = subMap.get("w");
            		}
            	}
            	BigDecimal x = new BigDecimal(0);
                BigDecimal[] xy = computeXY(form1040LineItems, tr20pctMap, taxShownInReturn, true);
            	if (wStr != null) {
            		x = new BigDecimal(wStr);
            	}
            	BigDecimal xySummed = x.add(xy[1]);
            	BigDecimal underPayment = w.subtract(xySummed);
            	subMap = new HashMap<>();
            	if (subMap != null) {
            		subMap.put("underPayment", underPayment.toString());
            		subMap.put("w", w.toString());
            	}
            	totalMap.put("20", subMap);
            }
        }
    }

    public void calculate40PctPenalties(Map<String, Map<String, String>> trResultMap, Map<String, Map<String, Object>> form1040LineItems,
            Map<String, Map<String, Map<String, String>>> underPaymentMap, Set<String> penaltyTypes, String taxShownInReturn) {
    	
        // For Agreed
        Map<String, String> tr40pctMap = trResultMap.get(CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A);
        if (tr40pctMap != null) {
            String wStr = null;
            BigDecimal w = computeW(form1040LineItems, tr40pctMap, true);
            Map<String, Map<String, String>> agreedMap = underPaymentMap.get("Agreed");
            Map<String, String> subMap = null;
            if (w != null) {
            	if (agreedMap != null) {
            		subMap = agreedMap.get("20");
            		if (subMap == null) {
            			subMap = agreedMap.get("noPenalty");
            		}
        			wStr = subMap.get("w");
            	}
            	BigDecimal x = new BigDecimal(0);
                BigDecimal[] xy = computeXY(form1040LineItems, tr40pctMap, taxShownInReturn, true);
            	if (wStr != null) {
            		x = new BigDecimal(wStr);
            	}
            	BigDecimal xySummed = x.add(xy[1]);
            	BigDecimal underPayment = w.subtract(xySummed);
            	subMap = new HashMap<>();
            	if (subMap != null) {
            		subMap.put("underPayment", underPayment.toString());
            		subMap.put("w", w.toString());
            	}
                agreedMap.put("40", subMap);
            }
        }
        
        // For Total
        tr40pctMap = trResultMap.get(CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A);
        if (tr40pctMap != null) {
            String wStr = null;
            BigDecimal w = computeW(form1040LineItems, tr40pctMap, false);
            Map<String, Map<String, String>> agreedMap = underPaymentMap.get("Total");
            Map<String, String> subMap = null;
            if (w != null) {
            	if (agreedMap != null) {
            		subMap = agreedMap.get("20");
            		if (subMap == null) {
            			subMap = agreedMap.get("noPenalty");
            		}
        			wStr = subMap.get("w");
            	}
            	BigDecimal x = new BigDecimal(0);
                BigDecimal[] xy = computeXY(form1040LineItems, tr40pctMap, taxShownInReturn, true);
            	if (wStr != null) {
            		x = new BigDecimal(wStr);
            	}
            	BigDecimal xySummed = x.add(xy[1]);
            	BigDecimal underPayment = w.subtract(xySummed);
            	subMap = new HashMap<>();
            	if (subMap != null) {
            		subMap.put("underPayment", underPayment.toString());
            		subMap.put("w", w.toString());
            	}
                agreedMap.put("40", subMap);
            }
        }
    }

    public void calculate75PctPenalties(Map<String, Map<String, String>> trResultMap, Map<String, Map<String, Object>> form1040LineItems,
            Map<String, Map<String, Map<String, String>>> underPaymentMap, Set<String> penaltyTypes, String taxShownInReturn) {
        
		// For Agreed
        Map<String, String> tr75pctMap = trResultMap.get(CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A);
        if (tr75pctMap != null) {
            String wStr = null;
            BigDecimal w = computeW(form1040LineItems, tr75pctMap, true);
            Map<String, Map<String, String>> agreedMap = underPaymentMap.get("Agreed");
            Map<String, String> subMap = null;
            if (w != null) {
            	if (agreedMap != null) {
            		subMap = agreedMap.get("40");
            		if (subMap == null) {
            			subMap = agreedMap.get("20");
            			if (subMap == null) {
            				subMap = agreedMap.get("noPenalty");
            			}
            		}
          			wStr = subMap.get("w");
            	}
            	BigDecimal x = new BigDecimal(0);
                BigDecimal[] xy = computeXY(form1040LineItems, tr75pctMap, taxShownInReturn, true);
            	if (wStr != null) {
            		x = new BigDecimal(wStr);
            	}
            	BigDecimal xySummed = x.add(xy[1]);
            	BigDecimal underPayment = w.subtract(xySummed);
            	subMap = new HashMap<>();
            	if (subMap != null) {
            		subMap.put("underPayment", underPayment.toString());
            		subMap.put("w", w.toString());
            	}
                agreedMap.put("75", subMap);
            }
        }

        // For Total
        tr75pctMap = trResultMap.get(CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A);
        if (tr75pctMap != null) {
            String wStr = null;
            BigDecimal w = computeW(form1040LineItems, tr75pctMap, false);
            Map<String, Map<String, String>> agreedMap = underPaymentMap.get("Total");
            Map<String, String> subMap = null;
            if (w != null) {
            	if (agreedMap != null) {
            		subMap = agreedMap.get("40");
            		if (subMap == null) {
            			subMap = agreedMap.get("20");
            			if (subMap == null) {
            				subMap = agreedMap.get("noPenalty");
            			}
            		}
          			wStr = subMap.get("w");
            	}
            	BigDecimal x = new BigDecimal(0);
                BigDecimal[] xy = computeXY(form1040LineItems, tr75pctMap, taxShownInReturn, true);
            	if (wStr != null) {
            		x = new BigDecimal(wStr);
            	}
            	BigDecimal xySummed = x.add(xy[1]);
            	BigDecimal underPayment = w.subtract(xySummed);
            	subMap = new HashMap<>();
            	if (subMap != null) {
            		subMap.put("underPayment", underPayment.toString());
            		subMap.put("w", w.toString());
            	}
                agreedMap.put("75", subMap);
            }
        }
    }

    private void collectPenaltyTypesFromLineItems(List<Map<String, Object>> lineItems, Set<String> penaltyTypes) {
        for (Map<String, Object> lineItem : lineItems) {
            String penaltyType = (String) lineItem.get("issuePenaltyTypeTxt");
            if (penaltyType != null) {
                penaltyTypes.add(penaltyType);
            }
            
            // Recursively check nested line items
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> nestedLineItems = (List<Map<String, Object>>) lineItem.get("lineItems");
            if (nestedLineItems != null) {
                collectPenaltyTypesFromLineItems(nestedLineItems, penaltyTypes);
            }
        }
    }
    
    private boolean hasExcludedPenaltyType1(Set<String> penaltyTypes) {
        return penaltyTypes.stream().anyMatch(EXCLUDE_PENALTY_TYPES1::contains);
    }
    
    private boolean hasExcludedPenaltyType2(Set<String> penaltyTypes) {
        return penaltyTypes.stream().anyMatch(EXCLUDE_PENALTY_TYPES2::contains);
    }
    
    private boolean hasPct20PenaltyType(Set<String> penaltyTypes) {
        return penaltyTypes.stream().anyMatch(PCT_20_PENALTY_TYPES::contains);
    }
    
    /*private boolean hasPct30PenaltyType(Set<String> penaltyTypes) {
        return penaltyTypes.stream().anyMatch(PCT_30_PENALTY_TYPES::contains);
    }*/
    
    private boolean hasPct40PenaltyType(Set<String> penaltyTypes) {
        return penaltyTypes.stream().anyMatch(PCT_40_PENALTY_TYPES::contains);
    }

    private boolean hasPct75PenaltyType(Set<String> penaltyTypes) {
        return penaltyTypes.stream().anyMatch(PCT_75_PENALTY_TYPES::contains);
    }
    
    private RetrieveFieldsResponseDTO callTrToSaveAndRetrieveFields(ValidatableRequest request, 
            String token, Map<String, String> authTokenSessionToken, String calcType) {
    	
    	Map<String, Object> headerMap = request.getHeader();
    	headerMap.put(CALC_TYPE_TXT, calcType);
        saveFieldsService.saveFields(request, token, authTokenSessionToken);
        return retrieveFieldsService.retrieveFields(request, token, authTokenSessionToken);
    }

    private DMIRequest createReturnRelatedRequest(ValidatableRequest inputPayload) {
        DMIRequest request = new DMIRequest();
        Map<String, Object> header = inputPayload.getHeader();
        
        // Set agreed code from first penalty request
        String agreedCd = extractAgreedCodeFromHeader(header);
        request.setAgreedCd(agreedCd);
        String taxAmount = findTaxAmount(inputPayload, agreedCd);
        
        // Set CalcInfo
        CalcInfo calcInfo = createCalcInfoFromHeader(header, taxAmount);
        request.setCalcInfo(calcInfo);
        
        // Set penalty fields from header
        setPenaltyFieldsFromHeader(request, header);
        
        return request;
    }
    
    @SuppressWarnings("unchecked")
    private void setPenaltyFieldsFromHeader(DMIRequest request, Map<String, Object> header) {
        List<Map<String, Object>> penaltyRequests = (List<Map<String, Object>>) header.get("PenaltyRequest");
        if (penaltyRequests != null && !penaltyRequests.isEmpty()) {
            Map<String, Object> firstPenaltyRequest = penaltyRequests.get(0);
            
            // Set PenMain
            List<Map<String, Object>> penMainMapList = (List<Map<String, Object>>) firstPenaltyRequest.get("PenMain");
            List<PenMain> penMainList = penMainMapList.stream()
                .map(map -> {
                    PenMain penMain = new PenMain();
                    penMain.setPenaltySectionCd((String) map.get("penaltySectionCd"));
                    return penMain;
                })
                .collect(Collectors.toList());
            request.setPenMain(penMainList);
            
            // Set Acc_Calc
            List<Map<String, Object>> accCalcMapList = (List<Map<String, Object>>) firstPenaltyRequest.get("Acc_Calc");
            List<AccCalc> accCalcList = accCalcMapList.stream()
                .map(map -> {
                    AccCalc accCalc = new AccCalc();
                    accCalc.setPenaltySectionCd((String) map.get("penaltySectionCd"));
                    accCalc.setPenaltyRt((String) map.get("penaltyRt"));
                    accCalc.setAssessmentAmt((Double) map.get("assessmentAmt"));
                    accCalc.setAssessmentDt((String) map.get("assessmentDt"));
                    accCalc.setPreviouslyAssessedPenaltyAmt((String) map.get("previouslyAssessedPenaltyAmt"));
                    return accCalc;
                })
                .collect(Collectors.toList());
            request.setAcc_Calc(accCalcList);
        }
        
        // Set empty FTP arrays
        request.setFtp_Not(new ArrayList<>());
        request.setFtp_Agreements(new ArrayList<>());
        request.setFtp_Calc(new ArrayList<>());
    }

    @SuppressWarnings("unchecked")
    private DMIRequest createIssueRelatedRequest(ValidatableRequest inputPayload,
            Map<String, Map<String, Map<String, String>>> underPaymentMap,
            Set<String> penaltyTypes) {
        
        DMIRequest request = new DMIRequest();
        Map<String, Object> header = inputPayload.getHeader();
        
        // Set agreed code based on underPaymentMap
        String agreedCd = getAgreedCode(underPaymentMap);
        request.setAgreedCd(agreedCd);
        String taxAmount = findTaxAmount(inputPayload, agreedCd);
        
        // Set CalcInfo
        CalcInfo calcInfo = createCalcInfoFromHeader(header, taxAmount);
        request.setCalcInfo(calcInfo);

        // Get PenaltyRequest based on agreed code
        List<Map<String, Object>> penaltyRequests = (List<Map<String, Object>>) header.get("PenaltyRequest");
        Map<String, Object> penaltyRequest = penaltyRequests.stream()
            .filter(pr -> agreedCd.equals(pr.get("AgreedCd")))
            .findFirst()
            .orElseThrow(() -> new IllegalStateException("No penalty request found for " + agreedCd));

        // Set PenMain from header
        request.setPenMain(getPenMainFromRequest((List<Map<String, Object>>) penaltyRequest.get("PenMain")));

        // Set Acc_Calc with assessment amounts from underPaymentMap
        request.setAcc_Calc(getAccCalcFromRequest(
            (List<Map<String, Object>>) penaltyRequest.get("Acc_Calc"),
            underPaymentMap.get(agreedCd)
        ));

        // Set FTP arrays
        request.setFtp_Not(new ArrayList<>());
        request.setFtp_Agreements(new ArrayList<>());

        // Set FTP_Calc if penalty types contain delinquency penalties
        if (penaltyTypes.stream().anyMatch(DELINQUENCY_PENALTY_TYPES::contains)) {
            List<Map<String, Object>> ftpCalcList = (List<Map<String, Object>>) penaltyRequest.get("FTP_Calc");
            request.setFtp_Calc(getFtpCalcFromRequest(ftpCalcList, taxAmount));
        } else {
            request.setFtp_Calc(new ArrayList<>());
        }
        
        return request;
    }

    private List<PenMain> getPenMainFromRequest(List<Map<String, Object>> penMainList) {
        if (penMainList == null) {
            return new ArrayList<>();
        }

        return penMainList.stream()
            .map((Map<String, Object> map) -> {
                PenMain penMain = new PenMain();
                penMain.setPenaltySectionCd((String) map.get("penaltySectionCd"));
                return penMain;
            })
            .collect(Collectors.toList());
    }

    private List<AccCalc> getAccCalcFromRequest(List<Map<String, Object>> accCalcList, 
            Map<String, Map<String, String>> categoryMap) {
        if (accCalcList == null) {
            return new ArrayList<>();
        }

        return accCalcList.stream()
            .map((Map<String, Object> map) -> {
                AccCalc accCalc = new AccCalc();
                accCalc.setPenaltySectionCd((String) map.get("penaltySectionCd"));
                accCalc.setPenaltyRt((String) map.get("penaltyRt"));
                accCalc.setAssessmentDt((String) map.get("assessmentDt"));
                accCalc.setPreviouslyAssessedPenaltyAmt((String) map.get("previouslyAssessedPenaltyAmt"));
                
                // Set assessment amount from underPaymentMap based on penalty rate
                String rateKey = String.valueOf(accCalc.getPenaltyRt());
                if (categoryMap != null && categoryMap.containsKey(rateKey)) {
                    Map<String, String> rateMap = categoryMap.get(rateKey);
                    if (rateMap != null && rateMap.containsKey("underPayment")) {
                        String underPayment = rateMap.get("underPayment");
                        accCalc.setAssessmentAmt(Double.parseDouble(underPayment));
                    }
                }
                
                return accCalc;
            })
            .collect(Collectors.toList());
    }

    private List<FtpCalc> getFtpCalcFromRequest(List<Map<String, Object>> ftpCalcList, String taxAmount) {
        if (ftpCalcList == null) {
            return new ArrayList<>();
        }

        return ftpCalcList.stream()
            .map((Map<String, Object> map) -> {
            	FtpCalc ftpCalc = new FtpCalc();
                ftpCalc.setPenaltySectionCd((String) map.get("penaltySectionCd"));
                ftpCalc.setInstallAgreeInd((String) map.get("installAgreeInd"));
                ftpCalc.setFraudulentInd((String) map.get("fraudulentInd"));
                ftpCalc.setReturnIncomeInd((String) map.get("returnIncomeInd"));
                ftpCalc.setAssessmentDt((String) map.get("assessmentDt"));
                ftpCalc.setBankruptcyInd((String) map.get("bankruptcyInd"));
                ftpCalc.setPreviouslyAssessedPenaltyAmt((String) map.get("previouslyAssessedPenaltyAmt"));
                
                // Set assessment amount if tax amount is available
                if (taxAmount != null && !taxAmount.isEmpty()) {
                    ftpCalc.setAssessmentAmt(Double.parseDouble(taxAmount));
                }
                
                return ftpCalc;
            })
            .collect(Collectors.toList());
    }

    @SuppressWarnings("unchecked")
    private String findTaxAmount(ValidatableRequest inputPayload, String agreedCd) {
        Map<String, Object> body = inputPayload.getBody();
        List<Map<String, Object>> forms = (List<Map<String, Object>>) body.get("forms");
        
        for (Map<String, Object> form : forms) {
            if (!"IRS1040".equals(form.get("formNum"))) {
                continue;
            }
            
            List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get("lineItems");
            for (Map<String, Object> lineItem : lineItems) {
                if ("/IRS1040/TotalTaxAmt".equals(lineItem.get("lineNameTxt"))) {
                    return "Total".equals(agreedCd) 
                        ? (String) lineItem.get("totalAdjTaxCalcValueTxt")
                        : (String) lineItem.get("agreedAdjTaxCalcValueTxt");
                }
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private String extractAgreedCodeFromHeader(Map<String, Object> header) {
        List<Map<String, Object>> penaltyRequests = (List<Map<String, Object>>) header.get("PenaltyRequest");
        if (penaltyRequests != null && !penaltyRequests.isEmpty()) {
            return (String) penaltyRequests.get(0).get("AgreedCd");
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private CalcInfo createCalcInfoFromHeader(Map<String, Object> header, String taxAmount) {
        Map<String, Object> calcInfoMap = (Map<String, Object>) header.get("CalcInfo");
        CalcInfo calcInfo = new CalcInfo();
        
        String tin = String.valueOf(calcInfoMap.get("tin"));
        if (!tin.contains("-")) {
            tin = tin.replaceFirst("(\\d{3})(\\d{2})(\\d{4})", "$1-$2-$3");
        }
        
        calcInfo.setTin(tin);
        calcInfo.setMftCd(String.valueOf(calcInfoMap.get("mftCd")));
        calcInfo.setTaxYr(String.valueOf(calcInfoMap.get("taxYr")));
        calcInfo.setTaxYr("2014"); //TODO remove it later
        calcInfo.setTaxMonthNum(String.valueOf(calcInfoMap.get("taxMonthNum")));
        calcInfo.setDueDt(String.valueOf(calcInfoMap.get("dueDt")));
        calcInfo.setExtendedDueDt(String.valueOf(calcInfoMap.get("extendedDueDt")));
        calcInfo.setReturnDt(String.valueOf(calcInfoMap.get("returnDt")));
        calcInfo.setReportDt(String.valueOf(calcInfoMap.get("reportDt")));
        calcInfo.setRunToDt(String.valueOf(calcInfoMap.get("runToDt")));
        calcInfo.setTaxDt(String.valueOf(calcInfoMap.get("taxDt")));
        calcInfo.setTaxAmt(taxAmount);
        calcInfo.setTransactionCd(String.valueOf(calcInfoMap.get("transactionCd")));
        calcInfo.setServerTxt(String.valueOf(calcInfoMap.get("serverTxt")));
        calcInfo.setResponseReturnCd(String.valueOf(calcInfoMap.get("responseReturnCd")));
        
        List<Map<String, Object>> penaltyRequests = (List<Map<String, Object>>) header.get("PenaltyRequest");
        if (penaltyRequests != null && !penaltyRequests.isEmpty()) {
            List<String> interestPenaltyCd = (List<String>) penaltyRequests.get(0).get("interestPenaltyCd");
            calcInfo.setInterestPenaltyCd(interestPenaltyCd);
        }
        
        return calcInfo;
    }

    private String getAgreedCode(Map<String, Map<String, Map<String, String>>> underPaymentMap) {
        if (underPaymentMap != null) {
            if (underPaymentMap.containsKey("Total")) {
                return "Total";
            } else if (underPaymentMap.containsKey("Agreed")) {
                return "Agreed";
            }
        }
        return null;
    }

    private void logRequest(DMIRequest request) {
        try {
            String requestJson = objectMapper.writeValueAsString(request);
            log.info("calculatePenaltyAndInterest - Request JSON to DMI: {}", requestJson);
        } catch (JsonProcessingException e) {
            log.error("Error converting DMI Request to JSON", e);
        }
    }

    private JsonNode sendRequest(DMIRequest request) {
        return webClient.post()
                .uri("/PIcalc")
                .bodyValue(request)
                .retrieve()
                .bodyToMono(JsonNode.class)
                .doOnError(error -> log.error("Error calling PI calculation service: ", error))
                .doOnSuccess(response -> log.debug("Successfully received PI calculation response"))
                .blockOptional(Duration.ofSeconds(30))
                .orElseThrow(() -> new RuntimeException("No response received from calculation service"));
    }
    
    @SuppressWarnings("unchecked")
    public String findAgreedTaxableIncomeAmount(ValidatableRequest inputPayload) {
        Map<String, Object> body = inputPayload.getBody();
        List<Map<String, Object>> forms = (List<Map<String, Object>>) body.get("forms");
        
        for (Map<String, Object> form : forms) {
            if (!"IRS1040".equals(form.get("formNum"))) {
                continue;
            }
            
            List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get("lineItems");
            for (Map<String, Object> lineItem : lineItems) {
                String lineNameTxt = (String) lineItem.get("lineNameTxt");
                if ("/IRS1040/TaxableIncomeAmt".equals(lineNameTxt)) {
                    return (String) lineItem.get("agreedAdjTaxCalcValueTxt");
                }
            }
        }
        return "";
    }
    
    @SuppressWarnings("unchecked")
    public String findTotalTaxableIncomeAmount(ValidatableRequest inputPayload) {
        Map<String, Object> body = inputPayload.getBody();
        List<Map<String, Object>> forms = (List<Map<String, Object>>) body.get("forms");
        
        for (Map<String, Object> form : forms) {
            if (!"IRS1040".equals(form.get("formNum"))) {
                continue;
            }
            
            List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get("lineItems");
            for (Map<String, Object> lineItem : lineItems) {
                String lineNameTxt = (String) lineItem.get("lineNameTxt");
                if ("/IRS1040/TaxableIncomeAmt".equals(lineNameTxt)) {
                    return (String) lineItem.get("totalAdjTaxCalcValueTxt");
                }
            }
        }
        return "";
    }
}