package gov.irs.jios.common.client.tr.pojo;

import java.util.List;

import lombok.Data;

@Data
public class RequestMapping {
    private List<FieldMapping> fieldMappings;
}
