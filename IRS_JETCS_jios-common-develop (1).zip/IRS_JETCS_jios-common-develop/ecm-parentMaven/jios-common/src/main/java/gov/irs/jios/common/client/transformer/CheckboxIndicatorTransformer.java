package gov.irs.jios.common.client.transformer;

import java.util.Map;
import lombok.extern.slf4j.Slf4j;
@Slf4j
/**
 * Takes ECM checkbox "X" and returns the specified value.
 * Check the TR UI to see what your indicator should be mapped to.
 * TODO- Consider merging similar checkbox transformers.
 */
public class CheckboxIndicatorTransformer {
	private static final Map<String, Boolean> ECM_TO_TR_MAP = Map.of(
			"TRUE", true,
			"FALSE", false,
			"1", true,
			"0", false,
			"X", true, // Theoretically, only this type should be sent from ECM for the AtRisk fields.
			"", false
	);

	// Currently, transform from TR to ECM is not used for indicators.
	private static final Map<String, String> TR_TO_ECM_MAP = Map.of();

	public static String form1116ForeignTaxesPaidEcmToTr(String ecmIndicatorValue) {
		return getTRCodeBasedOnECM("P", ecmIndicatorValue);
	}
	public static String form1116ForeignTaxesAccruedEcmToTr(String ecmIndicatorValue) {
		return getTRCodeBasedOnECM("A", ecmIndicatorValue);
	}
	public static String form1116ForeignIncmSection951AIndEcmToTr(String ecmIndicatorValue) {
		return getTRCodeBasedOnECM("D", ecmIndicatorValue);
	}
	public static String form1116ForeignBranchIncomeIndEcmToTr(String ecmIndicatorValue) {
		return getTRCodeBasedOnECM("C", ecmIndicatorValue);
	}
	public static String form1116ForeignIncPassiveCategoryIndEcmToTr(String ecmIndicatorValue) {
		return getTRCodeBasedOnECM("A", ecmIndicatorValue);
	}
	public static String form1116ForeignIncGeneralCategoryIndEcmToTr(String ecmIndicatorValue) {
		return getTRCodeBasedOnECM("J", ecmIndicatorValue);
	}
	public static String form1116ForeignIncSection901jIndEcmToTr(String ecmIndicatorValue) {
		return getTRCodeBasedOnECM("H", ecmIndicatorValue);
	}
	public static String form1116ForeignIncResourcedTreatyIndEcmToTr(String ecmIndicatorValue) {
		return getTRCodeBasedOnECM("I", ecmIndicatorValue);
	}
	public static String form1116ForeignIncLumpSumDistribIndEcmToTr(String ecmIndicatorValue) {
		return getTRCodeBasedOnECM("G", ecmIndicatorValue);
	}


	private static String getTRCodeBasedOnECM(String trCode, String ecmIndicatorValue){
		try {
			String trIndicator = null;
			if(ECM_TO_TR_MAP.get(ecmIndicatorValue)) {
				trIndicator = trCode;
			}
			if (trIndicator == null) {
				throw new IllegalArgumentException("Invalid ECM Indicator value: " + ecmIndicatorValue);
			}
			return trIndicator;
		} catch (Exception e){
			log.warn("CheckboxIndicatorTransformer: {}, Thrown from method '{}'", e.getMessage(), e.getStackTrace()[1].getMethodName());
			return "";
		}
	}
}
