package gov.irs.jios.common.client.preprocessor;

import java.util.List;

import org.springframework.stereotype.Component;

import gov.irs.jios.common.client.tr.pojo.FieldMapping;
import gov.irs.jios.common.request.ValidatableRequest;

@Component
public class EcmPreProcessorRegistry {
    private final List<EcmPreProcessor> preProcessors;
    
    public EcmPreProcessorRegistry(List<EcmPreProcessor> preProcessors) {
        this.preProcessors = preProcessors;
    }
    
    public void executePreProcessors(ValidatableRequest request, List<FieldMapping> allMappings) {
        for (EcmPreProcessor processor : preProcessors) {
            processor.preProcess(request, allMappings);
        }
    }
}
