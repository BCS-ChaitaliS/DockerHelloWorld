package gov.irs.jios.common.ecm.pojo;

import java.util.List;

import lombok.Data;

@Data
public class ValidationStatus {
	private boolean isSuccess;
    private String code;
    private String message;
    private List<String> messageVariables;
}
