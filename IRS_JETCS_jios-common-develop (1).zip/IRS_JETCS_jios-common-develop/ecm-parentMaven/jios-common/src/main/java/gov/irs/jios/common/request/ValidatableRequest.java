package gov.irs.jios.common.request;

import java.util.Map;

public interface ValidatableRequest {
	Map<String, Object> getHeader();
	Map<String, Object> getBody();
}
