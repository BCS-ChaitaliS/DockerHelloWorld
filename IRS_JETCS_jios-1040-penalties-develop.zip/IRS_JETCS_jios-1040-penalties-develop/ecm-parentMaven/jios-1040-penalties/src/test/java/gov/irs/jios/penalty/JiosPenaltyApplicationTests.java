package gov.irs.jios.penalty;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JiosPenaltyApplicationTests {

	@Test
	void contextLoads() {
	}

}
