package gov.irs.jios.penalty.utilities;

import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import gov.irs.jios.penalty.model.JiosBody;
import gov.irs.jios.penalty.model.JiosError;
import gov.irs.jios.penalty.model.JiosRequest;
import gov.irs.jios.penalty.model.JiosResponse;
import gov.irs.jios.penalty.model.LineItem;

public class JIOSUtility {

    public static JiosResponse prepareResponse(JiosRequest request) {
        JiosBody body = request.getBody();
        body.setForms(request.getBody().getForms());
        body.setErrors(Arrays.asList(new JiosError()));

        JiosResponse response = new JiosResponse();
        response.setHeader(request.getHeader());
        response.setBody(body);
        response.setHeader(request.getHeader());
        return response;
    }

    public static boolean lineItemIsNumeric(LineItem lineItem) {
        final String regex = "^[0-9.-]*$";
        final Pattern pattern = Pattern.compile(regex);
        String value = lineItem.getLineValueTxt();

        final Matcher valueMatcher = pattern.matcher(value);

        return valueMatcher.matches();
    }
}
