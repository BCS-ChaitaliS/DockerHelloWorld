package gov.irs.jios.penalty.request;

import java.util.Map;

import gov.irs.jios.common.request.ValidatableRequest;
import lombok.Data;

@Data
public class PenaltyCalculationRequest implements ValidatableRequest {
    private Map<String, Object> header = null;
    private Map<String, Object> body = null;
}