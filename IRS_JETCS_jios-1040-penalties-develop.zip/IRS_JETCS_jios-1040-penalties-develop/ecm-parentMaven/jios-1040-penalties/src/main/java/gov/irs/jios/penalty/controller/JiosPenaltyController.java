package gov.irs.jios.penalty.controller;

import static gov.irs.jios.common.util.JiosCommonConstants.CALC_INFO;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A;
//import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_30PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A;
//import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_30PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A;
import static gov.irs.jios.common.util.JiosCommonConstants.CALC_TYPE_TXT;
import static gov.irs.jios.common.util.JiosCommonConstants.EMPTY_STRING;
import static gov.irs.jios.common.util.JiosCommonConstants.PCT_20_PENALTY_TYPES;
//import static gov.irs.jios.common.util.JiosCommonConstants.PCT_30_PENALTY_TYPES;
import static gov.irs.jios.common.util.JiosCommonConstants.PCT_40_PENALTY_TYPES;
import static gov.irs.jios.common.util.JiosCommonConstants.PCT_75_PENALTY_TYPES;
import static gov.irs.jios.common.util.JiosCommonConstants.TAX_MONTH;
import static gov.irs.jios.common.util.JiosCommonConstants.TAX_PERIOD;
import static gov.irs.jios.common.util.JiosCommonConstants.TAX_YEAR;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.irs.jios.common.client.dmi.service.CalculatePenaltyAndInterestService;
import gov.irs.jios.common.client.tr.pojo.PenaltyFlags;
import gov.irs.jios.common.client.tr.pojo.RetrieveFieldsResponseDTO;
import gov.irs.jios.common.client.tr.service.AuthLocatorService;
import gov.irs.jios.common.client.tr.service.OpenSessionService;
import gov.irs.jios.common.client.tr.service.PingTokenService;
import gov.irs.jios.common.client.tr.service.RetrieveFieldsService;
import gov.irs.jios.common.client.tr.service.SaveFieldsService;
import gov.irs.jios.common.exception.ValidationException;
import gov.irs.jios.common.util.CommonUtil;
import gov.irs.jios.common.validation.GenericValidator;
import gov.irs.jios.penalty.request.PenaltyCalculationRequest;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@Tag(name = "Penalty Calculation", description = "Operations related to penalty calculation")
@RequestMapping("/jios-penalties") //TODO /jios-penalties/api/v1.0 - should be property driven or if there is any other better way to handle versioning
public class JiosPenaltyController {

	private final GenericValidator validator;
    
    @Autowired
    private AuthLocatorService authLocatorService;
    
    @Autowired
    private PingTokenService pingTokenService;
    
    @Autowired
    private OpenSessionService openSessionService;
    
    @Autowired
    private SaveFieldsService saveFieldsService;

    @Autowired
    private RetrieveFieldsService retrieveFieldsService;
    
    @Autowired
    private CalculatePenaltyAndInterestService penaltyAndInterestService;
    
    @Value("${mock.penalty.response.path:penalty-calc-response.json}")
    private String mockResponsePath;

    @Autowired
    private ObjectMapper objectMapper;
   
    @Value("${spring.profiles.active}")
	private String activeProfile;
    
    @Value("${should.make.tr.call:true}")
	private boolean shouldMakeTrCall;
    
    private static final String LINE_SEPARATOR = System.lineSeparator();
    
	public JiosPenaltyController() {
		this.validator = new GenericValidator("validation-rules/1040-penalty-validation-rules.json");
	}
    
    @PostMapping("/api/v1.0/penaltyCalculation")
    public ResponseEntity<?> penaltyCalculation(@RequestBody PenaltyCalculationRequest request) {
        log.debug("Received Penalty Calculation Request");

        HttpHeaders headers = new HttpHeaders();         
        headers.setContentType(MediaType.APPLICATION_JSON);

        try {
            if (request == null) {
            	log.warn("Invalid request");
                return ResponseEntity.badRequest().body("Invalid request");
            }
    
            log.info("Active Profile: {}", activeProfile);
            /*List<String> validationErrors = validator.validate(request);
            if (!validationErrors.isEmpty()) {
                log.warn("Validation errors: {}", validationErrors);
                return ResponseEntity.badRequest().body(validationErrors); //TODO - enable validation back after it is refactored for the latest ECM payload
            }*/
            
            computeTaxPrd(request);
            PenaltyFlags flags = analyzePenaltyRequest(request);

            // Log the ECM request payload
            try {
                String requestJson = objectMapper.writeValueAsString(request);
                log.info("saveFields - Request JSON from ECM: {}{}", LINE_SEPARATOR, requestJson);
            } catch (JsonProcessingException e) {
                log.error("Error converting ECM Penalty Calculation Request payload to JSON", e);
            }
            
            if (flags.isReturnRelated) {
                log.info("Processing return related penalty calculation");
                JsonNode response = penaltyAndInterestService.calculatePenaltyAndInterest(request, null, null);
                return createSuccessResponse(response);
            }

            if (flags.isIssueRelated) {
                Map<String, Map<String, String>> responseMap = new HashMap<>();
                Set<String> penaltyTypes = processIssueRelatedPenalty(request, responseMap, flags);
                
                Map<String, String> resultMap = calculatePenaltyValues(responseMap);
                JsonNode response = penaltyAndInterestService.calculatePenaltyAndInterest(request, resultMap, penaltyTypes);
                return createSuccessResponse(response);
            }
        }
        catch (ValidationException e) {
            log.error("ValidationException occurred during Penalty Calculation", e);
            return new ResponseEntity<>(e.getMessage(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        catch (Exception e) {
            log.error("Exception occurred during Penalty Calculation", e);
            return new ResponseEntity<>("An unexpected error occurred: " + e.getMessage(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        
        return new ResponseEntity<>("Empty Response", headers, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    
    private PenaltyFlags analyzePenaltyRequest(PenaltyCalculationRequest request) {
        PenaltyFlags flags = new PenaltyFlags();
        
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> penaltyRequests = (List<Map<String, Object>>) 
            request.getHeader().get("PenaltyRequest");

        if (penaltyRequests == null || penaltyRequests.isEmpty()) {
            throw new IllegalArgumentException("No PenaltyRequest found in header");
        }

        for (Map<String, Object> penaltyRequest : penaltyRequests) {
            String agreedCd = (String) penaltyRequest.get("AgreedCd");
            
            // Set agreement flags
            switch (agreedCd) {
                case "Agreed":
                    flags.setAgreed(true);
                    break;
                case "Total":
                    flags.setTotal(true);
                    break;
            }

            // Collect and compare penalty codes
            @SuppressWarnings("unchecked")
            List<String> interestPenaltyCodes = (List<String>) penaltyRequest.get("interestPenaltyCd");
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> penMainPenaltyCodes = (List<Map<String, Object>>) penaltyRequest.get("PenMain");

            Set<String> extractedPenaltySectionCodes = extractPenaltySectionCodes(penMainPenaltyCodes);
            Set<String> extractedInterestPenaltyCodes = extractInterestPenaltyCodes(interestPenaltyCodes);

            if (extractedPenaltySectionCodes.equals(extractedInterestPenaltyCodes)) {
                flags.setReturnRelated(true);
            } else {
                flags.setIssueRelated(true);
            }
        }

        log.info("Analyzed penalty request - ReturnRelated: {}, IssueRelated: {}, Agreed: {}, Total: {}", 
                flags.isReturnRelated, flags.isIssueRelated, flags.isAgreed, flags.isTotal);
        
        return flags;
    }
    
    private Set<String> extractPenaltySectionCodes(List<Map<String, Object>> penMain) {
        return penMain.stream()
            .map(item -> (String) item.get("penaltySectionCd"))
            .collect(Collectors.toSet());
    }

    private Set<String> extractInterestPenaltyCodes(List<String> codes) {
        return codes.stream()
            .filter(code -> !"interest".equals(code))
            .collect(Collectors.toSet());
    }
    
    private Set<String> processIssueRelatedPenalty(PenaltyCalculationRequest request, 
    		Map<String, Map<String, String>> responseMap, PenaltyFlags flags) throws Exception {
        
        String token = null;
        Map<String, String> authTokenSessionToken = null;
        if (shouldMakeTrCall) {
            token = "local".equals(activeProfile) ? authLocatorService.getToken() : pingTokenService.getAccessToken();
            log.info("token: {}", token);
            
            String locatorId = authLocatorService.createLocator(request.getHeader(), token);
            log.info("locatorId: {}", locatorId);
            
            authTokenSessionToken = openSessionService.openSession(request.getHeader(), token, locatorId);
            log.info("authTokenSessionToken: {}", authTokenSessionToken);
        }
        
        // Collect penalty types from line items
        Set<String> penaltyTypes = new HashSet<>();
        collectPenaltyTypesFromBody(request.getBody(), penaltyTypes);
        log.info("Collected penalty types from line items: {}", penaltyTypes);
        
        if (flags.isAgreed) {
            // Step 3: Process agreed underpayment calculations excluding 6662A
        	RetrieveFieldsResponseDTO response = processCalculationStep(request, token, authTokenSessionToken,
                CALC_TYPE_PENALTY_AGR_UNDRPYMNT_EXCL_6662A);
            populateResponseMap(response, responseMap, CALC_TYPE_PENALTY_AGR_UNDRPYMNT_EXCL_6662A);
        } 
        if (flags.isTotal) {
            // Step 4: Process total underpayment calculations excluding 6662A
        	RetrieveFieldsResponseDTO response = processCalculationStep(request, token, authTokenSessionToken,
                CALC_TYPE_PENALTY_TOT_UNDRPYMNT_EXCL_6662A);
            populateResponseMap(response, responseMap, CALC_TYPE_PENALTY_TOT_UNDRPYMNT_EXCL_6662A);
        }

        if (penaltyTypes.contains("")) {
            if (flags.isAgreed) {
                // Step 5: Process agreed underpayment subject to no penalty excluding 6662A
            	RetrieveFieldsResponseDTO response = processCalculationStep(request, token, authTokenSessionToken,
                    CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A);
            	populateResponseMap(response, responseMap, CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A);
            } 
            if (flags.isTotal) {
                // Step 6: Process total underpayment subject to no penalty excluding 6662A
            	RetrieveFieldsResponseDTO response = processCalculationStep(request, token, authTokenSessionToken,
                    CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A);
            	populateResponseMap(response, responseMap, CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A);
            }
        }
        
        if (hasPct20PenaltyType(penaltyTypes)) {
            if (flags.isAgreed) {
                // Step 7: Process agreed underpayment subject to 20% penalty excluding 6662A
            	RetrieveFieldsResponseDTO response = processCalculationStep(request, token, authTokenSessionToken,
                    CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A);
                populateResponseMap(response, responseMap, CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A);
            } 
            if (flags.isTotal) {
                // Step 8: Process total underpayment subject to 20% penalty excluding 6662A
            	RetrieveFieldsResponseDTO response = processCalculationStep(request, token, authTokenSessionToken,
                    CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A);
                populateResponseMap(response, responseMap, CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A);
            }
        }
        
        /*if (hasPct30PenaltyType(penaltyTypes)) {
            if (flags.isAgreed) {
                // Step 9: Process agreed underpayment subject to 30% penalty excluding 6662A
            	RetrieveFieldsResponseDTO response = processCalculationStep(request, token, authTokenSessionToken,
                    CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_30PCT_EXCL_6662A);
                populateResponseMap(response, responseMap, CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_30PCT_EXCL_6662A);
            } 
            if (flags.isTotal) {
                // Step 10: Process total underpayment subject to 30% penalty excluding 6662A
            	RetrieveFieldsResponseDTO response = processCalculationStep(request, token, authTokenSessionToken,
                    CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_30PCT_EXCL_6662A);
                populateResponseMap(response, responseMap, CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_30PCT_EXCL_6662A);
            }
        }*/
        
        if (hasPct40PenaltyType(penaltyTypes)) {
            if (flags.isAgreed) {
                // Step 11: Process agreed underpayment subject to 40% penalty excluding 6662A
            	RetrieveFieldsResponseDTO response = processCalculationStep(request, token, authTokenSessionToken,
                    CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A);
                populateResponseMap(response, responseMap, CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A);
            } 
            if (flags.isTotal) {
                // Step 12: Process total underpayment subject to 40% penalty excluding 6662A
            	RetrieveFieldsResponseDTO response = processCalculationStep(request, token, authTokenSessionToken,
                    CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A);
                populateResponseMap(response, responseMap, CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A);
            }
        }
        
        if (hasPct75PenaltyType(penaltyTypes)) {
            if (flags.isAgreed) {
                // Step 13: Process agreed underpayment subject to 75% penalty excluding 6662A
            	RetrieveFieldsResponseDTO response = processCalculationStep(request, token, authTokenSessionToken,
                    CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A);
                populateResponseMap(response, responseMap, CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A);
            } 
            if (flags.isTotal) {
                // Step 14: Process total underpayment subject to 75% penalty excluding 6662A
            	RetrieveFieldsResponseDTO response = processCalculationStep(request, token, authTokenSessionToken,
                    CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A);
                populateResponseMap(response, responseMap, CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A);
            }
        }

        return penaltyTypes;
    }
    
    @SuppressWarnings("unchecked")
    private void collectPenaltyTypesFromBody(Map<String, Object> body, Set<String> penaltyTypes) {
        List<Map<String, Object>> forms = (List<Map<String, Object>>) body.get("forms");
        if (forms != null) {
            for (Map<String, Object> form : forms) {
                List<Map<String, Object>> lineItems = (List<Map<String, Object>>) form.get("lineItems");
                if (lineItems != null) {
                    collectPenaltyTypesFromLineItems(lineItems, penaltyTypes);
                }
            }
        }
    }

    private void collectPenaltyTypesFromLineItems(List<Map<String, Object>> lineItems, Set<String> penaltyTypes) {
        for (Map<String, Object> lineItem : lineItems) {
            String penaltyType = (String) lineItem.get("issuePenaltyTypeTxt");
            if (penaltyType != null) {
                penaltyTypes.add(penaltyType);
            }
            
            // Recursively check nested line items
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> nestedLineItems = (List<Map<String, Object>>) lineItem.get("lineItems");
            if (nestedLineItems != null) {
                collectPenaltyTypesFromLineItems(nestedLineItems, penaltyTypes);
            }
        }
    }
    
    private Map<String, String> calculatePenaltyValues(Map<String, Map<String, String>> responseMap) {
        Map<String, String> resultMap = new HashMap<>();
        try {
            // Underpayment Subject to No Penalty for Agreed
            Map<String, String> subMap = responseMap.get(CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A);
            if (subMap != null) {
                String agreedNoPenalty = subMap.get("FED.CREDLTAX");
                resultMap.put("UnderpaymentSubjectToNoPenaltyForAgreed", agreedNoPenalty);
            }

            // Underpayment Subject to No Penalty for Total
            subMap = responseMap.get(CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A);
            if (subMap != null) {
                String totalNoPenalty = subMap.get("FED.CREDLTAX");
                resultMap.put("UnderpaymentSubjectToNoPenaltyForTotal", totalNoPenalty);
            }

            // Underpayment Subject to 20% Penalty calculations
            calculate20PctPenalties(responseMap, resultMap);

            // Underpayment Subject to 40% Penalty calculations
            calculate40PctPenalties(responseMap, resultMap);

            // Underpayment Subject to 75% Penalty calculations
            calculate75PctPenalties(responseMap, resultMap);

            return resultMap;
        } catch (Exception e) {
            log.error("Error calculating penalty values: {}", e.getMessage());
            throw new RuntimeException("Error calculating penalty values", e);
        }
    }

    private void calculate20PctPenalties(Map<String, Map<String, String>> responseMap, Map<String, String> resultMap) {
        // For Agreed
        Map<String, String> noPenaltyMap = responseMap.get(CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A);
        Map<String, String> pct20Map = responseMap.get(CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A);
        
        if (pct20Map != null) {
	        String noPenaltyValue = "0";
	        if (noPenaltyMap != null && noPenaltyMap.get("FED.CREDLTAX") != null) {
	        	noPenaltyValue = noPenaltyMap.get("FED.CREDLTAX");
	        	if (noPenaltyValue.isEmpty()) {
	        		noPenaltyValue = "0";
	        	}
	        }
	        String pct20Value = "0";
	        if (pct20Map != null && pct20Map.get("FED.CREDLTAX") != null) {
	        	pct20Value = pct20Map.get("FED.CREDLTAX");
	        	if (pct20Value.isEmpty()) {
	        		pct20Value = "0";
	        	}
	        }
	        
	        BigDecimal difference = new BigDecimal(pct20Value).subtract(new BigDecimal(noPenaltyValue));
	        resultMap.put("UnderpaymentSubjectTo20PctPenaltyForAgreed", difference.toString());
        }

        // For Total
        noPenaltyMap = responseMap.get(CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_NO_PNLTY_EXCL_6662A);
        pct20Map = responseMap.get(CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A);
        
        if (pct20Map != null) {
	        String noPenaltyValue = "0";
	        if (noPenaltyMap != null && noPenaltyMap.get("FED.CREDLTAX") != null) {
	        	noPenaltyValue = noPenaltyMap.get("FED.CREDLTAX");
	        	if (noPenaltyValue.isEmpty()) {
	        		noPenaltyValue = "0";
	        	}
	        }
	        String pct20Value = "0";
	        if (pct20Map != null && pct20Map.get("FED.CREDLTAX") != null) {
	        	pct20Value = pct20Map.get("FED.CREDLTAX");
	        	if (pct20Value.isEmpty()) {
	        		pct20Value = "0";
	        	}
	        }
	        
        	BigDecimal difference = new BigDecimal(pct20Value).subtract(new BigDecimal(noPenaltyValue));
            resultMap.put("UnderpaymentSubjectTo20PctPenaltyForTotal", difference.toString());
        }
    }

    private void calculate40PctPenalties(Map<String, Map<String, String>> responseMap, Map<String, String> resultMap) {
        // For Agreed
        Map<String, String> pct20Map = responseMap.get(CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A);
        Map<String, String> pct40Map = responseMap.get(CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A);
        
        if (pct40Map != null) {
	        String pct20Value = "0";
	        if (pct20Map != null && pct20Map.get("FED.CREDLTAX") != null) {
	        	pct20Value = pct20Map.get("FED.CREDLTAX");
	        	if (pct20Value.isEmpty()) {
	        		pct20Value = "0";
	        	}
	        }
	        String pct40Value = "0";
	        if (pct40Map != null && pct40Map.get("FED.CREDLTAX") != null) {
	        	pct40Value = pct40Map.get("FED.CREDLTAX");
	        	if (pct40Value.isEmpty()) {
	        		pct40Value = "0";
	        	}
	        }
        	 BigDecimal difference = new BigDecimal(pct40Value).subtract(new BigDecimal(pct20Value));
             resultMap.put("UnderpaymentSubjectTo40PctPenaltyForAgreed", difference.toString());
        }

        // For Total
        pct20Map = responseMap.get(CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_20PCT_EXCL_6662A);
        pct40Map = responseMap.get(CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A);
        
        if (pct40Map != null) {
	        String pct20Value = "0";
	        if (pct20Map != null && pct20Map.get("FED.CREDLTAX") != null) {
	        	pct20Value = pct20Map.get("FED.CREDLTAX");
	        	if (pct20Value.isEmpty()) {
	        		pct20Value = "0";
	        	}
	        }
	        String pct40Value = "0";
	        if (pct40Map != null && pct40Map.get("FED.CREDLTAX") != null) {
	        	pct40Value = pct40Map.get("FED.CREDLTAX");
	        	if (pct40Value.isEmpty()) {
	        		pct40Value = "0";
	        	}
	        }
        	BigDecimal difference = new BigDecimal(pct40Value).subtract(new BigDecimal(pct20Value));
            resultMap.put("UnderpaymentSubjectTo40PctPenaltyForTotal", difference.toString());
        }
    }

    private void calculate75PctPenalties(Map<String, Map<String, String>> responseMap, Map<String, String> resultMap) {
        // For Agreed
        Map<String, String> pct40Map = responseMap.get(CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A);
        Map<String, String> pct75Map = responseMap.get(CALC_TYPE_PENALTY_AGR_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A);
        
        if (pct75Map != null) {
	        String pct40Value = "0";
	        if (pct40Map != null && pct40Map.get("FED.CREDLTAX") != null) {
	        	pct40Value = pct40Map.get("FED.CREDLTAX");
	        	if (pct40Value.isEmpty()) {
	        		pct40Value = "0";
	        	}
	        }
	        String pct75Value = "0";
	        if (pct75Map != null && pct75Map.get("FED.CREDLTAX") != null) {
	        	pct75Value = pct75Map.get("FED.CREDLTAX");
	        	if (pct75Value.isEmpty()) {
	        		pct75Value = "0";
	        	}
	        }
        	BigDecimal difference = new BigDecimal(pct75Value).subtract(new BigDecimal(pct40Value));
            resultMap.put("UnderpaymentSubjectTo75PctPenaltyForAgreed", difference.toString());
        }

        // For Total
        pct40Map = responseMap.get(CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_40PCT_EXCL_6662A);
        pct75Map = responseMap.get(CALC_TYPE_PENALTY_TOT_UNDRPYMNT_SUBJ_75PCT_EXCL_6662A);
        
        if (pct75Map != null) {
	        String pct40Value = "0";
	        if (pct40Map != null && pct40Map.get("FED.CREDLTAX") != null) {
	        	pct40Value = pct40Map.get("FED.CREDLTAX");
	        	if (pct40Value.isEmpty()) {
	        		pct40Value = "0";
	        	}
	        }
	        String pct75Value = "0";
	        if (pct75Map != null && pct75Map.get("FED.CREDLTAX") != null) {
	        	pct75Value = pct75Map.get("FED.CREDLTAX");
	        	if (pct75Value.isEmpty()) {
	        		pct75Value = "0";
	        	}
	        }
        	BigDecimal difference = new BigDecimal(pct75Value).subtract(new BigDecimal(pct40Value));
            resultMap.put("UnderpaymentSubjectTo75PctPenaltyForTotal", difference.toString());
        }
    }
    
    private boolean hasPct20PenaltyType(Set<String> penaltyTypes) {
        return penaltyTypes.stream().anyMatch(PCT_20_PENALTY_TYPES::contains);
    }
    
    /*private boolean hasPct30PenaltyType(Set<String> penaltyTypes) {
        return penaltyTypes.stream().anyMatch(PCT_30_PENALTY_TYPES::contains);
    }*/
    
    private boolean hasPct40PenaltyType(Set<String> penaltyTypes) {
        return penaltyTypes.stream().anyMatch(PCT_40_PENALTY_TYPES::contains);
    }
    
    private boolean hasPct75PenaltyType(Set<String> penaltyTypes) {
        return penaltyTypes.stream().anyMatch(PCT_75_PENALTY_TYPES::contains);
    }
    
    private RetrieveFieldsResponseDTO processCalculationStep(PenaltyCalculationRequest request, 
            String token, Map<String, String> authTokenSessionToken, String calcType) {
    	
    	Map<String, Object> headerMap = request.getHeader();
    	headerMap.put(CALC_TYPE_TXT, calcType);
        saveFieldsService.saveFields(request, token, authTokenSessionToken);
        return retrieveFieldsService.retrieveFields(request, token, authTokenSessionToken);
    }
    
    private ResponseEntity<JsonNode> createSuccessResponse(JsonNode response) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return new ResponseEntity<>(response, headers, HttpStatus.OK);
    }
    
    private void computeTaxPrd(PenaltyCalculationRequest request) {
        Map<String, Object> header = request.getHeader();
        @SuppressWarnings("unchecked")
        Map<String, Object> calcInfo = (Map<String, Object>) header.get(CALC_INFO);
        
        if (calcInfo != null) {
            String taxYr = (String) calcInfo.get(TAX_YEAR);
            String taxMonthNum = (String) calcInfo.get(TAX_MONTH);
            
            if (taxYr != null && taxMonthNum != null) {
                String taxPrd = taxYr + taxMonthNum;
                header.put(TAX_PERIOD, taxPrd);
                log.info("Added {}: {} to header", TAX_PERIOD, taxPrd);
            } else {
                log.warn("Unable to create {}: {} or {} is missing in {}", TAX_PERIOD, TAX_YEAR, TAX_MONTH, CALC_INFO);
            }
        } else {
            log.warn("{} is missing in the header", CALC_INFO);
        }
    }
    
    private String getFieldValue(String jsonString, String targetFieldId) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode rootNode = objectMapper.readTree(jsonString);
            
            // Navigate to the fields array
            JsonNode fieldsResponseArray = rootNode.get("fieldsResponse");
            if (fieldsResponseArray != null && fieldsResponseArray.isArray()) {
                for (JsonNode responseNode : fieldsResponseArray) {
                    JsonNode fieldsNode = responseNode.get("fields");
                    if (fieldsNode != null && fieldsNode.isArray()) {
                        for (JsonNode fieldNode : fieldsNode) {
                            String fieldId = fieldNode.get("fieldId").asText();
                            if (targetFieldId.equals(fieldId)) {
                                return fieldNode.get("value").asText();
                            }
                        }
                    }
                }
            }
            
            log.debug("Field {} not found in response", targetFieldId);
            return null;
            
        } catch (JsonProcessingException e) {
            log.error("Error parsing JSON string: {}", e.getMessage());
            throw new RuntimeException("Error parsing JSON string", e);
        }
    }
    
    private void populateResponseMap(RetrieveFieldsResponseDTO response, 
    		Map<String, Map<String, String>> responseMap, String calcType) {
    	String totalTaxAmt = getFieldValue(response.getJsonResponse(), "FED.CREDLTAX");
    	totalTaxAmt = cleanTrValue(totalTaxAmt);
    	Map<String, String> responseSubMap = new HashMap<>();
    	responseSubMap.put("FED.CREDLTAX", totalTaxAmt);
    	responseMap.put(calcType, responseSubMap);
    }
    
    private String cleanTrValue(String trValue) {
	    if (trValue == null) {
	        return null;
	    }
	    if (trValue.trim().equals("NONE")) {
	        return "0";
	    }
	    if (trValue.trim().isEmpty()) {
	        return "0";
	    }
	    // Remove trailing spaces, commas, and period
	    String cleaned = trValue.trim().replaceAll("[,\\s]+$", EMPTY_STRING).replaceAll("\\.$", EMPTY_STRING);
	    // Remove commas from the middle of the string (for proper numeric parsing)
	    cleaned = cleaned.replace(",", EMPTY_STRING);
	    log.debug("Cleaned TR value from '{}' to '{}'", trValue, cleaned);
	    return cleaned;
	}
}