package gov.irs.jios.penalty.config;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;

@OpenAPIDefinition(
		info = @Info(
				title = "ETCS Form1040 Rest APIs",
				description = "Enterprise Penalties Calculation Service for Form1040", 
				version = "v1.0.0", 
				contact = @Contact(name = "ETCS Team", url = "need.valid.url.gov.irs.etcs", email = "etcs@irsgov.com")),

		servers = @Server(description = "dev", url = "http://localhost:8080")
)

public class SwaggerConfig {
	
}
