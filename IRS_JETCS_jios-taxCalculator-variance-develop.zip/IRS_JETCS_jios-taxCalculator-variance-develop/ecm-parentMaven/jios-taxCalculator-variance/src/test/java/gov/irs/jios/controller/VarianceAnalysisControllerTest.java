package gov.irs.jios.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.irs.jios.common.client.tr.pojo.RetrieveFieldsResponseDTO;
import gov.irs.jios.common.client.tr.service.AuthLocatorService;
import gov.irs.jios.common.client.tr.service.OpenSessionService;
import gov.irs.jios.common.client.tr.service.PingTokenService;
import gov.irs.jios.common.client.tr.service.RetrieveFieldsService;
import gov.irs.jios.common.client.tr.service.SaveFieldsService;
import gov.irs.jios.common.exception.ValidationException;
import gov.irs.jios.request.TaxCalculationRequest;
import gov.irs.jios.request.VarianceAnalysisRequest;

@ExtendWith(MockitoExtension.class)
class VarianceAnalysisControllerTest {

    @Mock
    private AuthLocatorService authLocatorService;
    
    @Mock
    private PingTokenService pingTokenService;
    
    @Mock
    private OpenSessionService openSessionService;
    
    @Mock
    private SaveFieldsService saveFieldsService;
    
    @Mock
    private RetrieveFieldsService retrieveFieldsService;
    
    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private VarianceAnalysisController controller;

    private VarianceAnalysisRequest validVarianceRequest;
    private TaxCalculationRequest validTaxRequest;
    private RetrieveFieldsResponseDTO mockResponse;
    private Map<String, String> mockAuthTokens;

    @BeforeEach
    void setUp() {
        // Set up properties using ReflectionTestUtils
        ReflectionTestUtils.setField(controller, "activeProfile", "local");
        ReflectionTestUtils.setField(controller, "shouldMakeTrCall", true);

        // Initialize test data
        validVarianceRequest = new VarianceAnalysisRequest();
        Map<String, Object> header = new HashMap<>();
        header.put("transactionId", "test-123-456");
        validVarianceRequest.setHeader(header);

        validTaxRequest = new TaxCalculationRequest();
        validTaxRequest.setHeader(new HashMap<>(header));
        validTaxRequest.setBody(new HashMap<>());

        mockResponse = new RetrieveFieldsResponseDTO();
        mockResponse.setJsonResponse("{\"test\":\"response\"}");

        mockAuthTokens = new HashMap<>();
        mockAuthTokens.put("authToken", "testAuthToken");
        mockAuthTokens.put("sessionToken", "testSessionToken");
    }

    @Test
    void varianceAnalysis_WithValidRequest_ReturnsSuccess() throws Exception {
        // Arrange
        when(authLocatorService.getToken()).thenReturn("testToken");
        when(authLocatorService.createLocator(any(), any())).thenReturn("testLocator");
        when(openSessionService.openSession(any(), any(), any())).thenReturn(mockAuthTokens);
        when(retrieveFieldsService.retrieveFields(any(), any(), any())).thenReturn(mockResponse);
        doNothing().when(saveFieldsService).saveFields(any(), any(), any());

        // Act
        ResponseEntity<?> response = controller.varianceAnalysis(validVarianceRequest);

        // Assert
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(mockResponse.getJsonResponse(), response.getBody());
        
        // Verify service calls
        verify(authLocatorService).getToken();
        verify(authLocatorService).createLocator(any(), any());
        verify(openSessionService).openSession(any(), any(), any());
        verify(saveFieldsService).saveFields(any(), any(), any());
        verify(retrieveFieldsService).retrieveFields(any(), any(), any());
    }

    @Test
    void varianceAnalysis_WithNullRequest_ReturnsBadRequest() {
        // Act
        ResponseEntity<?> response = controller.varianceAnalysis(null);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Request body is missing", response.getBody());
    }

    @Test
    void varianceAnalysis_WithNullHeader_ReturnsBadRequest() {
        // Arrange
        VarianceAnalysisRequest request = new VarianceAnalysisRequest();

        // Act
        ResponseEntity<?> response = controller.varianceAnalysis(request);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Header object is missing in the request", response.getBody());
    }

    @Test
    void taxCalculation_WithValidRequest_ReturnsSuccess() throws Exception {
        // Arrange
        when(authLocatorService.getToken()).thenReturn("testToken");
        when(authLocatorService.createLocator(any(), any())).thenReturn("testLocator");
        when(openSessionService.openSession(any(), any(), any())).thenReturn(mockAuthTokens);
        when(retrieveFieldsService.retrieveFields(any(), any(), any())).thenReturn(mockResponse);
        doNothing().when(saveFieldsService).saveFields(any(), any(), any());

        // Act
        ResponseEntity<?> response = controller.taxCalculation(validTaxRequest);

        // Assert
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(mockResponse.getJsonResponse(), response.getBody());
    }

    @Test
    void taxCalculation_WithPartialCalcType_MakesSecondCall() throws Exception {
        // Arrange
        validTaxRequest.getHeader().put("calcTypeTxt", "Partial");
        Map<String, Object> forms = new HashMap<>();
        forms.put("testForm", "testData");
        
        RetrieveFieldsResponseDTO firstResponse = new RetrieveFieldsResponseDTO();
        Map<String, Object> structuredResponse = new HashMap<>();
        structuredResponse.put("forms", forms);
        firstResponse.setStructuredResponse(structuredResponse);
        
        when(authLocatorService.getToken()).thenReturn("testToken");
        when(authLocatorService.createLocator(any(), any())).thenReturn("testLocator");
        when(openSessionService.openSession(any(), any(), any())).thenReturn(mockAuthTokens);
        when(retrieveFieldsService.retrieveFields(any(), any(), any()))
            .thenReturn(firstResponse)
            .thenReturn(mockResponse);
        doNothing().when(saveFieldsService).saveFields(any(), any(), any());

        // Act
        ResponseEntity<?> response = controller.taxCalculation(validTaxRequest);

        // Assert
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(saveFieldsService, times(2)).saveFields(any(), any(), any());
        verify(retrieveFieldsService, times(2)).retrieveFields(any(), any(), any());
    }

    @Test
    void taxCalculation_WithValidationException_ReturnsError() throws Exception {
        // Arrange
        when(authLocatorService.getToken()).thenReturn("testToken");
        doThrow(new ValidationException("Validation failed"))
            .when(saveFieldsService)
            .saveFields(any(), any(), any());

        // Act
        ResponseEntity<?> response = controller.taxCalculation(validTaxRequest);

        // Assert
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertTrue(((String) response.getBody()).contains("Validation failed"));
    }

    @Test
    void taxCalculation_WithGeneralException_ReturnsError() throws Exception {
        // Arrange
        when(authLocatorService.getToken()).thenReturn("testToken");
        doThrow(new RuntimeException("Unexpected error"))
            .when(saveFieldsService)
            .saveFields(any(), any(), any());

        // Act
        ResponseEntity<?> response = controller.taxCalculation(validTaxRequest);

        // Assert
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertTrue(((String) response.getBody()).contains("Unexpected error"));
    }
}