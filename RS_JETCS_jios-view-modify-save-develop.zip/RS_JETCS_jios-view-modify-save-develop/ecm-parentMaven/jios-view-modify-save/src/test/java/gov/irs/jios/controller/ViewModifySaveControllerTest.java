package gov.irs.jios.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.irs.jios.common.client.tr.pojo.RetrieveFieldsResponseDTO;
import gov.irs.jios.common.client.tr.service.AuthLocatorService;
import gov.irs.jios.common.client.tr.service.DownloadSnapshotService;
import gov.irs.jios.common.client.tr.service.OpenSessionService;
import gov.irs.jios.common.client.tr.service.OpenSnapshotService;
import gov.irs.jios.common.client.tr.service.PingTokenService;
import gov.irs.jios.common.client.tr.service.RetrieveFieldsService;
import gov.irs.jios.common.client.tr.service.SaveFieldsService;
import gov.irs.jios.request.SaveFieldsRequest;

@ExtendWith(MockitoExtension.class)
class ViewModifySaveControllerTest {

    @Mock
    private AuthLocatorService authLocatorService;
    
    @Mock
    private PingTokenService pingTokenService;
    
    @Mock
    private OpenSessionService openSessionService;
    
    @Mock
    private SaveFieldsService saveFieldsService;
    
    @Mock
    private RetrieveFieldsService retrieveFieldsService;
    
    @Mock
    private OpenSnapshotService openSnapshotService;
    
    @Mock
    private DownloadSnapshotService downloadSnapshotService;
    
    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private ViewModifySaveController controller;

    private SaveFieldsRequest saveFieldsRequest;
    private RetrieveFieldsResponseDTO mockResponse;
    private Map<String, String> mockAuthTokens;

    @BeforeEach
    void setUp() {
        // Set up properties using ReflectionTestUtils
        ReflectionTestUtils.setField(controller, "activeProfile", "local");
        ReflectionTestUtils.setField(controller, "shouldMakeTrCall", true);

        // Initialize test data
        saveFieldsRequest = new SaveFieldsRequest();
        Map<String, Object> header = new HashMap<>();
        header.put("transactionId", "test-123-456");
        header.put("locatorId", "ABCDEF");
        saveFieldsRequest.setHeader(header);

        mockResponse = new RetrieveFieldsResponseDTO();
        mockResponse.setJsonResponse("{\"test\":\"response\"}");

        mockAuthTokens = new HashMap<>();
        mockAuthTokens.put("authToken", "testAuthToken");
        mockAuthTokens.put("sessionToken", "testSessionToken");
    }

    @Test
    void openSnapshot_WithNullRequest_ReturnsBadRequest() {
        // Act
        ResponseEntity<?> response = controller.openSnapshot(null, null);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Request body is missing", response.getBody());
    }

    @Test
    void openSnapshot_WithNullHeader_ReturnsBadRequest() {
        // Arrange
        SaveFieldsRequest request = new SaveFieldsRequest();

        // Act
        ResponseEntity<?> response = controller.openSnapshot(request, null);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Header object is missing in the request", response.getBody());
    }
    
    @Test
    void downloadSnapshot_WithNullRequest_ReturnsBadRequest() {
        // Act
        ResponseEntity<?> response = controller.downloadSnapshot(null);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Request body is missing", response.getBody());
    }

    @Test
    void downloadSnapshot_WithNullHeader_ReturnsBadRequest() {
        // Arrange
        SaveFieldsRequest request = new SaveFieldsRequest();

        // Act
        ResponseEntity<?> response = controller.downloadSnapshot(request);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Header object is missing in the request", response.getBody());
    }
    
    @Test
    void downloadSnapshot_WithNoLocatorIdHeader_ReturnsBadRequest() {
        // Arrange
        SaveFieldsRequest request = new SaveFieldsRequest();
        Map<String, Object> header = new HashMap<>();
        header.put("transactionId", "test-123-456");
        request.setHeader(header);
        // Act
        ResponseEntity<?> response = controller.downloadSnapshot(request);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("LocatorId is missing in the header", response.getBody());
    }

}