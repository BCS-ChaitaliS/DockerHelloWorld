package gov.irs.jios.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@Tag(name = "Save Fields", description = "TR Mock Controller")
@RequestMapping("/jios-tr-mock")
public class TRMockController {
    
    @Autowired
    private ResourceLoader resourceLoader;
   
    @GetMapping("/api/v1.0/download")
    public ResponseEntity<?> downloadFile() {
        Resource resource = resourceLoader.getResource("classpath:TaxReturnApi-OpenApi-V6.zip");

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"TaxReturnApi-OpenApi-V6.zip\"")
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(resource);
    }

}