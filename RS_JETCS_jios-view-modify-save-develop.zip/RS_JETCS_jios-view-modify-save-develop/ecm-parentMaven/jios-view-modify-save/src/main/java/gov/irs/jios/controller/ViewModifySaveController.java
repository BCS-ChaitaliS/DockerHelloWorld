package gov.irs.jios.controller;

import static gov.irs.jios.common.util.JiosCommonConstants.TAX_PERIOD;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.irs.jios.common.client.tr.pojo.RetrieveFieldsResponseDTO;
import gov.irs.jios.common.client.tr.service.AuthLocatorService;
import gov.irs.jios.common.client.tr.service.CloseLocatorService;
import gov.irs.jios.common.client.tr.service.DownloadSnapshotService;
import gov.irs.jios.common.client.tr.service.OpenSessionService;
import gov.irs.jios.common.client.tr.service.OpenSnapshotService;
import gov.irs.jios.common.client.tr.service.PingTokenService;
import gov.irs.jios.common.client.tr.service.RetrieveFieldsService;
import gov.irs.jios.common.client.tr.service.SaveFieldsService;
import gov.irs.jios.common.exception.ConfigurationException;
import gov.irs.jios.common.exception.ValidationException;
import gov.irs.jios.common.util.CommonUtil;
import gov.irs.jios.common.util.JiosCommonConstants;
import gov.irs.jios.common.validation.GenericValidator;
import gov.irs.jios.request.SaveFieldsRequest;
import gov.irs.jios.response.OpenSnapshotResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@Tag(name = "Save Fields", description = "Save Fields Controller")
@RequestMapping("/jios-view-modify-save") //TODO /jios/api/v1.0 - should be property driven or if there is any other better way to handle versioning
public class ViewModifySaveController {
	
    private final GenericValidator validator;
    
    @Value("${tr.snapshot-download-url}")
    private String trSnapshotDownloadUrl;
    
    @Value("${tr.snapshot-open-url}")
    private String trSnapshotOpenUrl;
    
    @Value("${log.file.dir}")
    private String logFileDir;
    
    @Autowired
    private AuthLocatorService authLocatorService;
    
    @Autowired
    private PingTokenService pingTokenService;
    
    @Autowired
    private OpenSessionService openSessionService;
    
    @Autowired
    private SaveFieldsService saveFieldsService;
    
    @Autowired
    private RetrieveFieldsService retrieveFieldsService;
    
    @Autowired
    private OpenSnapshotService openSnapshotService;
    
    @Autowired
    private DownloadSnapshotService downloadSnapshotService;
    
    @Autowired
    private CloseLocatorService closeLocatorService;
    
    @Autowired
    private ObjectMapper objectMapper;
    
    @Value("${spring.profiles.active}")
	private String activeProfile;
    
    @Value("${should.make.tr.call:true}")
	private boolean shouldMakeTrCall;

    public ViewModifySaveController() {
        this.validator = new GenericValidator("validation-rules/save-fields-validation-rules.json");
    }
    
    private static final String LINE_SEPARATOR = System.lineSeparator();
    
    @PostMapping("/api/v1.0/saveFields")
    public ResponseEntity<?> saveFields(@RequestBody SaveFieldsRequest request) {
        try {
            if (request == null) {
                log.warn("Received null request");
                return ResponseEntity.badRequest().body("Request body is missing");
            }
            
            if (request.getHeader() == null) {
                log.warn("header object is missing in the request");
                return ResponseEntity.badRequest().body("Header object is missing in the request");
            }
            
            String transactionId = (String) request.getHeader().get("transactionId");
            if (transactionId != null) {
            	int lastIndex = transactionId.lastIndexOf("-");
            	if (lastIndex > 0) {
            		MDC.put("requestId", transactionId.substring(lastIndex + 1, transactionId.length()));
            	}
            }
            
            log.debug("Received Save Fields Request");
            log.info("Active Profile: {}", activeProfile);
            /*List<String> validationErrors = validator.validate(request);
            if (!validationErrors.isEmpty()) {
                log.warn("Validation errors: {}", validationErrors);
                return ResponseEntity.badRequest().body(validationErrors); //TODO - enable validation back after it is refactored for the latest ECM payload
            }*/
            
            String token = null, locatorId = null;
            Map<String, String> authTokenSessionToken = null;
            if (shouldMakeTrCall) {
	            token = "local".equals(activeProfile) || "sbx".equals(activeProfile) ? authLocatorService.getToken() : pingTokenService.getAccessToken();
	            log.info("token: {}", token);
	             
	            locatorId = authLocatorService.createLocator(request.getHeader(), token);
	            log.info("locatorId: {}", locatorId);
	            
	            authTokenSessionToken = openSessionService.openSession(request.getHeader(), token, locatorId);
	            log.info("authTokenSessionToken: {}", authTokenSessionToken);
            }

            // Log the ECM request payload
        	try {
                String requestJson = objectMapper.writeValueAsString(request);
                log.info("saveFields - Request JSON from ECM: {}{}", LINE_SEPARATOR, requestJson);
            } catch (JsonProcessingException e) {
            	log.error("Error converting ECM Varaince Request payload to JSON", e);
            }

            saveFieldsService.saveFields(request, token, authTokenSessionToken);
            // RetrieveFieldsResponseDTO response = retrieveFieldsService.retrieveFields(request, token, authTokenSessionToken);
            
            OpenSnapshotResponse response = new OpenSnapshotResponse();
            response.setHeader(request.getHeader());
            response.getHeader().put("locatorId", locatorId);
            response.setBody(new HashMap<String, Object> (authTokenSessionToken));
            log.info("Save Fields Completed Successfully");
            
            HttpHeaders headers = new HttpHeaders();         
            headers.setContentType(MediaType.APPLICATION_JSON);  
            return new ResponseEntity<>(objectMapper.writeValueAsString(response), headers, HttpStatus.OK);
        }
        catch (ValidationException e) {
            log.error("ValidationException occurred during Save Fields", e);
            HttpHeaders headers = new HttpHeaders();         
            headers.setContentType(MediaType.APPLICATION_JSON);       
            return new ResponseEntity<>(e.getMessage(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        catch (Exception e) {
            log.error("Exception occurred during Save Fields", e);
            HttpHeaders headers = new HttpHeaders();         
            headers.setContentType(MediaType.APPLICATION_JSON);       
            return new ResponseEntity<>("An unexpected error occurred: " + e.getMessage(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        finally {
            MDC.remove("requestId");
        }
    }
    
    @PostMapping(path = "/api/v1.0/openSnapshot", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    public ResponseEntity<?> openSnapshot(@RequestPart(value= "formData") SaveFieldsRequest request,
										   @RequestPart(value= "snapshot", required = false) MultipartFile file) {
        try {
            if (request == null) {
                log.warn("Received null request");
                return ResponseEntity.badRequest().body("Request body is missing");
            }
            
            if (request.getHeader() == null) {
                log.warn("header object is missing in the request");
                return ResponseEntity.badRequest().body("Header object is missing in the request");
            }
            
            String transactionId = (String) request.getHeader().get("transactionId");
            if (transactionId != null) {
            	int lastIndex = transactionId.lastIndexOf("-");
            	if (lastIndex > 0) {
            		MDC.put("requestId", transactionId.substring(lastIndex + 1, transactionId.length()));
            	}
            }
            
            log.debug("Received Open Snapshot Request");
            log.info("Active Profile: {}", activeProfile);
            
            String token = null, locatorId = null;
            Map<String, String> authTokenSessionToken = null;
            if (shouldMakeTrCall) {
	            token = "local".equals(activeProfile) || "sbx".equals(activeProfile) ? authLocatorService.getToken() : pingTokenService.getAccessToken();
	            log.info("token: {}", token);
	             
	            locatorId = ObjectUtils.isNotEmpty(request.getHeader().get("locatorId")) ? (String) request.getHeader().get("locatorId") : authLocatorService.createLocator(request.getHeader(), token);
	            log.info("locatorId: {}", locatorId);
	            
	            // Call Open session only if snapshot is not present
	            if (file == null) {
		            authTokenSessionToken = openSessionService.openSession(request.getHeader(), token, locatorId);
		            log.info("authTokenSessionToken from open session: {}", authTokenSessionToken);
	            }
            }

            // Log the ECM request payload
        	try {
                String requestJson = objectMapper.writeValueAsString(request);
                log.info("saveFields - Request JSON from ECM: {}{}", LINE_SEPARATOR, requestJson);
            } catch (JsonProcessingException e) {
            	log.error("Error converting ECM Varaince Request payload to JSON", e);
            }
        	
            if (file != null) {
            	
            	if(request.getHeader().get("locatorId") == null) {
            		throw new IllegalArgumentException("locatorId is missing in the header");
            	}
            	
            	String taxPrd = (String) request.getHeader().get(TAX_PERIOD);
                if (taxPrd == null) {
                    throw new IllegalArgumentException("taxPrd is missing in the header");
                }
                String taxYear;
                try {
                    taxYear = CommonUtil.extractTaxYear(taxPrd);
                } catch (IllegalArgumentException e) {
                    throw new ConfigurationException("Invalid tax period in header: " + e.getMessage());
                }
                
                //Open the snapshot in TR
                authTokenSessionToken = openSnapshotService.openSnapshot(token, taxYear, locatorId, file);
                log.info("authTokenSessionToken from open snapshot: {}", authTokenSessionToken);
	    	}

            saveFieldsService.saveFields(request, token, authTokenSessionToken);
            
            OpenSnapshotResponse response = new OpenSnapshotResponse();
            response.setHeader(request.getHeader());
            response.getHeader().put("locatorId", locatorId);
            response.setBody(new HashMap<String, Object> (authTokenSessionToken));

            log.info("Open Snapshot Completed Successfully");
            HttpHeaders headers = new HttpHeaders();         
            headers.setContentType(MediaType.APPLICATION_JSON);  
            return new ResponseEntity<>(objectMapper.writeValueAsString(response), headers, HttpStatus.OK);
        }
        catch (ValidationException e) {
            log.error("ValidationException occurred during Save Fields", e);
            HttpHeaders headers = new HttpHeaders();         
            headers.setContentType(MediaType.APPLICATION_JSON);       
            return new ResponseEntity<>(e.getMessage(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        catch (Exception e) {
            log.error("Exception occurred during Save Fields", e);
            HttpHeaders headers = new HttpHeaders();         
            headers.setContentType(MediaType.APPLICATION_JSON);       
            return new ResponseEntity<>("An unexpected error occurred: " + e.getMessage(), headers, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        finally {
            MDC.remove("requestId");
        }
    }
    
    @PostMapping("/api/v1.0/downloadSnapshot")
    public ResponseEntity<?> downloadSnapshot(@RequestBody SaveFieldsRequest request) {
    	
    	MultiValueMap<String, Object> multipartResponse = new LinkedMultiValueMap<String, Object>();
    	HttpHeaders jsonDataHeaders = new HttpHeaders();
    	jsonDataHeaders.setContentType(MediaType.APPLICATION_JSON);
    	
    	if (request == null) {
            log.warn("Received null request");
            return ResponseEntity.badRequest().body("Request body is missing");
        }
        
        if (request.getHeader() == null) {
            log.warn("header object is missing in the request");
            return ResponseEntity.badRequest().body("Header object is missing in the request");
        }
        
        String transactionId = (String) request.getHeader().get("transactionId");
        if (transactionId != null) {
        	int lastIndex = transactionId.lastIndexOf("-");
        	if (lastIndex > 0) {
        		MDC.put("requestId", transactionId.substring(lastIndex + 1, transactionId.length()));
        	}
        }
        log.debug("Received download Snapshot request");
        
        if (request.getHeader().get("locatorId") == null) {
            log.warn("locatorId is missing in the header");
            return ResponseEntity.badRequest().body("LocatorId is missing in the header");
        }
        
        if (ObjectUtils.isEmpty(request.getBody().get(JiosCommonConstants.AUTH_TOKEN)) ||
        		ObjectUtils.isEmpty(request.getBody().get(JiosCommonConstants.TAX_RETURN_SESSION_TOKEN))) {
            log.warn("AuthToken is missing in the body");
            return ResponseEntity.badRequest().body("AuthToken is missing in the body");
        }
        
    	byte[] bytes = null;
    	try {
            log.info("Active Profile: {}", activeProfile);
            
            String token = null, locatorId = null;
            Map<String, String> authTokenSessionToken = new HashMap<String, String>();
            if (shouldMakeTrCall) {
	            token = "local".equals(activeProfile) || "sbx".equals(activeProfile) ? authLocatorService.getToken() : pingTokenService.getAccessToken();
	            log.info("token: {}", token);
	             
	            locatorId = (String) request.getHeader().get("locatorId");
	            log.info("locatorId: {}", locatorId);
	            
	            authTokenSessionToken.put(JiosCommonConstants.AUTH_TOKEN, (String) request.getBody().get(JiosCommonConstants.AUTH_TOKEN));
	            authTokenSessionToken.put(JiosCommonConstants.TAX_RETURN_SESSION_TOKEN, (String) request.getBody().get(JiosCommonConstants.TAX_RETURN_SESSION_TOKEN));
            }

            // Log the ECM request payload
        	try {
                String requestJson = objectMapper.writeValueAsString(request);
                log.info("retrieveFields - Request JSON from ECM: {}{}", LINE_SEPARATOR, requestJson);
            } catch (JsonProcessingException e) {
            	log.error("Error converting ECM Varaince Request payload to JSON", e);
            }

        	ResponseEntity<byte[]> responseEntity = downloadSnapshotService.downloadSnapshot(token, authTokenSessionToken);
        	
            RetrieveFieldsResponseDTO response = retrieveFieldsService.retrieveFields(request, token, authTokenSessionToken);
            
    		// Close Locator after download Snapshot
    		closeLocatorService.closeLocator(token, authTokenSessionToken);
    		bytes = responseEntity.getBody();

    		// Get snapshot zip file name from TR response Header
    		String fileName = getFileName(responseEntity.getHeaders());
    		SaveFieldsRequest tempRequest = objectMapper.readValue(response.getJsonResponse(), SaveFieldsRequest.class);
    		tempRequest.getHeader().put("fileName", fileName);
    		
    		// Update response with new JSON that has fileName
    		response.setJsonResponse(objectMapper.writeValueAsString(tempRequest));
    		
    		// Download Snapshot from TR for local and sandbox
	    	if("local".equals(activeProfile) || "sbx".equals(activeProfile)) {
	    		try {
	    			writeToZipFile(bytes, locatorId);
	    		} catch(Exception e) {
	    			log.error("Exception occurred during Snapshot Write to zip file", e);
	    		}
	    	}
            log.info("Download Snapshot Completed Successfully");

	    	HttpHeaders contentHeaders = new HttpHeaders();
	    	contentHeaders.setContentType(MediaType.parseMediaType("application/zip"));
	    	multipartResponse.add("formData", new HttpEntity<>(response.getJsonResponse(), jsonDataHeaders));
	    	multipartResponse.add("snapshot", new HttpEntity<>(bytes, contentHeaders));
	    	
		} catch (Exception e) {
			log.error("Exception occurred during Snapshot Download", e);
			return new ResponseEntity<>("An unexpected error occurred: " + e.getMessage(), jsonDataHeaders, HttpStatus.INTERNAL_SERVER_ERROR);
		}
    	finally {
            MDC.remove("requestId");
        }
    	return ResponseEntity.status(HttpStatus.OK).contentType(MediaType.MULTIPART_FORM_DATA).body(multipartResponse);
    }
    
    private String getFileName(HttpHeaders httpHeaders) throws Exception {
        String contentDisposition = httpHeaders.getFirst("Content-Disposition");

        if (contentDisposition != null) {
            String[] parts = contentDisposition.split(";");
            for (String part : parts) {
                if (part.trim().startsWith("filename=")) {
                    String fileName = part.split("=")[1].trim();
                    log.info(" File name {}", fileName);
                    return fileName;
                }
            }
        }
        throw new Exception("FileName is missing from response header in Download Snapshot call");
    }
    
    private void writeToZipFile(byte[] bytes, String locatorId) throws IOException {
    	String filePath = logFileDir + File.separator + "A" + locatorId + "3.zip";
    	log.info("Download snapshot path " + filePath);
        FileOutputStream outputStream = new FileOutputStream(new File(filePath));
        outputStream.write(bytes);
        outputStream.close();
    }
    
}